"""
Real Estate Investment Analyzer - Client Format
Main application entry point
"""

import sys
import argparse
from datetime import datetime
import uuid

from config import validate_config, get_config_value
from state import InvestmentState
from workflows.investment_workflow import build_investment_workflow
from utils.logging_utils import setup_logging


def main():
    """Main application entry point"""
    # Setup logging
    log_file = get_config_value("LOG_FILE", "logs/investment_analysis.log")
    log_level = get_config_value("LOG_LEVEL", "INFO")
    setup_logging(log_level, log_file)

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Real Estate Investment Analyzer - Client Format Multi-Agent System"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Analyze command
    analyze_parser = subparsers.add_parser("analyze", help="Analyze property investment")
    analyze_parser.add_argument("property_id", help="Property ID")
    analyze_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run demo with sample property")
    demo_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    args = parser.parse_args()

    try:
        # Validate configuration
        validate_config()

        # Handle commands
        if args.command == "analyze":
            analyze_property(args.property_id, args.max_workers)
        elif args.command == "demo":
            run_demo(args.max_workers)
        else:
            # Interactive mode
            interactive_mode()

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


def analyze_property(property_id: str, max_workers: int = 5):
    """
    Run investment analysis for a property

    Args:
        property_id: Property identifier
        max_workers: Maximum parallel workers
    """
    print(f"\n{'='*70}")
    print(f"REAL ESTATE INVESTMENT ANALYZER - CLIENT FORMAT")
    print(f"{'='*70}")
    print(f"Property ID: {property_id}")
    print(f"Max Workers: {max_workers}")
    print(f"{'='*70}\n")

    # In a real system, this would fetch from property data API
    # For demo, we'll use sample data
    print("NOTE: Using demo property data. In production, would fetch from MLS/property API.")

    initial_state = create_demo_property_state(property_id)

    print(f"Analysis ID: {initial_state.analysis_id}")
    print(f"Starting workflow execution...\n")

    # Build and execute workflow
    workflow = build_investment_workflow(max_workers=max_workers)
    final_state = workflow.run(initial_state)

    # Display results
    display_results(final_state)


def create_demo_property_state(property_id: str) -> InvestmentState:
    """Create a demo property state with sample data"""
    analysis_id = f"INV-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"

    return InvestmentState(
        analysis_id=analysis_id,
        property_id=property_id,
        address="123 Maple Street",
        city="Austin",
        state="TX",
        zip_code="78701",
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        property_type="single_family",
        listing_price=425000,
        square_footage=1850,
        bedrooms=3,
        bathrooms=2.5,
        year_built=2010,
        lot_size=6500,
        location_data={
            "school_rating": "excellent",
            "crime_rating": "safe",
            "walkability_score": 75,
            "transit_score": 65,
            "amenities": ["public_transit", "shopping", "parks", "restaurants", "hospitals"],
            "commute_time_minutes": 25
        },
        comparable_properties=[
            {"price": 415000, "square_footage": 1800},
            {"price": 430000, "square_footage": 1900},
            {"price": 420000, "square_footage": 1850},
            {"price": 435000, "square_footage": 1950},
        ],
        historical_prices=[
            {"year": 2020, "median_price": 350000},
            {"year": 2021, "median_price": 365000},
            {"year": 2022, "median_price": 385000},
            {"year": 2023, "median_price": 405000},
            {"year": 2024, "median_price": 420000},
        ],
        market_data={
            "current_inventory": 85,
            "avg_days_on_market": 35,
            "price_reductions": 12.0
        },
        property_details={
            "overall_condition": "good",
            "component_conditions": {
                "roof": "good",
                "hvac": "excellent",
                "foundation": "excellent",
                "plumbing": "good",
                "electrical": "good",
                "kitchen": "excellent",
                "bathrooms": "good"
            },
            "recent_updates": ["kitchen remodel 2022", "new HVAC 2021", "fresh paint 2024"],
            "known_issues": [],
            "down_payment_percent": 20.0,
            "interest_rate": 7.0,
            "estimated_rent": 2800,
            "property_tax_annual": 6375,
            "insurance_annual": 1500,
            "hoa_monthly": 0,
            "maintenance_annual": 2500
        }
    )


def display_results(state: InvestmentState):
    """Display investment analysis results"""
    print(f"\n{'='*70}")
    print("INVESTMENT ANALYSIS COMPLETE")
    print(f"{'='*70}")
    print(f"Analysis ID: {state.analysis_id}")
    print(f"Property: {state.address}, {state.city}, {state.state}")
    print(f"Decision: {state.decision.upper()}")

    if state.is_good_investment:
        print(f"\n[RECOMMEND] {state.critical_reason}")
    else:
        print(f"\n[NOT RECOMMENDED] {state.critical_reason}")

    # Display metrics
    if state.decision_metrics:
        print(f"\n{'='*70}")
        print("INVESTMENT METRICS")
        print(f"{'='*70}")
        metrics = state.decision_metrics
        print(f"Overall Score:        {metrics.get('overall_investment_score', 0):.2f}/10.0")
        print(f"Location Score:       {metrics.get('location_score', 0):.2f}/10.0")
        print(f"Pricing Score:        {metrics.get('pricing_score', 0):.2f}/10.0")
        print(f"Market Score:         {metrics.get('market_score', 0):.2f}/10.0")
        print(f"Condition Score:      {metrics.get('condition_score', 0):.2f}/10.0")
        print(f"Annual ROI:           {metrics.get('annual_roi', 0):.1f}%")
        print(f"Monthly Cash Flow:    ${metrics.get('monthly_cash_flow', 0):,.0f}")
        print(f"Risk Score:           {metrics.get('risk_score', 0):.2f}/10.0")
        print(f"AI Recommendation:    {metrics.get('ai_recommendation', 'UNKNOWN')}")

    # Display report summary
    if state.investment_report:
        print(f"\n{'='*70}")
        print("INVESTMENT REPORT SUMMARY")
        print(f"{'='*70}")
        report = state.investment_report

        print(f"Recommendation: {report.get('recommendation', 'UNKNOWN')}")
        print(f"Priority: {report.get('priority', 'LOW')}")
        print(f"Risk Level: {report.get('risk_level', 'UNKNOWN')}")

        key_findings = report.get('key_findings', [])
        if key_findings:
            print(f"\nKey Findings:")
            for finding in key_findings[:5]:
                print(f"  - {finding}")

        action_items = report.get('action_items', [])
        if action_items:
            print(f"\nRecommended Actions:")
            for action in action_items[:5]:
                print(f"  - {action}")

    print(f"\n{'='*70}")
    print("Notification sent to configured recipient")
    print(f"{'='*70}\n")


def run_demo(max_workers: int = 5):
    """Run demo with sample property data"""
    print("\n" + "="*70)
    print("DEMO MODE - Real Estate Investment Analyzer")
    print("="*70)
    print("This will analyze a sample property in Austin, TX.")
    print("\nSample Property:")
    print("  - 3BR/2.5BA Single-Family Home")
    print("  - 1,850 sq ft, Built 2010")
    print("  - Asking Price: $425,000")
    print("  - Excellent location with recent updates")

    property_id = "DEMO-PROP-001"

    print(f"\nAnalyzing property: {property_id}\n")

    analyze_property(property_id, max_workers)


def interactive_mode():
    """Interactive mode for investment analysis"""
    print("\n" + "="*70)
    print("Real Estate Investment Analyzer - Client Format Multi-Agent System")
    print("="*70)
    print("\n1. Analyze Property (with Property ID)")
    print("2. Run Demo")
    print("0. Exit")

    choice = input("\nSelect option (0-2): ").strip()

    if choice == "0":
        print("Goodbye!")
        return

    elif choice == "1":
        property_id = input("Enter property ID: ").strip()
        max_workers_str = input("Enter max workers (default 5): ").strip()

        max_workers = int(max_workers_str) if max_workers_str else 5
        analyze_property(property_id, max_workers)

    elif choice == "2":
        max_workers_str = input("Enter max workers (default 5): ").strip()
        max_workers = int(max_workers_str) if max_workers_str else 5
        run_demo(max_workers)

    else:
        print("ERROR: Invalid choice")


if __name__ == "__main__":
    main()
