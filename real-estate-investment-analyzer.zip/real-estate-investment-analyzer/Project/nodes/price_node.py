from state import InvestmentState
from agents.price_agent import PriceAgent

agent = PriceAgent()

def price_node(state: InvestmentState) -> InvestmentState:
    state.price_analysis = agent.analyze(
        state.listing_price,
        state.square_footage,
        state.comparable_properties,
        property_type=state.property_type,
        bedrooms=state.bedrooms,
        bathrooms=state.bathrooms
    )
    return state
