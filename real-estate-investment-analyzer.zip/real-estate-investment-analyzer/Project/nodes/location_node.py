from state import InvestmentState
from agents.location_agent import LocationAgent

agent = LocationAgent()

def location_node(state: InvestmentState) -> InvestmentState:
    location_data = state.location_data or {}
    state.location_analysis = agent.analyze(
        state.address, state.city, state.state, state.zip_code,
        school_rating=location_data.get("school_rating", "average"),
        crime_rating=location_data.get("crime_rating", "moderate"),
        walkability_score=location_data.get("walkability_score", 50),
        transit_score=location_data.get("transit_score", 50),
        amenities=location_data.get("amenities", []),
        commute_time_minutes=location_data.get("commute_time_minutes", 30)
    )
    return state
