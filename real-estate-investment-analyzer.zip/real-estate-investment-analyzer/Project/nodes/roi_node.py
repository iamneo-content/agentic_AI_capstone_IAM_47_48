from state import InvestmentState
from agents.roi_agent import ROIAgent

agent = ROIAgent()

def roi_node(state: InvestmentState) -> InvestmentState:
    property_details = state.property_details or {}
    
    context = {
        "location_score": state.location_analysis.get("location_score", 0),
        "price_analysis": state.price_analysis,
        "market_trends": state.market_trends_analysis,
        "condition_score": state.property_condition_analysis.get("condition_score", 0),
        "address": state.address,
        "city": state.city,
        "state": state.state,
        "property_type": state.property_type
    }
    
    state.roi_analysis = agent.analyze(
        state.listing_price,
        down_payment_percent=property_details.get("down_payment_percent", 20.0),
        interest_rate=property_details.get("interest_rate", 7.0),
        estimated_rent=property_details.get("estimated_rent", 2500),
        property_tax_annual=property_details.get("property_tax_annual", 5000),
        insurance_annual=property_details.get("insurance_annual", 1200),
        context=context
    )
    return state
