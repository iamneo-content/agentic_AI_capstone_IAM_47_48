import logging
from typing import List
from datetime import datetime
from state import InvestmentState
from services.notification_service import NotificationService

logger = logging.getLogger("report_node")

def report_node(state: InvestmentState) -> InvestmentState:
    logger.info("Generating final investment report")
    
    # Build report
    report = {
        "analysis_id": state.analysis_id,
        "property_id": state.property_id,
        "address": state.address,
        "city": state.city,
        "state": state.state,
        "timestamp": state.timestamp,
        "decision": state.decision,
        "recommendation": state.decision.replace("_", " ").title(),
        "priority": state.investment_priority,
        "risk_level": state.risk_level,
        "is_good_investment": state.is_good_investment,
        "overall_score": state.decision_metrics.get("overall_investment_score", 0),
        "metrics": state.decision_metrics,
        "key_findings": _generate_key_findings(state),
        "action_items": _generate_action_items(state),
        "location_highlights": state.location_analysis.get("insights", []),
        "pricing_insights": state.price_analysis.get("insights", []),
        "market_insights": state.market_trends_analysis.get("insights", []),
        "roi_insights": state.roi_analysis.get("insights", []),
        "ai_recommendation": state.roi_analysis.get("ai_insights", {})
    }
    
    # Send notification
    try:
        notification_service = NotificationService()
        notification_service.send_investment_report(
            state.property_details,
            report,
            state.is_good_investment
        )
        logger.info("Investment report notification sent")
        state.notifications_sent.append({
            "type": "investment_report",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "sent"
        })
    except Exception as e:
        logger.error(f"Failed to send report notification: {e}")
        state.notifications_sent.append({
            "type": "investment_report",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "failed",
            "error": str(e)
        })
    
    logger.info("Report generation complete")
    
    state.investment_report = report
    state.updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    return state

def _generate_key_findings(state: InvestmentState) -> List[str]:
    findings = []
    
    if state.critical_reason:
        findings.append(state.critical_reason)
    
    # Location
    location_score = state.location_analysis.get("location_score", 0)
    location_tier = state.location_analysis.get("location_tier", "")
    if location_score > 0:
        findings.append(f"Location: {location_tier} ({location_score}/10)")
    
    # Pricing
    if state.price_analysis.get("is_undervalued"):
        findings.append(f"GREAT DEAL: Property undervalued by {abs(state.price_analysis.get('percent_difference', 0)):.1f}%")
    elif state.price_analysis.get("is_overvalued"):
        findings.append(f"OVERPRICED: Property overvalued by {state.price_analysis.get('percent_difference', 0):.1f}%")
    
    # Market
    market_temp = state.market_trends_analysis.get("market_temperature", "")
    if market_temp:
        findings.append(f"Market: {market_temp} with {state.market_trends_analysis.get('trend_direction', 'STABLE')} trend")
    
    # ROI
    annual_roi = state.roi_analysis.get("annualized_roi", 0)
    if annual_roi > 0:
        findings.append(f"Projected Annual ROI: {annual_roi:.1f}%")
    
    return findings

def _generate_action_items(state: InvestmentState) -> List[str]:
    actions = []
    decision = state.decision
    
    if decision == "strong_buy":
        actions.append("RECOMMEND: Make offer immediately - excellent investment")
        actions.append("Act quickly to secure property")
        actions.append("Consider offering at or near asking price")
    elif decision == "buy":
        actions.append("RECOMMEND: Make offer - solid investment opportunity")
        actions.append("Use pricing analysis for negotiation")
        actions.append("Complete full inspection before closing")
    elif decision == "consider":
        actions.append("CONSIDER: Acceptable investment with some concerns")
        actions.append("Negotiate aggressively on price")
        actions.append("Factor in all repair costs before deciding")
    else:
        actions.append("PASS: Look for better opportunities")
        actions.append(f"Reason: {state.critical_reason}")
    
    # Add specific recommendations
    if state.price_analysis.get("negotiation_recommendations"):
        actions.extend(state.price_analysis["negotiation_recommendations"][:2])
    
    if state.property_condition_analysis.get("recommendations"):
        actions.extend(state.property_condition_analysis["recommendations"][:2])
    
    return actions
