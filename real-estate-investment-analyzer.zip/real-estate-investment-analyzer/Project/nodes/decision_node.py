import logging
from state import InvestmentState
from config import get_config_value

logger = logging.getLogger("decision_node")

def decision_node(state: InvestmentState) -> InvestmentState:
    logger.info("Making investment decision based on analysis")
    
    # Get thresholds
    LOCATION_THRESHOLD = get_config_value("LOCATION_SCORE_THRESHOLD", 7.0)
    PRICE_FAIRNESS_THRESHOLD = get_config_value("PRICE_FAIRNESS_THRESHOLD", 0.85)
    MARKET_GROWTH_THRESHOLD = get_config_value("MARKET_GROWTH_THRESHOLD", 3.0)
    CONDITION_THRESHOLD = get_config_value("PROPERTY_CONDITION_THRESHOLD", 6.0)
    MIN_ROI_THRESHOLD = get_config_value("MIN_ROI_THRESHOLD", 8.0)
    MAX_RISK_SCORE = get_config_value("MAX_RISK_SCORE", 6.0)
    
    # Get metrics
    summary = state.coordination_summary
    overall_score = summary.get("overall_investment_score", 0)
    location_score = summary.get("location_score", 0)
    pricing_score = summary.get("pricing_score", 0)
    market_score = summary.get("market_score", 0)
    condition_score = summary.get("condition_score", 0)
    annual_roi = summary.get("annual_roi", 0)
    cash_flow = summary.get("cash_flow", 0)
    ai_recommendation = summary.get("ai_recommendation", "HOLD")
    
    # Calculate risk score
    risk_score = 10 - overall_score
    
    # Make decision
    decision = "hold"
    is_good_investment = False
    investment_priority = "LOW"
    risk_level = "HIGH" if risk_score > MAX_RISK_SCORE else "MODERATE" if risk_score > 4 else "LOW"
    critical_reason = ""
    
    # Strong buy criteria
    if (overall_score >= 8.0 and annual_roi >= MIN_ROI_THRESHOLD * 1.5 and 
        location_score >= LOCATION_THRESHOLD and cash_flow > 500):
        decision = "strong_buy"
        is_good_investment = True
        investment_priority = "HIGH"
        critical_reason = f"Excellent investment: Score {overall_score}/10, ROI {annual_roi}%"
        
    # Buy criteria
    elif (overall_score >= 7.0 and annual_roi >= MIN_ROI_THRESHOLD and 
          location_score >= LOCATION_THRESHOLD - 1):
        decision = "buy"
        is_good_investment = True
        investment_priority = "MEDIUM"
        critical_reason = f"Good investment opportunity: Score {overall_score}/10"
        
    # Consider criteria
    elif overall_score >= 6.0 and annual_roi >= MIN_ROI_THRESHOLD * 0.75:
        decision = "consider"
        is_good_investment = False
        investment_priority = "MEDIUM"
        critical_reason = f"Marginal investment: Score {overall_score}/10 - proceed with caution"
        
    # Pass criteria
    else:
        decision = "pass"
        is_good_investment = False
        investment_priority = "LOW"
        
        # Determine why we're passing
        if location_score < LOCATION_THRESHOLD:
            critical_reason = f"Poor location score: {location_score}/10"
        elif annual_roi < MIN_ROI_THRESHOLD:
            critical_reason = f"Insufficient ROI: {annual_roi}%"
        elif cash_flow < -500:
            critical_reason = f"Negative cash flow: ${cash_flow}/month"
        else:
            critical_reason = f"Below investment criteria: Score {overall_score}/10"
    
    logger.info(f"Decision: {decision.upper()}, Priority: {investment_priority}, Risk: {risk_level}")
    
    # Build decision metrics
    decision_metrics = {
        "overall_investment_score": overall_score,
        "location_score": location_score,
        "pricing_score": pricing_score,
        "market_score": market_score,
        "condition_score": condition_score,
        "annual_roi": annual_roi,
        "monthly_cash_flow": cash_flow,
        "risk_score": round(risk_score, 2),
        "ai_recommendation": ai_recommendation
    }
    
    state.decision = decision
    state.is_good_investment = is_good_investment
    state.investment_priority = investment_priority
    state.risk_level = risk_level
    state.critical_reason = critical_reason
    state.decision_metrics = decision_metrics
    
    return state
