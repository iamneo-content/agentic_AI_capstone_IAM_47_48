from state import InvestmentState
from agents.property_condition_agent import PropertyConditionAgent

agent = PropertyConditionAgent()

def property_condition_node(state: InvestmentState) -> InvestmentState:
    property_details = state.property_details or {}
    state.property_condition_analysis = agent.analyze(
        state.year_built,
        overall_condition=property_details.get("overall_condition", "good"),
        component_conditions=property_details.get("component_conditions", {}),
        recent_updates=property_details.get("recent_updates", []),
        known_issues=property_details.get("known_issues", [])
    )
    return state
