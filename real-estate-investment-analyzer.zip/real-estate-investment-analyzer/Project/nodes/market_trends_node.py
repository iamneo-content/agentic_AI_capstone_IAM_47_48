from state import InvestmentState
from agents.market_trends_agent import MarketTrendsAgent

agent = MarketTrendsAgent()

def market_trends_node(state: InvestmentState) -> InvestmentState:
    market_data = state.market_data or {}
    state.market_trends_analysis = agent.analyze(
        state.city,
        state.state,
        historical_prices=state.historical_prices,
        market_data=market_data,
        current_inventory=market_data.get("current_inventory", 100),
        avg_days_on_market=market_data.get("avg_days_on_market", 45),
        price_reductions=market_data.get("price_reductions", 15.0)
    )
    return state
