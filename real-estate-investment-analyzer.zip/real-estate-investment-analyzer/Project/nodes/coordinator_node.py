from state import InvestmentState
from agents.coordinator_agent import CoordinatorAgent

agent = CoordinatorAgent()

def coordinator_node(state: InvestmentState) -> InvestmentState:
    result = agent.analyze(
        state.location_analysis,
        state.price_analysis,
        state.market_trends_analysis,
        state.property_condition_analysis,
        state.roi_analysis
    )
    state.coordination_summary = result.get("coordination_summary", {})
    return state
