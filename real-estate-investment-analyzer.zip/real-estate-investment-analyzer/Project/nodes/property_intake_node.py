from state import InvestmentState
from agents.property_intake_agent import PropertyIntakeAgent

agent = PropertyIntakeAgent()

def property_intake_node(state: InvestmentState) -> InvestmentState:
    property_data = {
        "property_id": state.property_id,
        "address": state.address,
        "city": state.city,
        "state": state.state,
        "zip_code": state.zip_code,
        "property_type": state.property_type,
        "listing_price": state.listing_price,
        "square_footage": state.square_footage,
        "bedrooms": state.bedrooms,
        "bathrooms": state.bathrooms,
        "year_built": state.year_built,
        "lot_size": state.lot_size
    }
    
    intake_data = agent.analyze(state.property_id, property_data)
    state.property_details.update(intake_data)
    return state
