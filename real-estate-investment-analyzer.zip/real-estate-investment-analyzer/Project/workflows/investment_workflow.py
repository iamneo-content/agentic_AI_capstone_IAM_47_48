"""
Investment Workflow Builder

Defines the staged real estate investment analysis pipeline with parallel and sequential nodes.
"""

from graph import InvestmentGraph
from nodes import (
    property_intake_node,
    location_node,
    price_node,
    market_trends_node,
    property_condition_node,
    roi_node,
    coordinator_node,
    decision_node,
    report_node
)


def build_investment_workflow(max_workers: int = 5) -> InvestmentGraph:
    """
    Build the real estate investment workflow with parallel execution

    Stages:
    1. Property intake (collect and validate property data)
    2. Parallel analyses (location, price, market trends, condition, ROI)
    3. Coordinator (aggregate results)
    4. Decision (make investment decision)
    5. Report (generate final report and send notification)

    Args:
        max_workers: Maximum number of parallel workers (default: 5)

    Returns:
        Compiled InvestmentGraph ready for execution
    """
    stages = [
        # Stage 1: Property intake
        [property_intake_node],

        # Stage 2: Parallel analyses (all 5 run simultaneously)
        [location_node, price_node, market_trends_node, property_condition_node, roi_node],

        # Stage 3: Coordinator
        [coordinator_node],

        # Stage 4: Decision
        [decision_node],

        # Stage 5: Report
        [report_node]
    ]

    return InvestmentGraph(stages=stages, max_workers=max_workers, raise_on_error=False)
