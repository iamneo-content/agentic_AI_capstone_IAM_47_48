"""
Workflows - Workflow Definitions
All workflow definitions for real estate investment
"""

from .investment_workflow import build_investment_workflow

__all__ = ["build_investment_workflow"]
