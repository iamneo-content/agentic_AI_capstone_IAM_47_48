"""
Investment State - Shared State for Real Estate Investment Analysis Pipeline

Dataclass-based state management with clone and merge capabilities.
This is ONLY a data structure - NO business logic, NO orchestration logic.
"""

from dataclasses import dataclass, field, asdict, is_dataclass
from typing import List, Dict, Any, Optional
import copy


@dataclass
class InvestmentState:
    """
    Shared state for multi-agent real estate investment analysis pipeline

    This is a pure data structure with helper methods for state management.
    All business logic lives in agents/ and nodes/
    All orchestration logic lives in graph.py and workflows/
    """

    # Basic investment information
    analysis_id: str = ""
    property_id: str = ""
    address: str = ""
    timestamp: str = ""

    # Property details
    property_details: Dict[str, Any] = field(default_factory=dict)
    property_type: str = ""  # Single-family, Multi-family, Commercial, etc.
    listing_price: float = 0.0
    square_footage: int = 0
    bedrooms: int = 0
    bathrooms: float = 0.0
    year_built: int = 0
    lot_size: float = 0.0

    # Location data
    location_data: Dict[str, Any] = field(default_factory=dict)
    neighborhood: str = ""
    city: str = ""
    state: str = ""
    zip_code: str = ""

    # Market data
    comparable_properties: List[Dict[str, Any]] = field(default_factory=list)
    market_data: Dict[str, Any] = field(default_factory=dict)
    historical_prices: List[Dict[str, Any]] = field(default_factory=list)

    # Analysis results (populated by agents)
    location_analysis: Dict[str, Any] = field(default_factory=dict)
    price_analysis: Dict[str, Any] = field(default_factory=dict)
    market_trends_analysis: Dict[str, Any] = field(default_factory=dict)
    property_condition_analysis: Dict[str, Any] = field(default_factory=dict)
    roi_analysis: Dict[str, Any] = field(default_factory=dict)

    # Coordination data
    coordination_summary: Dict[str, Any] = field(default_factory=dict)

    # Decision results
    decision: str = ""
    is_good_investment: bool = False
    investment_priority: str = ""
    risk_level: str = ""
    critical_reason: str = ""
    decision_metrics: Dict[str, Any] = field(default_factory=dict)

    # Final investment report
    investment_report: Dict[str, Any] = field(default_factory=dict)

    # Workflow metadata
    notifications_sent: List[Dict[str, Any]] = field(default_factory=list)
    error: str = ""
    workflow_complete: bool = False
    updated_at: str = ""

    # Extra metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def clone(self) -> "InvestmentState":
        """
        Deep copy for safe parallel execution

        Returns:
            Deep copy of the current state
        """
        return copy.deepcopy(self)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert state to dictionary

        Returns:
            Dictionary representation of state
        """
        return asdict(self)

    def merge_from(self, other: Any, overwrite_scalars: bool = True) -> None:
        """
        Merge another InvestmentState or dict into this state

        Lists are extended, dicts are shallow merged, scalars are overwritten if allowed.

        Args:
            other: Another InvestmentState instance or dictionary to merge from
            overwrite_scalars: Whether to overwrite scalar values (default: True)
        """
        if other is None:
            return

        # Convert to dict if it's a dataclass
        if is_dataclass(other):
            other_dict = asdict(other)
        elif isinstance(other, dict):
            other_dict = other
        else:
            return

        for key, val in other_dict.items():
            if val is None:
                continue

            if not hasattr(self, key):
                # Store unknown keys in metadata
                self.metadata.setdefault("extra", {})[key] = val
                continue

            current = getattr(self, key)

            # Merge lists by extending
            if isinstance(current, list) and isinstance(val, list):
                current.extend(val)
                setattr(self, key, current)
                continue

            # Merge dicts by updating
            if isinstance(current, dict) and isinstance(val, dict):
                merged = current.copy()
                merged.update(val)
                setattr(self, key, merged)
                continue

            # Merge scalars by overwriting (if allowed and value is not empty)
            if overwrite_scalars and val not in (None, "", [], {}):
                setattr(self, key, val)
