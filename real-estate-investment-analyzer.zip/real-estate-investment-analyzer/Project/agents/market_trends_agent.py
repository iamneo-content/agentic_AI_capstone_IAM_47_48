from .base_agent import BaseAgent
from analyzers.market_trends_analyzer import MarketTrendsAnalyzer

class MarketTrendsAgent(BaseAgent):
    def __init__(self):
        super().__init__("market_trends")
        self.analyzer = MarketTrendsAnalyzer()
        self.log("Market trends agent initialized")
    
    def analyze(self, city, state, **kwargs):
        self.log(f"Analyzing market trends for {city}, {state}")
        return self.analyzer.analyze_trends(city, state, **kwargs)
