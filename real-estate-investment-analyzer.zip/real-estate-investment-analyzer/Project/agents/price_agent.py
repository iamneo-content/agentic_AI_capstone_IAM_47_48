from .base_agent import BaseAgent
from analyzers.price_analyzer import PriceAnalyzer

class PriceAgent(BaseAgent):
    def __init__(self):
        super().__init__("price")
        self.analyzer = PriceAnalyzer()
        self.log("Price agent initialized")
    
    def analyze(self, listing_price, square_footage, comparable_properties, **kwargs):
        self.log(f"Analyzing price: ${listing_price:,.0f}")
        return self.analyzer.analyze_price(listing_price, square_footage, comparable_properties, **kwargs)
