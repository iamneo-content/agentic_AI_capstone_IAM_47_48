from .base_agent import BaseAgent
from analyzers.property_condition_analyzer import PropertyConditionAnalyzer

class PropertyConditionAgent(BaseAgent):
    def __init__(self):
        super().__init__("property_condition")
        self.analyzer = PropertyConditionAnalyzer()
        self.log("Property condition agent initialized")
    
    def analyze(self, year_built, **kwargs):
        self.log(f"Analyzing property condition (built {year_built})")
        return self.analyzer.analyze_condition(year_built, **kwargs)
