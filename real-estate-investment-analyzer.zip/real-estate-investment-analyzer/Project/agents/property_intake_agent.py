from typing import Dict, Any
from .base_agent import BaseAgent

class PropertyIntakeAgent(BaseAgent):
    def __init__(self):
        super().__init__("property_intake")
        self.log("Property intake agent initialized")
    
    def analyze(self, property_id: str, property_data: Dict[str, Any]) -> Dict[str, Any]:
        self.log(f"Processing intake for property: {property_id}")
        return {
            "property_details": property_data,
            "property_id": property_id,
            "address": property_data.get("address", ""),
            "city": property_data.get("city", ""),
            "state": property_data.get("state", ""),
            "zip_code": property_data.get("zip_code", ""),
            "property_type": property_data.get("property_type", "single_family"),
            "listing_price": property_data.get("listing_price", 0),
            "square_footage": property_data.get("square_footage", 0),
            "bedrooms": property_data.get("bedrooms", 0),
            "bathrooms": property_data.get("bathrooms", 0),
            "year_built": property_data.get("year_built", 2000),
            "lot_size": property_data.get("lot_size", 0)
        }
