from .base_agent import BaseAgent
from analyzers.location_analyzer import LocationAnalyzer

class LocationAgent(BaseAgent):
    def __init__(self):
        super().__init__("location")
        self.analyzer = LocationAnalyzer()
        self.log("Location agent initialized")
    
    def analyze(self, address, city, state, zip_code, **kwargs):
        self.log(f"Analyzing location for {address}")
        return self.analyzer.analyze_location(address, city, state, zip_code, **kwargs)
