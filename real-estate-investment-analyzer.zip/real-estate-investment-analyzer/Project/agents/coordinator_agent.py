from typing import Dict, Any
from .base_agent import BaseAgent

class CoordinatorAgent(BaseAgent):
    def __init__(self):
        super().__init__("coordinator")
        self.log("Coordinator agent initialized")
    
    def analyze(self, location_analysis, price_analysis, market_trends_analysis, 
                condition_analysis, roi_analysis):
        self.log("Coordinating results from all analysis agents")
        
        location_score = location_analysis.get("location_score", 0)
        pricing_score = price_analysis.get("pricing_score", 0)
        market_score = market_trends_analysis.get("market_score", 0)
        condition_score = condition_analysis.get("condition_score", 0)
        roi_quality = roi_analysis.get("investment_quality", "")
        
        # Calculate overall investment score
        overall_score = (location_score * 0.25 + pricing_score * 0.25 + 
                        market_score * 0.20 + condition_score * 0.15 + 
                        self._roi_to_score(roi_quality) * 0.15)
        
        return {
            "coordination_summary": {
                "overall_investment_score": round(overall_score, 2),
                "location_score": location_score,
                "pricing_score": pricing_score,
                "market_score": market_score,
                "condition_score": condition_score,
                "roi_quality": roi_quality,
                "annual_roi": roi_analysis.get("annualized_roi", 0),
                "cash_flow": roi_analysis.get("monthly_cash_flow", 0),
                "ai_recommendation": roi_analysis.get("ai_insights", {}).get("overall_recommendation", "HOLD")
            }
        }
    
    def _roi_to_score(self, quality):
        scores = {"EXCELLENT": 10, "GOOD": 7, "FAIR": 5, "MARGINAL": 3, "POOR": 1}
        for key in scores:
            if key in quality:
                return scores[key]
        return 5
