from .base_agent import BaseAgent
from analyzers.roi_calculator import ROICalculator
from analyzers.gemini_client import GeminiClient

class ROIAgent(BaseAgent):
    def __init__(self):
        super().__init__("roi")
        self.calculator = ROICalculator()
        self.ai_client = GeminiClient()
        self.log("ROI agent initialized")
    
    def analyze(self, purchase_price, **kwargs):
        self.log(f"Calculating ROI for ${purchase_price:,.0f}")
        roi_data = self.calculator.calculate_roi(purchase_price, **kwargs)
        
        # Get AI insights if available
        context = kwargs.get("context", {})
        if context:
            ai_insights = self.ai_client.analyze_investment(
                kwargs.get("address", ""), kwargs.get("city", ""), kwargs.get("state", ""),
                kwargs.get("property_type", ""), purchase_price,
                context.get("location_score", 0), context.get("price_analysis", {}),
                context.get("market_trends", {}), context.get("condition_score", 0),
                roi_data, context
            )
            roi_data["ai_insights"] = ai_insights
        
        return roi_data
