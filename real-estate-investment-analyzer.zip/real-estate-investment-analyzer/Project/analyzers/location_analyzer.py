"""
Location Analyzer - Pure Tool
Analyzes property location quality and desirability
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("location_analyzer")


class LocationAnalyzer:
    """Pure location analysis tool - reusable across workflows"""

    def __init__(self):
        # Location scoring factors
        self.school_ratings = {
            "excellent": 10,
            "great": 8,
            "good": 6,
            "average": 4,
            "below_average": 2,
            "poor": 0
        }

        self.crime_ratings = {
            "very_safe": 10,
            "safe": 8,
            "moderate": 6,
            "concerning": 3,
            "high_crime": 0
        }

        # Neighborhood amenities scoring
        self.amenity_weights = {
            "public_transit": 1.5,
            "shopping": 1.0,
            "restaurants": 0.8,
            "parks": 1.2,
            "hospitals": 1.5,
            "gyms": 0.5,
            "libraries": 0.5
        }

    def analyze_location(
        self, address: str, city: str, state: str, zip_code: str,
        school_rating: str = "average", crime_rating: str = "moderate",
        walkability_score: int = 50, transit_score: int = 50,
        amenities: List[str] = None, commute_time_minutes: int = 30
    ) -> Dict[str, Any]:
        """
        Analyze property location

        Args:
            address: Property address
            city: City name
            state: State
            zip_code: ZIP code
            school_rating: School quality rating
            crime_rating: Crime safety rating
            walkability_score: Walk Score (0-100)
            transit_score: Transit Score (0-100)
            amenities: List of nearby amenities
            commute_time_minutes: Average commute time to city center

        Returns:
            Dictionary with location analysis data
        """
        if amenities is None:
            amenities = []

        # School score
        school_score = self.school_ratings.get(school_rating.lower(), 5)

        # Safety score
        safety_score = self.crime_ratings.get(crime_rating.lower(), 5)

        # Walkability normalized to 0-10
        walk_score = walkability_score / 10.0

        # Transit accessibility normalized to 0-10
        transit_accessibility = transit_score / 10.0

        # Amenities score
        amenities_score = self._calculate_amenities_score(amenities)

        # Commute score (inverse - shorter is better)
        commute_score = max(0, 10 - (commute_time_minutes / 6))

        # Calculate overall location score (weighted average)
        weights = {
            "schools": 0.25,
            "safety": 0.30,
            "walkability": 0.10,
            "transit": 0.10,
            "amenities": 0.15,
            "commute": 0.10
        }

        overall_score = (
            school_score * weights["schools"] +
            safety_score * weights["safety"] +
            walk_score * weights["walkability"] +
            transit_accessibility * weights["transit"] +
            amenities_score * weights["amenities"] +
            commute_score * weights["commute"]
        )

        # Determine location tier
        location_tier = self._get_location_tier(overall_score)

        # Generate insights
        insights = self._generate_location_insights(
            overall_score, school_score, safety_score, walk_score,
            transit_accessibility, amenities_score, commute_score
        )

        # Investment potential
        investment_potential = self._assess_investment_potential(
            overall_score, school_score, safety_score, amenities_score
        )

        return {
            "location_score": round(overall_score, 2),
            "location_tier": location_tier,
            "address": address,
            "city": city,
            "state": state,
            "zip_code": zip_code,
            "component_scores": {
                "schools": round(school_score, 2),
                "safety": round(safety_score, 2),
                "walkability": round(walk_score, 2),
                "transit": round(transit_accessibility, 2),
                "amenities": round(amenities_score, 2),
                "commute": round(commute_score, 2)
            },
            "amenities_nearby": amenities,
            "walkability_score": walkability_score,
            "transit_score": transit_score,
            "commute_time_minutes": commute_time_minutes,
            "insights": insights,
            "investment_potential": investment_potential
        }

    def _calculate_amenities_score(self, amenities: List[str]) -> float:
        """Calculate score based on nearby amenities"""
        if not amenities:
            return 0.0

        total_weight = 0.0
        for amenity in amenities:
            amenity_lower = amenity.lower()
            for key, weight in self.amenity_weights.items():
                if key in amenity_lower:
                    total_weight += weight
                    break

        # Normalize to 0-10 scale
        return min(total_weight / 2, 10.0)

    def _get_location_tier(self, score: float) -> str:
        """Determine location tier based on score"""
        if score >= 8.5:
            return "PRIME"
        elif score >= 7.0:
            return "EXCELLENT"
        elif score >= 5.5:
            return "GOOD"
        elif score >= 4.0:
            return "AVERAGE"
        else:
            return "BELOW_AVERAGE"

    def _generate_location_insights(
        self, overall: float, schools: float, safety: float,
        walk: float, transit: float, amenities: float, commute: float
    ) -> List[str]:
        """Generate location insights"""
        insights = []

        # Overall assessment
        if overall >= 8.0:
            insights.append("Excellent location with strong fundamentals")
        elif overall >= 6.0:
            insights.append("Good location with solid potential")
        else:
            insights.append("Location has some challenges to consider")

        # School quality
        if schools >= 8.0:
            insights.append("Top-rated schools - excellent for families")
        elif schools <= 4.0:
            insights.append("School quality below average - may limit buyer pool")

        # Safety
        if safety >= 8.0:
            insights.append("Very safe neighborhood")
        elif safety <= 4.0:
            insights.append("Safety concerns may impact property value")

        # Walkability & Transit
        if walk >= 7.0 or transit >= 7.0:
            insights.append("Great walkability/transit - appeals to urban professionals")

        # Amenities
        if amenities >= 7.0:
            insights.append("Excellent amenities nearby")

        # Commute
        if commute >= 7.0:
            insights.append("Convenient commute times")
        elif commute <= 4.0:
            insights.append("Long commute may be a drawback")

        return insights

    def _assess_investment_potential(
        self, overall_score: float, schools: float, safety: float, amenities: float
    ) -> str:
        """Assess investment potential based on location"""
        # Prime locations with schools and safety
        if overall_score >= 8.0 and schools >= 7.0 and safety >= 7.0:
            return "HIGH - Prime location likely to appreciate well"

        # Good locations
        elif overall_score >= 6.5:
            return "MODERATE_TO_HIGH - Solid location with good fundamentals"

        # Average locations
        elif overall_score >= 5.0:
            return "MODERATE - Decent location, standard appreciation expected"

        # Below average
        else:
            return "LOW - Location challenges may limit appreciation"
