"""
Gemini AI Client - Pure Tool
Interfaces with Google Gemini AI for real estate investment insights
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List, Optional
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("gemini_client")


class GeminiClient:
    """Pure Gemini AI client - reusable across workflows"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY", "")
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")

        if not api_key:
            logger.warning("Gemini API key not configured")
            self.model = None
        else:
            try:
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel(model_name)
                logger.info(f"Gemini client initialized with model: {model_name}")
            except Exception as e:
                logger.error(f"Failed to initialize Gemini: {e}")
                self.model = None

    def analyze_investment(
        self, address: str, city: str, state: str,
        property_type: str, listing_price: float,
        location_score: float, price_analysis: Dict[str, Any],
        market_trends: Dict[str, Any], condition_score: float,
        roi_metrics: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate AI-powered investment analysis

        Args:
            address: Property address
            city: City
            state: State
            property_type: Type of property
            listing_price: Listing price
            location_score: Location analysis score
            price_analysis: Price analysis results
            market_trends: Market trends analysis
            condition_score: Property condition score
            roi_metrics: ROI calculations
            context: Optional additional context

        Returns:
            Dictionary with AI investment analysis
        """
        if not self.model:
            return self._default_result("Gemini API not available")

        try:
            # Build prompt with investment data
            prompt = self._build_investment_prompt(
                address, city, state, property_type, listing_price,
                location_score, price_analysis, market_trends,
                condition_score, roi_metrics, context
            )

            # Generate analysis
            response = self.model.generate_content(prompt)

            # Parse response
            analysis_text = response.text if hasattr(response, 'text') else str(response)

            # Extract structured data from response
            analysis = self._parse_investment_response(analysis_text)

            return {
                'overall_recommendation': analysis.get('recommendation', 'HOLD'),
                'confidence': analysis.get('confidence', 0.7),
                'investment_strengths': analysis.get('strengths', []),
                'investment_concerns': analysis.get('concerns', []),
                'strategic_recommendations': analysis.get('strategies', []),
                'risk_factors': analysis.get('risks', []),
                'opportunity_assessment': analysis.get('opportunities', []),
                'market_positioning': analysis.get('positioning', 'MODERATE'),
                'raw_response': analysis_text[:1000]  # Limit size
            }

        except Exception as e:
            logger.error(f"Gemini investment analysis error: {e}")
            return self._default_result(str(e))

    def _build_investment_prompt(
        self, address: str, city: str, state: str, property_type: str,
        listing_price: float, location_score: float,
        price_analysis: Dict[str, Any], market_trends: Dict[str, Any],
        condition_score: float, roi_metrics: Dict[str, Any],
        context: Optional[Dict[str, Any]]
    ) -> str:
        """Build AI investment analysis prompt"""
        prompt = f"""You are an expert real estate investment analyst. Analyze the following investment opportunity and provide structured insights.

PROPERTY DETAILS:
- Address: {address}, {city}, {state}
- Type: {property_type}
- Listing Price: ${listing_price:,.0f}

ANALYSIS SCORES:
- Location Score: {location_score}/10
- Property Condition: {condition_score}/10
- Price Fairness: {price_analysis.get('pricing_score', 5)}/10

MARKET DATA:
- Market Temperature: {market_trends.get('market_temperature', 'BALANCED')}
- Annual Appreciation: {market_trends.get('annual_appreciation_rate', 0)}%
- Trend Direction: {market_trends.get('trend_direction', 'STABLE')}

PRICING ANALYSIS:
- Estimated Market Value: ${price_analysis.get('estimated_market_value', listing_price):,.0f}
- Price to Value Ratio: {price_analysis.get('price_to_value_ratio', 1.0):.2f}
- Pricing Assessment: {'UNDERVALUED' if price_analysis.get('is_undervalued') else 'FAIR' if price_analysis.get('is_fair_price') else 'OVERPRICED'}

FINANCIAL METRICS:
- Monthly Cash Flow: ${roi_metrics.get('monthly_cash_flow', 0):,.0f}
- Cash-on-Cash Return: {roi_metrics.get('cash_on_cash_return', 0):.1f}%
- Cap Rate: {roi_metrics.get('cap_rate', 0):.1f}%
- Annualized ROI: {roi_metrics.get('annualized_roi', 0):.1f}%
- Investment Quality: {roi_metrics.get('investment_quality', 'UNKNOWN')}
"""

        if context:
            prompt += f"\n\nADDITIONAL CONTEXT:\n"
            for key, value in context.items():
                prompt += f"- {key}: {value}\n"

        prompt += """
Please provide a comprehensive investment analysis with:

1. Overall Recommendation (BUY, STRONG_BUY, HOLD, or PASS)
2. Investment Strengths (2-5 key positive factors)
3. Investment Concerns (2-5 key risks or challenges)
4. Strategic Recommendations (specific action items)
5. Risk Factors (what could go wrong)
6. Opportunity Assessment (growth potential and upside)
7. Market Positioning (how this compares to market)

Format your response clearly with sections for each point.
"""

        return prompt

    def _parse_investment_response(self, response: str) -> Dict[str, Any]:
        """Parse AI response into structured data"""
        analysis = {
            'recommendation': 'HOLD',
            'confidence': 0.7,
            'strengths': [],
            'concerns': [],
            'strategies': [],
            'risks': [],
            'opportunities': [],
            'positioning': 'MODERATE'
        }

        # Extract recommendation
        response_upper = response.upper()
        if 'STRONG BUY' in response_upper or 'STRONG_BUY' in response_upper:
            analysis['recommendation'] = 'STRONG_BUY'
            analysis['confidence'] = 0.9
        elif 'BUY' in response_upper and 'PASS' not in response_upper[:100]:
            analysis['recommendation'] = 'BUY'
            analysis['confidence'] = 0.8
        elif 'PASS' in response_upper or 'AVOID' in response_upper:
            analysis['recommendation'] = 'PASS'
            analysis['confidence'] = 0.75
        else:
            analysis['recommendation'] = 'HOLD'
            analysis['confidence'] = 0.7

        # Extract sections
        lines = response.split('\n')
        current_section = None

        for line in lines:
            line = line.strip()
            if not line:
                continue

            line_lower = line.lower()

            # Detect section headers
            if 'strength' in line_lower or 'positive' in line_lower or 'pro' in line_lower:
                current_section = 'strengths'
            elif 'concern' in line_lower or 'risk' in line_lower or 'challenge' in line_lower:
                current_section = 'concerns'
            elif 'strateg' in line_lower or 'recommend' in line_lower or 'action' in line_lower:
                current_section = 'strategies'
            elif 'opportunit' in line_lower or 'upside' in line_lower or 'growth' in line_lower:
                current_section = 'opportunities'
            elif line.startswith('-') or line.startswith('*') or line[0:2].replace('.', '').isdigit():
                if current_section and current_section in analysis:
                    cleaned_line = line.lstrip('-*0123456789. ').strip()
                    if cleaned_line and len(cleaned_line) > 5:
                        analysis[current_section].append(cleaned_line)

        # Extract positioning
        if any(word in response_upper for word in ['COMPETITIVE', 'STRONG POSITION', 'EXCELLENT']):
            analysis['positioning'] = 'STRONG'
        elif any(word in response_upper for word in ['WEAK', 'POOR POSITION', 'BELOW MARKET']):
            analysis['positioning'] = 'WEAK'

        return analysis

    def _default_result(self, reason: str) -> Dict[str, Any]:
        """Return default result when AI analysis fails"""
        return {
            'overall_recommendation': 'HOLD',
            'confidence': 0.0,
            'investment_strengths': [],
            'investment_concerns': [f"AI analysis unavailable: {reason}"],
            'strategic_recommendations': ["Conduct thorough manual analysis"],
            'risk_factors': [],
            'opportunity_assessment': [],
            'market_positioning': 'UNKNOWN',
            'raw_response': f"Error: {reason}"
        }
