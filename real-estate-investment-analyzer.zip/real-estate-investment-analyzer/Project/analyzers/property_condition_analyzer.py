"""
Property Condition Analyzer - Pure Tool
Analyzes property physical condition and maintenance needs
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("property_condition_analyzer")


class PropertyConditionAnalyzer:
    """Pure property condition analysis tool - reusable across workflows"""

    def __init__(self):
        # Age depreciation factors
        self.age_scores = {
            (0, 5): 10,      # Brand new to 5 years
            (6, 15): 9,      # 6-15 years
            (16, 25): 7,     # 16-25 years
            (26, 40): 5,     # 26-40 years
            (41, 60): 3,     # 41-60 years
            (61, 999): 1     # Over 60 years
        }

        # Component condition ratings
        self.component_weights = {
            "roof": 1.5,
            "hvac": 1.3,
            "foundation": 1.8,
            "plumbing": 1.0,
            "electrical": 1.2,
            "windows": 0.8,
            "kitchen": 1.0,
            "bathrooms": 0.9,
            "flooring": 0.7,
            "exterior": 1.0
        }

    def analyze_condition(
        self, year_built: int, current_year: int = 2025,
        overall_condition: str = "good",
        component_conditions: Dict[str, str] = None,
        recent_updates: List[str] = None,
        known_issues: List[str] = None,
        inspection_date: str = None
    ) -> Dict[str, Any]:
        """
        Analyze property condition

        Args:
            year_built: Year property was built
            current_year: Current year
            overall_condition: Overall condition rating (excellent, good, fair, poor)
            component_conditions: Condition of specific components
            recent_updates: List of recent updates/renovations
            known_issues: List of known issues
            inspection_date: Date of last inspection

        Returns:
            Dictionary with property condition analysis
        """
        if component_conditions is None:
            component_conditions = {}
        if recent_updates is None:
            recent_updates = []
        if known_issues is None:
            known_issues = []

        # Calculate property age
        property_age = current_year - year_built

        # Age-based condition score
        age_score = self._get_age_score(property_age)

        # Overall condition score
        condition_scores = {
            "excellent": 10,
            "good": 7,
            "fair": 5,
            "poor": 2
        }
        base_condition_score = condition_scores.get(overall_condition.lower(), 5)

        # Component analysis
        component_analysis = self._analyze_components(component_conditions)

        # Calculate estimated repair costs
        repair_costs = self._estimate_repair_costs(
            component_conditions, known_issues, property_age
        )

        # Factor in recent updates
        update_bonus = len(recent_updates) * 0.5  # 0.5 points per update

        # Calculate overall condition score
        condition_score = (
            age_score * 0.3 +
            base_condition_score * 0.4 +
            component_analysis["avg_score"] * 0.3 +
            update_bonus
        )
        condition_score = min(condition_score, 10.0)

        # Determine condition tier
        condition_tier = self._get_condition_tier(condition_score)

        # Maintenance recommendations
        recommendations = self._generate_recommendations(
            property_age, component_conditions, known_issues, recent_updates
        )

        # Investment impact
        investment_impact = self._assess_investment_impact(
            condition_score, repair_costs["total_estimated"], property_age
        )

        return {
            "condition_score": round(condition_score, 2),
            "condition_tier": condition_tier,
            "property_age": property_age,
            "year_built": year_built,
            "overall_condition": overall_condition,
            "age_score": round(age_score, 2),
            "component_scores": component_analysis["scores"],
            "average_component_score": round(component_analysis["avg_score"], 2),
            "recent_updates": recent_updates,
            "known_issues": known_issues,
            "estimated_repair_costs": repair_costs,
            "recommendations": recommendations,
            "investment_impact": investment_impact,
            "inspection_current": inspection_date is not None
        }

    def _get_age_score(self, age: int) -> float:
        """Get condition score based on property age"""
        for (min_age, max_age), score in self.age_scores.items():
            if min_age <= age <= max_age:
                return float(score)
        return 1.0

    def _analyze_components(self, component_conditions: Dict[str, str]) -> Dict[str, Any]:
        """Analyze individual component conditions"""
        condition_scores = {
            "excellent": 10,
            "good": 7,
            "fair": 5,
            "poor": 2,
            "needs_replacement": 0
        }

        component_scores = {}
        weighted_sum = 0
        total_weight = 0

        for component, condition in component_conditions.items():
            score = condition_scores.get(condition.lower(), 5)
            component_scores[component] = score

            weight = self.component_weights.get(component, 1.0)
            weighted_sum += score * weight
            total_weight += weight

        avg_score = weighted_sum / total_weight if total_weight > 0 else 7.0

        return {
            "scores": component_scores,
            "avg_score": avg_score
        }

    def _estimate_repair_costs(
        self, component_conditions: Dict[str, str],
        known_issues: List[str], property_age: int
    ) -> Dict[str, Any]:
        """Estimate repair and maintenance costs"""
        # Base repair costs for components needing work
        repair_costs = {
            "roof": 15000,
            "hvac": 8000,
            "foundation": 25000,
            "plumbing": 5000,
            "electrical": 6000,
            "windows": 10000,
            "kitchen": 20000,
            "bathrooms": 12000,
            "flooring": 8000,
            "exterior": 7000
        }

        immediate_repairs = []
        near_term_maintenance = []
        total_immediate = 0
        total_near_term = 0

        # Check components needing repair
        for component, condition in component_conditions.items():
            cost = repair_costs.get(component, 5000)

            if condition.lower() in ["poor", "needs_replacement"]:
                immediate_repairs.append({
                    "item": component,
                    "condition": condition,
                    "estimated_cost": cost
                })
                total_immediate += cost

            elif condition.lower() == "fair":
                near_term_maintenance.append({
                    "item": component,
                    "condition": condition,
                    "estimated_cost": cost * 0.5  # Partial repair
                })
                total_near_term += cost * 0.5

        # Add known issues
        for issue in known_issues:
            issue_lower = issue.lower()
            estimated_cost = 3000  # Default

            if any(word in issue_lower for word in ["roof", "leak"]):
                estimated_cost = 8000
            elif any(word in issue_lower for word in ["foundation", "structural"]):
                estimated_cost = 15000
            elif any(word in issue_lower for word in ["hvac", "heating", "cooling"]):
                estimated_cost = 5000

            immediate_repairs.append({
                "item": issue,
                "condition": "issue",
                "estimated_cost": estimated_cost
            })
            total_immediate += estimated_cost

        # Age-based maintenance budget (annual)
        if property_age > 40:
            annual_maintenance = 3000
        elif property_age > 25:
            annual_maintenance = 2000
        elif property_age > 10:
            annual_maintenance = 1000
        else:
            annual_maintenance = 500

        return {
            "immediate_repairs": immediate_repairs,
            "near_term_maintenance": near_term_maintenance,
            "total_immediate": round(total_immediate, 2),
            "total_near_term": round(total_near_term, 2),
            "total_estimated": round(total_immediate + total_near_term, 2),
            "annual_maintenance_budget": annual_maintenance
        }

    def _get_condition_tier(self, score: float) -> str:
        """Determine condition tier"""
        if score >= 9.0:
            return "EXCELLENT"
        elif score >= 7.0:
            return "GOOD"
        elif score >= 5.0:
            return "FAIR"
        elif score >= 3.0:
            return "NEEDS_WORK"
        else:
            return "POOR"

    def _generate_recommendations(
        self, property_age: int, component_conditions: Dict[str, str],
        known_issues: List[str], recent_updates: List[str]
    ) -> List[str]:
        """Generate condition-based recommendations"""
        recommendations = []

        # Age-based recommendations
        if property_age > 50:
            recommendations.append("Older property - budget for higher maintenance costs")
            recommendations.append("Consider hiring specialist inspector for older homes")
        elif property_age > 30:
            recommendations.append("Mature property - expect some component replacements")

        # Component-specific recommendations
        critical_components = ["roof", "foundation", "hvac"]
        for comp in critical_components:
            if comp in component_conditions:
                condition = component_conditions[comp].lower()
                if condition in ["poor", "needs_replacement"]:
                    recommendations.append(f"CRITICAL: {comp.capitalize()} needs immediate attention")

        # Known issues
        if known_issues:
            recommendations.append(f"Address {len(known_issues)} known issue(s) before purchase")

        # Recent updates
        if len(recent_updates) > 3:
            recommendations.append("Well-maintained property with recent updates - good condition")
        elif len(recent_updates) == 0:
            recommendations.append("No recent updates - factor in renovation costs")

        if not recommendations:
            recommendations.append("Property in acceptable condition for its age")

        return recommendations

    def _assess_investment_impact(
        self, condition_score: float, total_repairs: float, property_age: int
    ) -> str:
        """Assess how condition impacts investment"""
        if condition_score >= 8.0 and total_repairs < 10000:
            return "POSITIVE - Excellent condition, minimal repairs needed"

        elif condition_score >= 6.0 and total_repairs < 25000:
            return "NEUTRAL - Good condition, manageable repairs"

        elif total_repairs > 50000:
            return "NEGATIVE - Significant repair costs will impact ROI"

        elif condition_score < 4.0:
            return "CONCERNING - Poor condition may deter future buyers"

        else:
            return "MODERATE - Some repairs needed but manageable"
