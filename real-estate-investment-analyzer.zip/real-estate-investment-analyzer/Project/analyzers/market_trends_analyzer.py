"""
Market Trends Analyzer - Pure Tool
Analyzes real estate market trends and appreciation potential
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List
import statistics

logger = logging.getLogger("market_trends_analyzer")


class MarketTrendsAnalyzer:
    """Pure market trends analysis tool - reusable across workflows"""

    def __init__(self):
        pass

    def analyze_trends(
        self, city: str, state: str,
        historical_prices: List[Dict[str, Any]] = None,
        market_data: Dict[str, Any] = None,
        current_inventory: int = 100,
        avg_days_on_market: int = 45,
        price_reductions: float = 15.0  # percentage of listings with price reductions
    ) -> Dict[str, Any]:
        """
        Analyze market trends

        Args:
            city: City name
            state: State
            historical_prices: List of historical price data points
            market_data: Additional market data
            current_inventory: Number of active listings
            avg_days_on_market: Average days properties stay on market
            price_reductions: Percentage of listings with price reductions

        Returns:
            Dictionary with market trends analysis
        """
        if historical_prices is None:
            historical_prices = []
        if market_data is None:
            market_data = {}

        # Calculate price appreciation
        appreciation_data = self._calculate_appreciation(historical_prices)

        # Analyze market temperature
        market_temp = self._analyze_market_temperature(
            avg_days_on_market, price_reductions, current_inventory
        )

        # Market trend direction
        trend_direction = self._determine_trend_direction(
            appreciation_data, avg_days_on_market
        )

        # Future growth forecast
        growth_forecast = self._forecast_growth(appreciation_data, market_temp)

        # Investment timing assessment
        timing_assessment = self._assess_timing(market_temp, trend_direction, appreciation_data)

        # Generate insights
        insights = self._generate_market_insights(
            market_temp, trend_direction, appreciation_data, avg_days_on_market
        )

        return {
            "market_location": f"{city}, {state}",
            "market_temperature": market_temp,
            "trend_direction": trend_direction,
            "annual_appreciation_rate": round(appreciation_data.get("annual_rate", 0), 2),
            "5_year_appreciation": round(appreciation_data.get("five_year_total", 0), 2),
            "avg_days_on_market": avg_days_on_market,
            "current_inventory": current_inventory,
            "price_reduction_rate": price_reductions,
            "growth_forecast": growth_forecast,
            "timing_assessment": timing_assessment,
            "insights": insights,
            "market_score": self._calculate_market_score(
                market_temp, appreciation_data.get("annual_rate", 0)
            )
        }

    def _calculate_appreciation(self, historical_prices: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate price appreciation rates"""
        if not historical_prices or len(historical_prices) < 2:
            return {"annual_rate": 3.0, "five_year_total": 15.0, "has_data": False}

        # Sort by year
        sorted_prices = sorted(historical_prices, key=lambda x: x.get("year", 0))

        # Calculate year-over-year changes
        yoy_changes = []
        for i in range(1, len(sorted_prices)):
            prev_price = sorted_prices[i-1].get("median_price", 0)
            curr_price = sorted_prices[i].get("median_price", 0)

            if prev_price > 0:
                change = ((curr_price - prev_price) / prev_price) * 100
                yoy_changes.append(change)

        # Calculate average annual appreciation
        annual_rate = statistics.mean(yoy_changes) if yoy_changes else 3.0

        # Calculate 5-year total appreciation
        if len(sorted_prices) >= 5:
            first_price = sorted_prices[0].get("median_price", 0)
            last_price = sorted_prices[-1].get("median_price", 0)
            if first_price > 0:
                five_year_total = ((last_price - first_price) / first_price) * 100
            else:
                five_year_total = annual_rate * 5
        else:
            five_year_total = annual_rate * 5

        return {
            "annual_rate": annual_rate,
            "five_year_total": five_year_total,
            "has_data": True,
            "data_points": len(historical_prices)
        }

    def _analyze_market_temperature(
        self, days_on_market: int, price_reductions: float, inventory: int
    ) -> str:
        """Determine market temperature (hot, warm, balanced, cool, cold)"""
        score = 0

        # Days on market factor
        if days_on_market < 30:
            score += 2
        elif days_on_market < 60:
            score += 1
        elif days_on_market > 90:
            score -= 1

        # Price reductions factor
        if price_reductions < 10:
            score += 2
        elif price_reductions < 20:
            score += 1
        elif price_reductions > 30:
            score -= 1

        # Inventory factor (higher inventory = cooler market)
        if inventory < 50:
            score += 1
        elif inventory > 150:
            score -= 1

        # Determine temperature
        if score >= 4:
            return "HOT"
        elif score >= 2:
            return "WARM"
        elif score >= 0:
            return "BALANCED"
        elif score >= -2:
            return "COOL"
        else:
            return "COLD"

    def _determine_trend_direction(
        self, appreciation_data: Dict[str, Any], days_on_market: int
    ) -> str:
        """Determine market trend direction"""
        annual_rate = appreciation_data.get("annual_rate", 0)

        if annual_rate > 5.0 and days_on_market < 45:
            return "STRONGLY_RISING"
        elif annual_rate > 3.0:
            return "RISING"
        elif annual_rate > 1.0:
            return "SLIGHTLY_RISING"
        elif annual_rate > -1.0:
            return "STABLE"
        elif annual_rate > -3.0:
            return "SLIGHTLY_DECLINING"
        else:
            return "DECLINING"

    def _forecast_growth(
        self, appreciation_data: Dict[str, Any], market_temp: str
    ) -> Dict[str, Any]:
        """Forecast future growth"""
        annual_rate = appreciation_data.get("annual_rate", 3.0)

        # Adjust forecast based on market temperature
        if market_temp in ["HOT", "WARM"]:
            forecast_rate = annual_rate * 0.9  # Slight moderation expected
        elif market_temp == "BALANCED":
            forecast_rate = annual_rate
        else:  # COOL or COLD
            forecast_rate = max(annual_rate * 0.7, 1.0)  # Potential slowdown

        return {
            "1_year_forecast": round(forecast_rate, 2),
            "3_year_forecast": round(forecast_rate * 3, 2),
            "5_year_forecast": round(forecast_rate * 5, 2),
            "confidence": "MODERATE" if appreciation_data.get("has_data") else "LOW"
        }

    def _assess_timing(
        self, market_temp: str, trend_direction: str,
        appreciation_data: Dict[str, Any]
    ) -> str:
        """Assess investment timing"""
        annual_rate = appreciation_data.get("annual_rate", 0)

        # Hot market with strong appreciation
        if market_temp == "HOT" and annual_rate > 6.0:
            return "CAUTION - Market may be overheated, consider waiting for correction"

        # Warm/balanced market with good appreciation
        elif market_temp in ["WARM", "BALANCED"] and annual_rate >= 3.0:
            return "GOOD - Healthy market with solid fundamentals"

        # Cool market with stable/positive growth
        elif market_temp == "COOL" and annual_rate >= 0:
            return "EXCELLENT - Buyer's market with room for appreciation"

        # Cold market or declining
        elif market_temp == "COLD" or annual_rate < 0:
            return "PROCEED WITH CAUTION - Market challenges present"

        else:
            return "FAIR - Market conditions are reasonable for investment"

    def _calculate_market_score(self, market_temp: str, annual_rate: float) -> float:
        """Calculate overall market score (0-10)"""
        score = 5.0  # Base score

        # Temperature adjustment
        temp_scores = {
            "HOT": 1.0,  # Hot can be risky
            "WARM": 2.5,
            "BALANCED": 2.0,
            "COOL": 1.5,
            "COLD": 0.0
        }
        score += temp_scores.get(market_temp, 0)

        # Appreciation adjustment
        if annual_rate >= 5.0:
            score += 3.0
        elif annual_rate >= 3.0:
            score += 2.0
        elif annual_rate >= 1.0:
            score += 1.0
        elif annual_rate < 0:
            score -= 2.0

        return min(max(score, 0), 10)

    def _generate_market_insights(
        self, market_temp: str, trend_direction: str,
        appreciation_data: Dict[str, Any], days_on_market: int
    ) -> List[str]:
        """Generate market insights"""
        insights = []

        annual_rate = appreciation_data.get("annual_rate", 0)

        # Market temperature insights
        if market_temp == "HOT":
            insights.append("HOT market - high demand, low inventory, properties selling quickly")
        elif market_temp == "WARM":
            insights.append("WARM market - healthy buyer activity and steady appreciation")
        elif market_temp == "BALANCED":
            insights.append("BALANCED market - stable conditions favorable for both buyers and sellers")
        elif market_temp == "COOL":
            insights.append("COOL market - more negotiating power for buyers")
        else:
            insights.append("COLD market - weak demand may present opportunities")

        # Appreciation insights
        if annual_rate >= 5.0:
            insights.append(f"Strong appreciation of {annual_rate:.1f}% annually")
        elif annual_rate >= 3.0:
            insights.append(f"Solid appreciation of {annual_rate:.1f}% annually")
        elif annual_rate >= 0:
            insights.append(f"Modest appreciation of {annual_rate:.1f}% annually")
        else:
            insights.append(f"Market depreciation of {abs(annual_rate):.1f}% annually - concerning")

        # Days on market
        if days_on_market < 30:
            insights.append("Properties selling very quickly - act fast on good opportunities")
        elif days_on_market > 90:
            insights.append("Properties staying on market longer - more time to negotiate")

        return insights
