"""
ROI Calculator - Pure Tool
Calculates return on investment metrics for real estate
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any

logger = logging.getLogger("roi_calculator")


class ROICalculator:
    """Pure ROI calculation tool - reusable across workflows"""

    def __init__(self):
        pass

    def calculate_roi(
        self, purchase_price: float, down_payment_percent: float = 20.0,
        interest_rate: float = 7.0, loan_term_years: int = 30,
        estimated_rent: float = 2500, property_tax_annual: float = 5000,
        insurance_annual: float = 1200, hoa_monthly: float = 0,
        maintenance_annual: float = 2000, vacancy_rate: float = 5.0,
        property_management_percent: float = 10.0,
        estimated_appreciation: float = 3.0,
        holding_period_years: int = 5
    ) -> Dict[str, Any]:
        """
        Calculate comprehensive ROI metrics

        Args:
            purchase_price: Property purchase price
            down_payment_percent: Down payment percentage
            interest_rate: Mortgage interest rate (annual %)
            loan_term_years: Loan term in years
            estimated_rent: Monthly rental income
            property_tax_annual: Annual property tax
            insurance_annual: Annual insurance
            hoa_monthly: Monthly HOA fees
            maintenance_annual: Annual maintenance costs
            vacancy_rate: Vacancy rate percentage
            property_management_percent: Property management fee percentage
            estimated_appreciation: Annual appreciation rate
            holding_period_years: Investment holding period

        Returns:
            Dictionary with ROI calculations
        """
        # Calculate down payment and loan amount
        down_payment = purchase_price * (down_payment_percent / 100)
        loan_amount = purchase_price - down_payment

        # Calculate monthly mortgage payment
        monthly_rate = (interest_rate / 100) / 12
        num_payments = loan_term_years * 12

        if monthly_rate > 0:
            monthly_mortgage = loan_amount * (monthly_rate * (1 + monthly_rate) ** num_payments) / \
                             ((1 + monthly_rate) ** num_payments - 1)
        else:
            monthly_mortgage = loan_amount / num_payments

        # Monthly operating expenses
        monthly_property_tax = property_tax_annual / 12
        monthly_insurance = insurance_annual / 12
        monthly_maintenance = maintenance_annual / 12

        # Gross monthly rental income
        gross_monthly_income = estimated_rent

        # Adjustments for vacancy and management
        vacancy_loss = gross_monthly_income * (vacancy_rate / 100)
        management_fee = gross_monthly_income * (property_management_percent / 100)

        # Net monthly rental income
        net_monthly_income = gross_monthly_income - vacancy_loss - management_fee

        # Total monthly expenses
        total_monthly_expenses = (
            monthly_mortgage + monthly_property_tax + monthly_insurance +
            hoa_monthly + monthly_maintenance
        )

        # Monthly cash flow
        monthly_cash_flow = net_monthly_income - total_monthly_expenses
        annual_cash_flow = monthly_cash_flow * 12

        # Cash-on-cash return (annual cash flow / initial investment)
        closing_costs = purchase_price * 0.03  # Estimate 3% closing costs
        total_initial_investment = down_payment + closing_costs
        cash_on_cash_return = (annual_cash_flow / total_initial_investment * 100) if total_initial_investment > 0 else 0

        # Calculate cap rate (NOI / purchase price)
        noi = (net_monthly_income * 12) - (property_tax_annual + insurance_annual + maintenance_annual + hoa_monthly * 12)
        cap_rate = (noi / purchase_price * 100) if purchase_price > 0 else 0

        # Calculate equity build-up over holding period
        equity_buildup = self._calculate_equity_buildup(
            loan_amount, monthly_rate, num_payments, holding_period_years
        )

        # Calculate appreciation over holding period
        future_value = purchase_price * ((1 + estimated_appreciation / 100) ** holding_period_years)
        appreciation_gain = future_value - purchase_price

        # Total return over holding period
        total_cash_flow_period = annual_cash_flow * holding_period_years
        total_return = appreciation_gain + total_cash_flow_period + equity_buildup

        # ROI over holding period
        roi_percent = (total_return / total_initial_investment * 100) if total_initial_investment > 0 else 0
        annualized_roi = roi_percent / holding_period_years

        # Generate investment insights
        insights = self._generate_roi_insights(
            monthly_cash_flow, cash_on_cash_return, cap_rate,
            annualized_roi, appreciation_gain
        )

        # Assess investment quality
        investment_quality = self._assess_investment_quality(
            cash_on_cash_return, cap_rate, annualized_roi
        )

        return {
            "purchase_price": purchase_price,
            "total_initial_investment": round(total_initial_investment, 2),
            "down_payment": round(down_payment, 2),
            "loan_amount": round(loan_amount, 2),
            "monthly_mortgage": round(monthly_mortgage, 2),
            "monthly_cash_flow": round(monthly_cash_flow, 2),
            "annual_cash_flow": round(annual_cash_flow, 2),
            "cash_on_cash_return": round(cash_on_cash_return, 2),
            "cap_rate": round(cap_rate, 2),
            "noi": round(noi, 2),
            "holding_period_years": holding_period_years,
            "equity_buildup": round(equity_buildup, 2),
            "appreciation_gain": round(appreciation_gain, 2),
            "total_return": round(total_return, 2),
            "roi_percent": round(roi_percent, 2),
            "annualized_roi": round(annualized_roi, 2),
            "future_value": round(future_value, 2),
            "insights": insights,
            "investment_quality": investment_quality,
            "break_even_years": self._calculate_break_even(
                total_initial_investment, annual_cash_flow
            )
        }

    def _calculate_equity_buildup(
        self, loan_amount: float, monthly_rate: float,
        num_payments: int, years: int
    ) -> float:
        """Calculate principal paid down over holding period"""
        if monthly_rate == 0:
            return (loan_amount / num_payments) * (years * 12)

        months = years * 12
        equity = 0

        # Calculate monthly payment
        monthly_payment = loan_amount * (monthly_rate * (1 + monthly_rate) ** num_payments) / \
                         ((1 + monthly_rate) ** num_payments - 1)

        # Calculate remaining balance after holding period
        remaining_balance = loan_amount * ((1 + monthly_rate) ** num_payments - (1 + monthly_rate) ** months) / \
                          ((1 + monthly_rate) ** num_payments - 1)

        equity = loan_amount - remaining_balance
        return equity

    def _calculate_break_even(self, initial_investment: float, annual_cash_flow: float) -> float:
        """Calculate break-even point in years"""
        if annual_cash_flow <= 0:
            return 999  # Never breaks even with negative cash flow

        return initial_investment / annual_cash_flow if annual_cash_flow > 0 else 999

    def _generate_roi_insights(
        self, monthly_cash_flow: float, cash_on_cash: float,
        cap_rate: float, annualized_roi: float, appreciation: float
    ) -> list[str]:
        """Generate ROI insights"""
        insights = []

        # Cash flow insights
        if monthly_cash_flow > 500:
            insights.append(f"Excellent cash flow: ${monthly_cash_flow:,.0f}/month")
        elif monthly_cash_flow > 0:
            insights.append(f"Positive cash flow: ${monthly_cash_flow:,.0f}/month")
        elif monthly_cash_flow > -200:
            insights.append(f"Slight negative cash flow: ${monthly_cash_flow:,.0f}/month - manageable")
        else:
            insights.append(f"Negative cash flow: ${monthly_cash_flow:,.0f}/month - concerning")

        # Cash-on-cash return
        if cash_on_cash >= 10:
            insights.append(f"Strong cash-on-cash return: {cash_on_cash:.1f}%")
        elif cash_on_cash >= 6:
            insights.append(f"Solid cash-on-cash return: {cash_on_cash:.1f}%")
        elif cash_on_cash >= 0:
            insights.append(f"Modest cash-on-cash return: {cash_on_cash:.1f}%")
        else:
            insights.append(f"Negative cash-on-cash return: {cash_on_cash:.1f}%")

        # Cap rate
        if cap_rate >= 8:
            insights.append(f"Excellent cap rate: {cap_rate:.1f}%")
        elif cap_rate >= 5:
            insights.append(f"Good cap rate: {cap_rate:.1f}%")
        elif cap_rate >= 3:
            insights.append(f"Fair cap rate: {cap_rate:.1f}%")

        # Annualized ROI
        if annualized_roi >= 15:
            insights.append(f"Outstanding annualized ROI: {annualized_roi:.1f}%")
        elif annualized_roi >= 10:
            insights.append(f"Strong annualized ROI: {annualized_roi:.1f}%")
        elif annualized_roi >= 6:
            insights.append(f"Solid annualized ROI: {annualized_roi:.1f}%")

        # Appreciation
        if appreciation > 50000:
            insights.append(f"Significant appreciation potential: ${appreciation:,.0f}")

        return insights

    def _assess_investment_quality(
        self, cash_on_cash: float, cap_rate: float, annualized_roi: float
    ) -> str:
        """Assess overall investment quality"""
        score = 0

        # Cash-on-cash scoring
        if cash_on_cash >= 10:
            score += 3
        elif cash_on_cash >= 6:
            score += 2
        elif cash_on_cash >= 3:
            score += 1

        # Cap rate scoring
        if cap_rate >= 8:
            score += 3
        elif cap_rate >= 5:
            score += 2
        elif cap_rate >= 3:
            score += 1

        # Annualized ROI scoring
        if annualized_roi >= 15:
            score += 4
        elif annualized_roi >= 10:
            score += 3
        elif annualized_roi >= 8:
            score += 2
        elif annualized_roi >= 5:
            score += 1

        # Determine quality
        if score >= 8:
            return "EXCELLENT - Outstanding investment metrics"
        elif score >= 6:
            return "GOOD - Strong investment potential"
        elif score >= 4:
            return "FAIR - Acceptable investment"
        elif score >= 2:
            return "MARGINAL - Below average returns"
        else:
            return "POOR - Weak investment metrics"
