"""
Price Analyzer - Pure Tool
Analyzes property pricing relative to market value
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List
import statistics

logger = logging.getLogger("price_analyzer")


class PriceAnalyzer:
    """Pure price analysis tool - reusable across workflows"""

    def __init__(self):
        pass

    def analyze_price(
        self, listing_price: float, square_footage: int,
        comparable_properties: List[Dict[str, Any]],
        property_type: str = "single_family",
        bedrooms: int = 3, bathrooms: float = 2.0
    ) -> Dict[str, Any]:
        """
        Analyze property price relative to market

        Args:
            listing_price: Listed price of property
            square_footage: Property square footage
            comparable_properties: List of comparable properties
            property_type: Type of property
            bedrooms: Number of bedrooms
            bathrooms: Number of bathrooms

        Returns:
            Dictionary with price analysis data
        """
        if not comparable_properties:
            return self._default_analysis(listing_price, square_footage)

        # Calculate price per square foot
        price_per_sqft = listing_price / square_footage if square_footage > 0 else 0

        # Analyze comparables
        comp_analysis = self._analyze_comparables(comparable_properties)

        # Calculate market value estimate
        market_value = self._estimate_market_value(
            square_footage, comp_analysis, bedrooms, bathrooms
        )

        # Price to value ratio
        price_to_value = listing_price / market_value if market_value > 0 else 1.0

        # Determine if price is fair
        is_fair_price = 0.85 <= price_to_value <= 1.15
        is_undervalued = price_to_value < 0.90
        is_overvalued = price_to_value > 1.10

        # Calculate potential savings/overpayment
        difference = listing_price - market_value
        percent_difference = (difference / market_value * 100) if market_value > 0 else 0

        # Generate insights
        insights = self._generate_price_insights(
            price_to_value, percent_difference, is_undervalued,
            is_overvalued, comp_analysis
        )

        # Negotiation recommendations
        negotiation_recs = self._generate_negotiation_recommendations(
            price_to_value, percent_difference, comp_analysis
        )

        return {
            "listing_price": listing_price,
            "estimated_market_value": round(market_value, 2),
            "price_per_sqft": round(price_per_sqft, 2),
            "market_price_per_sqft": round(comp_analysis.get("avg_price_per_sqft", 0), 2),
            "price_to_value_ratio": round(price_to_value, 3),
            "is_fair_price": is_fair_price,
            "is_undervalued": is_undervalued,
            "is_overvalued": is_overvalued,
            "price_difference": round(difference, 2),
            "percent_difference": round(percent_difference, 2),
            "comparable_count": len(comparable_properties),
            "insights": insights,
            "negotiation_recommendations": negotiation_recs,
            "pricing_score": self._calculate_pricing_score(price_to_value)
        }

    def _analyze_comparables(self, comparables: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze comparable properties"""
        if not comparables:
            return {"avg_price": 0, "avg_price_per_sqft": 0, "price_range": (0, 0)}

        prices = []
        prices_per_sqft = []

        for comp in comparables:
            price = comp.get("price", 0)
            sqft = comp.get("square_footage", 0)

            if price > 0:
                prices.append(price)

            if price > 0 and sqft > 0:
                prices_per_sqft.append(price / sqft)

        return {
            "avg_price": statistics.mean(prices) if prices else 0,
            "median_price": statistics.median(prices) if prices else 0,
            "avg_price_per_sqft": statistics.mean(prices_per_sqft) if prices_per_sqft else 0,
            "median_price_per_sqft": statistics.median(prices_per_sqft) if prices_per_sqft else 0,
            "price_range": (min(prices), max(prices)) if prices else (0, 0),
            "price_std_dev": statistics.stdev(prices) if len(prices) > 1 else 0
        }

    def _estimate_market_value(
        self, square_footage: int, comp_analysis: Dict[str, Any],
        bedrooms: int, bathrooms: float
    ) -> float:
        """Estimate market value based on comparables"""
        # Use average price per sqft from comparables
        base_value = square_footage * comp_analysis.get("avg_price_per_sqft", 0)

        # Adjust for bedrooms/bathrooms (simplified)
        bedroom_adjustment = (bedrooms - 3) * 5000  # $5k per bedroom vs 3br baseline
        bathroom_adjustment = (bathrooms - 2.0) * 3000  # $3k per bathroom vs 2ba baseline

        market_value = base_value + bedroom_adjustment + bathroom_adjustment

        return max(market_value, 0)

    def _calculate_pricing_score(self, price_to_value: float) -> float:
        """Calculate pricing score (0-10, higher is better for buyer)"""
        # Lower price to value ratio = better deal = higher score
        if price_to_value <= 0.85:
            return 10.0
        elif price_to_value <= 0.90:
            return 9.0
        elif price_to_value <= 0.95:
            return 8.0
        elif price_to_value <= 1.0:
            return 7.0
        elif price_to_value <= 1.05:
            return 6.0
        elif price_to_value <= 1.10:
            return 5.0
        elif price_to_value <= 1.15:
            return 4.0
        elif price_to_value <= 1.20:
            return 3.0
        else:
            return max(0, 3.0 - (price_to_value - 1.20) * 5)

    def _generate_price_insights(
        self, price_to_value: float, percent_diff: float,
        is_undervalued: bool, is_overvalued: bool,
        comp_analysis: Dict[str, Any]
    ) -> List[str]:
        """Generate price insights"""
        insights = []

        # Overall pricing assessment
        if is_undervalued:
            insights.append(f"EXCELLENT DEAL: Property priced {abs(percent_diff):.1f}% below market value")
        elif is_overvalued:
            insights.append(f"OVERPRICED: Property priced {percent_diff:.1f}% above market value")
        else:
            insights.append("Property priced fairly relative to market")

        # Price per sqft comparison
        if price_to_value < 0.95:
            insights.append("Price per sqft is below market average - good value")
        elif price_to_value > 1.05:
            insights.append("Price per sqft is above market average")

        # Market variation
        price_std = comp_analysis.get("price_std_dev", 0)
        if price_std > 50000:
            insights.append("High price variation in comparable properties")

        # Comparable count
        comp_count = len(insights)
        if comp_count < 3:
            insights.append("Limited comparable data - pricing estimate has higher uncertainty")

        return insights

    def _generate_negotiation_recommendations(
        self, price_to_value: float, percent_diff: float,
        comp_analysis: Dict[str, Any]
    ) -> List[str]:
        """Generate negotiation recommendations"""
        recommendations = []

        if price_to_value <= 0.90:
            recommendations.append("Strong position - property is already well-priced")
            recommendations.append("Consider offering at or near asking price to secure the deal")

        elif price_to_value <= 1.0:
            recommendations.append("Fair pricing - minimal negotiation room")
            recommendations.append("Offer 2-3% below asking as a starting point")

        elif price_to_value <= 1.10:
            recommendations.append("Property is slightly overpriced")
            recommendations.append(f"Negotiate down by approximately {abs(percent_diff):.1f}% to reach market value")

        else:
            recommendations.append("Property is significantly overpriced")
            recommendations.append(f"Strong negotiation recommended - target {abs(percent_diff):.1f}% reduction")
            recommendations.append("Be prepared to walk away if seller is inflexible")

        # Market-based recommendations
        avg_price = comp_analysis.get("avg_price", 0)
        if avg_price > 0:
            recommendations.append(f"Use comparable average price ${avg_price:,.0f} as negotiation leverage")

        return recommendations

    def _default_analysis(self, listing_price: float, square_footage: int) -> Dict[str, Any]:
        """Return default analysis when no comparables available"""
        price_per_sqft = listing_price / square_footage if square_footage > 0 else 0

        return {
            "listing_price": listing_price,
            "estimated_market_value": listing_price,
            "price_per_sqft": round(price_per_sqft, 2),
            "market_price_per_sqft": 0,
            "price_to_value_ratio": 1.0,
            "is_fair_price": False,
            "is_undervalued": False,
            "is_overvalued": False,
            "price_difference": 0,
            "percent_difference": 0,
            "comparable_count": 0,
            "insights": ["No comparable properties available for pricing analysis"],
            "negotiation_recommendations": ["Conduct independent market research before making offer"],
            "pricing_score": 5.0
        }
