#!/usr/bin/env python3
"""
Comprehensive Test Suite for Real Estate Investment Analyzer

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import InvestmentState
    from graph import InvestmentGraph
    from workflows.investment_workflow import build_investment_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.property_intake_agent import PropertyIntakeAgent
    from agents.location_agent import LocationAgent
    from agents.property_condition_agent import PropertyConditionAgent
    from agents.price_agent import PriceAgent
    from agents.market_trends_agent import MarketTrendsAgent
    from agents.roi_agent import ROIAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.location_analyzer import LocationAnalyzer
    from analyzers.property_condition_analyzer import PropertyConditionAnalyzer
    from analyzers.price_analyzer import PriceAnalyzer
    from analyzers.market_trends_analyzer import MarketTrendsAnalyzer
    from analyzers.roi_calculator import ROICalculator

    # Import nodes
    from nodes.property_intake_node import property_intake_node
    from nodes.location_node import location_node
    from nodes.property_condition_node import property_condition_node
    from nodes.price_node import price_node
    from nodes.market_trends_node import market_trends_node
    from nodes.roi_node import roi_node
    from nodes.decision_node import decision_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestRealEstateInvestmentAnalyzerArchitecture(unittest.TestCase):
    """Test suite for Real Estate Investment Analyzer Architecture"""

    def setUp(self):
        """Setup test environment"""
        self.sample_state = InvestmentState(
            analysis_id="TEST-123",
            property_id="PROP-456",
            address="123 Main St",
            city="San Francisco",
            state="CA",
            zip_code="94102",
            property_type="single_family",
            listing_price=850000,
            square_footage=1800,
            bedrooms=3,
            bathrooms=2.0,
            year_built=1990,
            lot_size=5000,
            location_data={
                "school_rating": "excellent",
                "crime_rating": "safe",
                "walkability_score": 85
            },
            comparable_properties=[
                {"price": 840000, "square_footage": 1750},
                {"price": 860000, "square_footage": 1850}
            ],
            market_data={
                "current_inventory": 100,
                "avg_days_on_market": 30
            },
            property_details={
                "overall_condition": "good",
                "estimated_rent": 4500
            }
        )

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test InvestmentState dataclass creation"""
        logger.info("Testing InvestmentState creation...")

        state = InvestmentState(
            property_id="TEST-123",
            address="123 Main St",
            city="Austin",
            state="TX"
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.property_id, "TEST-123", "Property ID should be set correctly")
        self.assertEqual(state.city, "Austin", "City should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test InvestmentState clone method"""
        logger.info("Testing InvestmentState clone...")

        state = self.sample_state.clone()

        self.assertIsNotNone(state, "Cloned state should not be None")
        self.assertEqual(state.property_id, "PROP-456", "Property ID should match")
        self.assertIsNot(state, self.sample_state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    def test_state_merge(self):
        """Test InvestmentState merge_from method"""
        logger.info("Testing InvestmentState merge_from...")

        state1 = InvestmentState(property_id="TEST-1", address="123 Main St")
        state2 = InvestmentState(property_id="TEST-1", city="Austin", state="TX")

        state1.merge_from(state2)

        self.assertEqual(state1.city, "Austin", "City should be merged")
        self.assertEqual(state1.state, "TX", "State should be merged")
        self.assertEqual(state1.address, "123 Main St", "Address should remain unchanged")

        logger.info("✓ State merge tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_location_analyzer(self):
        """Test LocationAnalyzer (pure tool)"""
        logger.info("Testing LocationAnalyzer...")

        analyzer = LocationAnalyzer()
        results = analyzer.analyze_location(
            address="123 Main St",
            city="San Francisco",
            state="CA",
            zip_code="94102",
            school_rating="excellent",
            crime_rating="safe",
            walkability_score=85
        )

        self.assertIsNotNone(results, "Location analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ LocationAnalyzer tests passed")

    def test_property_condition_analyzer(self):
        """Test PropertyConditionAnalyzer (pure tool)"""
        logger.info("Testing PropertyConditionAnalyzer...")

        analyzer = PropertyConditionAnalyzer()
        results = analyzer.analyze_condition(
            year_built=1990,
            overall_condition="good",
            component_conditions={
                "roof": "good",
                "hvac": "excellent",
                "foundation": "excellent"
            }
        )

        self.assertIsNotNone(results, "Property condition analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ PropertyConditionAnalyzer tests passed")

    def test_price_analyzer(self):
        """Test PriceAnalyzer (pure tool)"""
        logger.info("Testing PriceAnalyzer...")

        analyzer = PriceAnalyzer()
        results = analyzer.analyze_price(
            listing_price=850000,
            square_footage=1800,
            comparable_properties=[
                {"price": 840000, "square_footage": 1750},
                {"price": 860000, "square_footage": 1850}
            ],
            property_type="single_family",
            bedrooms=3,
            bathrooms=2.0
        )

        self.assertIsNotNone(results, "Price analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ PriceAnalyzer tests passed")

    def test_market_trends_analyzer(self):
        """Test MarketTrendsAnalyzer (pure tool)"""
        logger.info("Testing MarketTrendsAnalyzer...")

        analyzer = MarketTrendsAnalyzer()
        results = analyzer.analyze_trends(
            city="San Francisco",
            state="CA",
            historical_prices=[
                {"year": 2020, "median_price": 800000},
                {"year": 2021, "median_price": 850000},
                {"year": 2022, "median_price": 900000}
            ],
            current_inventory=100,
            avg_days_on_market=30
        )

        self.assertIsNotNone(results, "Market trends analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ MarketTrendsAnalyzer tests passed")

    def test_roi_calculator(self):
        """Test ROICalculator (pure tool)"""
        logger.info("Testing ROICalculator...")

        analyzer = ROICalculator()
        results = analyzer.calculate_roi(
            purchase_price=850000,
            down_payment_percent=20.0,
            interest_rate=7.0,
            estimated_rent=4500,
            property_tax_annual=8500,
            insurance_annual=1200
        )

        self.assertIsNotNone(results, "ROI calculation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ ROICalculator tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze(None, None)

        logger.info("✓ BaseAgent tests passed")

    def test_location_agent(self):
        """Test LocationAgent (coordinator)"""
        logger.info("Testing LocationAgent...")

        agent = LocationAgent()
        results = agent.analyze(
            address="123 Main St",
            city="San Francisco",
            state="CA",
            zip_code="94102",
            school_rating="excellent",
            crime_rating="safe",
            walkability_score=85
        )

        self.assertIsNotNone(results, "Location agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ LocationAgent tests passed")

    def test_property_intake_agent(self):
        """Test PropertyIntakeAgent"""
        logger.info("Testing PropertyIntakeAgent...")

        agent = PropertyIntakeAgent()
        property_data = {
            "property_id": "TEST-123",
            "address": "123 Main St",
            "listing_price": 850000
        }
        results = agent.analyze("TEST-123", property_data)

        self.assertIsNotNone(results, "Property intake results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ PropertyIntakeAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_property_intake_node(self):
        """Test property_intake_node (thin wrapper)"""
        logger.info("Testing property_intake_node...")

        state = self.sample_state.clone()
        result = property_intake_node(state)

        self.assertIsNotNone(result, "Property intake node result should not be None")
        self.assertIsInstance(result, InvestmentState, "Result should be InvestmentState")

        logger.info("✓ property_intake_node tests passed")

    def test_location_node(self):
        """Test location_node (thin wrapper)"""
        logger.info("Testing location_node...")

        state = self.sample_state.clone()
        result = location_node(state)

        self.assertIsNotNone(result, "Location node result should not be None")
        self.assertIsInstance(result, InvestmentState, "Result should be InvestmentState")

        logger.info("✓ location_node tests passed")

    def test_decision_node(self):
        """Test decision_node logic"""
        logger.info("Testing decision_node...")

        state = self.sample_state.clone()
        state.location_analysis = {"location_score": 8.5}
        state.property_condition_analysis = {"condition_score": 8.0}
        state.price_analysis = {"price_fairness_score": 7.5}
        state.market_trends_analysis = {"market_score": 8.0}
        state.roi_analysis = {"annual_roi": 12.5}

        result = decision_node(state)

        self.assertIsNotNone(result, "Decision result should not be None")
        self.assertIsInstance(result, InvestmentState, "Result should be InvestmentState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ decision_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_investment_graph_creation(self):
        """Test InvestmentGraph class creation"""
        logger.info("Testing InvestmentGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = InvestmentGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ InvestmentGraph creation tests passed")

    def test_investment_graph_execution(self):
        """Test InvestmentGraph execution"""
        logger.info("Testing InvestmentGraph execution...")

        def test_node(state: InvestmentState) -> InvestmentState:
            state.property_id = "MODIFIED"
            return state

        stages = [[test_node]]
        graph = InvestmentGraph(stages=stages, max_workers=1)

        initial_state = InvestmentState(property_id="ORIGINAL")
        result = graph.run(initial_state)

        self.assertEqual(result.property_id, "MODIFIED", "State should be modified")
        self.assertTrue(result.workflow_complete, "Workflow should be marked complete")

        logger.info("✓ InvestmentGraph execution tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_investment_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, InvestmentGraph, "Workflow should be InvestmentGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        location_agent = LocationAgent()
        self.assertIsNotNone(location_agent.analyzer, "LocationAgent should have an analyzer")
        self.assertIsInstance(location_agent.analyzer, LocationAnalyzer, "Should use LocationAnalyzer")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = self.sample_state.clone()
        result = location_node(state)

        self.assertIsInstance(result, InvestmentState, "Node should return InvestmentState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Real Estate Investment Analyzer - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
