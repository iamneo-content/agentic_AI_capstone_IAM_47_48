"""
Healthcare Patient Journey Optimizer - Main Entry Point

This is the main entry point for the Healthcare Patient Journey Optimizer.
It uses CrewAI Flow for orchestrating the patient journey optimization pipeline.
"""

import logging
import os
from dotenv import load_dotenv
from flows.patient_journey_flow import PatientJourneyFlow
from utils.output_handler import process_and_save_results

load_dotenv()

# Disable CrewAI telemetry to prevent connection errors
os.environ['OTEL_SDK_DISABLED'] = 'true'
os.environ['DO_NOT_TRACK'] = '1'

# Suppress CrewAI telemetry logging
logging.getLogger('crewai.telemetry.telemetry').setLevel(logging.CRITICAL)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """
    Main execution function - Entry point for the application.

    This is the primary entry point that orchestrates the entire pipeline using CrewAI Flow:
    1. Initialize the Flow orchestrator
    2. Execute the Flow with state management and conditional branching
    3. Process and save results

    The Flow provides:
    - State management across different stages
    - Conditional branching based on results
    - Event-driven execution of crews
    - Dynamic routing based on data quality and compliance findings
    - Comprehensive error handling

    Returns:
        Flow execution results or None on error
    """
    try:
        logger.info("=" * 70)
        logger.info("Healthcare Patient Journey Optimizer with CrewAI Flow")
        logger.info("=" * 70)

        logger.info("\n🏥 Flow Architecture:")
        logger.info("  1. Patient Data Aggregation → Collect and integrate patient data from EHR systems")
        logger.info("  2. Clinical Pathway Analysis → Conditional: Analyzes treatment pathways if data quality is sufficient")
        logger.info("  3. Compliance Checking → Ensure HIPAA compliance and privacy standards")
        logger.info("  4. Patient Experience Optimization → Analyze feedback and optimize patient journeys")
        logger.info("  5. Finalization → Aggregate results and generate comprehensive reports")
        logger.info("")

        # Initialize and execute Flow
        logger.info("🚀 Starting Patient Journey Optimization Flow...")
        flow = PatientJourneyFlow(verbose=True)

        # Execute the flow - this runs all steps with state management
        result = flow.kickoff()

        logger.info("\n" + "=" * 70)
        logger.info("Flow execution completed!")
        logger.info("=" * 70)

        # Process and save all results
        if process_and_save_results(result):
            logger.info("\n" + "=" * 70)
            logger.info("SUCCESS: Flow completed successfully!")
            logger.info("All outputs saved to 'outputs' directory")
            logger.info("=" * 70)

            # Display flow metrics
            if 'metrics' in result:
                logger.info("\n📊 Flow Execution Metrics:")
                for step, duration in result['metrics'].items():
                    logger.info(f"  - {step}: {duration:.2f}s")
                logger.info(f"  - Total: {result.get('execution_time', 0):.2f}s")
        else:
            logger.warning("⚠️ Failed to process and save results (non-critical)")

        return result

    except Exception as e:
        logger.error(f"\n❌ ERROR: Flow execution failed: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    main()
