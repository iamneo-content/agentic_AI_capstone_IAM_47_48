```mermaid
graph TD
    Start([Flow Start]) --> PDA[Patient Data Agent]

    PDA -->|Data Quality Score >= 50| CPA[Clinical Pathway Agent]
    PDA -->|Data Quality Score < 50| Skip[Skip Pathway Analysis]

    CPA --> CA[Compliance Agent]
    Skip --> CA

    CA --> PEA[Patient Experience Agent]

    PEA --> End([Flow Complete])

    style PDA fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style CPA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style CA fill:#fff3e0,stroke:#e65100,stroke-width:2px
    style PEA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style Start fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style End fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style Skip fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
```
