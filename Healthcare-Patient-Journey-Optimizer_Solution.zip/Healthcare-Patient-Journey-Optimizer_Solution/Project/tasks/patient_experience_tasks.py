"""
Patient Experience Optimization Task

This task defines the workflow for analyzing patient feedback and
generating journey improvement recommendations.
"""

from crewai import Task
from agents.patient_experience_agent import create_patient_experience_agent

agent = create_patient_experience_agent()

patient_experience_task = Task(
    description="""Optimize patient experience by analyzing feedback and journey data comprehensively.

    Your responsibilities:
    1. Analyze patient feedback from multiple sources:
       - HCAHPS (Hospital Consumer Assessment of Healthcare Providers and Systems) surveys
       - Patient satisfaction surveys (post-visit, post-discharge)
       - Online reviews and social media mentions
       - Patient complaints and grievances
       - Compliments and positive feedback
       - Focus group results and patient interviews
    2. Use the Patient Feedback Analyzer Tool to process and analyze sentiment
    3. Evaluate satisfaction scores and identify trends over time:
       - Overall satisfaction scores
       - Domain-specific scores (communication, responsiveness, pain management, etc.)
       - Net Promoter Score (NPS) and likelihood to recommend
       - Comparison to benchmarks and peer institutions
    4. Map the complete patient journey with all touchpoints:
       - Pre-visit (scheduling, registration, pre-arrival communications)
       - Arrival and check-in experience
       - Waiting room and wait times
       - Clinical encounter (provider interaction, exam, procedures)
       - Discharge process and post-visit instructions
       - Follow-up care and ongoing engagement
    5. Identify specific pain points, friction areas, and moments of delight
    6. Analyze root causes of dissatisfaction using patient verbatim comments
    7. Use the Journey Report Generator Tool to create comprehensive visualizations
    8. Benchmark performance against industry standards
    9. Provide prioritized, actionable improvement recommendations with:
       - Quick wins (low effort, high impact)
       - Strategic initiatives (high effort, transformational impact)
       - Specific interventions for each pain point

    Focus on patient-centered care, empathy, and continuous improvement.""",
    agent=agent,
    expected_output="""A comprehensive patient experience optimization report including:
    - Executive summary of patient experience status and key findings
    - Patient feedback analysis:
      * Overall satisfaction score and trend (last 6-12 months)
      * Sentiment analysis breakdown (positive/neutral/negative percentages)
      * Key themes from patient comments (top 5-10 themes)
      * Net Promoter Score and loyalty metrics
      * Comparison to national benchmarks
    - Detailed journey touchpoint mapping with:
      * Visual journey map showing all touchpoints
      * Satisfaction scores by touchpoint
      * Identified moments of truth and critical touchpoints
      * Emotional journey curve (highs and lows)
    - Pain point analysis:
      * Top 10 pain points ranked by frequency and severity
      * Root cause analysis for each pain point
      * Patient quotes and examples
      * Impact assessment on overall satisfaction
    - Positive highlights and best practices:
      * Areas of excellence and high satisfaction
      * Staff members or departments receiving praise
      * Practices to maintain and replicate
    - Benchmark comparison:
      * Performance vs. national HCAHPS percentiles
      * Peer comparison (similar institutions)
      * Gap analysis and improvement potential
    - Prioritized improvement recommendations:
      * Quick wins (5-7 recommendations, 0-3 months implementation)
      * Medium-term initiatives (3-5 recommendations, 3-6 months)
      * Strategic transformations (2-3 recommendations, 6-12 months)
      * Each recommendation includes:
        - Specific action steps
        - Expected impact on satisfaction
        - Resource requirements
        - Success metrics
    - Implementation roadmap with timeline and milestones
    - Predicted satisfaction score improvement if recommendations implemented"""
)
