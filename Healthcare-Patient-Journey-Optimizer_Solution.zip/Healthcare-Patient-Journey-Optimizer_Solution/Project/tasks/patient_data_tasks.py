"""
Patient Data Aggregation Task

This task defines the data aggregation workflow for collecting and
integrating patient data from multiple sources.
"""

from crewai import Task
from agents.patient_data_agent import create_patient_data_agent

agent = create_patient_data_agent()

patient_data_aggregation_task = Task(
    description="""Aggregate comprehensive patient data from all available sources.

    Your responsibilities:
    1. Retrieve patient records from EHR systems using the EHR Integration Tool
    2. Collect recent lab results, imaging reports, and diagnostic tests
    3. Parse and normalize data from different formats (HL7, FHIR, etc.)
    4. Extract key clinical information:
       - Patient demographics and insurance information
       - Current medications, allergies, and immunizations
       - Medical history, chronic conditions, and diagnoses
       - Recent vital signs and lab values
       - Care team members and recent encounters
    5. Identify any data gaps, inconsistencies, or quality issues
    6. Create a unified, comprehensive patient data profile

    Use the EHR Integration Tool and Patient Data Parser Tool to gather and process information.
    Focus on completeness, accuracy, and data quality.""",
    agent=agent,
    expected_output="""A comprehensive patient data profile in structured JSON format including:
    - Patient demographics (name, DOB, MRN, contact info)
    - Complete medical history and current diagnoses
    - Current medication list with dosages and frequencies
    - Known allergies and adverse reactions
    - Recent lab results with values and reference ranges
    - Vital signs trending over the last 6 months
    - Imaging reports and radiology findings
    - Care team information and recent encounters
    - Data quality assessment report identifying any gaps or concerns
    - Summary of data sources accessed and integration status"""
)
