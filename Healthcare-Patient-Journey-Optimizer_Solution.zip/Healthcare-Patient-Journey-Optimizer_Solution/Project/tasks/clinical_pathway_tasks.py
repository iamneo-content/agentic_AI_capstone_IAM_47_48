"""
Clinical Pathway Analysis Task

This task defines the workflow for analyzing clinical protocols and
mapping optimal treatment pathways.
"""

from crewai import Task
from agents.clinical_pathway_agent import create_clinical_pathway_agent

agent = create_clinical_pathway_agent()

clinical_pathway_task = Task(
    description="""Analyze clinical protocols and map optimal treatment pathways based on patient data.

    Your responsibilities:
    1. Review patient condition, diagnoses, and medical history from aggregated data
    2. Analyze relevant clinical protocols and evidence-based guidelines:
       - NCCN (National Comprehensive Cancer Network) guidelines
       - AHA/ACC (American Heart Association/American College of Cardiology) guidelines
       - CDC clinical guidelines
       - Specialty-specific protocols (oncology, cardiology, etc.)
    3. Use the Clinical Protocol Analyzer Tool to identify applicable protocols
    4. Map potential treatment pathway options using the Treatment Pathway Mapper Tool
    5. Evaluate each pathway considering:
       - Clinical effectiveness and outcomes data
       - Patient-specific factors (age, comorbidities, contraindications)
       - Risk-benefit analysis
       - Resource requirements and care coordination needs
       - Drug interactions and adverse event profiles
    6. Identify the optimal care strategy with clear justification
    7. Document alternative pathways and decision points

    Consider evidence-based medicine, patient safety, and care efficiency in your analysis.""",
    agent=agent,
    expected_output="""A comprehensive clinical pathway analysis report including:
    - Primary diagnosis and condition assessment summary
    - List of applicable clinical protocols and guidelines referenced
    - Detailed treatment pathway map with:
      * Initial treatment phase
      * Follow-up and monitoring plan
      * Decision points and triggers for pathway changes
      * Expected timeline and milestones
    - Comparative analysis of 2-3 pathway options including:
      * Clinical effectiveness scores
      * Risk assessment for each pathway
      * Resource requirements
      * Expected outcomes and quality metrics
    - Recommended optimal pathway with detailed justification
    - Alternative pathways for consideration if primary fails
    - Care coordination requirements and specialist referrals needed
    - Monitoring parameters and success metrics"""
)
