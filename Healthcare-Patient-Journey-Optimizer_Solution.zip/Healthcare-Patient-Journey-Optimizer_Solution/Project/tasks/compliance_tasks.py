"""
Compliance Checking Task

This task defines the workflow for ensuring HIPAA compliance and
maintaining patient privacy standards.
"""

from crewai import Task
from agents.compliance_agent import create_compliance_agent

agent = create_compliance_agent()

compliance_task = Task(
    description="""Ensure all patient data handling processes comply with HIPAA regulations and privacy standards.

    Your responsibilities:
    1. Conduct comprehensive HIPAA compliance audit across all patient data operations
    2. Check HIPAA Privacy Rule compliance:
       - Verify proper patient consent and authorization
       - Review minimum necessary standard implementation
       - Check notice of privacy practices distribution
       - Audit patient rights (access, amendment, accounting of disclosures)
    3. Verify HIPAA Security Rule implementation:
       - Administrative safeguards (security management, workforce training)
       - Physical safeguards (facility access, workstation security)
       - Technical safeguards (access control, encryption, audit controls)
       - Transmission security for PHI
    4. Use the HIPAA Compliance Checker Tool to scan for violations
    5. Use the Privacy Auditor Tool to audit data access patterns and usage
    6. Review breach notification procedures and incident response plans
    7. Identify any compliance gaps, violations, or privacy risks:
       - Unauthorized access or disclosure
       - Inadequate safeguards
       - Missing documentation or policies
       - Insufficient audit trails
    8. Assess risk severity and potential impact
    9. Recommend specific corrective actions with implementation priority

    Maintain strict adherence to regulatory requirements and patient privacy protection.""",
    agent=agent,
    expected_output="""A comprehensive HIPAA compliance assessment report including:
    - Executive summary of overall compliance status (Pass/Fail/Needs Improvement)
    - HIPAA Privacy Rule compliance analysis:
      * Patient consent and authorization status
      * Minimum necessary standard implementation
      * Patient rights fulfillment
      * Notice of privacy practices compliance
    - HIPAA Security Rule implementation review:
      * Administrative safeguards assessment
      * Physical safeguards evaluation
      * Technical safeguards verification
      * Transmission security status
    - Data access audit results:
      * Access log review findings
      * Unusual access patterns detected
      * Authorization verification results
    - Detailed list of identified violations or compliance gaps with:
      * Description of each issue
      * Severity rating (Critical/High/Medium/Low)
      * Affected systems or processes
      * Potential consequences
    - Risk assessment matrix with likelihood and impact ratings
    - Prioritized corrective action plan with:
      * Specific remediation steps
      * Responsible parties
      * Recommended timeline
      * Resource requirements
    - Compliance score and improvement recommendations"""
)
