"""
Task definitions for Healthcare Patient Journey Optimizer.

This module contains 4 specialized tasks corresponding to each agent:
1. Patient Data Aggregation Task
2. Clinical Pathway Analysis Task
3. Compliance Checking Task
4. Patient Experience Optimization Task
"""

from .patient_data_tasks import patient_data_aggregation_task
from .clinical_pathway_tasks import clinical_pathway_task
from .compliance_tasks import compliance_task
from .patient_experience_tasks import patient_experience_task

__all__ = [
    'patient_data_aggregation_task',
    'clinical_pathway_task',
    'compliance_task',
    'patient_experience_task'
]
