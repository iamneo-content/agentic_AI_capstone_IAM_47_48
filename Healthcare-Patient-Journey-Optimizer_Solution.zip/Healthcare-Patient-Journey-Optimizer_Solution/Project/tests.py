"""
Unit tests for Healthcare Patient Journey Optimizer.

This module contains test cases for agents, tasks, tools, and workflows.
"""

import pytest
import sys
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from crewai import Agent, Crew

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agents.patient_data_agent import create_patient_data_agent
from agents.clinical_pathway_agent import create_clinical_pathway_agent
from agents.compliance_agent import create_compliance_agent
from agents.patient_experience_agent import create_patient_experience_agent

from tools.ehr_integration import EHRIntegrationTool
from tools.clinical_protocol_analyzer import ClinicalProtocolAnalyzerTool
from tools.hipaa_compliance_checker import HIPAAComplianceCheckerTool
from tools.patient_feedback_analyzer import PatientFeedbackAnalyzerTool

from crew import PatientJourneyCrew, create_patient_journey_crew


class TestAgents:
    """Test cases for all agents."""

    def test_patient_data_agent_creation(self):
        """Test patient data aggregator agent creation."""
        agent = create_patient_data_agent()

        assert agent is not None
        assert isinstance(agent, Agent)
        assert agent.role == "Patient Data Aggregator Specialist"
        assert "collect and integrate" in agent.goal.lower()
        assert len(agent.tools) == 2
        assert agent.verbose is True

    def test_clinical_pathway_agent_creation(self):
        """Test clinical pathway agent creation."""
        agent = create_clinical_pathway_agent()

        assert agent is not None
        assert isinstance(agent, Agent)
        assert agent.role == "Clinical Pathway Specialist"
        assert "clinical protocols" in agent.goal.lower()
        assert len(agent.tools) == 2
        assert agent.verbose is True

    def test_compliance_agent_creation(self):
        """Test compliance and privacy agent creation."""
        agent = create_compliance_agent()

        assert agent is not None
        assert isinstance(agent, Agent)
        assert "compliance" in agent.role.lower()
        assert len(agent.tools) >= 1
        assert agent.verbose is True

    def test_patient_experience_agent_creation(self):
        """Test patient experience agent creation."""
        agent = create_patient_experience_agent()

        assert agent is not None
        assert isinstance(agent, Agent)
        assert "patient experience" in agent.role.lower()
        assert len(agent.tools) >= 1
        assert agent.verbose is True


class TestTools:
    """Test cases for all tools."""

    def test_ehr_integration_tool(self):
        """Test EHR integration tool."""
        tool = EHRIntegrationTool()

        assert tool is not None
        assert tool.name == "EHR Integration Tool"
        assert "Electronic Health Record" in tool.description

        # Test tool execution
        result = tool._run(patient_id="P12345", data_types="all")
        assert result is not None
        assert "P12345" in result
        assert "success" in result.lower() or "error" in result.lower()

    def test_clinical_protocol_analyzer(self):
        """Test clinical protocol analyzer tool."""
        tool = ClinicalProtocolAnalyzerTool()

        assert tool is not None
        assert tool.name == "Clinical Protocol Analyzer Tool"
        assert "clinical protocols" in tool.description.lower()

        # Test tool execution
        result = tool._run(condition="Diabetes", protocol_type="standard")
        assert result is not None
        assert "Diabetes" in result
        assert "success" in result.lower() or "error" in result.lower()

    def test_hipaa_compliance_checker(self):
        """Test HIPAA compliance checker tool."""
        tool = HIPAAComplianceCheckerTool()

        assert tool is not None
        assert tool.name == "HIPAA Compliance Checker Tool"
        assert "HIPAA" in tool.description

        # Test tool execution
        result = tool._run(process_name="data_transfer", check_type="full")
        assert result is not None
        assert "data_transfer" in result
        assert "success" in result.lower() or "error" in result.lower()

    def test_patient_feedback_analyzer(self):
        """Test patient feedback analyzer tool."""
        tool = PatientFeedbackAnalyzerTool()

        assert tool is not None
        assert tool.name == "Patient Feedback Analyzer Tool"
        assert "feedback" in tool.description.lower()

        # Test tool execution
        result = tool._run(feedback_source="survey", analysis_type="sentiment")
        assert result is not None
        assert "survey" in result
        assert "success" in result.lower() or "error" in result.lower()


class TestWorkflows:
    """Test cases for workflows."""

    def test_crew_initialization(self):
        """Test PatientJourneyCrew initialization."""
        crew_orchestrator = PatientJourneyCrew(verbose=False)

        assert crew_orchestrator is not None
        assert len(crew_orchestrator.agents) == 4
        assert len(crew_orchestrator.tasks) == 4
        assert 'patient_data' in crew_orchestrator.agents
        assert 'clinical_pathway' in crew_orchestrator.agents
        assert 'compliance' in crew_orchestrator.agents
        assert 'patient_experience' in crew_orchestrator.agents

    def test_create_patient_journey_crew(self):
        """Test the crew creation factory function."""
        crew_orchestrator = create_patient_journey_crew(verbose=False)

        assert crew_orchestrator is not None
        assert isinstance(crew_orchestrator, PatientJourneyCrew)
        assert len(crew_orchestrator.list_available_agents()) == 4
        assert len(crew_orchestrator.list_available_tasks()) == 4

    def test_create_crew_with_specific_agents(self):
        """Test creating crew with specific agents and tasks."""
        crew_orchestrator = PatientJourneyCrew(verbose=False)

        # Test creating crew with subset of agents
        crew = crew_orchestrator.create_crew(
            agents=['patient_data', 'compliance'],
            tasks=['patient_data', 'compliance']
        )

        assert crew is not None
        assert isinstance(crew, Crew)
        assert len(crew.agents) == 2

    def test_get_agent(self):
        """Test getting specific agents."""
        crew_orchestrator = PatientJourneyCrew(verbose=False)

        patient_agent = crew_orchestrator.get_agent('patient_data')
        assert patient_agent is not None
        assert isinstance(patient_agent, Agent)

        clinical_agent = crew_orchestrator.get_agent('clinical_pathway')
        assert clinical_agent is not None
        assert isinstance(clinical_agent, Agent)

    def test_get_task(self):
        """Test getting specific tasks."""
        crew_orchestrator = PatientJourneyCrew(verbose=False)

        patient_task = crew_orchestrator.get_task('patient_data')
        assert patient_task is not None

        compliance_task = crew_orchestrator.get_task('compliance')
        assert compliance_task is not None

    def test_list_available_agents(self):
        """Test listing available agents."""
        crew_orchestrator = PatientJourneyCrew(verbose=False)

        agents = crew_orchestrator.list_available_agents()
        assert agents is not None
        assert len(agents) == 4
        assert 'patient_data' in agents
        assert 'clinical_pathway' in agents
        assert 'compliance' in agents
        assert 'patient_experience' in agents

    def test_list_available_tasks(self):
        """Test listing available tasks."""
        crew_orchestrator = PatientJourneyCrew(verbose=False)

        tasks = crew_orchestrator.list_available_tasks()
        assert tasks is not None
        assert len(tasks) == 4
        assert 'patient_data' in tasks
        assert 'clinical_pathway' in tasks
        assert 'compliance' in tasks
        assert 'patient_experience' in tasks


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
