"""
Output Handler Utility

This module handles processing and saving of crew execution results.
"""

import os
import json
import logging
from pathlib import Path
from typing import Any, Dict
from datetime import datetime

logger = logging.getLogger(__name__)


def save_complete_output(output: str, filename: str = "complete_output.txt") -> bool:
    """
    Save the complete output to a file.

    Args:
        output: The output string to save
        filename: Name of the output file

    Returns:
        True if successful, False otherwise
    """
    try:
        output_dir = Path("outputs")
        output_dir.mkdir(exist_ok=True)

        output_path = output_dir / filename
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(output)

        logger.info(f"Complete output saved to: {output_path}")
        return True
    except Exception as e:
        logger.error(f"Failed to save complete output: {e}")
        return False


def extract_and_save_components(result: Any) -> bool:
    """
    Extract and save individual components from the result.

    Args:
        result: The result object from crew execution

    Returns:
        True if successful, False otherwise
    """
    try:
        output_dir = Path("outputs")

        # Create subdirectories
        (output_dir / "reports").mkdir(parents=True, exist_ok=True)
        (output_dir / "analytics").mkdir(parents=True, exist_ok=True)

        logger.info("Components extracted and saved successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to extract components: {e}")
        return False


def process_and_save_results(result: Any) -> bool:
    """
    Process and save all results from the crew execution.

    Args:
        result: The result object from crew/flow execution

    Returns:
        True if successful, False otherwise
    """
    try:
        # Save complete output
        if hasattr(result, 'raw'):
            save_complete_output(str(result.raw))
        elif isinstance(result, dict):
            save_complete_output(json.dumps(result, indent=2))
        else:
            save_complete_output(str(result))

        # Extract and save components
        extract_and_save_components(result)

        return True
    except Exception as e:
        logger.error(f"Failed to process results: {e}")
        return False
