"""
LLM Configuration Utility

This module provides centralized LLM configuration for all agents.
"""

import os
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


def get_llm_config():
    """
    Get the centralized LLM configuration.

    Returns:
        LLM configuration object for CrewAI agents
    """
    # Load config from file if exists
    config_path = Path(__file__).parent.parent / 'configs' / 'app_config.json'

    llm_settings = {
        "model": os.getenv("GEMINI_MODEL", "gemini/gemini-2.0-flash"),
        "max_tokens": 3000,
        "temperature": 0.3,
        "timeout": 30
    }

    if config_path.exists():
        with open(config_path, 'r') as f:
            config = json.load(f)
            if 'llm_config' in config:
                llm_settings.update(config['llm_config'])

    # For CrewAI, we just return the model name as string
    # CrewAI will handle the LiteLLM integration automatically
    return llm_settings.get("model")
