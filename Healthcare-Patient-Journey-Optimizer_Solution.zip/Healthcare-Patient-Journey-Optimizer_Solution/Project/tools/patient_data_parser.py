"""
Patient Data Parser Tool

Parses and normalizes patient data from various sources.
"""

from crewai.tools import BaseTool
from typing import Type, Optional
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class PatientDataParserInput(BaseModel):
    """Input schema for Patient Data Parser Tool."""
    data_source: str = Field(..., description="Source of the patient data (EHR, lab, imaging, etc.)")
    raw_data: str = Field(..., description="Raw patient data to parse")


class PatientDataParserTool(BaseTool):
    name: str = "Patient Data Parser Tool"
    description: str = "Parses and normalizes patient data from various sources into a standardized format for analysis."
    args_schema: Type[BaseModel] = PatientDataParserInput

    def _run(self, data_source: str, raw_data: str) -> str:
        """
        Parse patient data from various sources.

        Args:
            data_source: Source of the data
            raw_data: Raw data to parse

        Returns:
            Parsed and normalized data
        """
        try:
            logger.info(f"Parsing data from source: {data_source}")

            result = {
                "status": "success",
                "data_source": data_source,
                "parsed": True,
                "message": "Data parsed and normalized successfully"
            }

            return str(result)

        except Exception as e:
            logger.error(f"Data parsing error: {str(e)}")
            return str({"status": "error", "message": str(e)})
