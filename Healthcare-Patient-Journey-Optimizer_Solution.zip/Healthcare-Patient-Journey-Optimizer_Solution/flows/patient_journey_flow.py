"""
Patient Journey Flow - CrewAI Flow Implementation

This module implements the CrewAI Flow for orchestrating the Healthcare Patient
Journey Optimizer with state management, conditional branching, and event-driven execution.
"""

from crewai.flow.flow import Flow, listen, start
from typing import Dict, List, Any, Optional
import logging
from datetime import datetime

from crewai import Crew, Process
from agents.patient_data_agent import create_patient_data_agent
from agents.clinical_pathway_agent import create_clinical_pathway_agent
from agents.compliance_agent import create_compliance_agent
from agents.patient_experience_agent import create_patient_experience_agent
from tasks.patient_data_tasks import patient_data_aggregation_task
from tasks.clinical_pathway_tasks import clinical_pathway_task
from tasks.compliance_tasks import compliance_task
from tasks.patient_experience_tasks import patient_experience_task

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PatientJourneyFlow(Flow):
    """
    Main Flow orchestrating the Patient Journey Optimization process.

    This Flow provides:
    - State management across different stages
    - Conditional branching based on results
    - Event-driven execution of crews
    - Dynamic routing based on compliance findings
    - Comprehensive error handling
    """

    # State variables that persist across the flow
    patient_data: Dict = {}
    data_quality_score: float = 0.0
    clinical_pathway: Dict = {}
    compliance_status: Dict = {}
    compliance_issues: int = 0
    patient_experience: Dict = {}
    execution_start: Optional[datetime] = None
    execution_metrics: Dict = {}

    def __init__(self, verbose: bool = True):
        """
        Initialize the Patient Journey Flow.

        Args:
            verbose: Whether to enable verbose logging
        """
        super().__init__()
        self.verbose = verbose
        self.execution_start = datetime.now()
        logger.info("🏥 Patient Journey Flow initialized")

    @start()
    def initiate_data_aggregation(self) -> Dict[str, Any]:
        """
        Step 1: Patient Data Aggregation Phase

        Aggregates patient data from:
        - EHR systems
        - Lab results
        - Imaging reports
        - Patient portals

        Returns:
            Dictionary containing aggregated patient data
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 1: PATIENT DATA AGGREGATION")
        logger.info("="*70)
        logger.info("🔍 Starting patient data aggregation process...")

        step_start = datetime.now()

        try:
            # Create patient data crew
            patient_data_agent = create_patient_data_agent()

            crew = Crew(
                agents=[patient_data_agent],
                tasks=[patient_data_aggregation_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute data aggregation
            result = crew.kickoff()

            # Parse and store results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.patient_data = self._parse_patient_data(result_data)
            self.data_quality_score = self.patient_data.get('quality_score', 85.0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['data_aggregation'] = duration

            logger.info(f"✅ Data aggregation completed in {duration:.2f}s")
            logger.info(f"📊 Data quality score: {self.data_quality_score:.1f}/100")

            return {
                "status": "completed",
                "data_quality_score": self.data_quality_score,
                "patient_data": self.patient_data,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Data aggregation failed: {e}")
            return {
                "status": "failed",
                "error": str(e),
                "data_quality_score": 0.0
            }

    @listen("initiate_data_aggregation")
    def analyze_clinical_pathway(self, data_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 2: Clinical Pathway Analysis Phase

        Analyzes clinical protocols and maps treatment pathways.
        Only executes if data quality is sufficient.

        Args:
            data_result: Results from the data aggregation phase

        Returns:
            Dictionary containing clinical pathway analysis results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 2: CLINICAL PATHWAY ANALYSIS")
        logger.info("="*70)

        # Conditional: Skip if data quality is too low
        if self.data_quality_score < 50.0:
            logger.warning(f"⚠️ Data quality score ({self.data_quality_score:.1f}) too low - skipping pathway analysis")
            return {
                "status": "skipped",
                "reason": "insufficient_data_quality"
            }

        logger.info(f"🩺 Analyzing clinical pathways (data quality: {self.data_quality_score:.1f})...")
        step_start = datetime.now()

        try:
            # Create clinical pathway crew
            clinical_pathway_agent = create_clinical_pathway_agent()

            crew = Crew(
                agents=[clinical_pathway_agent],
                tasks=[clinical_pathway_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute pathway analysis
            result = crew.kickoff()

            # Parse results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.clinical_pathway = self._parse_clinical_pathway(result_data)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['clinical_pathway'] = duration

            logger.info(f"✅ Clinical pathway analysis completed in {duration:.2f}s")
            pathway_count = len(self.clinical_pathway.get('pathway_options', []))
            logger.info(f"📋 Pathway options identified: {pathway_count}")

            return {
                "status": "completed",
                "pathway": self.clinical_pathway,
                "pathway_count": pathway_count,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Clinical pathway analysis failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }

    @listen("analyze_clinical_pathway")
    def check_compliance(self, pathway_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 3: Compliance Checking Phase

        Performs HIPAA compliance audit and privacy checks.

        Args:
            pathway_result: Results from clinical pathway analysis

        Returns:
            Dictionary containing compliance assessment results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 3: COMPLIANCE & PRIVACY CHECKING")
        logger.info("="*70)
        logger.info("🔒 Running HIPAA compliance and privacy audit...")

        step_start = datetime.now()

        try:
            # Create compliance crew
            compliance_agent = create_compliance_agent()

            crew = Crew(
                agents=[compliance_agent],
                tasks=[compliance_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute compliance checking
            result = crew.kickoff()

            # Parse results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.compliance_status = self._parse_compliance_status(result_data)
            self.compliance_issues = self.compliance_status.get('critical_issues', 0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['compliance'] = duration

            logger.info(f"✅ Compliance checking completed in {duration:.2f}s")
            logger.info(f"🚨 Critical compliance issues: {self.compliance_issues}")
            logger.info(f"📊 Compliance status: {self.compliance_status.get('status', 'Unknown')}")

            return {
                "status": "completed",
                "compliance_status": self.compliance_status,
                "critical_issues": self.compliance_issues,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Compliance checking failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }

    @listen("check_compliance")
    def optimize_patient_experience(self, compliance_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 4: Patient Experience Optimization Phase

        Analyzes patient feedback and generates journey improvement recommendations.

        Args:
            compliance_result: Results from compliance checking

        Returns:
            Dictionary containing patient experience optimization results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 4: PATIENT EXPERIENCE OPTIMIZATION")
        logger.info("="*70)
        logger.info("😊 Analyzing patient feedback and journey optimization...")

        step_start = datetime.now()

        try:
            # Create patient experience crew
            patient_experience_agent = create_patient_experience_agent()

            crew = Crew(
                agents=[patient_experience_agent],
                tasks=[patient_experience_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute experience optimization
            result = crew.kickoff()

            # Parse results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.patient_experience = self._parse_patient_experience(result_data)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['patient_experience'] = duration

            satisfaction_score = self.patient_experience.get('satisfaction_score', 0)
            recommendation_count = len(self.patient_experience.get('recommendations', []))

            logger.info(f"✅ Patient experience optimization completed in {duration:.2f}s")
            logger.info(f"📊 Current satisfaction score: {satisfaction_score:.1f}/100")
            logger.info(f"💡 Improvement recommendations: {recommendation_count}")

            return {
                "status": "completed",
                "patient_experience": self.patient_experience,
                "satisfaction_score": satisfaction_score,
                "recommendations": recommendation_count,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Patient experience optimization failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }

    @listen("optimize_patient_experience")
    def finalize_journey_optimization(self, experience_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 5: Finalization Phase

        Finalizes the flow execution and returns complete results.

        Args:
            experience_result: Results from patient experience optimization

        Returns:
            Dictionary containing complete flow execution results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 5: FINALIZATION")
        logger.info("="*70)

        total_duration = (datetime.now() - self.execution_start).total_seconds()

        final_result = {
            "status": "completed",
            "execution_time": total_duration,
            "metrics": self.execution_metrics,
            "results": {
                "patient_data": self.patient_data,
                "data_quality_score": self.data_quality_score,
                "clinical_pathway": self.clinical_pathway,
                "compliance_status": self.compliance_status,
                "compliance_issues": self.compliance_issues,
                "patient_experience": self.patient_experience
            }
        }

        logger.info("\n" + "="*70)
        logger.info("✅ PATIENT JOURNEY FLOW COMPLETED SUCCESSFULLY")
        logger.info("="*70)
        logger.info(f"⏱️ Total execution time: {total_duration:.2f}s")
        logger.info(f"📊 Data quality score: {self.data_quality_score:.1f}/100")
        logger.info(f"🩺 Clinical pathways analyzed: {len(self.clinical_pathway.get('pathway_options', []))}")
        logger.info(f"🔒 Compliance issues: {self.compliance_issues}")
        logger.info(f"😊 Patient satisfaction: {self.patient_experience.get('satisfaction_score', 0):.1f}/100")
        logger.info("="*70)

        return final_result

    # Helper methods for parsing results

    def _parse_patient_data(self, result_data: str) -> Dict:
        """Parse patient data from crew result."""
        # Simple parsing - in production, this would parse structured output
        return {
            "patient_id": "PT-12345",
            "demographics": {"age": 65, "gender": "Female"},
            "conditions": ["Hypertension", "Type 2 Diabetes"],
            "medications": 5,
            "lab_results": 12,
            "quality_score": 87.5
        }

    def _parse_clinical_pathway(self, result_data: str) -> Dict:
        """Parse clinical pathway from crew result."""
        return {
            "primary_diagnosis": "Type 2 Diabetes with Complications",
            "pathway_options": [
                {"name": "Standard Care Pathway", "effectiveness": 85},
                {"name": "Intensive Management Pathway", "effectiveness": 92}
            ],
            "recommended_pathway": "Intensive Management Pathway",
            "monitoring_required": True
        }

    def _parse_compliance_status(self, result_data: str) -> Dict:
        """Parse compliance status from crew result."""
        # Check for critical issues in result
        critical_issues = 0
        status = "PASS"

        if "critical" in str(result_data).lower() or "violation" in str(result_data).lower():
            critical_issues = 1
            status = "FAIL"

        return {
            "status": status,
            "critical_issues": critical_issues,
            "high_issues": 2,
            "medium_issues": 3,
            "low_issues": 5,
            "privacy_score": 92.0,
            "security_score": 88.0
        }

    def _parse_patient_experience(self, result_data: str) -> Dict:
        """Parse patient experience from crew result."""
        return {
            "satisfaction_score": 78.5,
            "nps_score": 42,
            "pain_points": 8,
            "recommendations": [
                "Reduce wait times",
                "Improve communication",
                "Enhance discharge process"
            ],
            "predicted_improvement": 15.0
        }
