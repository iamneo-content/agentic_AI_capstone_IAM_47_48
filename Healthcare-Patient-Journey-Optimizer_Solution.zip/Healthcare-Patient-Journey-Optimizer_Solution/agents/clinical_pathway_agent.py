"""
Clinical Pathway Agent

This agent analyzes clinical protocols and treatment pathways to recommend
optimal care strategies for patients.
"""

from crewai import Agent
from tools.clinical_protocol_analyzer import ClinicalProtocolAnalyzerTool
from tools.treatment_pathway_mapper import TreatmentPathwayMapperTool
from utils.llm_config import get_llm_config


def create_clinical_pathway_agent():
    """
    Create the Clinical Pathway Agent.

    This agent analyzes clinical protocols and guidelines, maps treatment pathways
    for specific conditions, and recommends optimal care strategies based on
    evidence-based medicine and best practices.

    Returns:
        Configured Agent for clinical pathway analysis
    """
    llm = get_llm_config()

    protocol_tool = ClinicalProtocolAnalyzerTool()
    pathway_tool = TreatmentPathwayMapperTool()

    agent = Agent(
        role="Clinical Pathway Specialist",
        goal="Analyze clinical protocols and optimize treatment pathways to ensure evidence-based, efficient patient care",
        backstory="""You are a board-certified clinical specialist with extensive experience in
        evidence-based medicine, clinical guidelines (NCCN, AHA, ACC), and care pathway optimization.
        You excel at analyzing complex treatment protocols, identifying optimal care sequences, and
        recommending pathways that balance clinical effectiveness with patient-centered care. Your
        expertise includes understanding drug interactions, treatment protocols for chronic conditions,
        and coordinating multi-disciplinary care teams.""",
        llm=llm,
        tools=[protocol_tool, pathway_tool],
        verbose=True
    )

    return agent
