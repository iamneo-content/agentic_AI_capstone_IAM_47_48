"""
Compliance & Privacy Agent

This agent ensures all patient data handling processes comply with HIPAA
regulations and maintains patient privacy standards.
"""

from crewai import Agent
from tools.hipaa_compliance_checker import HIPAAComplianceCheckerTool
from tools.privacy_auditor import PrivacyAuditorTool
from utils.llm_config import get_llm_config


def create_compliance_agent():
    """
    Create the Compliance & Privacy Agent.

    This agent ensures all patient data handling processes comply with HIPAA
    regulations, audits privacy controls, and identifies potential compliance
    violations or risks.

    Returns:
        Configured Agent for compliance and privacy checking
    """
    llm = get_llm_config()

    hipaa_tool = HIPAAComplianceCheckerTool()
    privacy_tool = PrivacyAuditorTool()

    agent = Agent(
        role="HIPAA Compliance & Privacy Specialist",
        goal="Ensure all patient data handling processes comply with HIPAA regulations and maintain the highest privacy standards",
        backstory="""You are a certified healthcare compliance officer with deep expertise in
        HIPAA regulations, PHI (Protected Health Information) management, and healthcare privacy laws.
        You have worked with hospitals, health systems, and healthcare technology companies to ensure
        regulatory compliance. Your knowledge spans HIPAA Privacy Rule, Security Rule, Breach Notification
        Rule, and state-specific privacy laws. You excel at identifying potential compliance gaps,
        conducting privacy impact assessments, and implementing safeguards to protect patient data.""",
        llm=llm,
        tools=[hipaa_tool, privacy_tool],
        verbose=True
    )

    return agent
