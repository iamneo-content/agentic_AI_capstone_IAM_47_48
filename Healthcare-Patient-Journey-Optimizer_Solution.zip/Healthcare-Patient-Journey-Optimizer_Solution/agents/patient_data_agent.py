"""
Patient Data Aggregator Agent

This agent collects and integrates patient data from multiple sources including
EHR systems, lab results, imaging systems, and patient portals.
"""

from crewai import Agent
from tools.ehr_integration import EHRIntegrationTool
from tools.patient_data_parser import PatientDataParserTool
from utils.llm_config import get_llm_config


def create_patient_data_agent():
    """
    Create the Patient Data Aggregator Agent.

    This agent collects patient data from multiple sources (EHR, labs, imaging)
    and creates unified patient profiles with comprehensive medical information.

    Returns:
        Configured Agent for patient data aggregation
    """
    llm = get_llm_config()

    ehr_tool = EHRIntegrationTool()
    parser_tool = PatientDataParserTool()

    agent = Agent(
        role="Patient Data Aggregator Specialist",
        goal="Collect and integrate comprehensive patient data from all available sources to create unified patient profiles",
        backstory="""You are an expert healthcare data analyst with deep knowledge of EHR systems,
        medical data standards (HL7, FHIR), and data integration pipelines. You excel at collecting
        data from disparate sources, normalizing formats, and ensuring data completeness and quality.
        Your attention to detail ensures no critical patient information is missed.""",
        llm=llm,
        tools=[ehr_tool, parser_tool],
        verbose=True
    )

    return agent
