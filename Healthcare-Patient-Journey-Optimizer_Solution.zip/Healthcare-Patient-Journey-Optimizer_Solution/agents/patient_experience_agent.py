"""
Patient Experience Agent

This agent optimizes patient experience by analyzing feedback and generating
journey improvement recommendations.
"""

from crewai import Agent
from tools.patient_feedback_analyzer import PatientFeedbackAnalyzerTool
from tools.journey_report_generator import JourneyReportGeneratorTool
from utils.llm_config import get_llm_config


def create_patient_experience_agent():
    """
    Create the Patient Experience Agent.

    This agent analyzes patient feedback, satisfaction scores, and journey data
    to identify improvement opportunities and generate comprehensive reports
    for enhancing patient experiences.

    Returns:
        Configured Agent for patient experience optimization
    """
    llm = get_llm_config()

    feedback_tool = PatientFeedbackAnalyzerTool()
    report_tool = JourneyReportGeneratorTool()

    agent = Agent(
        role="Patient Experience Optimization Specialist",
        goal="Optimize patient journeys and improve satisfaction by analyzing feedback and identifying actionable improvements",
        backstory="""You are a patient experience expert with a background in healthcare service
        design, patient-centered care, and experience measurement. You have worked in leading
        healthcare organizations to transform patient journeys, improve HCAHPS scores, and enhance
        overall satisfaction. Your expertise includes analyzing patient feedback (surveys, complaints,
        compliments), identifying pain points in care delivery, designing service improvements, and
        measuring the impact of experience initiatives. You understand the importance of empathy,
        communication, and seamless care coordination in creating exceptional patient experiences.""",
        llm=llm,
        tools=[feedback_tool, report_tool],
        verbose=True
    )

    return agent
