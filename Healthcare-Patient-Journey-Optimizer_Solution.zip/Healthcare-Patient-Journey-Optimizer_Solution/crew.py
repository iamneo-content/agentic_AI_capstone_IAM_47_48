"""
Patient Journey Crew Orchestration

This module provides crew orchestration for the Healthcare Patient Journey Optimizer.
It offers backward compatibility with traditional Crew-based execution while the
main application uses Flow-based orchestration.
"""

from crewai import Crew, Process
from typing import Any, Optional, List
import logging
from datetime import datetime

from agents.patient_data_agent import create_patient_data_agent
from agents.clinical_pathway_agent import create_clinical_pathway_agent
from agents.compliance_agent import create_compliance_agent
from agents.patient_experience_agent import create_patient_experience_agent

from tasks.patient_data_tasks import patient_data_aggregation_task
from tasks.clinical_pathway_tasks import clinical_pathway_task
from tasks.compliance_tasks import compliance_task
from tasks.patient_experience_tasks import patient_experience_task

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PatientJourneyCrew:
    """
    Main crew orchestration class for the Healthcare Patient Journey Optimizer.

    This class encapsulates all crew-related logic and provides a clean
    interface for running different workflows.
    """

    def __init__(self, verbose: bool = True):
        """
        Initialize the crew orchestrator.

        Args:
            verbose: Whether to enable verbose output during execution
        """
        self.verbose = verbose
        self.agents = {}
        self.tasks = {}
        self._initialize_agents()
        self._initialize_tasks()
        logger.info("Patient Journey Crew initialized successfully")

    def _initialize_agents(self):
        """Initialize all agents for the crew."""
        logger.info("Initializing agents...")

        self.agents = {
            'patient_data': create_patient_data_agent(),
            'clinical_pathway': create_clinical_pathway_agent(),
            'compliance': create_compliance_agent(),
            'patient_experience': create_patient_experience_agent()
        }

        logger.info(f"Initialized {len(self.agents)} agents")

    def _initialize_tasks(self):
        """Initialize all tasks for the crew."""
        logger.info("Initializing tasks...")

        self.tasks = {
            'patient_data': patient_data_aggregation_task,
            'clinical_pathway': clinical_pathway_task,
            'compliance': compliance_task,
            'patient_experience': patient_experience_task
        }

        logger.info(f"Initialized {len(self.tasks)} tasks")

    def create_crew(
        self,
        agents: Optional[List[str]] = None,
        tasks: Optional[List[str]] = None,
        process: Process = Process.sequential
    ) -> Crew:
        """
        Create a crew with specified agents and tasks.

        Args:
            agents: List of agent keys to include (default: all agents)
            tasks: List of task keys to include (default: all tasks)
            process: CrewAI process type (sequential or hierarchical)

        Returns:
            Configured Crew instance
        """
        agent_keys = agents or list(self.agents.keys())
        task_keys = tasks or list(self.tasks.keys())

        selected_agents = [self.agents[key] for key in agent_keys if key in self.agents]
        selected_tasks = [self.tasks[key] for key in task_keys if key in self.tasks]

        logger.info(f"Creating crew with {len(selected_agents)} agents and {len(selected_tasks)} tasks")

        crew = Crew(
            agents=selected_agents,
            tasks=selected_tasks,
            verbose=self.verbose,
            process=process
        )

        return crew

    def run_full_pipeline(self) -> Any:
        """
        Run the complete patient journey optimization pipeline.

        This is the main workflow that includes all agents and tasks.

        Returns:
            The result of the crew execution
        """
        logger.info("Starting full patient journey optimization pipeline...")
        start_time = datetime.now()

        crew = self.create_crew()
        result = crew.kickoff()

        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"Full pipeline completed in {duration:.2f} seconds")

        return result

    def run_data_to_pathway_pipeline(self) -> Any:
        """
        Run a streamlined pipeline from data aggregation to pathway analysis.

        This workflow focuses on data collection and clinical pathway mapping.

        Returns:
            The result of the crew execution
        """
        logger.info("Starting data-to-pathway pipeline...")
        start_time = datetime.now()

        crew = self.create_crew(
            agents=['patient_data', 'clinical_pathway'],
            tasks=['patient_data', 'clinical_pathway']
        )

        result = crew.kickoff()

        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"Data-to-pathway pipeline completed in {duration:.2f} seconds")

        return result

    def run_compliance_check(self) -> Any:
        """
        Run a compliance-focused workflow.

        This workflow focuses on data collection and HIPAA compliance checking.

        Returns:
            The result of the crew execution
        """
        logger.info("Starting compliance check workflow...")
        start_time = datetime.now()

        crew = self.create_crew(
            agents=['patient_data', 'compliance'],
            tasks=['patient_data', 'compliance']
        )

        result = crew.kickoff()

        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"Compliance check completed in {duration:.2f} seconds")

        return result

    def run_custom_workflow(
        self,
        agents: List[str],
        tasks: List[str],
        process: Process = Process.sequential
    ) -> Any:
        """
        Run a custom workflow with specified agents and tasks.

        Args:
            agents: List of agent keys to include
            tasks: List of task keys to include
            process: CrewAI process type

        Returns:
            The result of the crew execution
        """
        logger.info(f"Starting custom workflow with agents: {agents}, tasks: {tasks}")
        start_time = datetime.now()

        crew = self.create_crew(agents=agents, tasks=tasks, process=process)
        result = crew.kickoff()

        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"Custom workflow completed in {duration:.2f} seconds")

        return result

    def get_agent(self, agent_key: str):
        """Get a specific agent by key."""
        return self.agents.get(agent_key)

    def get_task(self, task_key: str):
        """Get a specific task by key."""
        return self.tasks.get(task_key)

    def list_available_agents(self) -> List[str]:
        """Get list of available agent keys."""
        return list(self.agents.keys())

    def list_available_tasks(self) -> List[str]:
        """Get list of available task keys."""
        return list(self.tasks.keys())


def create_patient_journey_crew(verbose: bool = True) -> PatientJourneyCrew:
    """
    Create and return a Patient Journey Crew instance.

    Args:
        verbose: Whether to enable verbose output

    Returns:
        PatientJourneyCrew instance
    """
    return PatientJourneyCrew(verbose=verbose)


def run_full_pipeline(verbose: bool = True) -> Any:
    """
    Quick function to run the full pipeline.

    Args:
        verbose: Whether to enable verbose output

    Returns:
        The result of the crew execution
    """
    crew_orchestrator = PatientJourneyCrew(verbose=verbose)
    return crew_orchestrator.run_full_pipeline()
