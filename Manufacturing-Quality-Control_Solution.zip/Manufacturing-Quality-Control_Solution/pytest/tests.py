"""
Comprehensive Test Suite for Manufacturing Quality Control Solution
All test cases using pytest
"""

import pytest
import ast
import json
from datetime import datetime
from unittest.mock import Mock, patch

# Import tools to test
from tools.quality_inspection_tool import QualityInspectionTool


# ==================== FIXTURES ====================

@pytest.fixture
def sample_inspection_type():
    """Sample inspection type for testing"""
    return "visual"


@pytest.fixture
def sample_inspection_data():
    """Sample inspection data for testing"""
    return {
        "total_units": 1000,
        "defective_units": 45,
        "defect_rate": 4.5,
        "yield_rate": 95.5,
        "first_pass_quality": 93.2,
        "defects_by_type": {
            "dimensional": 12,
            "surface_defect": 15,
            "functional_failure": 5,
            "material_defect": 8,
            "assembly_error": 5
        },
        "severity_breakdown": {
            "critical": 2,
            "major": 15,
            "minor": 20,
            "cosmetic": 8
        }
    }


@pytest.fixture
def sample_defect_analysis():
    """Sample defect analysis data for testing"""
    return {
        "status": "success",
        "critical_defects": 2,
        "major_defects": 15,
        "minor_defects": 20,
        "top_defect_type": "dimensional",
        "pareto_analysis": {
            "top_contributors": ["surface_defect", "dimensional", "material_defect"]
        },
        "trend": "stable"
    }


@pytest.fixture
def sample_root_cause_findings():
    """Sample root cause findings for testing"""
    return {
        "status": "success",
        "root_causes": [
            {
                "issue": "Machine calibration drift",
                "category": "Machine",
                "severity": "high"
            },
            {
                "issue": "Inadequate operator training",
                "category": "Man",
                "severity": "medium"
            },
            {
                "issue": "Material specification variance",
                "category": "Material",
                "severity": "high"
            }
        ],
        "5_whys_analysis": {
            "defect": "dimensional_variation",
            "root_cause": "machine_calibration_drift"
        }
    }


@pytest.fixture
def sample_improvement_plan():
    """Sample improvement plan for testing"""
    return {
        "status": "success",
        "recommendations": [
            {
                "priority": "high",
                "action": "Implement preventive maintenance schedule",
                "category": "Machine",
                "expected_impact": "30% reduction in machine-related defects"
            },
            {
                "priority": "high",
                "action": "Enhanced operator training program",
                "category": "Man",
                "expected_impact": "25% reduction in operator errors"
            },
            {
                "priority": "medium",
                "action": "Supplier quality audits",
                "category": "Material",
                "expected_impact": "20% reduction in material defects"
            }
        ],
        "total_recommendations": 3
    }


# ==================== TEST CASES ====================

class TestQualityInspectionTool:
    """Test cases for QualityInspectionTool"""

    def test_quality_inspection_tool_returns_valid_structure(self, sample_inspection_type):
        """Test Case 1: Verify QualityInspectionTool returns valid structure"""
        tool = QualityInspectionTool()
        result = tool._run(inspection_type=sample_inspection_type)

        # Verify result is a string report
        assert isinstance(result, str)
        assert "Quality Inspection Report" in result
        assert "Production Metrics" in result
        assert "Defects by Type" in result

    def test_quality_inspection_tool_includes_all_metrics(self):
        """Test Case 2: Verify QualityInspectionTool includes all required metrics"""
        tool = QualityInspectionTool()
        result = tool._run(inspection_type="dimensional")

        # Check for all required sections
        assert "Total Units Inspected" in result
        assert "Defective Units" in result
        assert "Defect Rate" in result
        assert "Yield Rate" in result
        assert "First Pass Quality" in result
        assert "Process Capability" in result
        assert "Cpk Index" in result
        assert "Sigma Level" in result

    def test_quality_inspection_tool_includes_defect_breakdown(self):
        """Test Case 3: Verify QualityInspectionTool includes defect breakdown"""
        tool = QualityInspectionTool()
        result = tool._run(inspection_type="functional")

        # Check for defect types
        assert "Dimensional Issues" in result
        assert "Surface Defects" in result
        assert "Functional Failures" in result
        assert "Material Defects" in result
        assert "Assembly Errors" in result

    def test_quality_inspection_tool_includes_severity_levels(self):
        """Test Case 4: Verify QualityInspectionTool includes severity breakdown"""
        tool = QualityInspectionTool()
        result = tool._run(inspection_type="visual")

        # Check for severity levels
        assert "Severity Breakdown" in result
        assert "Critical" in result
        assert "Major" in result
        assert "Minor" in result
        assert "Cosmetic" in result

    def test_quality_inspection_tool_different_inspection_types(self):
        """Test Case 5: Verify QualityInspectionTool works with different inspection types"""
        tool = QualityInspectionTool()

        inspection_types = ["visual", "dimensional", "functional", "material", "surface"]

        for inspection_type in inspection_types:
            result = tool._run(inspection_type=inspection_type)
            assert isinstance(result, str)
            assert inspection_type.upper() in result
            assert "Quality Inspection Report" in result

    def test_quality_inspection_tool_includes_quality_trends(self):
        """Test Case 6: Verify QualityInspectionTool includes quality trends"""
        tool = QualityInspectionTool()
        result = tool._run(inspection_type="visual")

        # Check for trend analysis
        assert "Quality Trends" in result
        assert "Week-over-Week Change" in result
        assert "Month-over-Month Change" in result


class TestQualityControlFlow:
    """Test cases for Quality Control Flow"""

    def test_flow_initialization(self):
        """Test Case 7: Verify Quality Control Flow initializes correctly"""
        from flows.quality_control_flow import QualityControlFlow

        flow = QualityControlFlow(verbose=False)

        assert flow.verbose == False
        assert flow.defect_rate == 0.0
        assert flow.critical_defects == 0
        assert isinstance(flow.inspection_data, dict)
        assert isinstance(flow.execution_metrics, dict)

    def test_flow_state_management(self):
        """Test Case 8: Verify Flow maintains state correctly"""
        from flows.quality_control_flow import QualityControlFlow

        flow = QualityControlFlow(verbose=False)

        # Set some state
        flow.defect_rate = 4.5
        flow.critical_defects = 2

        assert flow.defect_rate == 4.5
        assert flow.critical_defects == 2


class TestAgentCreation:
    """Test cases for Agent creation functions"""

    def test_quality_inspector_agent_creation(self):
        """Test Case 9: Verify Quality Inspector Agent is created correctly"""
        from agents.quality_inspector_agent import create_quality_inspector_agent

        agent = create_quality_inspector_agent()

        assert agent.role == "Quality Inspector Specialist"
        assert agent.verbose == True
        assert len(agent.tools) > 0

    def test_defect_analyzer_agent_creation(self):
        """Test Case 10: Verify Defect Analyzer Agent is created correctly"""
        from agents.defect_analyzer_agent import create_defect_analyzer_agent

        agent = create_defect_analyzer_agent()

        assert agent.role == "Defect Analysis Expert"
        assert agent.verbose == True

    def test_root_cause_investigator_agent_creation(self):
        """Test Case 11: Verify Root Cause Investigator Agent is created correctly"""
        from agents.root_cause_investigator_agent import create_root_cause_investigator_agent

        agent = create_root_cause_investigator_agent()

        assert agent.role == "Root Cause Analysis Specialist"
        assert agent.verbose == True

    def test_improvement_recommender_agent_creation(self):
        """Test Case 12: Verify Improvement Recommender Agent is created correctly"""
        from agents.improvement_recommender_agent import create_improvement_recommender_agent

        agent = create_improvement_recommender_agent()

        assert agent.role == "Quality Improvement Strategist"
        assert agent.verbose == True


class TestTaskCreation:
    """Test cases for Task creation"""

    def test_quality_inspection_task_structure(self):
        """Test Case 13: Verify Quality Inspection Task has correct structure"""
        from tasks.quality_inspection_tasks import quality_inspection_task

        assert quality_inspection_task.description is not None
        assert quality_inspection_task.expected_output is not None
        assert quality_inspection_task.agent is not None
        assert "inspection" in quality_inspection_task.description.lower()

    def test_defect_analysis_task_structure(self):
        """Test Case 14: Verify Defect Analysis Task has correct structure"""
        from tasks.defect_analysis_tasks import defect_analysis_task

        assert defect_analysis_task.description is not None
        assert defect_analysis_task.expected_output is not None
        assert defect_analysis_task.agent is not None
        assert "pareto" in defect_analysis_task.description.lower()

    def test_root_cause_investigation_task_structure(self):
        """Test Case 15: Verify Root Cause Investigation Task has correct structure"""
        from tasks.root_cause_investigation_tasks import root_cause_investigation_task

        assert root_cause_investigation_task.description is not None
        assert root_cause_investigation_task.expected_output is not None
        assert root_cause_investigation_task.agent is not None
        assert "5 whys" in root_cause_investigation_task.description.lower()

    def test_improvement_recommendation_task_structure(self):
        """Test Case 16: Verify Improvement Recommendation Task has correct structure"""
        from tasks.improvement_recommendation_tasks import improvement_recommendation_task

        assert improvement_recommendation_task.description is not None
        assert improvement_recommendation_task.expected_output is not None
        assert improvement_recommendation_task.agent is not None
        assert "improvement" in improvement_recommendation_task.description.lower()


class TestConfigurationFiles:
    """Test cases for configuration files"""

    def test_app_config_structure(self):
        """Test Case 17: Verify app_config.json has correct structure"""
        import json
        from pathlib import Path

        config_path = Path(__file__).parent / 'configs' / 'app_config.json'

        with open(config_path, 'r') as f:
            config = json.load(f)

        assert "llm_config" in config
        assert "quality_control_settings" in config
        assert "defect_classification" in config
        assert "improvement_priorities" in config

    def test_llm_config_has_required_fields(self):
        """Test Case 18: Verify LLM config has all required fields"""
        import json
        from pathlib import Path

        config_path = Path(__file__).parent / 'configs' / 'app_config.json'

        with open(config_path, 'r') as f:
            config = json.load(f)

        llm_config = config["llm_config"]

        assert "model" in llm_config
        assert "max_tokens" in llm_config
        assert "temperature" in llm_config
        assert "timeout" in llm_config

    def test_quality_control_settings_structure(self):
        """Test Case 19: Verify quality control settings are properly configured"""
        import json
        from pathlib import Path

        config_path = Path(__file__).parent / 'configs' / 'app_config.json'

        with open(config_path, 'r') as f:
            config = json.load(f)

        qc_settings = config["quality_control_settings"]

        assert "inspection_types" in qc_settings
        assert "metrics_tracked" in qc_settings
        assert "alert_thresholds" in qc_settings
        assert isinstance(qc_settings["inspection_types"], list)
        assert len(qc_settings["inspection_types"]) > 0


class TestUtilityFunctions:
    """Test cases for utility functions"""

    def test_llm_config_utility_returns_model(self):
        """Test Case 20: Verify get_llm_config returns model string"""
        from utils.llm_config import get_llm_config

        model = get_llm_config()

        assert isinstance(model, str)
        assert "gemini" in model.lower()

    def test_output_handler_processes_results(self, sample_inspection_data):
        """Test Case 21: Verify output handler can process results"""
        from utils.output_handler import process_and_save_results

        # Create a test result
        test_result = {
            "status": "completed",
            "results": sample_inspection_data
        }

        # This should return True if successful
        result = process_and_save_results(test_result)

        assert isinstance(result, bool)


# ==================== MAIN ====================

if __name__ == "__main__":
    # Run tests with pytest when executed directly
    pytest.main([__file__, "-v", "--tb=short"])
