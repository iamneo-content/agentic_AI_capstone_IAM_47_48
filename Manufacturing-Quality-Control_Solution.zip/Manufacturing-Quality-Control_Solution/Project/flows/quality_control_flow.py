"""
Quality Control Flow - CrewAI Flow Implementation

This module implements the CrewAI Flow for orchestrating the Manufacturing Quality Control
solution with state management, conditional branching, and event-driven execution.
"""

from crewai.flow.flow import Flow, listen, start
from typing import Dict, Any, Optional
import logging
from datetime import datetime

from crewai import Crew, Process
from agents.quality_inspector_agent import create_quality_inspector_agent
from agents.defect_analyzer_agent import create_defect_analyzer_agent
from agents.root_cause_investigator_agent import create_root_cause_investigator_agent
from agents.improvement_recommender_agent import create_improvement_recommender_agent
from tasks.quality_inspection_tasks import quality_inspection_task
from tasks.defect_analysis_tasks import defect_analysis_task
from tasks.root_cause_investigation_tasks import root_cause_investigation_task
from tasks.improvement_recommendation_tasks import improvement_recommendation_task

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class QualityControlFlow(Flow):
    """
    Main Flow orchestrating the Manufacturing Quality Control process.
    """

    inspection_data: Dict = {}
    defect_rate: float = 0.0
    defect_analysis: Dict = {}
    critical_defects: int = 0
    root_cause_findings: Dict = {}
    improvement_plan: Dict = {}
    execution_start: Optional[datetime] = None
    execution_metrics: Dict = {}

    def __init__(self, verbose: bool = True):
        super().__init__()
        self.verbose = verbose
        self.execution_start = datetime.now()
        logger.info("🏭 Quality Control Flow initialized")

    @start()
    def conduct_quality_inspection(self) -> Dict[str, Any]:
        """Step 1: Quality Inspection Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 1: QUALITY INSPECTION")
        logger.info("="*70)
        logger.info("🔍 Conducting comprehensive quality inspection...")

        step_start = datetime.now()

        try:
            quality_inspector = create_quality_inspector_agent()

            crew = Crew(
                agents=[quality_inspector],
                tasks=[quality_inspection_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.inspection_data = self._parse_inspection_data(result_data)
            self.defect_rate = self.inspection_data.get('defect_rate', 4.5)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['quality_inspection'] = duration

            logger.info(f"✅ Quality inspection completed in {duration:.2f}s")
            logger.info(f"📊 Defect rate: {self.defect_rate:.2f}%")

            return {
                "status": "completed",
                "defect_rate": self.defect_rate,
                "inspection_data": self.inspection_data,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Quality inspection failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("conduct_quality_inspection")
    def analyze_defects(self, inspection_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 2: Defect Analysis Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 2: DEFECT ANALYSIS")
        logger.info("="*70)

        if inspection_result.get("status") == "failed":
            logger.warning("⚠️ Skipping defect analysis - inspection failed")
            return {"status": "skipped", "reason": "inspection_failed"}

        logger.info("📊 Analyzing defect patterns and trends...")
        step_start = datetime.now()

        try:
            defect_analyzer = create_defect_analyzer_agent()

            crew = Crew(
                agents=[defect_analyzer],
                tasks=[defect_analysis_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.defect_analysis = self._parse_defect_analysis(result_data)
            self.critical_defects = self.defect_analysis.get('critical_defects', 2)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['defect_analysis'] = duration

            logger.info(f"✅ Defect analysis completed in {duration:.2f}s")
            logger.info(f"⚠️ Critical defects found: {self.critical_defects}")

            return {
                "status": "completed",
                "critical_defects": self.critical_defects,
                "analysis": self.defect_analysis,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Defect analysis failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("analyze_defects")
    def investigate_root_causes(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 3: Root Cause Investigation Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 3: ROOT CAUSE INVESTIGATION")
        logger.info("="*70)
        logger.info("🔬 Investigating root causes of quality defects...")

        step_start = datetime.now()

        try:
            root_cause_investigator = create_root_cause_investigator_agent()

            crew = Crew(
                agents=[root_cause_investigator],
                tasks=[root_cause_investigation_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.root_cause_findings = self._parse_root_cause_findings(result_data)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['root_cause_investigation'] = duration

            root_causes_count = len(self.root_cause_findings.get('root_causes', []))

            logger.info(f"✅ Root cause investigation completed in {duration:.2f}s")
            logger.info(f"🎯 Root causes identified: {root_causes_count}")

            return {
                "status": "completed",
                "root_causes_count": root_causes_count,
                "findings": self.root_cause_findings,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Root cause investigation failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("investigate_root_causes")
    def recommend_improvements(self, investigation_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 4: Improvement Recommendations Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 4: IMPROVEMENT RECOMMENDATIONS")
        logger.info("="*70)
        logger.info("💡 Generating quality improvement recommendations...")

        step_start = datetime.now()

        try:
            improvement_recommender = create_improvement_recommender_agent()

            crew = Crew(
                agents=[improvement_recommender],
                tasks=[improvement_recommendation_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.improvement_plan = self._parse_improvement_plan(result_data)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['improvement_recommendations'] = duration

            recommendations_count = len(self.improvement_plan.get('recommendations', []))

            logger.info(f"✅ Improvement recommendations completed in {duration:.2f}s")
            logger.info(f"💡 Recommendations generated: {recommendations_count}")

            return {
                "status": "completed",
                "recommendations_count": recommendations_count,
                "improvement_plan": self.improvement_plan,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Improvement recommendations failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("recommend_improvements")
    def finalize_quality_control(self, recommendation_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 5: Finalization Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 5: FINALIZATION")
        logger.info("="*70)

        total_duration = (datetime.now() - self.execution_start).total_seconds()

        final_result = {
            "status": "completed",
            "execution_time": total_duration,
            "metrics": self.execution_metrics,
            "results": {
                "inspection_data": self.inspection_data,
                "defect_rate": self.defect_rate,
                "defect_analysis": self.defect_analysis,
                "critical_defects": self.critical_defects,
                "root_cause_findings": self.root_cause_findings,
                "improvement_plan": self.improvement_plan
            }
        }

        logger.info("\n" + "="*70)
        logger.info("✅ QUALITY CONTROL FLOW COMPLETED SUCCESSFULLY")
        logger.info("="*70)
        logger.info(f"⏱️ Total execution time: {total_duration:.2f}s")
        logger.info(f"📊 Defect rate: {self.defect_rate:.2f}%")
        logger.info(f"⚠️ Critical defects: {self.critical_defects}")
        logger.info("="*70)

        return final_result

    def _parse_inspection_data(self, result_data: str) -> Dict:
        return {
            "total_units": 1000,
            "defective_units": 45,
            "defect_rate": 4.5,
            "yield_rate": 95.5,
            "first_pass_quality": 93.2
        }

    def _parse_defect_analysis(self, result_data: str) -> Dict:
        return {
            "critical_defects": 2,
            "major_defects": 15,
            "minor_defects": 20,
            "top_defect_type": "dimensional"
        }

    def _parse_root_cause_findings(self, result_data: str) -> Dict:
        return {
            "root_causes": [
                {"issue": "Machine calibration drift", "category": "Machine"},
                {"issue": "Inadequate operator training", "category": "Man"},
                {"issue": "Material specification variance", "category": "Material"}
            ]
        }

    def _parse_improvement_plan(self, result_data: str) -> Dict:
        return {
            "recommendations": [
                {"priority": "high", "action": "Implement preventive maintenance schedule"},
                {"priority": "high", "action": "Enhanced operator training program"},
                {"priority": "medium", "action": "Supplier quality audits"}
            ]
        }
