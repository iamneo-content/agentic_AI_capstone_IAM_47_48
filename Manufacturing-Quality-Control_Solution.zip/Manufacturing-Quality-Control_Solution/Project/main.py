"""
Manufacturing Quality Control Solution - Main Entry Point

This is the main entry point for the Manufacturing Quality Control Solution.
It uses CrewAI Flow for orchestrating the quality control pipeline.
"""

import logging
import os
from dotenv import load_dotenv
from flows.quality_control_flow import QualityControlFlow
from utils.output_handler import process_and_save_results

load_dotenv()

os.environ['OTEL_SDK_DISABLED'] = 'true'
os.environ['DO_NOT_TRACK'] = '1'

logging.getLogger('crewai.telemetry.telemetry').setLevel(logging.CRITICAL)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """
    Main execution function - Entry point for the application.

    Returns:
        Flow execution results or None on error
    """
    try:
        logger.info("=" * 70)
        logger.info("🏭 Manufacturing Quality Control Solution with CrewAI Flow")
        logger.info("=" * 70)

        logger.info("\n🎯 Flow Architecture:")
        logger.info("  1. Quality Inspection → Conduct comprehensive quality inspections")
        logger.info("  2. Defect Analysis → Analyze defect patterns and trends")
        logger.info("  3. Root Cause Investigation → Identify root causes of defects")
        logger.info("  4. Improvement Recommendations → Generate actionable improvements")
        logger.info("  5. Finalization → Aggregate results and generate reports")
        logger.info("")

        logger.info("🚀 Starting Quality Control Flow...")
        flow = QualityControlFlow(verbose=True)

        result = flow.kickoff()

        logger.info("\n" + "=" * 70)
        logger.info("Flow execution completed!")
        logger.info("=" * 70)

        if process_and_save_results(result):
            logger.info("\n" + "=" * 70)
            logger.info("SUCCESS: Flow completed successfully!")
            logger.info("All outputs saved to 'outputs' directory")
            logger.info("=" * 70)

            if 'metrics' in result:
                logger.info("\n📊 Flow Execution Metrics:")
                for step, duration in result['metrics'].items():
                    logger.info(f"  - {step}: {duration:.2f}s")
                logger.info(f"  - Total: {result.get('execution_time', 0):.2f}s")
        else:
            logger.warning("⚠️ Failed to process and save results (non-critical)")

        return result

    except Exception as e:
        logger.error(f"\n❌ ERROR: Flow execution failed: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    main()
