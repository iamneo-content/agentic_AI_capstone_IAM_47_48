"""
Quality Inspection Tool

A tool for simulating quality inspection data collection from manufacturing lines.
"""

from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import random


class QualityInspectionInput(BaseModel):
    """Input schema for Quality Inspection Tool."""
    inspection_type: str = Field(..., description="Type of inspection: visual, dimensional, functional, material, surface")


class QualityInspectionTool(BaseTool):
    name: str = "Quality Inspection Data Collector"
    description: str = (
        "Collects quality inspection data from manufacturing production lines. "
        "Provides defect rates, yield metrics, and quality measurements."
    )
    args_schema: Type[BaseModel] = QualityInspectionInput

    def _run(self, inspection_type: str) -> str:
        """
        Simulate quality inspection data collection.

        Args:
            inspection_type: Type of inspection to perform

        Returns:
            Formatted quality inspection data
        """
        # Simulate inspection data
        total_units = random.randint(800, 1200)
        defective_units = random.randint(10, 60)
        defect_rate = (defective_units / total_units) * 100
        yield_rate = 100 - defect_rate

        defects_by_type = {
            "dimensional": random.randint(2, 15),
            "surface_defect": random.randint(3, 20),
            "functional_failure": random.randint(1, 8),
            "material_defect": random.randint(1, 7),
            "assembly_error": random.randint(2, 10)
        }

        severity_breakdown = {
            "critical": random.randint(0, 3),
            "major": random.randint(5, 15),
            "minor": random.randint(10, 30),
            "cosmetic": random.randint(5, 15)
        }

        result = f"""
Quality Inspection Report - {inspection_type.upper()}
{'='*60}

Production Metrics:
- Total Units Inspected: {total_units}
- Defective Units: {defective_units}
- Defect Rate: {defect_rate:.2f}%
- Yield Rate: {yield_rate:.2f}%
- First Pass Quality: {yield_rate - random.uniform(2, 5):.2f}%

Defects by Type:
- Dimensional Issues: {defects_by_type['dimensional']}
- Surface Defects: {defects_by_type['surface_defect']}
- Functional Failures: {defects_by_type['functional_failure']}
- Material Defects: {defects_by_type['material_defect']}
- Assembly Errors: {defects_by_type['assembly_error']}

Severity Breakdown:
- Critical: {severity_breakdown['critical']} defects
- Major: {severity_breakdown['major']} defects
- Minor: {severity_breakdown['minor']} defects
- Cosmetic: {severity_breakdown['cosmetic']} defects

Process Capability:
- Cpk Index: {random.uniform(1.2, 1.8):.2f}
- Sigma Level: {random.uniform(3.5, 5.0):.2f}σ

Quality Trends:
- Week-over-Week Change: {random.uniform(-5, 3):.1f}%
- Month-over-Month Change: {random.uniform(-8, 5):.1f}%
"""
        return result
