"""
Quality Inspector Agent

This agent performs comprehensive quality inspections on manufactured products
to identify defects and quality issues.
"""

from crewai import Agent
from tools.quality_inspection_tool import QualityInspectionTool
from utils.llm_config import get_llm_config


def create_quality_inspector_agent():
    """
    Create the Quality Inspector Agent.

    This agent conducts detailed quality inspections to identify defects,
    measure quality metrics, and assess production output quality.

    Returns:
        Configured Agent for quality inspection
    """
    llm = get_llm_config()

    quality_inspection_tool = QualityInspectionTool()

    agent = Agent(
        role="Quality Inspector Specialist",
        goal="Conduct comprehensive quality inspections to identify defects, measure quality metrics, and ensure products meet specifications",
        backstory="""You are an expert quality inspector with decades of experience in
        manufacturing quality control. You excel at visual inspection, dimensional measurement,
        functional testing, and material analysis. Your keen eye for detail helps identify even
        the smallest defects that could impact product quality. You understand ISO 9001 standards,
        Six Sigma methodologies, and statistical process control. You work with precision
        measurement equipment, automated inspection systems, and maintain detailed inspection
        records to ensure consistent product quality.""",
        llm=llm,
        tools=[quality_inspection_tool],
        verbose=True
    )

    return agent
