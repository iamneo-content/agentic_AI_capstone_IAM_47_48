"""
Defect Analyzer Agent

This agent analyzes defect patterns and trends to understand quality issues.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_defect_analyzer_agent():
    """
    Create the Defect Analyzer Agent.

    This agent analyzes defect data to identify patterns, trends, and correlations
    in manufacturing quality issues.

    Returns:
        Configured Agent for defect analysis
    """
    llm = get_llm_config()

    agent = Agent(
        role="Defect Analysis Expert",
        goal="Analyze defect patterns, identify trends, and classify quality issues to understand their impact and frequency",
        backstory="""You are a manufacturing quality analyst with expertise in statistical
        analysis, defect classification, and quality trend analysis. You excel at identifying
        patterns in defect data, correlating quality issues with process parameters, and using
        data visualization to communicate insights. You're skilled in Pareto analysis, control
        charts, and defect categorization. Your analytical approach helps manufacturing teams
        understand the root causes of quality problems and prioritize improvement efforts.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
