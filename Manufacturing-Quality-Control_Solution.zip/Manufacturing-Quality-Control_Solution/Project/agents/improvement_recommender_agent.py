"""
Improvement Recommender Agent

This agent generates actionable recommendations for quality improvement.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_improvement_recommender_agent():
    """
    Create the Improvement Recommender Agent.

    This agent generates practical, actionable recommendations for improving
    manufacturing quality and reducing defects.

    Returns:
        Configured Agent for improvement recommendations
    """
    llm = get_llm_config()

    agent = Agent(
        role="Quality Improvement Strategist",
        goal="Develop practical, actionable recommendations to improve manufacturing quality, reduce defects, and enhance process capability",
        backstory="""You are a continuous improvement expert with deep knowledge of Lean
        Manufacturing, Six Sigma, and Total Quality Management principles. You excel at
        translating quality data and root cause analysis into specific, implementable
        improvement actions. You understand the balance between cost, quality, and production
        efficiency. Your recommendations are practical, prioritized, and include clear
        implementation steps. You consider equipment upgrades, process modifications, training
        needs, and preventive measures to create comprehensive improvement plans that deliver
        measurable results.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
