"""
Root Cause Investigator Agent

This agent investigates the root causes of quality defects and failures.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_root_cause_investigator_agent():
    """
    Create the Root Cause Investigator Agent.

    This agent performs detailed root cause analysis to identify the underlying
    reasons for quality defects and production failures.

    Returns:
        Configured Agent for root cause investigation
    """
    llm = get_llm_config()

    agent = Agent(
        role="Root Cause Analysis Specialist",
        goal="Investigate manufacturing defects using systematic methods to identify root causes and prevent recurrence",
        backstory="""You are a Six Sigma Black Belt with extensive experience in root cause
        analysis methodologies including 5 Whys, Fishbone diagrams, and Failure Mode Effects
        Analysis (FMEA). You excel at investigating complex quality issues, interviewing
        production personnel, analyzing process data, and identifying systemic problems. Your
        systematic approach helps teams move beyond symptoms to address fundamental causes of
        quality defects. You understand manufacturing processes, material science, and equipment
        performance to provide comprehensive root cause analysis.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
