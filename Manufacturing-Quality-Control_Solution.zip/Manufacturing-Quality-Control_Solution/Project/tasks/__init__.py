"""Tasks package initialization"""
