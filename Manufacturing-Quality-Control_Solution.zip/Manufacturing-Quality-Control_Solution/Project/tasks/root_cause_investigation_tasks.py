"""
Root Cause Investigation Tasks

Tasks for investigating the root causes of quality defects.
"""

from crewai import Task
from agents.root_cause_investigator_agent import create_root_cause_investigator_agent

root_cause_investigation_task = Task(
    description="""Investigate root causes of identified quality defects using systematic methods.

    Your tasks:
    1. Apply 5 Whys methodology to drill down to fundamental causes
    2. Create Fishbone diagrams to explore all potential contributing factors
    3. Analyze the 6Ms: Man, Machine, Material, Method, Measurement, Mother Nature
    4. Investigate process parameters and their relationship to defects
    5. Review equipment performance and maintenance records
    6. Examine operator training and work instructions
    7. Identify systemic issues vs. random variations
    8. Validate root causes with supporting evidence

    Be thorough and systematic in your investigation.""",

    expected_output="""A comprehensive root cause analysis report containing:
    - 5 Whys analysis for major defect types
    - Fishbone diagram identifying all contributing factors
    - Analysis of the 6Ms (Man, Machine, Material, Method, Measurement, Environment)
    - Identified root causes with supporting evidence
    - Distinction between systemic and random issues
    - Process parameter correlations
    - Equipment and maintenance findings
    - Training and procedure gaps identified""",

    agent=create_root_cause_investigator_agent()
)
