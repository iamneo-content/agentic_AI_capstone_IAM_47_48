"""
Defect Analysis Tasks

Tasks for analyzing defect patterns and trends.
"""

from crewai import Task
from agents.defect_analyzer_agent import create_defect_analyzer_agent

defect_analysis_task = Task(
    description="""Analyze defect patterns and quality trends from inspection data.

    Your tasks:
    1. Perform Pareto analysis to identify the most critical defect types
    2. Analyze defect trends over time (daily, weekly, monthly)
    3. Identify correlations between defect types and production conditions
    4. Assess defect severity distribution and its impact on quality
    5. Compare current quality performance against targets and benchmarks
    6. Identify emerging quality issues that require immediate attention
    7. Provide statistical insights into defect patterns

    Use data-driven analysis to uncover meaningful insights.""",

    expected_output="""A detailed defect analysis report containing:
    - Pareto chart of top defect contributors
    - Defect trend analysis with statistical insights
    - Severity impact assessment
    - Quality performance vs. targets comparison
    - Identification of critical quality issues
    - Data-driven insights and patterns
    - Recommended focus areas for improvement""",

    agent=create_defect_analyzer_agent()
)
