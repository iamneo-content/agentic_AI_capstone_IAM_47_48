"""
Improvement Recommendation Tasks

Tasks for generating quality improvement recommendations.
"""

from crewai import Task
from agents.improvement_recommender_agent import create_improvement_recommender_agent

improvement_recommendation_task = Task(
    description="""Develop actionable recommendations to improve manufacturing quality.

    Your tasks:
    1. Prioritize improvement opportunities based on impact and feasibility
    2. Develop specific corrective actions for identified root causes
    3. Design preventive measures to avoid defect recurrence
    4. Recommend process improvements and optimization strategies
    5. Suggest equipment upgrades or modifications if needed
    6. Identify training needs and competency development areas
    7. Propose quality control enhancements and inspection improvements
    8. Establish metrics to track improvement effectiveness
    9. Create implementation roadmap with clear action items

    Provide practical, cost-effective recommendations.""",

    expected_output="""A comprehensive quality improvement plan containing:
    - Prioritized list of improvement opportunities
    - Specific corrective actions for each root cause
    - Preventive measures to avoid recurrence
    - Process optimization recommendations
    - Equipment and technology recommendations
    - Training and development needs
    - Enhanced quality control procedures
    - Key performance indicators to track progress
    - Implementation roadmap with timeline and responsibilities
    - Expected impact on quality metrics (defect reduction, yield improvement)""",

    agent=create_improvement_recommender_agent()
)
