"""
Quality Inspection Tasks

Tasks for conducting quality inspections on manufactured products.
"""

from crewai import Task
from agents.quality_inspector_agent import create_quality_inspector_agent

quality_inspection_task = Task(
    description="""Conduct comprehensive quality inspection of manufactured products.

    Your tasks:
    1. Perform visual, dimensional, functional, and material inspections
    2. Collect quality metrics including defect rates, yield rates, and first pass quality
    3. Identify and categorize all defects by type and severity
    4. Measure process capability indices (Cpk, Sigma level)
    5. Document quality trends and changes over time
    6. Provide detailed inspection reports with measurements and observations

    Focus on accuracy and thoroughness in all inspections.""",

    expected_output="""A comprehensive quality inspection report containing:
    - Production metrics (units inspected, defect rate, yield rate)
    - Detailed defect breakdown by type and severity
    - Process capability measurements
    - Quality trend analysis
    - Statistical quality metrics
    - Inspection observations and notes""",

    agent=create_quality_inspector_agent()
)
