"""
Output Handler Utility

Processes and saves flow execution results to the outputs directory.
"""

import json
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


def process_and_save_results(result):
    """
    Process and save flow execution results.

    Args:
        result: Flow execution result

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        output_dir = Path(__file__).parent.parent / 'outputs'
        output_dir.mkdir(exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = output_dir / f"quality_control_report_{timestamp}.json"

        if isinstance(result, dict):
            result_data = result
        else:
            result_data = {"result": str(result)}

        with open(output_file, 'w') as f:
            json.dump(result_data, f, indent=2)

        logger.info(f"Results saved to: {output_file}")
        return True

    except Exception as e:
        logger.error(f"Failed to save results: {e}")
        return False
