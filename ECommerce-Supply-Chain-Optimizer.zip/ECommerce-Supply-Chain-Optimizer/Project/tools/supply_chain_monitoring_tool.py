"""
Supply Chain Monitoring Tool

This tool simulates real-time supply chain monitoring including inventory levels,
order fulfillment, logistics performance, and supplier metrics.
"""

from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import random


class SupplyChainMonitoringInput(BaseModel):
    """Input schema for Supply Chain Monitoring."""
    analysis_type: str = Field(
        ...,
        description="Type of supply chain analysis to perform: 'inventory', 'logistics', 'demand', 'supplier'"
    )


class SupplyChainMonitoringTool(BaseTool):
    name: str = "Supply Chain Analytics and Monitoring System"
    description: str = "Monitors and analyzes supply chain metrics including inventory, logistics, demand, and supplier performance"
    args_schema: Type[BaseModel] = SupplyChainMonitoringInput

    def _run(self, analysis_type: str) -> str:
        """
        Execute supply chain monitoring and analysis.

        Args:
            analysis_type: Type of analysis (inventory, logistics, demand, supplier)

        Returns:
            Formatted supply chain analytics report
        """
        # Generate realistic supply chain metrics
        total_skus = random.randint(1500, 3500)
        total_warehouses = random.randint(3, 8)
        total_suppliers = random.randint(50, 150)
        monthly_orders = random.randint(15000, 45000)

        inventory_turnover = round(random.uniform(4.5, 12.0), 2)
        stockout_rate = round(random.uniform(0.5, 4.5), 2)
        carrying_cost_percent = round(random.uniform(15, 30), 1)

        avg_delivery_days = round(random.uniform(2.0, 7.0), 1)
        on_time_delivery = round(random.uniform(88.0, 98.5), 1)
        shipping_cost_per_order = round(random.uniform(5.50, 15.50), 2)

        demand_variance = round(random.uniform(10, 35), 1)
        forecast_accuracy = round(random.uniform(75, 92), 1)

        supplier_quality_score = round(random.uniform(75, 95), 1)
        supplier_lead_time = random.randint(5, 21)
        supplier_defect_rate = round(random.uniform(0.2, 3.5), 2)

        # Generate warehouse data
        warehouses = []
        warehouse_names = ["East Coast Hub", "West Coast Hub", "Central Hub", "Southern Hub", "International Hub"]
        for i in range(min(total_warehouses, len(warehouse_names))):
            warehouses.append({
                "name": warehouse_names[i],
                "capacity_utilization": round(random.uniform(65, 95), 1),
                "inventory_value": random.randint(500000, 2500000),
                "picking_accuracy": round(random.uniform(96, 99.5), 1)
            })

        # Generate product category performance
        categories = ["Electronics", "Apparel", "Home & Garden", "Sports & Outdoors", "Books & Media"]
        category_performance = []
        for cat in categories:
            category_performance.append({
                "category": cat,
                "sales_volume": random.randint(2000, 8000),
                "turnover_rate": round(random.uniform(4, 15), 1),
                "margin_percent": round(random.uniform(15, 45), 1)
            })

        # Generate top suppliers
        top_suppliers = random.randint(3, 5)
        suppliers_data = []
        for i in range(top_suppliers):
            suppliers_data.append({
                "supplier": f"Supplier_{chr(65+i)}",
                "quality_score": round(random.uniform(80, 98), 1),
                "on_time_delivery": round(random.uniform(85, 99), 1),
                "cost_rating": random.choice(["Competitive", "Above Average", "Premium"])
            })

        # Generate route optimization data
        routes = random.randint(15, 40)
        route_efficiency = round(random.uniform(78, 94), 1)
        fuel_cost_savings = round(random.uniform(8000, 25000), 2)

        # Generate demand forecast data
        next_month_demand = random.randint(16000, 50000)
        seasonal_factor = round(random.uniform(0.8, 1.4), 2)
        trending_products = random.randint(120, 350)

        report = f"""
ECommerce Supply Chain Optimization Report - {analysis_type.upper()}
======================================================================

Supply Chain Overview:
- Total SKUs Managed: {total_skus:,}
- Active Warehouses: {total_warehouses}
- Supplier Network: {total_suppliers} suppliers
- Monthly Order Volume: {monthly_orders:,} orders
- Order Fulfillment Rate: {on_time_delivery}%

Inventory Management Metrics:
- Inventory Turnover Rate: {inventory_turnover}x per year
- Stockout Rate: {stockout_rate}%
- Carrying Cost: {carrying_cost_percent}% of inventory value
- Average Stock Coverage: {random.randint(25, 60)} days
- Slow-Moving Items: {random.randint(150, 450)} SKUs
- Out-of-Stock Items: {random.randint(15, 85)} SKUs

Warehouse Performance:
"""
        for wh in warehouses:
            report += f"- {wh['name']}: {wh['capacity_utilization']}% utilized, ${wh['inventory_value']:,} inventory, {wh['picking_accuracy']}% picking accuracy\n"

        report += f"""
Logistics Performance:
- Average Delivery Time: {avg_delivery_days} days
- On-Time Delivery Rate: {on_time_delivery}%
- Average Shipping Cost per Order: ${shipping_cost_per_order}
- Active Delivery Routes: {routes}
- Route Optimization Efficiency: {route_efficiency}%
- Fuel Cost Savings (YTD): ${fuel_cost_savings:,.2f}
- Returns Rate: {round(random.uniform(2.5, 8.5), 1)}%

Carrier Performance:
- Primary Carriers: {random.randint(3, 6)}
- Carrier Reliability Score: {round(random.uniform(85, 96), 1)}/100
- Package Damage Rate: {round(random.uniform(0.3, 2.1), 2)}%
- Last Mile Delivery Efficiency: {round(random.uniform(82, 94), 1)}%

Demand Forecasting:
- Forecast Accuracy: {forecast_accuracy}%
- Demand Variance: ±{demand_variance}%
- Next Month Projected Demand: {next_month_demand:,} orders
- Seasonal Factor: {seasonal_factor}
- Trending Products: {trending_products} SKUs
- High-Demand Categories: {random.randint(2, 4)}

Product Category Performance:
"""
        for cat_perf in category_performance:
            report += f"- {cat_perf['category']}: {cat_perf['sales_volume']:,} units/month, {cat_perf['turnover_rate']}x turnover, {cat_perf['margin_percent']}% margin\n"

        report += f"""
Supplier Performance:
- Average Supplier Quality Score: {supplier_quality_score}/100
- Average Lead Time: {supplier_lead_time} days
- Average Defect Rate: {supplier_defect_rate}%
- Supplier Compliance Rate: {round(random.uniform(88, 98), 1)}%
- Alternative Suppliers Available: {random.randint(2, 5)} per key component

Top Performing Suppliers:
"""
        for supp in suppliers_data:
            report += f"- {supp['supplier']}: Quality {supp['quality_score']}/100, On-Time {supp['on_time_delivery']}%, Cost: {supp['cost_rating']}\n"

        report += f"""
Cost Analysis:
- Total Supply Chain Cost: ${random.randint(2500000, 8500000):,}/month
- Procurement Costs: ${random.randint(1500000, 5000000):,}/month
- Warehousing Costs: ${random.randint(300000, 1200000):,}/month
- Transportation Costs: ${random.randint(400000, 1800000):,}/month
- Handling & Processing: ${random.randint(150000, 550000):,}/month

Optimization Opportunities:
- Potential Cost Savings: ${random.randint(150000, 650000):,}/year
- Inventory Reduction Opportunity: {round(random.uniform(8, 22), 1)}%
- Route Optimization Potential: {round(random.uniform(5, 18), 1)}% reduction in miles
- Supplier Consolidation Savings: ${random.randint(50000, 250000):,}/year

Risk Assessment:
- Supply Chain Risk Score: {random.randint(35, 75)}/100 (lower is better)
- Single Source Dependencies: {random.randint(8, 28)} SKUs
- Supplier Concentration Risk: {random.choice(["Low", "Medium", "Medium-High"])}
- Inventory Obsolescence Risk: {round(random.uniform(2, 8), 1)}% of inventory value
- Stockout Risk: {random.choice(["Low", "Medium", "High"])} for critical items

Technology & Automation:
- Automated Order Processing: {round(random.uniform(65, 92), 1)}%
- Warehouse Automation Level: {round(random.uniform(45, 85), 1)}%
- Real-Time Inventory Tracking: {round(random.uniform(88, 99), 1)}%
- AI-Powered Demand Forecasting: {random.choice(["Enabled", "Partially Enabled", "In Development"])}

Key Performance Indicators (KPIs):
- Perfect Order Rate: {round(random.uniform(85, 96), 1)}%
- Cash-to-Cash Cycle Time: {random.randint(35, 75)} days
- Supply Chain Cycle Time: {random.randint(15, 35)} days
- Customer Order Cycle Time: {avg_delivery_days} days
- Capacity Utilization: {round(random.uniform(72, 89), 1)}%

Recommendations:
- Optimize inventory levels for slow-moving items
- Implement dynamic routing for cost reduction
- Expand supplier base for high-risk components
- Enhance demand forecasting with AI/ML models
- Increase warehouse automation to improve efficiency
- Negotiate better rates with underperforming carriers
- Implement just-in-time (JIT) for select categories
- Strengthen supplier relationships for critical components
"""

        return report
