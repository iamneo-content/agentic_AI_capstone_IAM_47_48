"""
ECommerce Supply Chain Optimizer - Main Entry Point

This module serves as the entry point for the ECommerce Supply Chain Optimizer
using CrewAI Flow for multi-agent orchestration.
"""

import logging
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

from flows.supply_chain_flow import SupplyChainOptimizationFlow

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def ensure_output_directory() -> Path:
    """Ensure the output directory exists."""
    output_dir = Path(__file__).parent / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def process_and_save_results(result: Dict[str, Any]) -> bool:
    """Process and save the flow execution results."""
    try:
        output_dir = ensure_output_directory()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = output_dir / f"supply_chain_optimization_report_{timestamp}.json"

        # Save results to JSON
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, default=str)

        logger.info(f"📄 Results saved to: {output_file}")

        # Display summary
        if result.get("status") == "completed":
            logger.info("\n" + "="*70)
            logger.info("📊 SUPPLY CHAIN OPTIMIZATION SUMMARY")
            logger.info("="*70)

            results = result.get("results", {})

            logger.info(f"📈 Inventory Turnover: {results.get('inventory_turnover', 0):.1f}x per year")
            logger.info(f"⚠️  Stockout Rate: {results.get('stockout_rate', 0):.1f}%")

            inventory_data = results.get("inventory_data", {})
            logger.info(f"💰 Inventory Optimization Savings: ${inventory_data.get('optimization_savings', 0):,}")
            logger.info(f"📦 Slow-Moving SKUs: {inventory_data.get('slow_moving_skus', 0)}")

            logger.info(f"\n🎯 Demand Forecast Accuracy: {results.get('forecast_accuracy', 0):.1f}%")
            demand_data = results.get("demand_forecast", {})
            logger.info(f"📅 Next 30-Day Demand: {demand_data.get('next_30_day_demand', 0):,} orders")

            logger.info(f"\n🚚 On-Time Delivery Rate: {results.get('on_time_delivery', 0):.1f}%")
            logistics_data = results.get("logistics_data", {})
            logger.info(f"💵 Logistics Cost Savings: ${logistics_data.get('cost_savings', 0):,}")
            logger.info(f"⏱️  Average Delivery Time: {logistics_data.get('avg_delivery_days', 0):.1f} days")

            logger.info(f"\n⭐ Supplier Quality Score: {results.get('supplier_quality_score', 0):.1f}/100")
            supplier_data = results.get("supplier_data", {})
            logger.info(f"⚠️  At-Risk Suppliers: {supplier_data.get('at_risk_suppliers', 0)}")
            logger.info(f"💰 Procurement Savings: ${supplier_data.get('procurement_savings', 0):,}")

            metrics = result.get("metrics", {})
            logger.info(f"\n⏱️  Total Execution Time: {result.get('execution_time', 0):.2f}s")

            # Calculate total savings
            total_savings = (
                inventory_data.get('optimization_savings', 0) +
                logistics_data.get('cost_savings', 0) +
                supplier_data.get('procurement_savings', 0)
            )
            logger.info(f"💎 Total Potential Annual Savings: ${total_savings:,}")

            logger.info("="*70)

            return True

        else:
            logger.error("❌ Flow execution did not complete successfully")
            return False

    except Exception as e:
        logger.error(f"❌ Error processing results: {e}")
        return False


def main():
    """Main execution function."""
    logger.info("="*70)
    logger.info("📦 ECOMMERCE SUPPLY CHAIN OPTIMIZER")
    logger.info("="*70)
    logger.info("🚀 Initializing multi-agent supply chain optimization system...")
    logger.info("="*70 + "\n")

    try:
        # Initialize and run the flow
        flow = SupplyChainOptimizationFlow(verbose=True)
        result = flow.kickoff()

        # Process and save results
        if process_and_save_results(result):
            logger.info("\n✅ SUCCESS: Supply Chain Optimization completed successfully!")
            return result
        else:
            logger.error("\n❌ FAILURE: Flow execution encountered errors")
            return None

    except Exception as e:
        logger.error(f"\n❌ CRITICAL ERROR: {e}", exc_info=True)
        return None


if __name__ == "__main__":
    main()
