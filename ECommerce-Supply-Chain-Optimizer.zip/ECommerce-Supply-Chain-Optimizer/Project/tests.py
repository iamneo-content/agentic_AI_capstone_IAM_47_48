"""
Comprehensive Test Suite for ECommerce Supply Chain Optimizer

This test suite covers all major components of the platform including:
- Tools (SupplyChainMonitoringTool)
- Agents (Inventory, Demand Forecasting, Logistics, Supplier)
- Tasks (All supply chain optimization tasks)
- Flow (SupplyChainOptimizationFlow)
- Configuration files
- Utilities
"""

import pytest
import json
import os
from pathlib import Path
from datetime import datetime

# Import tools
from tools.supply_chain_monitoring_tool import SupplyChainMonitoringTool

# Import agents
from agents.inventory_optimizer_agent import create_inventory_optimizer_agent
from agents.demand_forecasting_agent import create_demand_forecasting_agent
from agents.logistics_coordinator_agent import create_logistics_coordinator_agent
from agents.supplier_performance_agent import create_supplier_performance_agent

# Import tasks
from tasks.inventory_optimization_tasks import inventory_optimization_task
from tasks.demand_forecasting_tasks import demand_forecasting_task
from tasks.logistics_optimization_tasks import logistics_optimization_task
from tasks.supplier_performance_tasks import supplier_performance_task

# Import flow
from flows.supply_chain_flow import SupplyChainOptimizationFlow

# Import utilities
from utils.llm_config import get_llm_config
from utils.output_handler import process_and_save_results


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def sample_analysis_type():
    """Sample analysis type for testing."""
    return "inventory"


@pytest.fixture
def sample_supply_chain_data():
    """Sample supply chain data for testing."""
    return {
        "inventory_turnover": 8.5,
        "stockout_rate": 2.3,
        "on_time_delivery": 94.2,
        "forecast_accuracy": 86.5,
        "supplier_quality_score": 88.7
    }


@pytest.fixture
def config_file_path():
    """Path to configuration file."""
    return Path(__file__).parent / "configs" / "app_config.json"


# ============================================================================
# TOOL TESTS
# ============================================================================

class TestSupplyChainMonitoringTool:
    """Test suite for SupplyChainMonitoringTool."""

    def test_supply_chain_tool_initialization(self):
        """Test that SupplyChainMonitoringTool initializes correctly."""
        tool = SupplyChainMonitoringTool()
        assert tool is not None
        assert tool.name == "Supply Chain Analytics and Monitoring System"
        assert hasattr(tool, '_run')

    def test_supply_chain_tool_returns_valid_structure(self, sample_analysis_type):
        """Test that supply chain tool returns a valid report structure."""
        tool = SupplyChainMonitoringTool()
        result = tool._run(analysis_type=sample_analysis_type)

        assert isinstance(result, str)
        assert "ECommerce Supply Chain Optimization Report" in result
        assert "Supply Chain Overview" in result
        assert "Inventory Management Metrics" in result
        assert "Logistics Performance" in result

    def test_supply_chain_tool_different_analysis_types(self):
        """Test tool with different analysis types."""
        tool = SupplyChainMonitoringTool()
        analysis_types = ["inventory", "logistics", "demand", "supplier"]

        for analysis_type in analysis_types:
            result = tool._run(analysis_type=analysis_type)
            assert isinstance(result, str)
            assert len(result) > 0
            assert analysis_type.upper() in result


# ============================================================================
# AGENT TESTS
# ============================================================================

class TestAgents:
    """Test suite for all supply chain agents."""

    def test_inventory_optimizer_agent_creation(self):
        """Test Inventory Optimizer Agent creation."""
        agent = create_inventory_optimizer_agent()
        assert agent is not None
        assert agent.role == "Inventory Optimization Specialist"
        assert len(agent.tools) > 0

    def test_demand_forecasting_agent_creation(self):
        """Test Demand Forecasting Agent creation."""
        agent = create_demand_forecasting_agent()
        assert agent is not None
        assert agent.role == "Demand Planning and Forecasting Analyst"
        assert hasattr(agent, 'goal')

    def test_logistics_coordinator_agent_creation(self):
        """Test Logistics Coordinator Agent creation."""
        agent = create_logistics_coordinator_agent()
        assert agent is not None
        assert agent.role == "Logistics and Distribution Coordinator"
        assert hasattr(agent, 'backstory')

    def test_supplier_performance_agent_creation(self):
        """Test Supplier Performance Agent creation."""
        agent = create_supplier_performance_agent()
        assert agent is not None
        assert agent.role == "Supplier Performance and Procurement Specialist"
        assert hasattr(agent, 'llm')


# ============================================================================
# TASK TESTS
# ============================================================================

class TestTasks:
    """Test suite for all supply chain tasks."""

    def test_inventory_optimization_task_structure(self):
        """Test inventory optimization task structure."""
        task = inventory_optimization_task
        assert task is not None
        assert hasattr(task, 'description')
        assert hasattr(task, 'expected_output')
        assert hasattr(task, 'agent')
        assert len(task.description) > 0

    def test_demand_forecasting_task_structure(self):
        """Test demand forecasting task structure."""
        task = demand_forecasting_task
        assert task is not None
        assert hasattr(task, 'description')
        assert hasattr(task, 'expected_output')
        assert "forecast" in task.description.lower()

    def test_logistics_optimization_task_structure(self):
        """Test logistics optimization task structure."""
        task = logistics_optimization_task
        assert task is not None
        assert hasattr(task, 'description')
        assert "logistics" in task.description.lower()

    def test_supplier_performance_task_structure(self):
        """Test supplier performance task structure."""
        task = supplier_performance_task
        assert task is not None
        assert hasattr(task, 'description')
        assert "supplier" in task.description.lower()


# ============================================================================
# FLOW TESTS
# ============================================================================

class TestSupplyChainOptimizationFlow:
    """Test suite for SupplyChainOptimizationFlow."""

    def test_flow_initialization(self):
        """Test flow initializes correctly."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        assert flow is not None
        assert hasattr(flow, 'inventory_data')
        assert hasattr(flow, 'inventory_turnover')
        assert hasattr(flow, 'demand_forecast')
        assert hasattr(flow, 'logistics_data')
        assert hasattr(flow, 'supplier_data')
        assert flow.execution_start is not None

    def test_flow_has_required_methods(self):
        """Test flow has all required step methods."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        assert hasattr(flow, 'optimize_inventory')
        assert hasattr(flow, 'forecast_demand')
        assert hasattr(flow, 'optimize_logistics')
        assert hasattr(flow, 'evaluate_suppliers')
        assert hasattr(flow, 'finalize_optimization')

    def test_flow_parsing_methods(self):
        """Test flow has parsing methods for each step."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        assert hasattr(flow, '_parse_inventory_data')
        assert hasattr(flow, '_parse_demand_forecast')
        assert hasattr(flow, '_parse_logistics_data')
        assert hasattr(flow, '_parse_supplier_data')

    def test_flow_parse_inventory_data(self):
        """Test inventory data parsing returns valid structure."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        result = flow._parse_inventory_data("sample result")
        assert isinstance(result, dict)
        assert 'inventory_turnover' in result
        assert 'stockout_rate' in result
        assert 'carrying_cost_percent' in result

    def test_flow_parse_demand_forecast(self):
        """Test demand forecast parsing returns valid structure."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        result = flow._parse_demand_forecast("sample result")
        assert isinstance(result, dict)
        assert 'forecast_accuracy' in result
        assert 'next_30_day_demand' in result
        assert 'seasonal_factor' in result

    def test_flow_parse_logistics_data(self):
        """Test logistics data parsing returns valid structure."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        result = flow._parse_logistics_data("sample result")
        assert isinstance(result, dict)
        assert 'on_time_delivery' in result
        assert 'cost_savings' in result

    def test_flow_parse_supplier_data(self):
        """Test supplier data parsing returns valid structure."""
        flow = SupplyChainOptimizationFlow(verbose=False)
        result = flow._parse_supplier_data("sample result")
        assert isinstance(result, dict)
        assert 'quality_score' in result
        assert 'at_risk_suppliers' in result


# ============================================================================
# CONFIGURATION TESTS
# ============================================================================

class TestConfiguration:
    """Test suite for configuration files."""

    def test_config_file_exists(self, config_file_path):
        """Test that configuration file exists."""
        assert config_file_path.exists()
        assert config_file_path.is_file()

    def test_config_file_valid_json(self, config_file_path):
        """Test that configuration file is valid JSON."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        assert isinstance(config, dict)

    def test_config_has_supply_chain_settings(self, config_file_path):
        """Test configuration has supply chain settings."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        assert 'supply_chain_settings' in config

    def test_config_inventory_metrics(self, config_file_path):
        """Test configuration has inventory metrics defined."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        settings = config['supply_chain_settings']
        assert 'inventory_metrics' in settings
        assert isinstance(settings['inventory_metrics'], list)
        assert len(settings['inventory_metrics']) > 0

    def test_config_optimization_thresholds(self, config_file_path):
        """Test configuration has optimization thresholds."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        settings = config['supply_chain_settings']
        assert 'optimization_thresholds' in settings
        thresholds = settings['optimization_thresholds']
        assert 'min_inventory_turnover' in thresholds
        assert 'max_stockout_rate_percent' in thresholds


# ============================================================================
# UTILITY TESTS
# ============================================================================

class TestUtilities:
    """Test suite for utility functions."""

    def test_get_llm_config(self):
        """Test LLM configuration retrieval."""
        config = get_llm_config()
        assert config is not None
        assert isinstance(config, str)
        assert "gemini" in config.lower()

    def test_process_and_save_results_with_dict(self, sample_supply_chain_data):
        """Test result processing with dictionary data."""
        result = process_and_save_results(sample_supply_chain_data)
        assert isinstance(result, bool)

    def test_process_and_save_results_with_string(self):
        """Test result processing with string data."""
        result = process_and_save_results("test result")
        assert isinstance(result, bool)


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestIntegration:
    """Integration tests for the complete platform."""

    def test_output_directory_creation(self):
        """Test that output directory can be created."""
        output_dir = Path(__file__).parent / "outputs"
        output_dir.mkdir(parents=True, exist_ok=True)
        assert output_dir.exists()
        assert output_dir.is_dir()

    def test_agents_and_tasks_compatibility(self):
        """Test that agents and tasks are compatible."""
        # Each task should have an agent
        assert inventory_optimization_task.agent is not None
        assert demand_forecasting_task.agent is not None
        assert logistics_optimization_task.agent is not None
        assert supplier_performance_task.agent is not None

    def test_supply_chain_metrics_consistency(self):
        """Test that supply chain metrics are consistent across components."""
        flow = SupplyChainOptimizationFlow(verbose=False)

        # Test initial state
        assert flow.inventory_turnover == 0.0
        assert flow.stockout_rate == 0.0
        assert flow.forecast_accuracy == 0.0
        assert flow.on_time_delivery == 0.0
        assert flow.supplier_quality_score == 0.0


# ============================================================================
# RUN TESTS
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
