"""
Inventory Optimization Tasks

Tasks for optimizing inventory levels, warehouse allocation, and stock management.
"""

from crewai import Task
from agents.inventory_optimizer_agent import create_inventory_optimizer_agent

inventory_optimization_task = Task(
    description="""Optimize inventory levels across the supply chain network to minimize costs while maintaining service levels.

    Your tasks:
    1. Analyze current inventory levels, turnover rates, and carrying costs
    2. Identify slow-moving, obsolete, and excess inventory items
    3. Calculate optimal reorder points and safety stock levels for key SKUs
    4. Optimize inventory allocation across multiple warehouse locations
    5. Implement ABC analysis to prioritize inventory management efforts
    6. Calculate economic order quantity (EOQ) for high-volume items
    7. Assess stockout risks and recommend mitigation strategies
    8. Optimize warehouse space utilization and storage strategies
    9. Recommend just-in-time (JIT) or vendor-managed inventory (VMI) opportunities
    10. Develop inventory reduction strategies for overstocked categories

    Focus on balancing inventory costs with customer service level requirements.""",

    expected_output="""A comprehensive inventory optimization report containing:
    - Current inventory performance metrics (turnover, carrying cost, stockout rate)
    - Inventory health assessment by product category and warehouse
    - Slow-moving and obsolete inventory identification (SKUs and values)
    - Optimized reorder points and safety stock recommendations
    - Economic order quantity (EOQ) calculations for top items
    - ABC classification analysis with inventory prioritization
    - Warehouse allocation optimization recommendations
    - Inventory reduction opportunities and expected savings
    - Stockout risk assessment and mitigation strategies
    - Multi-echelon inventory optimization recommendations
    - Just-in-time (JIT) and VMI implementation opportunities
    - Expected inventory cost reduction and ROI analysis""",

    agent=create_inventory_optimizer_agent()
)
