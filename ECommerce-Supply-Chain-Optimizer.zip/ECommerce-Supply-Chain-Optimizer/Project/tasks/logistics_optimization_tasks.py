"""
Logistics Optimization Tasks

Tasks for optimizing shipping routes, carrier performance, and delivery operations.
"""

from crewai import Task
from agents.logistics_coordinator_agent import create_logistics_coordinator_agent

logistics_optimization_task = Task(
    description="""Optimize logistics and distribution operations to reduce costs, improve delivery times, and enhance customer satisfaction.

    Your tasks:
    1. Analyze current shipping routes and identify optimization opportunities
    2. Evaluate carrier performance (on-time delivery, cost, damage rates)
    3. Optimize route planning and load consolidation strategies
    4. Assess last-mile delivery efficiency and improvement opportunities
    5. Implement zone skipping and direct shipping where beneficial
    6. Analyze transportation cost structure and negotiate better carrier rates
    7. Evaluate cross-docking and hub-and-spoke distribution models
    8. Optimize delivery scheduling to reduce transit times
    9. Assess multi-modal transportation opportunities
    10. Implement dynamic routing based on real-time conditions

    Focus on achieving the optimal balance between cost, speed, and service quality.""",

    expected_output="""A comprehensive logistics optimization report containing:
    - Current logistics performance analysis (delivery times, costs, rates)
    - Route optimization recommendations with distance and cost savings
    - Carrier performance evaluation and selection criteria
    - Load consolidation opportunities and freight optimization
    - Last-mile delivery improvements and cost reduction strategies
    - Zone skipping and direct shipping analysis
    - Transportation cost breakdown and negotiation opportunities
    - Cross-docking feasibility assessment
    - Hub-and-spoke network optimization recommendations
    - Multi-modal transportation opportunities
    - Dynamic routing implementation plan
    - Expected cost savings and delivery time improvements
    - Service level impact analysis and customer satisfaction metrics""",

    agent=create_logistics_coordinator_agent()
)
