"""
Demand Forecasting Tasks

Tasks for predicting customer demand and analyzing market trends.
"""

from crewai import Task
from agents.demand_forecasting_agent import create_demand_forecasting_agent

demand_forecasting_task = Task(
    description="""Develop accurate demand forecasts to enable proactive inventory planning and supply chain optimization.

    Your tasks:
    1. Analyze historical sales data and identify demand patterns and trends
    2. Perform seasonal decomposition to understand cyclical demand variations
    3. Identify trending and declining product categories
    4. Forecast demand for the next 30, 60, and 90 days by product category
    5. Assess promotional impact on demand and adjust forecasts accordingly
    6. Analyze demand variability and forecast uncertainty
    7. Identify new product launch demand patterns
    8. Evaluate external factors affecting demand (market trends, competition, economic indicators)
    9. Measure forecast accuracy and identify areas for improvement
    10. Recommend demand sensing and real-time forecasting enhancements

    Focus on providing actionable demand insights for inventory and procurement planning.""",

    expected_output="""A detailed demand forecasting report containing:
    - Historical demand analysis and trend identification
    - Seasonal patterns and cyclical variations by category
    - 30/60/90-day demand forecasts with confidence intervals
    - Trending and declining product identification
    - Promotional impact analysis and adjusted forecasts
    - Demand variability assessment and risk factors
    - New product demand projections
    - External factors and market influences on demand
    - Forecast accuracy metrics (MAPE, MAD, bias)
    - High-risk forecast items requiring closer monitoring
    - Demand sensing recommendations for real-time adjustments
    - Forecast model improvements and optimization opportunities""",

    agent=create_demand_forecasting_agent()
)
