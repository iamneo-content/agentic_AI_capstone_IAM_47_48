"""
Supplier Performance Tasks

Tasks for evaluating suppliers, optimizing procurement, and ensuring supply chain resilience.
"""

from crewai import Task
from agents.supplier_performance_agent import create_supplier_performance_agent

supplier_performance_task = Task(
    description="""Evaluate supplier performance and optimize procurement strategies to ensure supply chain resilience and cost-effectiveness.

    Your tasks:
    1. Assess supplier performance metrics (quality, delivery, cost, responsiveness)
    2. Identify underperforming suppliers and develop improvement plans
    3. Evaluate supplier risk profiles and supply chain vulnerabilities
    4. Analyze single-source dependencies and recommend diversification strategies
    5. Assess total cost of ownership (TCO) for key supplier relationships
    6. Evaluate supplier financial health and business continuity risks
    7. Recommend dual sourcing or alternative supplier strategies
    8. Assess supplier capacity and scalability for growth
    9. Evaluate ethical sourcing and sustainability practices
    10. Develop supplier development and collaboration programs

    Focus on building a resilient, cost-effective, and sustainable supplier network.""",

    expected_output="""A comprehensive supplier performance report containing:
    - Supplier scorecard with quality, delivery, cost, and service metrics
    - Top performing and underperforming supplier identification
    - Supplier improvement plans and development opportunities
    - Supply chain risk assessment by supplier and category
    - Single-source dependency analysis and mitigation strategies
    - Total cost of ownership (TCO) analysis for key suppliers
    - Supplier financial health assessment
    - Dual sourcing and alternative supplier recommendations
    - Supplier capacity and scalability evaluation
    - Ethical sourcing and sustainability assessment
    - Supplier consolidation or expansion opportunities
    - Contract renegotiation recommendations
    - Expected cost savings and risk reduction benefits""",

    agent=create_supplier_performance_agent()
)
