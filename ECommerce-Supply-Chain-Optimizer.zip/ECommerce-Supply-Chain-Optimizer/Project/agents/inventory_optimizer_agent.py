"""
Inventory Optimizer Agent

Specialized agent for optimizing inventory levels, warehouse management,
and stock allocation across the supply chain network.
"""

from crewai import Agent
from tools.supply_chain_monitoring_tool import SupplyChainMonitoringTool
from utils.llm_config import get_llm_config


def create_inventory_optimizer_agent():
    """
    Create and return an Inventory Optimizer Agent.

    Returns:
        Agent: Configured inventory optimization agent
    """
    return Agent(
        role="Inventory Optimization Specialist",
        goal="Optimize inventory levels, minimize carrying costs, and prevent stockouts while maintaining high service levels",
        backstory="""You are an expert in inventory management and optimization with deep knowledge of
        supply chain analytics. You specialize in demand-driven inventory planning, safety stock calculations,
        reorder point optimization, and ABC analysis. You understand economic order quantity (EOQ), just-in-time
        (JIT) principles, and multi-echelon inventory optimization. You have expertise in warehouse management
        systems (WMS), inventory turnover analysis, and seasonal demand patterns. You excel at balancing inventory
        costs with service level requirements and identifying slow-moving or obsolete inventory.""",
        tools=[SupplyChainMonitoringTool()],
        verbose=True,
        llm=get_llm_config()
    )
