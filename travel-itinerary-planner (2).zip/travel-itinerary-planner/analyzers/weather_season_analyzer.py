"""
Weather and Season Analyzer

Analyzes weather patterns, seasonal suitability, and climate considerations
for travel planning.
"""

from typing import Dict, Any, List
import logging


class WeatherSeasonAnalyzer:
    """Analyzer for weather and seasonal suitability"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.weather")

    def analyze_weather_season(
        self,
        destination: str,
        travel_dates: Dict[str, str],
        interests: List[str],
        preferences: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze weather and seasonal suitability

        Args:
            destination: Travel destination
            travel_dates: Start and end dates
            interests: Traveler interests
            preferences: Weather preferences

        Returns:
            Weather and season analysis with suitability scores
        """
        self.logger.info(f"Analyzing weather/season for {destination}")

        # Get seasonal data for destination
        seasonal_data = self._get_seasonal_data(destination, travel_dates)

        # Calculate suitability scores
        weather_score = self._calculate_weather_score(
            seasonal_data, interests, preferences
        )

        # Determine season suitability
        if weather_score >= 9.0:
            suitability = "IDEAL"
        elif weather_score >= 7.5:
            suitability = "EXCELLENT"
        elif weather_score >= 6.0:
            suitability = "GOOD"
        elif weather_score >= 4.5:
            suitability = "ACCEPTABLE"
        else:
            suitability = "CHALLENGING"

        # Generate recommendations
        recommendations = self._generate_weather_recommendations(
            seasonal_data, suitability
        )

        return {
            "agent": "WeatherSeason",
            "status": "success",
            "weather_score": weather_score,
            "season_suitability": suitability,
            "season": seasonal_data.get("season", "unknown"),
            "average_temp": seasonal_data.get("avg_temp", 0),
            "rainfall_probability": seasonal_data.get("rainfall_prob", 0),
            "peak_season": seasonal_data.get("is_peak_season", False),
            "crowd_level": seasonal_data.get("crowd_level", "moderate"),
            "weather_highlights": seasonal_data.get("highlights", []),
            "weather_concerns": seasonal_data.get("concerns", []),
            "packing_recommendations": self._generate_packing_tips(seasonal_data),
            "weather_recommendations": recommendations
        }

    def _get_seasonal_data(
        self,
        destination: str,
        travel_dates: Dict[str, str]
    ) -> Dict[str, Any]:
        """Get seasonal weather data for destination (simplified)"""
        # Sample seasonal data (would use real weather API)
        seasonal_database = {
            "Paris": {
                "spring": {
                    "season": "Spring",
                    "avg_temp": 15,
                    "rainfall_prob": 40,
                    "is_peak_season": True,
                    "crowd_level": "high",
                    "highlights": ["Mild weather", "Blooming gardens", "Outdoor cafes"],
                    "concerns": ["Occasional rain", "Higher prices"]
                },
                "summer": {
                    "season": "Summer",
                    "avg_temp": 25,
                    "rainfall_prob": 20,
                    "is_peak_season": True,
                    "crowd_level": "very_high",
                    "highlights": ["Warm weather", "Long daylight hours", "Festivals"],
                    "concerns": ["Crowds", "High prices", "Can be hot"]
                },
                "fall": {
                    "season": "Fall",
                    "avg_temp": 16,
                    "rainfall_prob": 35,
                    "is_peak_season": False,
                    "crowd_level": "moderate",
                    "highlights": ["Pleasant weather", "Fall colors", "Lower prices"],
                    "concerns": ["Shorter days", "Some rain"]
                },
                "winter": {
                    "season": "Winter",
                    "avg_temp": 7,
                    "rainfall_prob": 45,
                    "is_peak_season": False,
                    "crowd_level": "low",
                    "highlights": ["Festive atmosphere", "Low crowds", "Lower prices"],
                    "concerns": ["Cold weather", "Short days", "Rain"]
                }
            },
            "Bali": {
                "dry_season": {
                    "season": "Dry Season",
                    "avg_temp": 28,
                    "rainfall_prob": 10,
                    "is_peak_season": True,
                    "crowd_level": "high",
                    "highlights": ["Sunny weather", "Perfect for beach", "Clear skies"],
                    "concerns": ["Crowds", "Higher prices"]
                },
                "wet_season": {
                    "season": "Wet Season",
                    "avg_temp": 27,
                    "rainfall_prob": 70,
                    "is_peak_season": False,
                    "crowd_level": "low",
                    "highlights": ["Lush greenery", "Lower prices", "Fewer tourists"],
                    "concerns": ["Heavy rain", "Humidity", "Some closures"]
                }
            },
            "Tokyo": {
                "spring": {
                    "season": "Spring (Cherry Blossom)",
                    "avg_temp": 16,
                    "rainfall_prob": 30,
                    "is_peak_season": True,
                    "crowd_level": "very_high",
                    "highlights": ["Cherry blossoms", "Pleasant weather", "Festivals"],
                    "concerns": ["Very crowded", "High prices", "Book early"]
                },
                "summer": {
                    "season": "Summer",
                    "avg_temp": 28,
                    "rainfall_prob": 50,
                    "is_peak_season": False,
                    "crowd_level": "moderate",
                    "highlights": ["Festivals", "Beach trips nearby"],
                    "concerns": ["Hot and humid", "Rainy season", "Typhoons"]
                },
                "fall": {
                    "season": "Fall",
                    "avg_temp": 18,
                    "rainfall_prob": 25,
                    "is_peak_season": True,
                    "crowd_level": "high",
                    "highlights": ["Fall foliage", "Comfortable weather", "Clear skies"],
                    "concerns": ["Popular season", "Higher prices"]
                },
                "winter": {
                    "season": "Winter",
                    "avg_temp": 8,
                    "rainfall_prob": 20,
                    "is_peak_season": False,
                    "crowd_level": "low",
                    "highlights": ["Lower prices", "Winter illuminations"],
                    "concerns": ["Cold weather", "Some attractions close"]
                }
            }
        }

        # Default to summer season if destination not in database
        default_data = {
            "season": "Summer",
            "avg_temp": 25,
            "rainfall_prob": 30,
            "is_peak_season": True,
            "crowd_level": "moderate",
            "highlights": ["Warm weather"],
            "concerns": ["Check local conditions"]
        }

        dest_data = seasonal_database.get(destination, {"summer": default_data})
        # Simplified: just return summer data (would parse actual dates)
        return list(dest_data.values())[0]

    def _calculate_weather_score(
        self,
        seasonal_data: Dict[str, Any],
        interests: List[str],
        preferences: Dict[str, Any]
    ) -> float:
        """Calculate weather suitability score"""
        score = 7.0  # Base score

        # Temperature preferences
        avg_temp = seasonal_data.get("avg_temp", 20)
        if 18 <= avg_temp <= 26:
            score += 1.5  # Ideal temperature range
        elif 15 <= avg_temp <= 30:
            score += 0.5  # Acceptable range

        # Rainfall consideration
        rainfall = seasonal_data.get("rainfall_prob", 50)
        if rainfall < 20:
            score += 1.5
        elif rainfall < 40:
            score += 0.5
        elif rainfall > 60:
            score -= 1.0

        # Peak season consideration
        is_peak = seasonal_data.get("is_peak_season", False)
        crowd_level = seasonal_data.get("crowd_level", "moderate")

        # Adjust for beach/outdoor interests
        outdoor_interests = ["beach", "hiking", "nature", "adventure", "photography"]
        has_outdoor = any(i in outdoor_interests for i in interests)

        if has_outdoor:
            if rainfall < 30:
                score += 0.5
            else:
                score -= 0.5

        # Crowd preference
        if preferences.get("avoid_crowds", False) and crowd_level in ["very_high", "high"]:
            score -= 0.5

        return min(10.0, max(0.0, score))

    def _generate_weather_recommendations(
        self,
        seasonal_data: Dict[str, Any],
        suitability: str
    ) -> List[str]:
        """Generate weather-related recommendations"""
        recommendations = []

        rainfall = seasonal_data.get("rainfall_prob", 0)
        if rainfall > 50:
            recommendations.append("Pack rain gear and umbrella")
            recommendations.append("Plan indoor activities as backup")

        if seasonal_data.get("is_peak_season", False):
            recommendations.append("Book accommodations and attractions well in advance")

        crowd_level = seasonal_data.get("crowd_level", "moderate")
        if crowd_level in ["very_high", "high"]:
            recommendations.append("Visit popular attractions early morning or late evening")

        if suitability == "CHALLENGING":
            recommendations.append("Consider traveling in a different season for better experience")

        return recommendations

    def _generate_packing_tips(self, seasonal_data: Dict[str, Any]) -> List[str]:
        """Generate packing recommendations based on weather"""
        tips = []

        avg_temp = seasonal_data.get("avg_temp", 20)

        if avg_temp < 10:
            tips.extend(["Warm jacket", "Layers", "Scarf and gloves"])
        elif avg_temp < 18:
            tips.extend(["Light jacket", "Layers", "Long pants"])
        elif avg_temp < 26:
            tips.extend(["Light clothing", "Light jacket for evenings"])
        else:
            tips.extend(["Light, breathable clothing", "Sun protection", "Hat"])

        if seasonal_data.get("rainfall_prob", 0) > 40:
            tips.append("Waterproof jacket or umbrella")

        return tips
