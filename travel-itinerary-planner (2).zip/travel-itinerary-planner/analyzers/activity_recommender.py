"""
Activity Recommender

Recommends activities, attractions, and experiences based on traveler
interests, destination characteristics, and available budget.
"""

from typing import Dict, Any, List
import logging


class ActivityRecommender:
    """Analyzer for activity recommendations"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.activity")

    def recommend_activities(
        self,
        destination: str,
        interests: List[str],
        travel_dates: Dict[str, str],
        budget: float,
        group_size: int,
        travel_style: str,
        destination_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Recommend activities for the itinerary

        Args:
            destination: Travel destination
            interests: Traveler interests
            travel_dates: Start and end dates
            budget: Total budget
            group_size: Number of travelers
            travel_style: Travel style preference
            destination_info: Additional destination information

        Returns:
            Activity recommendations with categorization and scheduling
        """
        self.logger.info(f"Recommending activities for {destination}")

        # Get activity database for destination
        available_activities = self._get_available_activities(destination)

        # Filter and rank activities
        recommended = self._filter_and_rank_activities(
            available_activities, interests, travel_style, budget, group_size
        )

        # Categorize activities
        categorized = self._categorize_activities(recommended)

        # Calculate diversity score
        diversity_score = self._calculate_diversity(categorized)

        # Generate daily activity suggestions
        daily_suggestions = self._suggest_daily_activities(
            recommended, travel_dates
        )

        return {
            "agent": "ActivityRecommender",
            "status": "success",
            "recommended_activities": recommended[:15],  # Top 15
            "categorized_activities": categorized,
            "diversity_score": diversity_score,
            "daily_suggestions": daily_suggestions,
            "total_activities": len(recommended),
            "must_do": self._identify_must_do(recommended),
            "budget_friendly": self._identify_budget_friendly(recommended),
            "activity_tips": self._generate_activity_tips(recommended, interests)
        }

    def _get_available_activities(self, destination: str) -> List[Dict[str, Any]]:
        """Get available activities for destination (simplified database)"""
        # Sample activity database
        activities = {
            "Paris": [
                {"name": "Eiffel Tower Visit", "category": "landmark", "cost": 30, "duration": 2, "interests": ["sightseeing", "photography"]},
                {"name": "Louvre Museum", "category": "museum", "cost": 20, "duration": 4, "interests": ["art", "culture", "history"]},
                {"name": "Seine River Cruise", "category": "experience", "cost": 40, "duration": 2, "interests": ["sightseeing", "relaxation"]},
                {"name": "Montmartre Walking Tour", "category": "tour", "cost": 25, "duration": 3, "interests": ["culture", "art", "walking"]},
                {"name": "French Cooking Class", "category": "experience", "cost": 80, "duration": 3, "interests": ["food", "culture"]},
                {"name": "Notre-Dame Cathedral", "category": "landmark", "cost": 0, "duration": 1, "interests": ["history", "architecture"]},
                {"name": "Champs-Élysées Shopping", "category": "shopping", "cost": 100, "duration": 3, "interests": ["shopping", "sightseeing"]},
            ],
            "Tokyo": [
                {"name": "Senso-ji Temple", "category": "landmark", "cost": 0, "duration": 2, "interests": ["culture", "history", "photography"]},
                {"name": "Tokyo Skytree", "category": "landmark", "cost": 25, "duration": 2, "interests": ["sightseeing", "photography"]},
                {"name": "Tsukiji Fish Market", "category": "market", "cost": 10, "duration": 2, "interests": ["food", "culture"]},
                {"name": "Sushi Making Class", "category": "experience", "cost": 70, "duration": 3, "interests": ["food", "culture"]},
                {"name": "Shibuya Crossing", "category": "attraction", "cost": 0, "duration": 1, "interests": ["sightseeing", "photography"]},
                {"name": "Traditional Tea Ceremony", "category": "experience", "cost": 50, "duration": 2, "interests": ["culture", "tradition"]},
                {"name": "Akihabara Electronics District", "category": "shopping", "cost": 50, "duration": 3, "interests": ["technology", "shopping"]},
            ],
            "Bali": [
                {"name": "Ubud Rice Terraces", "category": "nature", "cost": 5, "duration": 3, "interests": ["nature", "photography", "hiking"]},
                {"name": "Tanah Lot Temple", "category": "landmark", "cost": 3, "duration": 2, "interests": ["culture", "photography"]},
                {"name": "Beach Day at Seminyak", "category": "beach", "cost": 10, "duration": 4, "interests": ["beach", "relaxation"]},
                {"name": "Balinese Cooking Class", "category": "experience", "cost": 40, "duration": 3, "interests": ["food", "culture"]},
                {"name": "Yoga Retreat Session", "category": "wellness", "cost": 30, "duration": 2, "interests": ["wellness", "relaxation"]},
                {"name": "Water Temple Tour", "category": "tour", "cost": 25, "duration": 4, "interests": ["culture", "history"]},
                {"name": "Surfing Lesson", "category": "adventure", "cost": 45, "duration": 2, "interests": ["adventure", "sports", "beach"]},
            ]
        }

        return activities.get(destination, [
            {"name": "City Walking Tour", "category": "tour", "cost": 20, "duration": 3, "interests": ["sightseeing", "culture"]},
            {"name": "Local Museum Visit", "category": "museum", "cost": 15, "duration": 2, "interests": ["culture", "history"]},
            {"name": "Local Market Exploration", "category": "market", "cost": 10, "duration": 2, "interests": ["culture", "shopping"]},
        ])

    def _filter_and_rank_activities(
        self,
        activities: List[Dict[str, Any]],
        interests: List[str],
        travel_style: str,
        budget: float,
        group_size: int
    ) -> List[Dict[str, Any]]:
        """Filter and rank activities based on preferences"""
        ranked = []

        for activity in activities:
            # Calculate relevance score
            score = 0

            # Interest matching
            activity_interests = activity.get("interests", [])
            interest_matches = sum(1 for i in interests if any(
                i.lower() in ai.lower() or ai.lower() in i.lower()
                for ai in activity_interests
            ))
            score += interest_matches * 3

            # Budget consideration
            per_person_cost = activity.get("cost", 0)
            if per_person_cost == 0:
                score += 2  # Free activities get bonus
            elif per_person_cost <= 30:
                score += 1

            # Add score and cost info
            activity["relevance_score"] = score
            activity["total_cost"] = per_person_cost * group_size

            ranked.append(activity)

        # Sort by relevance score
        ranked.sort(key=lambda x: x["relevance_score"], reverse=True)

        return ranked

    def _categorize_activities(
        self,
        activities: List[Dict[str, Any]]
    ) -> Dict[str, List[Dict[str, Any]]]:
        """Categorize activities by type"""
        categorized = {}

        for activity in activities:
            category = activity.get("category", "other")
            if category not in categorized:
                categorized[category] = []
            categorized[category].append(activity)

        return categorized

    def _calculate_diversity(self, categorized: Dict[str, List[Dict[str, Any]]]) -> float:
        """Calculate diversity score based on activity variety"""
        num_categories = len(categorized)

        # More categories = higher diversity
        if num_categories >= 6:
            return 9.5
        elif num_categories >= 4:
            return 8.0
        elif num_categories >= 3:
            return 7.0
        else:
            return 5.5

    def _suggest_daily_activities(
        self,
        activities: List[Dict[str, Any]],
        travel_dates: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Suggest activities for each day"""
        # Simplified - would calculate actual number of days
        suggestions = []

        # Group activities by time of day
        for i in range(min(3, len(activities) // 2)):
            daily_plan = {
                "day": i + 1,
                "morning": activities[i * 2] if i * 2 < len(activities) else None,
                "afternoon": activities[i * 2 + 1] if i * 2 + 1 < len(activities) else None
            }
            suggestions.append(daily_plan)

        return suggestions

    def _identify_must_do(self, activities: List[Dict[str, Any]]) -> List[str]:
        """Identify must-do activities"""
        must_do = []

        for activity in activities[:5]:  # Top 5 are must-do
            if activity.get("relevance_score", 0) >= 3:
                must_do.append(activity["name"])

        return must_do

    def _identify_budget_friendly(self, activities: List[Dict[str, Any]]) -> List[str]:
        """Identify budget-friendly activities"""
        budget_friendly = []

        for activity in activities:
            if activity.get("cost", 999) <= 20:
                budget_friendly.append(activity["name"])

        return budget_friendly[:5]

    def _generate_activity_tips(
        self,
        activities: List[Dict[str, Any]],
        interests: List[str]
    ) -> List[str]:
        """Generate activity tips"""
        tips = [
            "Book popular attractions in advance to avoid long queues",
            "Consider purchasing a city pass for multiple attractions",
        ]

        # Add interest-specific tips
        if "food" in interests:
            tips.append("Try local food tours to experience authentic cuisine")

        if "culture" in interests or "history" in interests:
            tips.append("Hire local guides for deeper cultural insights")

        return tips
