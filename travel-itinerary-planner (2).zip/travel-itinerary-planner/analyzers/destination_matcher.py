"""
Destination Matcher

Matches destinations to traveler preferences, interests, and travel style.
Provides suitability scores and alternative destination recommendations.
"""

from typing import Dict, Any, List
import logging


class DestinationMatcher:
    """Analyzer for destination-preference matching"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.destination")

    def match_destination(
        self,
        destination: str,
        interests: List[str],
        travel_style: str,
        preferences: Dict[str, Any],
        group_size: int
    ) -> Dict[str, Any]:
        """
        Match destination to traveler preferences

        Args:
            destination: Travel destination
            interests: List of traveler interests
            travel_style: Preferred travel style
            preferences: Additional preferences
            group_size: Number of travelers

        Returns:
            Destination matching results with suitability scores
        """
        self.logger.info(f"Matching destination: {destination} to preferences")

        # Get destination characteristics
        dest_characteristics = self._get_destination_characteristics(destination)

        # Calculate match scores
        interest_match = self._calculate_interest_match(interests, dest_characteristics)
        style_match = self._calculate_style_match(travel_style, dest_characteristics)
        group_suitability = self._calculate_group_suitability(group_size, dest_characteristics)

        # Overall match score (weighted average)
        match_score = (
            interest_match * 0.50 +
            style_match * 0.30 +
            group_suitability * 0.20
        )

        # Determine suitability level
        if match_score >= 8.5:
            suitability = "EXCELLENT"
        elif match_score >= 7.5:
            suitability = "VERY_GOOD"
        elif match_score >= 6.5:
            suitability = "GOOD"
        elif match_score >= 5.0:
            suitability = "FAIR"
        else:
            suitability = "POOR"

        # Find alternative destinations
        alternatives = self._find_alternatives(
            destination, interests, travel_style, match_score
        )

        return {
            "agent": "DestinationMatcher",
            "status": "success",
            "match_score": match_score,
            "suitability_level": suitability,
            "interest_match_score": interest_match,
            "style_match_score": style_match,
            "group_suitability_score": group_suitability,
            "destination_highlights": dest_characteristics.get("highlights", []),
            "destination_type": dest_characteristics.get("type", "unknown"),
            "best_for": dest_characteristics.get("best_for", []),
            "alternative_destinations": alternatives,
            "match_reasons": self._generate_match_reasons(
                match_score, interests, travel_style, dest_characteristics
            )
        }

    def _get_destination_characteristics(self, destination: str) -> Dict[str, Any]:
        """Get characteristics for destination (simplified - would use real data/API)"""
        # Sample destination database
        destinations = {
            "Paris": {
                "type": "cultural_urban",
                "highlights": ["museums", "architecture", "dining", "art", "history"],
                "best_for": ["couples", "culture enthusiasts", "food lovers"],
                "style_fit": ["luxury", "comfort", "cultural"],
                "activity_level": "moderate"
            },
            "Tokyo": {
                "type": "urban_cultural",
                "highlights": ["technology", "food", "culture", "shopping", "temples"],
                "best_for": ["solo", "couples", "food lovers", "culture enthusiasts"],
                "style_fit": ["comfort", "adventure", "cultural"],
                "activity_level": "high"
            },
            "Bali": {
                "type": "beach_cultural",
                "highlights": ["beaches", "temples", "wellness", "nature", "culture"],
                "best_for": ["couples", "wellness seekers", "adventure"],
                "style_fit": ["comfort", "budget", "adventure"],
                "activity_level": "moderate"
            },
            "New York": {
                "type": "urban",
                "highlights": ["museums", "dining", "entertainment", "shopping", "architecture"],
                "best_for": ["all groups", "entertainment lovers", "urban explorers"],
                "style_fit": ["luxury", "comfort", "standard"],
                "activity_level": "high"
            },
            "Iceland": {
                "type": "nature_adventure",
                "highlights": ["nature", "hiking", "hot springs", "northern lights", "glaciers"],
                "best_for": ["adventure seekers", "nature lovers", "photographers"],
                "style_fit": ["adventure", "standard"],
                "activity_level": "high"
            }
        }

        return destinations.get(
            destination,
            {
                "type": "unknown",
                "highlights": ["sightseeing", "culture"],
                "best_for": ["general travel"],
                "style_fit": ["standard"],
                "activity_level": "moderate"
            }
        )

    def _calculate_interest_match(
        self,
        interests: List[str],
        dest_char: Dict[str, Any]
    ) -> float:
        """Calculate how well destination matches interests"""
        if not interests:
            return 7.0  # neutral score

        highlights = dest_char.get("highlights", [])
        matches = sum(1 for interest in interests if any(
            interest.lower() in highlight.lower() or highlight.lower() in interest.lower()
            for highlight in highlights
        ))

        # Score from 0-10
        match_ratio = matches / len(interests) if interests else 0
        return min(10.0, match_ratio * 10 + 5.0)

    def _calculate_style_match(self, travel_style: str, dest_char: Dict[str, Any]) -> float:
        """Calculate how well destination matches travel style"""
        style_fit = dest_char.get("style_fit", [])

        if travel_style.lower() in [s.lower() for s in style_fit]:
            return 9.0
        elif any(s.lower() in travel_style.lower() for s in style_fit):
            return 7.5
        else:
            return 6.0

    def _calculate_group_suitability(
        self,
        group_size: int,
        dest_char: Dict[str, Any]
    ) -> float:
        """Calculate destination suitability for group size"""
        best_for = dest_char.get("best_for", [])

        if group_size == 1 and "solo" in best_for:
            return 9.5
        elif group_size == 2 and "couples" in best_for:
            return 9.5
        elif group_size >= 3 and ("groups" in best_for or "families" in best_for):
            return 9.0
        elif "all groups" in best_for:
            return 8.5
        else:
            return 7.0

    def _find_alternatives(
        self,
        current: str,
        interests: List[str],
        travel_style: str,
        current_score: float
    ) -> List[str]:
        """Find alternative destinations if match score is low"""
        if current_score >= 7.5:
            return []  # Current destination is good

        # Simple alternatives based on interests
        alternatives_map = {
            "culture": ["Paris", "Rome", "Kyoto"],
            "beach": ["Bali", "Maldives", "Greece"],
            "adventure": ["Iceland", "New Zealand", "Peru"],
            "food": ["Tokyo", "Bangkok", "Barcelona"],
            "nature": ["Iceland", "Costa Rica", "Norway"]
        }

        alternatives = set()
        for interest in interests:
            if interest.lower() in alternatives_map:
                alternatives.update(alternatives_map[interest.lower()])

        # Remove current destination
        alternatives.discard(current)

        return list(alternatives)[:3]

    def _generate_match_reasons(
        self,
        score: float,
        interests: List[str],
        travel_style: str,
        dest_char: Dict[str, Any]
    ) -> List[str]:
        """Generate reasons for the match score"""
        reasons = []

        highlights = dest_char.get("highlights", [])
        matching_interests = [i for i in interests if any(
            i.lower() in h.lower() or h.lower() in i.lower() for h in highlights
        )]

        if matching_interests:
            reasons.append(
                f"Destination aligns with interests: {', '.join(matching_interests[:3])}"
            )

        if travel_style.lower() in [s.lower() for s in dest_char.get("style_fit", [])]:
            reasons.append(f"Excellent fit for {travel_style} travel style")

        if score < 7.0:
            reasons.append("Consider exploring alternative destinations for better match")

        return reasons
