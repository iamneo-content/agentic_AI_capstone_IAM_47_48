"""
Budget Analyzer

Analyzes budget feasibility, allocation across categories,
and provides financial recommendations for travel planning.
"""

from typing import Dict, Any, List
import logging


class BudgetAnalyzer:
    """Analyzer for budget feasibility and allocation"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.budget")

    def analyze_budget(
        self,
        destination: str,
        budget: float,
        currency: str,
        travel_dates: Dict[str, str],
        group_size: int,
        travel_style: str,
        interests: List[str]
    ) -> Dict[str, Any]:
        """
        Analyze budget feasibility and allocation

        Args:
            destination: Travel destination
            budget: Total budget amount
            currency: Currency code (USD, EUR, etc.)
            travel_dates: Start and end dates
            group_size: Number of travelers
            travel_style: Travel style (luxury, budget, adventure, etc.)
            interests: List of traveler interests

        Returns:
            Budget analysis with feasibility and allocation recommendations
        """
        self.logger.info(f"Analyzing budget: {budget} {currency} for {destination}")

        # Calculate per-person budget
        per_person_budget = budget / group_size if group_size > 0 else budget

        # Estimate costs based on destination and travel style
        estimated_costs = self._estimate_costs(
            destination, travel_style, travel_dates, interests
        )

        # Calculate budget feasibility
        total_estimated = sum(estimated_costs.values())
        budget_ratio = budget / total_estimated if total_estimated > 0 else 0

        # Determine feasibility level
        if budget_ratio >= 1.2:
            feasibility = "COMFORTABLE"
            budget_score = 10.0
        elif budget_ratio >= 1.0:
            feasibility = "ADEQUATE"
            budget_score = 8.5
        elif budget_ratio >= 0.85:
            feasibility = "TIGHT"
            budget_score = 7.0
        elif budget_ratio >= 0.7:
            feasibility = "CHALLENGING"
            budget_score = 5.5
        else:
            feasibility = "INSUFFICIENT"
            budget_score = 3.0

        # Recommended allocation
        allocation = self._calculate_allocation(budget, travel_style)

        return {
            "agent": "BudgetAnalyzer",
            "status": "success",
            "budget_feasibility": feasibility,
            "budget_score": budget_score,
            "budget_ratio": budget_ratio,
            "per_person_budget": per_person_budget,
            "estimated_costs": estimated_costs,
            "total_estimated": total_estimated,
            "recommended_allocation": allocation,
            "currency": currency,
            "savings_opportunities": self._identify_savings(
                feasibility, travel_style, interests
            ),
            "budget_warnings": self._generate_warnings(feasibility, budget_ratio)
        }

    def _estimate_costs(
        self,
        destination: str,
        travel_style: str,
        travel_dates: Dict[str, str],
        interests: List[str]
    ) -> Dict[str, float]:
        """Estimate costs by category"""
        # Base costs by travel style
        style_multipliers = {
            "luxury": 2.5,
            "comfort": 1.5,
            "standard": 1.0,
            "budget": 0.6,
            "adventure": 0.8,
            "cultural": 0.9
        }

        multiplier = style_multipliers.get(travel_style.lower(), 1.0)

        # Rough estimates (would be enhanced with real data/APIs)
        base_costs = {
            "accommodation": 800 * multiplier,
            "food_dining": 400 * multiplier,
            "activities": 300 * multiplier,
            "transportation": 250 * multiplier,
            "shopping_misc": 150 * multiplier
        }

        # Adjust for interests
        if "adventure" in interests:
            base_costs["activities"] *= 1.3
        if "dining" in interests or "food" in interests:
            base_costs["food_dining"] *= 1.4

        return base_costs

    def _calculate_allocation(self, budget: float, travel_style: str) -> Dict[str, float]:
        """Calculate recommended budget allocation"""
        if travel_style.lower() == "luxury":
            percentages = {
                "accommodation": 0.40,
                "food_dining": 0.25,
                "activities": 0.20,
                "transportation": 0.10,
                "shopping_misc": 0.05
            }
        elif travel_style.lower() == "budget":
            percentages = {
                "accommodation": 0.30,
                "food_dining": 0.20,
                "activities": 0.25,
                "transportation": 0.15,
                "shopping_misc": 0.10
            }
        else:  # standard/comfort
            percentages = {
                "accommodation": 0.35,
                "food_dining": 0.25,
                "activities": 0.20,
                "transportation": 0.12,
                "shopping_misc": 0.08
            }

        return {category: budget * pct for category, pct in percentages.items()}

    def _identify_savings(
        self,
        feasibility: str,
        travel_style: str,
        interests: List[str]
    ) -> List[str]:
        """Identify potential savings opportunities"""
        savings = []

        if feasibility in ["TIGHT", "CHALLENGING", "INSUFFICIENT"]:
            savings.append("Consider traveling during off-season for lower accommodation costs")
            savings.append("Book flights and hotels in advance for better rates")
            savings.append("Use public transportation instead of taxis")

            if travel_style.lower() in ["luxury", "comfort"]:
                savings.append("Consider downgrading accommodation tier to save 20-30%")

            if "dining" not in interests:
                savings.append("Mix restaurant dining with local markets and street food")

        return savings

    def _generate_warnings(self, feasibility: str, budget_ratio: float) -> List[str]:
        """Generate budget warnings"""
        warnings = []

        if feasibility == "INSUFFICIENT":
            warnings.append(
                f"Budget is {int((1 - budget_ratio) * 100)}% below estimated costs"
            )
            warnings.append("Significant budget increase or trip adjustments recommended")

        elif feasibility == "CHALLENGING":
            warnings.append("Budget is tight - careful spending monitoring required")
            warnings.append("Consider building a 10-15% contingency buffer")

        elif feasibility == "TIGHT":
            warnings.append("Limited flexibility for unexpected expenses")

        return warnings
