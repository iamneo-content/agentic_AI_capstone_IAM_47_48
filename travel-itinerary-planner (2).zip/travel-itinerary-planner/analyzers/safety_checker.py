"""
Safety Checker

Evaluates destination safety, travel advisories, health requirements,
and security considerations for travelers.
"""

from typing import Dict, Any, List
import logging


class SafetyChecker:
    """Analyzer for destination safety assessment"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.safety")

    def check_safety(
        self,
        destination: str,
        travel_dates: Dict[str, str],
        group_size: int,
        preferences: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Assess destination safety and travel requirements

        Args:
            destination: Travel destination
            travel_dates: Start and end dates
            group_size: Number of travelers
            preferences: Traveler preferences

        Returns:
            Safety assessment with advisories and recommendations
        """
        self.logger.info(f"Assessing safety for {destination}")

        # Get safety data
        safety_data = self._get_safety_data(destination)

        # Calculate safety score
        safety_score = self._calculate_safety_score(safety_data, group_size)

        # Determine safety level
        if safety_score >= 9.0:
            safety_level = "VERY_SAFE"
            has_critical = False
        elif safety_score >= 7.5:
            safety_level = "SAFE"
            has_critical = False
        elif safety_score >= 6.0:
            safety_level = "MODERATE"
            has_critical = False
        elif safety_score >= 4.0:
            safety_level = "CAUTION_ADVISED"
            has_critical = False
        else:
            safety_level = "HIGH_RISK"
            has_critical = True

        # Get health requirements
        health_reqs = self._get_health_requirements(destination)

        # Generate advisories
        advisories = self._generate_advisories(safety_data, safety_level)

        return {
            "agent": "SafetyChecker",
            "status": "success",
            "safety_score": safety_score,
            "safety_level": safety_level,
            "has_critical_issues": has_critical,
            "crime_rate": safety_data.get("crime_rate", "unknown"),
            "political_stability": safety_data.get("political_stability", "unknown"),
            "health_risk_level": safety_data.get("health_risk", "low"),
            "health_requirements": health_reqs,
            "travel_advisories": safety_data.get("advisories", []),
            "safety_tips": self._generate_safety_tips(destination, safety_level),
            "emergency_contacts": self._get_emergency_contacts(destination),
            "advisories": advisories,
            "insurance_recommended": safety_score < 8.0
        }

    def _get_safety_data(self, destination: str) -> Dict[str, Any]:
        """Get safety data for destination (simplified database)"""
        # Sample safety database (would use real travel advisory APIs)
        safety_database = {
            "Paris": {
                "crime_rate": "low",
                "political_stability": "stable",
                "health_risk": "low",
                "terrorism_risk": "low",
                "natural_disaster_risk": "very_low",
                "advisories": [],
                "base_score": 8.5
            },
            "Tokyo": {
                "crime_rate": "very_low",
                "political_stability": "very_stable",
                "health_risk": "very_low",
                "terrorism_risk": "very_low",
                "natural_disaster_risk": "moderate",  # Earthquakes
                "advisories": ["Be aware of earthquake preparedness procedures"],
                "base_score": 9.0
            },
            "Bali": {
                "crime_rate": "low",
                "political_stability": "stable",
                "health_risk": "moderate",  # Tropical diseases
                "terrorism_risk": "low",
                "natural_disaster_risk": "moderate",  # Volcanic activity
                "advisories": ["Be aware of volcanic activity", "Take malaria precautions in some areas"],
                "base_score": 7.5
            },
            "New York": {
                "crime_rate": "low",
                "political_stability": "stable",
                "health_risk": "very_low",
                "terrorism_risk": "low",
                "natural_disaster_risk": "low",
                "advisories": [],
                "base_score": 8.0
            },
            "Iceland": {
                "crime_rate": "very_low",
                "political_stability": "very_stable",
                "health_risk": "very_low",
                "terrorism_risk": "very_low",
                "natural_disaster_risk": "moderate",  # Volcanic, weather
                "advisories": ["Weather can change rapidly", "Stay on marked trails"],
                "base_score": 9.0
            }
        }

        return safety_database.get(destination, {
            "crime_rate": "moderate",
            "political_stability": "stable",
            "health_risk": "moderate",
            "terrorism_risk": "low",
            "natural_disaster_risk": "low",
            "advisories": ["Check latest travel advisories"],
            "base_score": 7.0
        })

    def _calculate_safety_score(
        self,
        safety_data: Dict[str, Any],
        group_size: int
    ) -> float:
        """Calculate overall safety score"""
        base_score = safety_data.get("base_score", 7.0)

        # Adjust for crime rate
        crime = safety_data.get("crime_rate", "moderate")
        if crime == "very_low":
            base_score += 0.5
        elif crime == "high":
            base_score -= 1.0
        elif crime == "very_high":
            base_score -= 2.0

        # Adjust for health risk
        health = safety_data.get("health_risk", "moderate")
        if health == "very_low":
            base_score += 0.3
        elif health == "high":
            base_score -= 0.8

        # Group size consideration (larger groups = slightly safer)
        if group_size >= 3:
            base_score += 0.2

        return min(10.0, max(0.0, base_score))

    def _get_health_requirements(self, destination: str) -> Dict[str, Any]:
        """Get health requirements for destination"""
        # Simplified health requirements (would use real data)
        health_reqs = {
            "Bali": {
                "vaccinations_required": ["Hepatitis A", "Typhoid"],
                "vaccinations_recommended": ["Hepatitis B", "Rabies"],
                "malaria_risk": "Low risk in some areas",
                "travel_insurance": "Highly recommended"
            },
            "Paris": {
                "vaccinations_required": [],
                "vaccinations_recommended": [],
                "malaria_risk": "None",
                "travel_insurance": "Recommended"
            },
            "Tokyo": {
                "vaccinations_required": [],
                "vaccinations_recommended": ["Japanese Encephalitis (for rural areas)"],
                "malaria_risk": "None",
                "travel_insurance": "Recommended"
            }
        }

        return health_reqs.get(destination, {
            "vaccinations_required": [],
            "vaccinations_recommended": [],
            "malaria_risk": "None",
            "travel_insurance": "Recommended"
        })

    def _generate_advisories(
        self,
        safety_data: Dict[str, Any],
        safety_level: str
    ) -> List[str]:
        """Generate safety advisories"""
        advisories = list(safety_data.get("advisories", []))

        if safety_level in ["CAUTION_ADVISED", "HIGH_RISK"]:
            advisories.append("Stay informed about local conditions")
            advisories.append("Register with your embassy")

        natural_disaster = safety_data.get("natural_disaster_risk", "low")
        if natural_disaster in ["moderate", "high"]:
            advisories.append(f"Be aware of {natural_disaster} natural disaster risk")

        return advisories

    def _generate_safety_tips(self, destination: str, safety_level: str) -> List[str]:
        """Generate destination safety tips"""
        tips = [
            "Keep copies of important documents",
            "Share your itinerary with family/friends",
            "Keep emergency contacts handy"
        ]

        if safety_level in ["MODERATE", "CAUTION_ADVISED"]:
            tips.extend([
                "Avoid displaying expensive items",
                "Stay in well-lit, populated areas at night",
                "Use registered taxis or ride-sharing apps"
            ])

        if safety_level == "HIGH_RISK":
            tips.extend([
                "Avoid political gatherings and demonstrations",
                "Maintain heightened awareness of surroundings"
            ])

        return tips

    def _get_emergency_contacts(self, destination: str) -> Dict[str, str]:
        """Get emergency contact numbers for destination"""
        # Simplified emergency contacts
        emergency_database = {
            "Paris": {
                "emergency": "112",
                "police": "17",
                "ambulance": "15",
                "fire": "18"
            },
            "Tokyo": {
                "emergency": "110 (Police) / 119 (Fire/Ambulance)",
                "police": "110",
                "ambulance": "119",
                "fire": "119"
            },
            "Bali": {
                "emergency": "112",
                "police": "110",
                "ambulance": "118",
                "fire": "113"
            }
        }

        return emergency_database.get(destination, {
            "emergency": "Check local emergency numbers",
            "police": "Check local number",
            "ambulance": "Check local number",
            "fire": "Check local number"
        })
