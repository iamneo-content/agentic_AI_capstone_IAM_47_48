"""
Gemini AI Client

Enhanced AI-powered analysis for travel planning using Google's Gemini model.
Provides intelligent insights for itinerary optimization and recommendations.
"""

import logging
from typing import Dict, Any, List, Optional

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

from config import ConfigManager


class GeminiClient:
    """Client for Google Gemini AI integration"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.gemini")
        self.config = ConfigManager()
        self.model = None

        if GEMINI_AVAILABLE:
            self._initialize_client()
        else:
            self.logger.warning("Google Generative AI not available - install with: pip install google-generativeai")

    def _initialize_client(self):
        """Initialize Gemini AI client"""
        try:
            api_key = self.config.get("GEMINI_API_KEY")
            if not api_key:
                self.logger.warning("GEMINI_API_KEY not configured - AI features disabled")
                return

            genai.configure(api_key=api_key)
            model_name = self.config.get("GEMINI_MODEL", "gemini-pro")
            self.model = genai.GenerativeModel(model_name)
            self.logger.info(f"Gemini AI initialized with model: {model_name}")

        except Exception as e:
            self.logger.error(f"Failed to initialize Gemini AI: {str(e)}")
            self.model = None

    def generate_itinerary_insights(
        self,
        destination: str,
        interests: List[str],
        travel_style: str,
        budget: float,
        duration_days: int
    ) -> Optional[str]:
        """
        Generate AI-powered itinerary insights

        Args:
            destination: Travel destination
            interests: List of interests
            travel_style: Travel style preference
            budget: Total budget
            duration_days: Trip duration in days

        Returns:
            AI-generated insights or None if unavailable
        """
        if not self.model:
            return None

        try:
            prompt = f"""
            As a travel expert, provide personalized itinerary insights for:

            Destination: {destination}
            Duration: {duration_days} days
            Interests: {', '.join(interests)}
            Travel Style: {travel_style}
            Budget: ${budget}

            Please provide:
            1. Hidden gems and local experiences
            2. Optimal daily schedule suggestions
            3. Money-saving tips specific to this destination
            4. Cultural etiquette and important customs
            5. Best neighborhoods to stay in

            Keep the response concise and actionable (max 500 words).
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error generating itinerary insights: {str(e)}")
            return None

    def optimize_daily_schedule(
        self,
        activities: List[Dict[str, Any]],
        destination: str,
        preferences: Dict[str, Any]
    ) -> Optional[str]:
        """
        Optimize daily activity schedule using AI

        Args:
            activities: List of recommended activities
            destination: Travel destination
            preferences: Traveler preferences

        Returns:
            Optimized schedule suggestions or None
        """
        if not self.model:
            return None

        try:
            activity_list = "\n".join([
                f"- {act['name']} ({act.get('duration', 2)}h, ${act.get('cost', 0)})"
                for act in activities[:10]
            ])

            prompt = f"""
            Optimize a daily schedule for {destination} with these activities:

            {activity_list}

            Consider:
            - Geographic proximity to minimize travel time
            - Best time of day for each activity
            - Energy levels (intensive activities early, relaxed later)
            - Opening hours and booking requirements

            Provide a suggested 3-day itinerary with morning, afternoon, and evening plans.
            Keep response concise (max 400 words).
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error optimizing schedule: {str(e)}")
            return None

    def analyze_travel_compatibility(
        self,
        destination: str,
        traveler_profile: Dict[str, Any],
        constraints: Dict[str, Any]
    ) -> Optional[str]:
        """
        Analyze travel compatibility using AI

        Args:
            destination: Travel destination
            traveler_profile: Traveler information and preferences
            constraints: Budget, time, and other constraints

        Returns:
            Compatibility analysis or None
        """
        if not self.model:
            return None

        try:
            prompt = f"""
            Analyze travel compatibility for:

            Destination: {destination}
            Traveler: {traveler_profile.get('travel_style', 'N/A')} style,
                     interests in {', '.join(traveler_profile.get('interests', []))}
            Constraints: Budget ${constraints.get('budget', 0)},
                        {constraints.get('duration', 'N/A')} days

            Provide:
            1. Compatibility score (1-10) with justification
            2. Potential misalignments or challenges
            3. Suggestions to improve compatibility

            Be honest and objective. Keep response under 300 words.
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error analyzing compatibility: {str(e)}")
            return None

    def generate_budget_advice(
        self,
        destination: str,
        budget: float,
        budget_breakdown: Dict[str, float],
        travel_style: str
    ) -> Optional[str]:
        """
        Generate AI-powered budget advice

        Args:
            destination: Travel destination
            budget: Total budget
            budget_breakdown: Allocation by category
            travel_style: Travel style

        Returns:
            Budget advice or None
        """
        if not self.model:
            return None

        try:
            breakdown_str = "\n".join([
                f"- {cat}: ${amt:.0f}"
                for cat, amt in budget_breakdown.items()
            ])

            prompt = f"""
            Provide budget optimization advice for:

            Destination: {destination}
            Total Budget: ${budget}
            Travel Style: {travel_style}

            Current Allocation:
            {breakdown_str}

            Suggest:
            1. Areas where budget can be optimized
            2. Worthwhile splurges for this destination
            3. Hidden costs to watch out for
            4. Best value-for-money experiences

            Keep advice practical and specific (max 350 words).
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error generating budget advice: {str(e)}")
            return None

    def is_available(self) -> bool:
        """Check if Gemini AI is available"""
        return self.model is not None
