"""Utility modules for travel itinerary planner"""

from .logging_utils import setup_logging

__all__ = ["setup_logging"]
