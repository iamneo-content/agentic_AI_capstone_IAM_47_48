"""
Notification Node

Sends email notifications with itinerary results.
"""

import logging
from datetime import datetime
from state import TravelItineraryState
from services.email_service import EmailService

logger = logging.getLogger("node.notification")


def notification_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Send email notification with itinerary

    Args:
        state: Current travel planning state

    Returns:
        Updated state with notification status
    """
    logger.info("Stage 5: Notification")

    # Create a working copy
    new_state = state.clone()

    try:
        # Check if email is provided
        if not new_state.traveler_email:
            logger.warning("No email address provided - skipping notification")
            new_state.workflow_complete = True
            new_state.updated_at = datetime.now().isoformat()
            return new_state

        # Initialize email service
        email_service = EmailService()

        # Format itinerary summary
        summary = _format_itinerary_summary(new_state)

        # Send email
        success = email_service.send_itinerary(
            to_email=new_state.traveler_email,
            traveler_name=new_state.traveler_name,
            destination=new_state.destination,
            decision=new_state.decision,
            overall_score=new_state.overall_score,
            itinerary_summary=summary
        )

        # Record notification
        notification = {
            "type": "email",
            "recipient": new_state.traveler_email,
            "status": "sent" if success else "failed",
            "timestamp": datetime.now().isoformat()
        }
        new_state.notifications_sent.append(notification)

        if success:
            logger.info(f"Notification sent to {new_state.traveler_email}")
        else:
            logger.warning(f"Failed to send notification to {new_state.traveler_email}")

        # Mark workflow as complete
        new_state.workflow_complete = True
        new_state.updated_at = datetime.now().isoformat()

    except Exception as e:
        logger.error(f"Error sending notification: {str(e)}")
        new_state.notifications_sent.append({
            "type": "email",
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        })
        new_state.workflow_complete = True  # Complete even on error

    return new_state


def _format_itinerary_summary(state: TravelItineraryState) -> str:
    """Format itinerary summary for email"""
    lines = []

    # Decision and score
    lines.append(f"Decision: {state.decision}")
    lines.append(f"Overall Score: {state.overall_score:.1f}/10")
    lines.append(f"Confidence: {state.confidence_level}")
    lines.append("")

    # Destination info
    lines.append(f"Destination: {state.destination}")
    lines.append(f"Dates: {state.travel_dates.get('start_date', 'N/A')} to {state.travel_dates.get('end_date', 'N/A')}")
    lines.append(f"Budget: {state.budget} {state.currency}")
    lines.append(f"Group Size: {state.group_size}")
    lines.append("")

    # Key highlights
    if state.travel_tips:
        lines.append("Key Travel Tips:")
        for tip in state.travel_tips[:5]:
            lines.append(f"  - {tip}")
        lines.append("")

    # Budget breakdown
    if state.budget_breakdown:
        lines.append("Budget Allocation:")
        for category, amount in state.budget_breakdown.items():
            lines.append(f"  - {category.replace('_', ' ').title()}: ${amount:.0f}")
        lines.append("")

    # Safety warnings
    if state.safety_warnings:
        lines.append("Safety Notices:")
        for warning in state.safety_warnings[:3]:
            lines.append(f"  - {warning}")
        lines.append("")

    return "\n".join(lines)
