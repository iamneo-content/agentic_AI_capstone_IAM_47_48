"""
Itinerary Generation Node

Generates detailed itinerary based on all analysis results and decision.
"""

import logging
from datetime import datetime
from state import TravelItineraryState

logger = logging.getLogger("node.itinerary_generation")


def itinerary_generation_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Generate detailed travel itinerary

    Args:
        state: Current travel planning state

    Returns:
        Updated state with complete itinerary
    """
    logger.info("Stage 4: Itinerary Generation")

    # Create a working copy
    new_state = state.clone()

    try:
        # Extract data from analysis results
        budget_data = new_state.budget_analysis_results[0] if new_state.budget_analysis_results else {}
        activities_data = new_state.activity_recommendations[0] if new_state.activity_recommendations else {}
        weather_data = new_state.weather_season_results[0] if new_state.weather_season_results else {}
        safety_data = new_state.safety_assessment_results[0] if new_state.safety_assessment_results else {}

        # Generate main itinerary
        itinerary = {
            "planning_id": new_state.planning_id,
            "destination": new_state.destination,
            "traveler_name": new_state.traveler_name,
            "travel_dates": new_state.travel_dates,
            "group_size": new_state.group_size,
            "decision": new_state.decision,
            "overall_score": new_state.overall_score,
            "confidence_level": new_state.confidence_level,
            "generated_at": datetime.now().isoformat()
        }

        # Generate daily plans
        daily_plans = activities_data.get("daily_suggestions", [])

        # Compile budget breakdown
        budget_breakdown = budget_data.get("recommended_allocation", {})

        # Compile travel tips
        travel_tips = []
        travel_tips.extend(budget_data.get("savings_opportunities", [])[:3])
        travel_tips.extend(activities_data.get("activity_tips", [])[:2])
        travel_tips.extend(weather_data.get("weather_recommendations", [])[:2])
        travel_tips.extend(safety_data.get("safety_tips", [])[:3])

        # Add packing recommendations
        packing_tips = weather_data.get("packing_recommendations", [])
        if packing_tips:
            travel_tips.append(f"Packing essentials: {', '.join(packing_tips[:5])}")

        # Update state
        new_state.itinerary = itinerary
        new_state.daily_plans = daily_plans
        new_state.budget_breakdown = budget_breakdown
        new_state.travel_tips = travel_tips

        logger.info(
            f"Itinerary generated - Decision: {new_state.decision}, "
            f"{len(daily_plans)} daily plans created, "
            f"{len(travel_tips)} travel tips compiled"
        )

    except Exception as e:
        logger.error(f"Error generating itinerary: {str(e)}")
        new_state.error = f"Itinerary generation error: {str(e)}"

    return new_state
