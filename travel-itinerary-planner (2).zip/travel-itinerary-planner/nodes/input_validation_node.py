"""
Input Validation Node

Validates and enriches travel planning input data.
"""

import logging
from datetime import datetime
from state import TravelItineraryState

logger = logging.getLogger("node.input_validation")


def input_validation_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Validate and enrich input data

    Args:
        state: Current travel planning state

    Returns:
        Updated state with validation results
    """
    logger.info("Stage 1: Input Validation")

    # Create a working copy
    new_state = state.clone()

    try:
        # Validate required fields
        errors = []

        if not new_state.destination:
            errors.append("Destination is required")

        if not new_state.budget or new_state.budget <= 0:
            errors.append("Valid budget is required")

        if not new_state.travel_dates:
            errors.append("Travel dates are required")

        if not new_state.traveler_name:
            errors.append("Traveler name is required")

        # Set validation errors if any
        if errors:
            new_state.error = "; ".join(errors)
            logger.error(f"Validation failed: {new_state.error}")
            return new_state

        # Enrich state with default values
        if not new_state.currency:
            new_state.currency = "USD"

        if not new_state.group_size or new_state.group_size <= 0:
            new_state.group_size = 1

        if not new_state.travel_style:
            new_state.travel_style = "standard"

        if not new_state.interests:
            new_state.interests = ["sightseeing", "culture"]

        # Set timestamp
        new_state.updated_at = datetime.now().isoformat()

        logger.info(
            f"Input validation successful - Destination: {new_state.destination}, "
            f"Budget: {new_state.budget} {new_state.currency}, "
            f"Travelers: {new_state.group_size}"
        )

    except Exception as e:
        logger.error(f"Error in input validation: {str(e)}")
        new_state.error = f"Validation error: {str(e)}"

    return new_state
