"""
Activity Recommendation Node

Wrapper for Activity Recommender Agent.
"""

import logging
from state import TravelItineraryState
from agents import ActivityRecommenderAgent

logger = logging.getLogger("node.activity_recommendation")


def activity_recommendation_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Recommend activities and experiences

    Args:
        state: Current travel planning state

    Returns:
        Updated state with activity recommendations
    """
    logger.info("Activity Recommendation Node: Recommending activities")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = ActivityRecommenderAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.activity_recommendations = [result]

        logger.info(
            f"Activity recommendation complete - "
            f"{len(result.get('recommended_activities', []))} activities recommended"
        )

    except Exception as e:
        logger.error(f"Error in activity recommendation: {str(e)}")
        new_state.activity_recommendations = [{
            "agent": "ActivityRecommender",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
