"""
Coordination Node

Wrapper for Coordinator Agent - aggregates all analysis results.
"""

import logging
from state import TravelItineraryState
from agents import CoordinatorAgent

logger = logging.getLogger("node.coordination")


def coordination_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Coordinate all analysis results and make final decision

    Args:
        state: Current travel planning state with all analysis results

    Returns:
        Updated state with coordination summary and decision
    """
    logger.info("Stage 3: Coordination - Aggregating analysis results")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run coordinator agent
        agent = CoordinatorAgent()
        result = agent.analyze(new_state)

        # Update state with coordination results
        new_state.coordination_summary = result
        new_state.decision = result.get("decision", "ERROR")
        new_state.overall_score = result.get("overall_score", 0.0)
        new_state.confidence_level = result.get("confidence_level", "NONE")
        new_state.decision_metrics = result.get("component_scores", {})

        # Update critical issues if coordinator found any
        if result.get("has_critical_issues", False):
            new_state.has_critical_issues = True
            new_state.critical_reason = result.get("decision_rationale", "")

        logger.info(
            f"Coordination complete - Decision: {new_state.decision}, "
            f"Overall Score: {new_state.overall_score:.2f}, "
            f"Confidence: {new_state.confidence_level}"
        )

    except Exception as e:
        logger.error(f"Error in coordination: {str(e)}")
        new_state.coordination_summary = {
            "agent": "Coordinator",
            "status": "error",
            "error_message": str(e)
        }
        new_state.decision = "ERROR"
        new_state.error = f"Coordination error: {str(e)}"

    return new_state
