"""
Weather and Season Node

Wrapper for Weather Season Agent.
"""

import logging
from state import TravelItineraryState
from agents import WeatherSeasonAgent

logger = logging.getLogger("node.weather_season")


def weather_season_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Analyze weather and seasonal suitability

    Args:
        state: Current travel planning state

    Returns:
        Updated state with weather/season analysis
    """
    logger.info("Weather Season Node: Analyzing weather and season")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = WeatherSeasonAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.weather_season_results = [result]

        logger.info(
            f"Weather/season analysis complete - "
            f"Suitability: {result.get('season_suitability', 'N/A')}"
        )

    except Exception as e:
        logger.error(f"Error in weather/season analysis: {str(e)}")
        new_state.weather_season_results = [{
            "agent": "WeatherSeason",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
