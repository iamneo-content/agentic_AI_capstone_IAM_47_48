"""
Destination Matching Node

Wrapper for Destination Matcher Agent.
"""

import logging
from state import TravelItineraryState
from agents import DestinationMatcherAgent

logger = logging.getLogger("node.destination_matching")


def destination_matching_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Match destination to preferences

    Args:
        state: Current travel planning state

    Returns:
        Updated state with destination matching results
    """
    logger.info("Destination Matching Node: Matching destination to preferences")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = DestinationMatcherAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.destination_matching_results = [result]

        # Store destination info for other agents
        new_state.destination_info = {
            "highlights": result.get("destination_highlights", []),
            "type": result.get("destination_type", "unknown"),
            "best_for": result.get("best_for", [])
        }

        logger.info(
            f"Destination matching complete - Match Score: {result.get('match_score', 0):.2f}"
        )

    except Exception as e:
        logger.error(f"Error in destination matching: {str(e)}")
        new_state.destination_matching_results = [{
            "agent": "DestinationMatcher",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
