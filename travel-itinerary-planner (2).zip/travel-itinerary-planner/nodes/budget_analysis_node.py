"""
Budget Analysis Node

Wrapper for Budget Analyzer Agent.
"""

import logging
from state import TravelItineraryState
from agents import BudgetAnalyzerAgent

logger = logging.getLogger("node.budget_analysis")


def budget_analysis_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Analyze budget feasibility

    Args:
        state: Current travel planning state

    Returns:
        Updated state with budget analysis results
    """
    logger.info("Budget Analysis Node: Analyzing budget feasibility")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = BudgetAnalyzerAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.budget_analysis_results = [result]

        logger.info(
            f"Budget analysis complete - Feasibility: {result.get('budget_feasibility', 'N/A')}"
        )

    except Exception as e:
        logger.error(f"Error in budget analysis: {str(e)}")
        new_state.budget_analysis_results = [{
            "agent": "BudgetAnalyzer",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
