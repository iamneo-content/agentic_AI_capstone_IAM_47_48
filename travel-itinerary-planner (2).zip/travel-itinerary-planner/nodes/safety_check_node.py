"""
Safety Check Node

Wrapper for Safety Checker Agent.
"""

import logging
from state import TravelItineraryState
from agents import SafetyCheckerAgent

logger = logging.getLogger("node.safety_check")


def safety_check_node(state: TravelItineraryState) -> TravelItineraryState:
    """
    Check destination safety and requirements

    Args:
        state: Current travel planning state

    Returns:
        Updated state with safety assessment
    """
    logger.info("Safety Check Node: Assessing destination safety")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = SafetyCheckerAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.safety_assessment_results = [result]

        # Extract critical safety info
        new_state.has_critical_issues = result.get("has_critical_issues", False)
        new_state.safety_warnings = result.get("travel_advisories", [])

        logger.info(
            f"Safety assessment complete - "
            f"Safety Level: {result.get('safety_level', 'N/A')}, "
            f"Critical Issues: {new_state.has_critical_issues}"
        )

    except Exception as e:
        logger.error(f"Error in safety assessment: {str(e)}")
        new_state.safety_assessment_results = [{
            "agent": "SafetyChecker",
            "status": "error",
            "error_message": str(e)
        }]
        new_state.has_critical_issues = True

    return new_state
