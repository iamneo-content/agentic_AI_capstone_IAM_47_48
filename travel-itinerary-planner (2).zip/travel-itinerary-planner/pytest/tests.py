#!/usr/bin/env python3
"""
Comprehensive Test Suite for Travel Itinerary Planner

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import TravelItineraryState
    from graph import TravelPlanningGraph
    from workflows import build_travel_planning_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.destination_matcher_agent import DestinationMatcherAgent
    from agents.weather_season_agent import WeatherSeasonAgent
    from agents.activity_recommender_agent import ActivityRecommenderAgent
    from agents.budget_analyzer_agent import BudgetAnalyzerAgent
    from agents.safety_checker_agent import SafetyCheckerAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.destination_matcher import DestinationMatcher
    from analyzers.weather_season_analyzer import WeatherSeasonAnalyzer
    from analyzers.activity_recommender import ActivityRecommender
    from analyzers.budget_analyzer import BudgetAnalyzer
    from analyzers.safety_checker import SafetyChecker

    # Import nodes
    from nodes.budget_analysis_node import budget_analysis_node
    from nodes.destination_matching_node import destination_matching_node
    from nodes.weather_season_node import weather_season_node
    from nodes.activity_recommendation_node import activity_recommendation_node
    from nodes.safety_check_node import safety_check_node
    from nodes.coordination_node import coordination_node
    from nodes.notification_node import notification_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestTravelItineraryPlannerArchitecture(unittest.TestCase):
    """Test suite for Travel Itinerary Planner Architecture"""

    SAMPLE_TRIP = {
        "trip_id": "TEST-123",
        "traveler": {
            "name": "John Doe",
            "preferences": ["beach", "culture", "food"],
            "travel_style": "adventure"
        },
        "destination": "Barcelona, Spain",
        "travel_dates": {
            "start": "2024-06-15",
            "end": "2024-06-22"
        },
        "budget": {
            "total": 3000,
            "currency": "USD"
        },
        "group_size": 2
    }

    def setUp(self):
        """Setup test environment"""
        self.sample_trip = self.SAMPLE_TRIP.copy()

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test TravelItineraryState dataclass creation"""
        logger.info("Testing TravelItineraryState creation...")

        state = TravelItineraryState(
            planning_id="TEST-123",
            traveler_name="Test User",
            destination="Paris",
            budget=3000.0
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.planning_id, "TEST-123", "Planning ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test TravelItineraryState clone method"""
        logger.info("Testing TravelItineraryState clone...")

        state = TravelItineraryState(
            planning_id="TEST-123",
            destination="Paris",
            budget=3000.0
        )
        state.destination_matching_results = [{"test": "data"}]

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.planning_id, state.planning_id, "Planning ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_destination_matcher(self):
        """Test DestinationMatcher (pure tool)"""
        logger.info("Testing DestinationMatcher...")

        analyzer = DestinationMatcher()
        results = analyzer.match_destination(
            destination="Barcelona, Spain",
            interests=["beach", "culture", "food"],
            travel_style="adventure",
            preferences={},
            group_size=2
        )

        self.assertIsNotNone(results, "Destination matching results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("match_score", results, "Should have match_score")

        logger.info("✓ DestinationMatcher tests passed")

    def test_weather_season_analyzer(self):
        """Test WeatherSeasonAnalyzer (pure tool)"""
        logger.info("Testing WeatherSeasonAnalyzer...")

        analyzer = WeatherSeasonAnalyzer()
        results = analyzer.analyze_weather_season(
            destination="Barcelona, Spain",
            travel_dates={"start_date": "2024-06-15", "end_date": "2024-06-22"},
            interests=["beach", "culture", "food"],
            preferences={}
        )

        self.assertIsNotNone(results, "Weather season analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ WeatherSeasonAnalyzer tests passed")

    def test_activity_recommender(self):
        """Test ActivityRecommender (pure tool)"""
        logger.info("Testing ActivityRecommender...")

        analyzer = ActivityRecommender()
        results = analyzer.recommend_activities(
            destination="Barcelona, Spain",
            interests=["beach", "culture", "food"],
            travel_dates={"start_date": "2024-06-15", "end_date": "2024-06-22"},
            budget=3000.0,
            group_size=2,
            travel_style="adventure",
            destination_info={}
        )

        self.assertIsNotNone(results, "Activity recommendation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ ActivityRecommender tests passed")

    def test_budget_analyzer(self):
        """Test BudgetAnalyzer (pure tool)"""
        logger.info("Testing BudgetAnalyzer...")

        analyzer = BudgetAnalyzer()
        results = analyzer.analyze_budget(
            destination="Barcelona, Spain",
            budget=3000.0,
            currency="USD",
            travel_dates={"start_date": "2024-06-15", "end_date": "2024-06-22"},
            group_size=2,
            travel_style="adventure",
            interests=["beach", "culture", "food"]
        )

        self.assertIsNotNone(results, "Budget analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ BudgetAnalyzer tests passed")

    def test_safety_checker(self):
        """Test SafetyChecker (pure tool)"""
        logger.info("Testing SafetyChecker...")

        analyzer = SafetyChecker()
        results = analyzer.check_safety(
            destination="Barcelona, Spain",
            travel_dates={"start_date": "2024-06-15", "end_date": "2024-06-22"},
            group_size=2,
            preferences={}
        )

        self.assertIsNotNone(results, "Safety check results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ SafetyChecker tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_destination_matcher_agent(self):
        """Test DestinationMatcherAgent (coordinator)"""
        logger.info("Testing DestinationMatcherAgent...")

        agent = DestinationMatcherAgent()
        state = TravelItineraryState(
            destination="Barcelona",
            interests=["beach", "culture", "food"],
            travel_style="adventure",
            group_size=2
        )
        results = agent.analyze(state)

        self.assertIsNotNone(results, "Destination matcher agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ DestinationMatcherAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_destination_matching_node(self):
        """Test destination_matching_node (thin wrapper)"""
        logger.info("Testing destination_matching_node...")

        state = TravelItineraryState(
            planning_id="TEST-TRIP",
            destination="Barcelona",
            interests=["beach", "culture", "food"],
            travel_style="adventure",
            group_size=2
        )

        result = destination_matching_node(state)

        self.assertIsNotNone(result, "Destination matching node result should not be None")
        self.assertIsInstance(result, TravelItineraryState, "Result should be TravelItineraryState")

        logger.info("✓ destination_matching_node tests passed")

    def test_coordination_node(self):
        """Test coordination_node logic"""
        logger.info("Testing coordination_node...")

        state = TravelItineraryState(
            planning_id="TEST-TRIP",
            destination="Barcelona",
            destination_matching_results=[{"match_score": 9.0}],
            weather_season_results=[{"weather_score": 8.0}],
            activity_recommendations=[{"total_activities": 15}],
            budget_analysis_results=[{"budget_score": 7.5}],
            safety_assessment_results=[{"safety_score": 9.0}]
        )

        result = coordination_node(state)

        self.assertIsNotNone(result, "Coordination result should not be None")
        self.assertIsInstance(result, TravelItineraryState, "Result should be TravelItineraryState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ coordination_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_travel_graph_creation(self):
        """Test TravelPlanningGraph class creation"""
        logger.info("Testing TravelPlanningGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = TravelPlanningGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ TravelPlanningGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_travel_planning_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, TravelPlanningGraph, "Workflow should be TravelPlanningGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        destination_agent = DestinationMatcherAgent()
        self.assertIsNotNone(destination_agent.matcher, "DestinationMatcherAgent should have a matcher")
        self.assertIsInstance(destination_agent.matcher, DestinationMatcher, "Should use DestinationMatcher")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = TravelItineraryState(
            planning_id="TEST-TRIP",
            destination="Barcelona",
            interests=["beach", "culture"],
            travel_style="adventure",
            group_size=2
        )

        result = destination_matching_node(state)
        self.assertIsInstance(result, TravelItineraryState, "Node should return TravelItineraryState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Travel Itinerary Planner - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
