"""
Travel Planning Workflow Builder

Constructs the multi-stage travel itinerary planning workflow with parallel execution.
"""

import logging
from typing import List
from graph import TravelPlanningGraph, NodeFunc
from nodes import (
    input_validation_node,
    budget_analysis_node,
    destination_matching_node,
    activity_recommendation_node,
    weather_season_node,
    safety_check_node,
    coordination_node,
    itinerary_generation_node,
    notification_node
)

logger = logging.getLogger("workflow.travel")


def build_travel_planning_workflow(max_workers: int = 5) -> TravelPlanningGraph:
    """
    Build the travel planning workflow graph

    Workflow Stages:
    1. Input Validation - Validate and enrich input data
    2. Parallel Analysis - Run 5 specialized agents in parallel:
       - Budget Analyzer
       - Destination Matcher
       - Activity Recommender
       - Weather/Season Agent
       - Safety Checker
    3. Coordination - Aggregate results and make decision
    4. Itinerary Generation - Create detailed itinerary
    5. Notification - Send email notification

    Args:
        max_workers: Maximum parallel workers (default: 5)

    Returns:
        TravelPlanningGraph ready to execute
    """
    logger.info("Building travel planning workflow")

    # Define workflow stages
    stages: List[List[NodeFunc]] = [
        # Stage 1: Input Validation (sequential)
        [input_validation_node],

        # Stage 2: Parallel Analysis (5 agents run in parallel)
        [
            budget_analysis_node,
            destination_matching_node,
            activity_recommendation_node,
            weather_season_node,
            safety_check_node
        ],

        # Stage 3: Coordination (sequential)
        [coordination_node],

        # Stage 4: Itinerary Generation (sequential)
        [itinerary_generation_node],

        # Stage 5: Notification (sequential)
        [notification_node]
    ]

    # Create and return graph
    workflow = TravelPlanningGraph(
        stages=stages,
        max_workers=max_workers,
        raise_on_error=False  # Continue workflow even if individual nodes fail
    )

    logger.info(
        f"Workflow built with {len(stages)} stages, "
        f"{len(stages[1])} parallel agents in stage 2"
    )

    return workflow
