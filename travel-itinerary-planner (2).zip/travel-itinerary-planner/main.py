"""
Travel Itinerary Planner - Main Entry Point

Multi-agent system for intelligent travel itinerary planning.
Uses 5 specialized agents to analyze budget, destination match, activities,
weather/season, and safety considerations.
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from typing import Dict, Any

from state import TravelItineraryState
from workflows import build_travel_planning_workflow
from utils.logging_utils import setup_logging
from config import ConfigManager


def create_sample_travel_request() -> TravelItineraryState:
    """Create a sample travel planning request for demonstration"""
    from config import get_config_value
    return TravelItineraryState(
        planning_id="TRIP-2024-001",
        traveler_name="Emma Johnson",
        traveler_email=get_config_value("EMAIL_TO", "emma.johnson@example.com"),
        timestamp=datetime.now().isoformat(),

        # Travel preferences
        destination="Paris",
        travel_dates={
            "start_date": "2024-09-15",
            "end_date": "2024-09-22"
        },
        budget=3500.0,
        currency="USD",
        travel_style="cultural",
        interests=["art", "history", "food", "museums", "architecture"],
        group_size=2,

        # Traveler preferences
        traveler_preferences={
            "avoid_crowds": True,
            "prefer_walkable": True,
            "dietary_restrictions": [],
            "accommodation_type": "boutique hotel"
        }
    )


def create_budget_travel_request() -> TravelItineraryState:
    """Create a budget travel scenario"""
    from config import get_config_value
    return TravelItineraryState(
        planning_id="TRIP-2024-002",
        traveler_name="Alex Chen",
        traveler_email=get_config_value("EMAIL_TO", "alex.chen@example.com"),
        timestamp=datetime.now().isoformat(),

        destination="Bali",
        travel_dates={
            "start_date": "2024-10-01",
            "end_date": "2024-10-14"
        },
        budget=1800.0,
        currency="USD",
        travel_style="budget",
        interests=["beach", "nature", "yoga", "hiking", "culture"],
        group_size=1,

        traveler_preferences={
            "avoid_crowds": True,
            "prefer_nature": True,
            "accommodation_type": "hostel"
        }
    )


def create_adventure_travel_request() -> TravelItineraryState:
    """Create an adventure travel scenario"""
    from config import get_config_value
    return TravelItineraryState(
        planning_id="TRIP-2024-003",
        traveler_name="Marcus Williams",
        traveler_email=get_config_value("EMAIL_TO", "marcus.w@example.com"),
        timestamp=datetime.now().isoformat(),

        destination="Iceland",
        travel_dates={
            "start_date": "2024-07-10",
            "end_date": "2024-07-20"
        },
        budget=4500.0,
        currency="USD",
        travel_style="adventure",
        interests=["hiking", "nature", "photography", "northern lights", "glaciers"],
        group_size=3,

        traveler_preferences={
            "activity_level": "high",
            "prefer_outdoor": True,
            "accommodation_type": "guesthouse"
        }
    )


def print_itinerary_summary(state: TravelItineraryState) -> None:
    """Print a summary of the travel itinerary planning results"""
    print("\n" + "="*80)
    print("TRAVEL ITINERARY PLANNING RESULTS")
    print("="*80)

    # Basic information
    print(f"\nPlanning ID: {state.planning_id}")
    print(f"Traveler: {state.traveler_name}")
    print(f"Destination: {state.destination}")
    print(f"Dates: {state.travel_dates.get('start_date', 'N/A')} to {state.travel_dates.get('end_date', 'N/A')}")
    print(f"Budget: {state.budget} {state.currency}")
    print(f"Group Size: {state.group_size}")
    print(f"Travel Style: {state.travel_style}")

    # Decision
    print(f"\n{'='*80}")
    print(f"DECISION: {state.decision}")
    print(f"Overall Score: {state.overall_score:.2f}/10")
    print(f"Confidence Level: {state.confidence_level}")
    print(f"{'='*80}")

    # Component scores
    if state.decision_metrics:
        print("\nComponent Scores:")
        for component, score in state.decision_metrics.items():
            print(f"  - {component.replace('_', ' ').title()}: {score:.2f}/10")

    # Decision rationale
    if state.coordination_summary:
        rationale = state.coordination_summary.get("decision_rationale", "")
        if rationale:
            print(f"\nRationale: {rationale}")

    # Recommendations
    if state.coordination_summary and state.coordination_summary.get("recommendations"):
        print("\nRecommendations:")
        for rec in state.coordination_summary["recommendations"]:
            print(f"  - {rec}")

    # Budget analysis
    if state.budget_analysis_results:
        budget_result = state.budget_analysis_results[0]
        print(f"\nBudget Analysis:")
        print(f"  Feasibility: {budget_result.get('budget_feasibility', 'N/A')}")
        print(f"  Score: {budget_result.get('budget_score', 0):.2f}/10")
        print(f"  Per Person: ${budget_result.get('per_person_budget', 0):.2f}")

        if budget_result.get('budget_warnings'):
            print("  Warnings:")
            for warning in budget_result['budget_warnings']:
                print(f"    - {warning}")

    # Destination matching
    if state.destination_matching_results:
        dest_result = state.destination_matching_results[0]
        print(f"\nDestination Match:")
        print(f"  Suitability: {dest_result.get('suitability_level', 'N/A')}")
        print(f"  Match Score: {dest_result.get('match_score', 0):.2f}/10")

        highlights = dest_result.get('destination_highlights', [])
        if highlights:
            print(f"  Highlights: {', '.join(highlights[:5])}")

    # Activities
    if state.activity_recommendations:
        activity_result = state.activity_recommendations[0]
        print(f"\nActivity Recommendations:")
        print(f"  Total Activities: {activity_result.get('total_activities', 0)}")
        print(f"  Diversity Score: {activity_result.get('diversity_score', 0):.2f}/10")

        must_do = activity_result.get('must_do', [])
        if must_do:
            print("  Must-Do Activities:")
            for activity in must_do[:5]:
                print(f"    - {activity}")

    # Weather/Season
    if state.weather_season_results:
        weather_result = state.weather_season_results[0]
        print(f"\nWeather & Season:")
        print(f"  Suitability: {weather_result.get('season_suitability', 'N/A')}")
        print(f"  Score: {weather_result.get('weather_score', 0):.2f}/10")
        print(f"  Season: {weather_result.get('season', 'N/A')}")
        print(f"  Avg Temperature: {weather_result.get('average_temp', 'N/A')}°C")
        print(f"  Rainfall Probability: {weather_result.get('rainfall_probability', 0)}%")

    # Safety
    if state.safety_assessment_results:
        safety_result = state.safety_assessment_results[0]
        print(f"\nSafety Assessment:")
        print(f"  Safety Level: {safety_result.get('safety_level', 'N/A')}")
        print(f"  Score: {safety_result.get('safety_score', 0):.2f}/10")
        print(f"  Critical Issues: {safety_result.get('has_critical_issues', False)}")

        if safety_result.get('travel_advisories'):
            print("  Advisories:")
            for advisory in safety_result['travel_advisories'][:3]:
                print(f"    - {advisory}")

    # Travel tips
    if state.travel_tips:
        print("\nTravel Tips:")
        for tip in state.travel_tips[:8]:
            print(f"  - {tip}")

    # Budget breakdown
    if state.budget_breakdown:
        print("\nBudget Allocation:")
        for category, amount in state.budget_breakdown.items():
            print(f"  - {category.replace('_', ' ').title()}: ${amount:.2f}")

    # Errors
    if state.error:
        print(f"\nErrors: {state.error}")

    print("\n" + "="*80)


def main():
    """Main entry point for travel itinerary planner"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="Travel Itinerary Planner - Multi-agent travel planning system"
    )
    parser.add_argument(
        "--scenario",
        type=str,
        choices=["cultural", "budget", "adventure"],
        default="cultural",
        help="Travel scenario to run (default: cultural)"
    )
    parser.add_argument(
        "--log-level",
        type=str,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level (default: INFO)"
    )
    parser.add_argument(
        "--log-file",
        type=str,
        help="Optional log file path"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=5,
        help="Maximum parallel workers (default: 5)"
    )

    args = parser.parse_args()

    # Setup logging
    log_file = args.log_file or "logs/travel_planner.log"
    setup_logging(log_level=args.log_level, log_file=log_file)

    logger = logging.getLogger(__name__)
    logger.info("Starting Travel Itinerary Planner")
    logger.info(f"Scenario: {args.scenario}")

    try:
        # Load configuration
        config = ConfigManager()
        logger.info(f"Configuration loaded from: {config.config_file}")

        # Create travel request based on scenario
        scenarios = {
            "cultural": create_sample_travel_request,
            "budget": create_budget_travel_request,
            "adventure": create_adventure_travel_request
        }

        initial_state = scenarios[args.scenario]()
        logger.info(f"Created travel request: {initial_state.planning_id}")

        # Build workflow
        workflow = build_travel_planning_workflow(max_workers=args.workers)
        logger.info("Workflow built successfully")

        # Execute workflow
        print(f"\nProcessing travel planning request for {initial_state.destination}...")
        print(f"Running {args.scenario} scenario with {args.workers} parallel workers\n")

        final_state = workflow.run(initial_state)

        # Print results
        print_itinerary_summary(final_state)

        # Log completion
        logger.info(
            f"Workflow completed - Decision: {final_state.decision}, "
            f"Score: {final_state.overall_score:.2f}"
        )

        # Print notification status
        if final_state.notifications_sent:
            last_notification = final_state.notifications_sent[-1]
            if last_notification.get("status") == "sent":
                print(f"\n✓ Itinerary sent to {final_state.traveler_email}")
            else:
                print(f"\n✗ Failed to send itinerary (email service may not be configured)")

        return 0

    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        print("\n\nProcess interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Fatal error: {str(e)}", exc_info=True)
        print(f"\n\nError: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
