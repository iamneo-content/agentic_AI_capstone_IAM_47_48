"""
Destination Matcher Agent

Matches destinations to traveler preferences and provides suitability scores
based on interests, travel style, and expectations.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.destination_matcher import DestinationMatcher
from state import TravelItineraryState


class DestinationMatcherAgent(BaseAgent):
    """Agent responsible for matching destinations to traveler preferences"""

    def __init__(self):
        super().__init__("DestinationMatcher")
        self.matcher = DestinationMatcher()

    def analyze(self, state: TravelItineraryState) -> Dict[str, Any]:
        """
        Match destination to traveler preferences

        Args:
            state: Current travel planning state

        Returns:
            Destination matching results with suitability scores
        """
        self.log(f"Matching destination {state.destination} to traveler preferences")

        try:
            # Extract traveler parameters
            destination = state.destination
            interests = state.interests
            travel_style = state.travel_style
            traveler_preferences = state.traveler_preferences
            group_size = state.group_size

            # Perform destination matching
            matching_result = self.matcher.match_destination(
                destination=destination,
                interests=interests,
                travel_style=travel_style,
                preferences=traveler_preferences,
                group_size=group_size
            )

            self.log(
                f"Destination matching complete - Match Score: {matching_result.get('match_score', 0):.2f}, "
                f"Suitability: {matching_result.get('suitability_level', 'N/A')}"
            )

            return matching_result

        except Exception as e:
            self.log(f"Error during destination matching: {str(e)}", level="error")
            return {
                "agent": "DestinationMatcher",
                "status": "error",
                "error_message": str(e),
                "match_score": 0.0,
                "suitability_level": "UNKNOWN"
            }
