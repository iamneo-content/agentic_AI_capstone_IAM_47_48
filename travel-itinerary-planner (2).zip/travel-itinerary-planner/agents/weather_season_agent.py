"""
Weather and Season Agent

Analyzes weather patterns, seasonal suitability, and climate considerations
for the travel destination and dates.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.weather_season_analyzer import WeatherSeasonAnalyzer
from state import TravelItineraryState


class WeatherSeasonAgent(BaseAgent):
    """Agent responsible for weather and seasonal analysis"""

    def __init__(self):
        super().__init__("WeatherSeason")
        self.analyzer = WeatherSeasonAnalyzer()

    def analyze(self, state: TravelItineraryState) -> Dict[str, Any]:
        """
        Analyze weather and seasonal suitability

        Args:
            state: Current travel planning state

        Returns:
            Weather and season analysis with suitability scores
        """
        self.log(f"Analyzing weather/season for {state.destination}")

        try:
            # Extract relevant parameters
            destination = state.destination
            travel_dates = state.travel_dates
            interests = state.interests
            traveler_preferences = state.traveler_preferences

            # Perform weather/season analysis
            analysis_result = self.analyzer.analyze_weather_season(
                destination=destination,
                travel_dates=travel_dates,
                interests=interests,
                preferences=traveler_preferences
            )

            self.log(
                f"Weather/season analysis complete - "
                f"Suitability: {analysis_result.get('season_suitability', 'N/A')}, "
                f"Score: {analysis_result.get('weather_score', 0):.2f}"
            )

            return analysis_result

        except Exception as e:
            self.log(f"Error during weather/season analysis: {str(e)}", level="error")
            return {
                "agent": "WeatherSeason",
                "status": "error",
                "error_message": str(e),
                "season_suitability": "UNKNOWN",
                "weather_score": 0.0
            }
