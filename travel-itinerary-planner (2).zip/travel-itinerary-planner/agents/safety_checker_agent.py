"""
Safety Checker Agent

Evaluates destination safety, travel advisories, health requirements,
and security considerations for travelers.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.safety_checker import SafetyChecker
from state import TravelItineraryState


class SafetyCheckerAgent(BaseAgent):
    """Agent responsible for safety assessment and travel advisories"""

    def __init__(self):
        super().__init__("SafetyChecker")
        self.checker = SafetyChecker()

    def analyze(self, state: TravelItineraryState) -> Dict[str, Any]:
        """
        Assess destination safety and travel requirements

        Args:
            state: Current travel planning state

        Returns:
            Safety assessment with advisories and recommendations
        """
        self.log(f"Assessing safety for {state.destination}")

        try:
            # Extract relevant parameters
            destination = state.destination
            travel_dates = state.travel_dates
            group_size = state.group_size
            traveler_preferences = state.traveler_preferences

            # Perform safety assessment
            safety_result = self.checker.check_safety(
                destination=destination,
                travel_dates=travel_dates,
                group_size=group_size,
                preferences=traveler_preferences
            )

            self.log(
                f"Safety assessment complete - "
                f"Safety Level: {safety_result.get('safety_level', 'N/A')}, "
                f"Score: {safety_result.get('safety_score', 0):.2f}, "
                f"Critical Issues: {safety_result.get('has_critical_issues', False)}"
            )

            return safety_result

        except Exception as e:
            self.log(f"Error during safety assessment: {str(e)}", level="error")
            return {
                "agent": "SafetyChecker",
                "status": "error",
                "error_message": str(e),
                "safety_level": "UNKNOWN",
                "safety_score": 0.0,
                "has_critical_issues": True
            }
