"""
Budget Analyzer Agent

Analyzes budget feasibility, allocation, and provides recommendations
for travel spending across different categories.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.budget_analyzer import BudgetAnalyzer
from state import TravelItineraryState


class BudgetAnalyzerAgent(BaseAgent):
    """Agent responsible for budget analysis and financial planning"""

    def __init__(self):
        super().__init__("BudgetAnalyzer")
        self.analyzer = BudgetAnalyzer()

    def analyze(self, state: TravelItineraryState) -> Dict[str, Any]:
        """
        Analyze budget feasibility for the travel plan

        Args:
            state: Current travel planning state

        Returns:
            Budget analysis results with allocation recommendations
        """
        self.log(f"Analyzing budget for {state.destination} trip")

        try:
            # Extract travel parameters
            destination = state.destination
            budget = state.budget
            currency = state.currency
            travel_dates = state.travel_dates
            group_size = state.group_size
            travel_style = state.travel_style
            interests = state.interests

            # Perform budget analysis
            analysis_result = self.analyzer.analyze_budget(
                destination=destination,
                budget=budget,
                currency=currency,
                travel_dates=travel_dates,
                group_size=group_size,
                travel_style=travel_style,
                interests=interests
            )

            self.log(
                f"Budget analysis complete - Feasibility: {analysis_result.get('budget_feasibility', 'N/A')}, "
                f"Score: {analysis_result.get('budget_score', 0):.2f}"
            )

            return analysis_result

        except Exception as e:
            self.log(f"Error during budget analysis: {str(e)}", level="error")
            return {
                "agent": "BudgetAnalyzer",
                "status": "error",
                "error_message": str(e),
                "budget_feasibility": "UNKNOWN",
                "budget_score": 0.0
            }
