"""
Activity Recommender Agent

Recommends activities, attractions, and experiences based on traveler
interests, destination characteristics, and travel dates.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.activity_recommender import ActivityRecommender
from state import TravelItineraryState


class ActivityRecommenderAgent(BaseAgent):
    """Agent responsible for recommending activities and experiences"""

    def __init__(self):
        super().__init__("ActivityRecommender")
        self.recommender = ActivityRecommender()

    def analyze(self, state: TravelItineraryState) -> Dict[str, Any]:
        """
        Recommend activities for the travel itinerary

        Args:
            state: Current travel planning state

        Returns:
            Activity recommendations with categorization and scheduling
        """
        self.log(f"Recommending activities for {state.destination}")

        try:
            # Extract relevant parameters
            destination = state.destination
            interests = state.interests
            travel_dates = state.travel_dates
            budget = state.budget
            group_size = state.group_size
            travel_style = state.travel_style
            destination_info = state.destination_info

            # Generate activity recommendations
            recommendations = self.recommender.recommend_activities(
                destination=destination,
                interests=interests,
                travel_dates=travel_dates,
                budget=budget,
                group_size=group_size,
                travel_style=travel_style,
                destination_info=destination_info
            )

            self.log(
                f"Activity recommendations complete - "
                f"{len(recommendations.get('recommended_activities', []))} activities suggested, "
                f"Diversity Score: {recommendations.get('diversity_score', 0):.2f}"
            )

            return recommendations

        except Exception as e:
            self.log(f"Error during activity recommendation: {str(e)}", level="error")
            return {
                "agent": "ActivityRecommender",
                "status": "error",
                "error_message": str(e),
                "recommended_activities": [],
                "diversity_score": 0.0
            }
