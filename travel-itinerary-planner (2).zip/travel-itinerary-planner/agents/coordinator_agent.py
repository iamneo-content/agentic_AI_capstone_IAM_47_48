"""
Coordinator Agent

Aggregates results from all specialized agents and makes final decisions
on itinerary recommendations, budget adjustments, and travel feasibility.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from state import TravelItineraryState
from config import ConfigManager


class CoordinatorAgent(BaseAgent):
    """Agent responsible for coordinating all analysis results and making final decisions"""

    def __init__(self):
        super().__init__("Coordinator")
        self.config = ConfigManager()

    def analyze(self, state: TravelItineraryState) -> Dict[str, Any]:
        """
        Coordinate all agent results and make final decision

        Args:
            state: Current travel planning state with all analysis results

        Returns:
            Coordination summary with final decision and recommendations
        """
        self.log("Coordinating analysis results from all agents")

        try:
            # Extract analysis results
            budget_results = state.budget_analysis_results
            destination_results = state.destination_matching_results
            activity_results = state.activity_recommendations
            weather_results = state.weather_season_results
            safety_results = state.safety_assessment_results

            # Calculate overall scores
            budget_score = self._extract_score(budget_results, "budget_score", 0.0)
            destination_score = self._extract_score(destination_results, "match_score", 0.0)
            activity_score = self._extract_score(activity_results, "diversity_score", 0.0)
            weather_score = self._extract_score(weather_results, "weather_score", 0.0)
            safety_score = self._extract_score(safety_results, "safety_score", 0.0)

            # Weighted average for overall score (safety and budget weighted higher)
            overall_score = (
                budget_score * 0.25 +
                destination_score * 0.20 +
                activity_score * 0.15 +
                weather_score * 0.15 +
                safety_score * 0.25
            )

            # Check for critical safety issues
            has_critical_safety = self._extract_value(safety_results, "has_critical_issues", False)
            safety_level = self._extract_value(safety_results, "safety_level", "UNKNOWN")

            # Determine decision
            decision = self._make_decision(
                overall_score=overall_score,
                budget_score=budget_score,
                safety_score=safety_score,
                destination_score=destination_score,
                has_critical_safety=has_critical_safety
            )

            # Determine confidence level
            confidence_level = self._calculate_confidence(overall_score, [
                budget_score, destination_score, activity_score, weather_score, safety_score
            ])

            coordination_summary = {
                "agent": "Coordinator",
                "status": "success",
                "overall_score": overall_score,
                "component_scores": {
                    "budget": budget_score,
                    "destination_match": destination_score,
                    "activities": activity_score,
                    "weather_season": weather_score,
                    "safety": safety_score
                },
                "decision": decision,
                "confidence_level": confidence_level,
                "has_critical_issues": has_critical_safety,
                "safety_level": safety_level,
                "decision_rationale": self._generate_rationale(
                    decision, overall_score, budget_score, safety_score, destination_score
                ),
                "recommendations": self._generate_recommendations(
                    decision, budget_results, destination_results, safety_results
                )
            }

            self.log(
                f"Coordination complete - Decision: {decision}, "
                f"Overall Score: {overall_score:.2f}, Confidence: {confidence_level}"
            )

            return coordination_summary

        except Exception as e:
            self.log(f"Error during coordination: {str(e)}", level="error")
            return {
                "agent": "Coordinator",
                "status": "error",
                "error_message": str(e),
                "decision": "ERROR",
                "overall_score": 0.0,
                "confidence_level": "NONE"
            }

    def _extract_score(self, results: list, key: str, default: float) -> float:
        """Extract score from results list"""
        if results and len(results) > 0:
            return results[0].get(key, default)
        return default

    def _extract_value(self, results: list, key: str, default: Any) -> Any:
        """Extract value from results list"""
        if results and len(results) > 0:
            return results[0].get(key, default)
        return default

    def _make_decision(
        self,
        overall_score: float,
        budget_score: float,
        safety_score: float,
        destination_score: float,
        has_critical_safety: bool
    ) -> str:
        """Make final decision based on scores and criteria"""
        # Critical safety issues = immediate rejection
        if has_critical_safety:
            return "NOT_RECOMMENDED"

        # Very low safety score
        safety_threshold = self.config.get("SAFETY_THRESHOLD", 7.0)
        if safety_score < safety_threshold:
            return "NOT_RECOMMENDED"

        # Budget fit check
        budget_threshold = self.config.get("BUDGET_FIT_THRESHOLD", 0.85)
        destination_threshold = self.config.get("DESTINATION_MATCH_THRESHOLD", 7.0)

        # Excellent overall match
        if overall_score >= 8.5:
            return "RECOMMENDED"

        # Good match but budget concerns
        if overall_score >= 7.0 and budget_score < budget_threshold:
            return "BUDGET_ADJUST"

        # Good match but destination mismatch
        if overall_score >= 7.0 and destination_score < destination_threshold:
            return "ALTERNATIVE_DESTINATION"

        # Decent match
        if overall_score >= 6.5:
            return "RECOMMENDED"

        # Low scores
        return "NOT_RECOMMENDED"

    def _calculate_confidence(self, overall_score: float, component_scores: list) -> str:
        """Calculate confidence level based on score variance"""
        # Check score consistency
        avg_score = sum(component_scores) / len(component_scores)
        variance = sum((s - avg_score) ** 2 for s in component_scores) / len(component_scores)

        if variance < 0.5 and overall_score >= 8.0:
            return "HIGH"
        elif variance < 1.0 and overall_score >= 7.0:
            return "MEDIUM"
        else:
            return "LOW"

    def _generate_rationale(
        self,
        decision: str,
        overall_score: float,
        budget_score: float,
        safety_score: float,
        destination_score: float
    ) -> str:
        """Generate human-readable rationale for the decision"""
        if decision == "RECOMMENDED":
            return (
                f"Trip is recommended with overall score of {overall_score:.1f}/10. "
                f"Budget feasibility: {budget_score:.1f}/10, Safety: {safety_score:.1f}/10, "
                f"Destination match: {destination_score:.1f}/10."
            )
        elif decision == "BUDGET_ADJUST":
            return (
                f"Trip has good potential (score: {overall_score:.1f}/10) but budget adjustments needed. "
                f"Current budget feasibility: {budget_score:.1f}/10. Consider increasing budget or "
                f"adjusting travel style."
            )
        elif decision == "ALTERNATIVE_DESTINATION":
            return (
                f"Overall trip quality is good (score: {overall_score:.1f}/10) but destination match is low "
                f"({destination_score:.1f}/10). Consider alternative destinations that better match preferences."
            )
        elif decision == "NOT_RECOMMENDED":
            return (
                f"Trip is not recommended (score: {overall_score:.1f}/10). "
                f"Safety concerns ({safety_score:.1f}/10) or insufficient overall suitability."
            )
        else:
            return "Unable to make recommendation due to analysis error."

    def _generate_recommendations(
        self,
        decision: str,
        budget_results: list,
        destination_results: list,
        safety_results: list
    ) -> list:
        """Generate actionable recommendations"""
        recommendations = []

        if decision == "BUDGET_ADJUST":
            budget_feasibility = self._extract_value(budget_results, "budget_feasibility", "")
            if budget_feasibility == "TIGHT":
                recommendations.append("Consider extending trip duration to spread costs")
                recommendations.append("Look for budget accommodation options")
            elif budget_feasibility == "INSUFFICIENT":
                recommendations.append("Increase budget by 20-30%")
                recommendations.append("Consider traveling during off-season")

        if decision == "ALTERNATIVE_DESTINATION":
            alternatives = self._extract_value(destination_results, "alternative_destinations", [])
            if alternatives:
                recommendations.append(f"Alternative destinations: {', '.join(alternatives[:3])}")

        if decision == "NOT_RECOMMENDED":
            safety_advisories = self._extract_value(safety_results, "advisories", [])
            if safety_advisories:
                recommendations.extend(safety_advisories[:2])

        return recommendations
