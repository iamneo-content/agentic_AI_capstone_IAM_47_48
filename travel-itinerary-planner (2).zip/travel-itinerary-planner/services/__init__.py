"""Services for travel itinerary planner"""

from .email_service import EmailService

__all__ = ["EmailService"]
