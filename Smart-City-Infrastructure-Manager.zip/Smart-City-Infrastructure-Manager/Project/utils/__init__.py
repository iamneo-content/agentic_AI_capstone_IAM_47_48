"""Utils package initialization"""
