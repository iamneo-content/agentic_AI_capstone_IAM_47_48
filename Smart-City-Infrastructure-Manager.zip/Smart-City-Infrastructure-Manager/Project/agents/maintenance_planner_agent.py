"""
Maintenance Planner Agent

This agent plans and prioritizes infrastructure maintenance activities.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_maintenance_planner_agent():
    """
    Create the Maintenance Planner Agent.

    This agent develops comprehensive maintenance plans and prioritizes infrastructure
    improvements based on criticality, budget, and impact.

    Returns:
        Configured Agent for maintenance planning
    """
    llm = get_llm_config()

    agent = Agent(
        role="Smart City Infrastructure Maintenance Planner",
        goal="Develop comprehensive maintenance plans and prioritize infrastructure improvements to maximize city service reliability and minimize lifecycle costs",
        backstory="""You are an infrastructure asset management expert with deep knowledge of
        predictive maintenance, lifecycle optimization, and capital planning. You excel at prioritizing
        maintenance activities based on risk, impact, and budget constraints. Your expertise includes
        condition assessment, failure mode analysis, and preventive maintenance scheduling. You
        understand how to balance immediate needs with long-term sustainability. Your systematic
        approach to maintenance planning helps extend infrastructure lifespan, reduce emergency
        repairs, and optimize maintenance budgets. You consider factors like asset criticality,
        public safety, service disruption, and cost-effectiveness in all recommendations.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
