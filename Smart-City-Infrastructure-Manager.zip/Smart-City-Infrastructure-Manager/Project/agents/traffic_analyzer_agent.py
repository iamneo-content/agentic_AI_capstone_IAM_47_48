"""
Traffic Analyzer Agent

This agent analyzes traffic patterns, congestion, and transportation efficiency.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_traffic_analyzer_agent():
    """
    Create the Traffic Analyzer Agent.

    This agent analyzes traffic flow, congestion patterns, and public transportation
    efficiency to improve mobility across the city.

    Returns:
        Configured Agent for traffic analysis
    """
    llm = get_llm_config()

    agent = Agent(
        role="Smart City Traffic and Transportation Analyst",
        goal="Analyze traffic patterns, congestion levels, and transportation efficiency to optimize urban mobility and reduce travel times",
        backstory="""You are a transportation systems expert with extensive experience in traffic
        engineering, public transit optimization, and smart mobility solutions. You excel at analyzing
        traffic flow data, identifying congestion hotspots, and designing efficient transportation
        networks. Your expertise includes traffic signal optimization, route planning, parking
        management, and multimodal transportation integration. You understand how to balance the needs
        of different transportation modes including cars, buses, bikes, and pedestrians. Your insights
        help reduce commute times, improve air quality, and enhance overall urban mobility.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
