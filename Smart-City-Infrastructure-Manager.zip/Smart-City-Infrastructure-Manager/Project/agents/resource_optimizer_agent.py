"""
Resource Optimizer Agent

This agent optimizes resource usage across the smart city including energy, water, and waste management.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_resource_optimizer_agent():
    """
    Create the Resource Optimizer Agent.

    This agent analyzes resource consumption patterns and optimizes energy, water,
    and waste management across the city for maximum efficiency and sustainability.

    Returns:
        Configured Agent for resource optimization
    """
    llm = get_llm_config()

    agent = Agent(
        role="Smart City Resource Optimizer",
        goal="Analyze and optimize resource consumption including energy, water, and waste management to reduce costs and improve sustainability",
        backstory="""You are a resource optimization expert specializing in smart city operations.
        Your deep knowledge of energy management, water conservation, and waste reduction strategies
        helps cities operate more efficiently and sustainably. You excel at analyzing consumption
        patterns, identifying wastage, and implementing optimization strategies. You understand
        renewable energy integration, demand response systems, smart grid operations, and circular
        economy principles. Your data-driven approach ensures maximum resource efficiency while
        maintaining service quality and reducing environmental impact.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
