"""
Infrastructure Monitor Agent

This agent monitors all smart city infrastructure components and their health status.
"""

from crewai import Agent
from tools.infrastructure_monitoring_tool import InfrastructureMonitoringTool
from utils.llm_config import get_llm_config


def create_infrastructure_monitor_agent():
    """
    Create the Infrastructure Monitor Agent.

    This agent monitors infrastructure health across roads, bridges, utilities,
    and public services to ensure optimal city operations.

    Returns:
        Configured Agent for infrastructure monitoring
    """
    llm = get_llm_config()

    infrastructure_monitoring_tool = InfrastructureMonitoringTool()

    agent = Agent(
        role="Smart City Infrastructure Monitor",
        goal="Monitor and assess the health, status, and performance of all smart city infrastructure components to ensure optimal city operations",
        backstory="""You are an expert infrastructure monitoring specialist with extensive experience
        in smart city systems, IoT sensor networks, and urban infrastructure management. You excel at
        collecting real-time data from roads, bridges, water supply systems, electrical grids, public
        transportation, waste management, street lighting, and communication networks. Your expertise
        in predictive analytics helps identify potential infrastructure failures before they occur.
        You understand the importance of maintaining high service availability and citizen satisfaction.""",
        llm=llm,
        tools=[infrastructure_monitoring_tool],
        verbose=True
    )

    return agent
