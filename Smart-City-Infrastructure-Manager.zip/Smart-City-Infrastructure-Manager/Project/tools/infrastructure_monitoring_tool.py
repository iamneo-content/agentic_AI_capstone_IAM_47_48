"""
Infrastructure Monitoring Tool

A tool for monitoring smart city infrastructure health and status.
"""

from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import random


class InfrastructureMonitoringInput(BaseModel):
    """Input schema for Infrastructure Monitoring Tool."""
    infrastructure_type: str = Field(..., description="Type of infrastructure: roads, bridges, water, electrical, transport, waste, lighting, network")


class InfrastructureMonitoringTool(BaseTool):
    name: str = "Infrastructure Monitoring System"
    description: str = (
        "Monitors smart city infrastructure health, status, and performance metrics. "
        "Provides real-time data on roads, bridges, utilities, and public services."
    )
    args_schema: Type[BaseModel] = InfrastructureMonitoringInput

    def _run(self, infrastructure_type: str) -> str:
        """
        Simulate infrastructure monitoring data collection.

        Args:
            infrastructure_type: Type of infrastructure to monitor

        Returns:
            Formatted infrastructure monitoring report
        """
        # Simulate infrastructure monitoring data
        total_assets = random.randint(500, 1500)
        critical_assets = random.randint(5, 25)
        needs_maintenance = random.randint(30, 120)
        health_score = random.uniform(65, 92)
        operational_efficiency = random.uniform(70, 95)

        infrastructure_metrics = {
            "roads": {
                "condition_index": random.uniform(70, 90),
                "traffic_flow_efficiency": random.uniform(65, 88),
                "pothole_count": random.randint(50, 200),
                "accident_hotspots": random.randint(5, 15)
            },
            "bridges": {
                "structural_integrity": random.uniform(75, 95),
                "load_capacity_percent": random.uniform(80, 98),
                "inspection_overdue": random.randint(2, 10)
            },
            "water": {
                "supply_reliability": random.uniform(85, 98),
                "leak_detection_rate": random.uniform(70, 90),
                "water_quality_index": random.uniform(80, 95),
                "pressure_stability": random.uniform(85, 98)
            },
            "electrical": {
                "grid_stability": random.uniform(90, 99),
                "outage_frequency": random.randint(2, 8),
                "renewable_integration": random.uniform(25, 45),
                "peak_demand_handling": random.uniform(80, 95)
            },
            "transport": {
                "on_time_performance": random.uniform(75, 92),
                "passenger_capacity_utilization": random.uniform(60, 85),
                "vehicle_condition_score": random.uniform(70, 90),
                "route_coverage_percent": random.uniform(85, 98)
            }
        }

        issues_detected = {
            "critical": random.randint(2, 8),
            "high": random.randint(10, 30),
            "medium": random.randint(20, 60),
            "low": random.randint(30, 100)
        }

        result = f"""
Smart City Infrastructure Monitoring Report - {infrastructure_type.upper()}
{'='*70}

Asset Overview:
- Total Infrastructure Assets: {total_assets}
- Assets Requiring Immediate Attention: {critical_assets}
- Assets Needing Scheduled Maintenance: {needs_maintenance}
- Overall Infrastructure Health Score: {health_score:.1f}/100
- Operational Efficiency: {operational_efficiency:.1f}%

Infrastructure-Specific Metrics:
"""

        if infrastructure_type.lower() in infrastructure_metrics:
            metrics = infrastructure_metrics[infrastructure_type.lower()]
            for key, value in metrics.items():
                metric_name = key.replace('_', ' ').title()
                if isinstance(value, float):
                    result += f"- {metric_name}: {value:.2f}%\n"
                else:
                    result += f"- {metric_name}: {value}\n"

        result += f"""
Issues Detected by Severity:
- Critical Issues: {issues_detected['critical']} (immediate action required)
- High Priority: {issues_detected['high']} (action within 7 days)
- Medium Priority: {issues_detected['medium']} (action within 30 days)
- Low Priority: {issues_detected['low']} (routine maintenance)

Performance Indicators:
- Citizen Satisfaction Index: {random.uniform(70, 88):.1f}%
- Service Availability: {random.uniform(92, 99.5):.2f}%
- Response Time to Issues: {random.uniform(2, 8):.1f} hours
- Maintenance Budget Utilization: {random.uniform(70, 95):.1f}%

Predictive Analysis:
- Projected Maintenance Needs (Next 90 Days): {random.randint(80, 200)} assets
- Expected Service Disruptions: {random.randint(3, 12)} incidents
- Budget Forecast: ${random.randint(2, 8)}M required
- Infrastructure Lifecycle Status: {random.choice(['Good', 'Fair', 'Needs Attention'])}

IoT Sensor Status:
- Active Sensors: {random.randint(800, 2000)}
- Sensor Uptime: {random.uniform(95, 99.8):.2f}%
- Data Collection Rate: {random.randint(1000, 5000)} readings/hour
- Anomalies Detected: {random.randint(5, 25)} in last 24 hours
"""
        return result
