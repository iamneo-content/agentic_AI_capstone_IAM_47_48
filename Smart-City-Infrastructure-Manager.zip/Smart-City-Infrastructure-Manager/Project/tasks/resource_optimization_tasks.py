"""
Resource Optimization Tasks

Tasks for optimizing resource usage across the smart city.
"""

from crewai import Task
from agents.resource_optimizer_agent import create_resource_optimizer_agent

resource_optimization_task = Task(
    description="""Analyze and optimize resource consumption across the smart city.

    Your tasks:
    1. Analyze energy consumption patterns across city infrastructure
    2. Identify opportunities for renewable energy integration
    3. Optimize electrical grid load distribution and peak demand management
    4. Assess water usage efficiency and identify conservation opportunities
    5. Analyze waste management operations and identify recycling improvements
    6. Evaluate resource costs and identify cost reduction opportunities
    7. Calculate sustainability metrics and environmental impact
    8. Identify resource wastage and inefficiencies
    9. Design optimization strategies for energy, water, and waste
    10. Estimate cost savings and environmental benefits

    Focus on data-driven optimization to reduce costs and improve sustainability.""",

    expected_output="""A comprehensive resource optimization report containing:
    - Energy consumption analysis by sector and time period
    - Renewable energy integration opportunities
    - Water usage patterns and conservation potential
    - Waste management efficiency metrics
    - Resource cost analysis and reduction opportunities
    - Sustainability performance indicators
    - Carbon footprint and environmental impact assessment
    - Optimization recommendations with expected savings
    - Implementation priorities and timelines
    - ROI analysis for optimization initiatives""",

    agent=create_resource_optimizer_agent()
)
