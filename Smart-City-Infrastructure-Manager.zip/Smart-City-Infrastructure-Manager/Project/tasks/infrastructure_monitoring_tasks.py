"""
Infrastructure Monitoring Tasks

Tasks for monitoring smart city infrastructure health and status.
"""

from crewai import Task
from agents.infrastructure_monitor_agent import create_infrastructure_monitor_agent

infrastructure_monitoring_task = Task(
    description="""Monitor all smart city infrastructure components and assess their health status.

    Your tasks:
    1. Monitor roads, highways, and transportation networks for condition and performance
    2. Assess bridges, tunnels, and critical infrastructure structural integrity
    3. Check water supply systems for reliability, quality, and leak detection
    4. Monitor electrical grid stability, outages, and renewable energy integration
    5. Evaluate public transportation on-time performance and capacity utilization
    6. Assess waste management efficiency and collection operations
    7. Monitor street lighting and communication network status
    8. Collect IoT sensor data and identify anomalies
    9. Calculate overall infrastructure health scores
    10. Identify critical issues requiring immediate attention

    Focus on comprehensive monitoring across all infrastructure types.""",

    expected_output="""A comprehensive infrastructure monitoring report containing:
    - Total infrastructure assets count and categorization
    - Overall infrastructure health score
    - Operational efficiency metrics
    - Infrastructure-specific performance indicators
    - Issues detected by severity (critical, high, medium, low)
    - Citizen satisfaction and service availability metrics
    - Predictive maintenance needs for next 90 days
    - IoT sensor status and data collection rates
    - Budget forecast for infrastructure maintenance
    - Detailed condition assessments for each infrastructure type""",

    agent=create_infrastructure_monitor_agent()
)
