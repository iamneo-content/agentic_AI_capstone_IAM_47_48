"""
Traffic Analysis Tasks

Tasks for analyzing traffic patterns and transportation efficiency.
"""

from crewai import Task
from agents.traffic_analyzer_agent import create_traffic_analyzer_agent

traffic_analysis_task = Task(
    description="""Analyze traffic patterns, congestion, and transportation efficiency across the city.

    Your tasks:
    1. Analyze traffic flow patterns during peak and off-peak hours
    2. Identify congestion hotspots and bottlenecks
    3. Assess public transportation utilization and on-time performance
    4. Evaluate parking availability and utilization rates
    5. Analyze multimodal transportation integration
    6. Identify accident-prone areas and safety concerns
    7. Calculate average commute times and travel efficiency
    8. Assess impact of traffic on air quality and emissions
    9. Evaluate traffic signal timing and coordination
    10. Identify opportunities for traffic flow optimization

    Focus on improving mobility and reducing congestion through data-driven insights.""",

    expected_output="""A comprehensive traffic analysis report containing:
    - Traffic flow patterns and congestion levels
    - Congestion hotspot identification with severity ratings
    - Public transportation performance metrics
    - Parking utilization analysis
    - Multimodal transportation assessment
    - Accident hotspot identification
    - Average commute time analysis
    - Traffic impact on air quality
    - Traffic signal optimization opportunities
    - Mobility improvement recommendations""",

    agent=create_traffic_analyzer_agent()
)
