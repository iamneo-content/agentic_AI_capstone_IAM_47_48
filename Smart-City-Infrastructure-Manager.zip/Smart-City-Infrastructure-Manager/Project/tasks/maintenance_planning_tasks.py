"""
Maintenance Planning Tasks

Tasks for planning and prioritizing infrastructure maintenance.
"""

from crewai import Task
from agents.maintenance_planner_agent import create_maintenance_planner_agent

maintenance_planning_task = Task(
    description="""Develop comprehensive maintenance plans for smart city infrastructure.

    Your tasks:
    1. Prioritize infrastructure maintenance based on criticality and risk
    2. Develop preventive maintenance schedules for all asset types
    3. Plan corrective maintenance for identified issues
    4. Allocate maintenance budgets across infrastructure categories
    5. Schedule maintenance to minimize service disruptions
    6. Identify infrastructure requiring immediate intervention
    7. Plan long-term capital improvements and upgrades
    8. Estimate maintenance costs and resource requirements
    9. Develop emergency response and contingency plans
    10. Create implementation roadmap with timelines and milestones

    Focus on maximizing infrastructure reliability while optimizing lifecycle costs.""",

    expected_output="""A comprehensive maintenance plan containing:
    - Prioritized maintenance activities by criticality and urgency
    - Preventive maintenance schedules for all infrastructure types
    - Corrective maintenance plans for identified issues
    - Budget allocation across infrastructure categories
    - Maintenance schedule minimizing service disruptions
    - Immediate intervention requirements
    - Long-term capital improvement roadmap
    - Cost estimates and resource requirements
    - Emergency response protocols
    - Implementation timeline with milestones and KPIs""",

    agent=create_maintenance_planner_agent()
)
