"""
Comprehensive Test Suite for Smart City Infrastructure Manager
All test cases using pytest
"""

import pytest
import ast
import json
from datetime import datetime
from unittest.mock import Mock, patch

# Import tools to test
from tools.infrastructure_monitoring_tool import InfrastructureMonitoringTool


# ==================== FIXTURES ====================

@pytest.fixture
def sample_infrastructure_type():
    """Sample infrastructure type for testing"""
    return "roads"


@pytest.fixture
def sample_infrastructure_data():
    """Sample infrastructure data for testing"""
    return {
        "total_assets": 1250,
        "critical_assets": 18,
        "needs_maintenance": 85,
        "health_score": 82.0,
        "operational_efficiency": 88.5
    }


# ==================== TEST CASES ====================

class TestInfrastructureMonitoringTool:
    """Test cases for InfrastructureMonitoringTool"""

    def test_infrastructure_monitoring_tool_returns_valid_structure(self, sample_infrastructure_type):
        """Test Case 1: Verify InfrastructureMonitoringTool returns valid structure"""
        tool = InfrastructureMonitoringTool()
        result = tool._run(infrastructure_type=sample_infrastructure_type)

        # Verify result is a string report
        assert isinstance(result, str)
        assert "Smart City Infrastructure Monitoring Report" in result
        assert "Asset Overview" in result

    def test_infrastructure_monitoring_tool_includes_all_metrics(self):
        """Test Case 2: Verify tool includes all required metrics"""
        tool = InfrastructureMonitoringTool()
        result = tool._run(infrastructure_type="electrical")

        # Check for all required sections
        assert "Total Infrastructure Assets" in result
        assert "Infrastructure Health Score" in result
        assert "Operational Efficiency" in result
        assert "Issues Detected by Severity" in result

    def test_infrastructure_monitoring_tool_different_types(self):
        """Test Case 3: Verify tool works with different infrastructure types"""
        tool = InfrastructureMonitoringTool()

        infrastructure_types = ["roads", "bridges", "water", "electrical", "transport"]

        for infra_type in infrastructure_types:
            result = tool._run(infrastructure_type=infra_type)
            assert isinstance(result, str)
            assert infra_type.upper() in result


class TestSmartCityFlow:
    """Test cases for Smart City Flow"""

    def test_flow_initialization(self):
        """Test Case 4: Verify Smart City Flow initializes correctly"""
        from flows.smart_city_flow import SmartCityFlow

        flow = SmartCityFlow(verbose=False)

        assert flow.verbose == False
        assert flow.infrastructure_health_score == 0.0
        assert flow.energy_efficiency_score == 0.0
        assert isinstance(flow.execution_metrics, dict)


class TestAgentCreation:
    """Test cases for Agent creation functions"""

    def test_infrastructure_monitor_agent_creation(self):
        """Test Case 5: Verify Infrastructure Monitor Agent is created correctly"""
        from agents.infrastructure_monitor_agent import create_infrastructure_monitor_agent

        agent = create_infrastructure_monitor_agent()

        assert agent.role == "Smart City Infrastructure Monitor"
        assert agent.verbose == True
        assert len(agent.tools) > 0

    def test_resource_optimizer_agent_creation(self):
        """Test Case 6: Verify Resource Optimizer Agent is created correctly"""
        from agents.resource_optimizer_agent import create_resource_optimizer_agent

        agent = create_resource_optimizer_agent()

        assert agent.role == "Smart City Resource Optimizer"
        assert agent.verbose == True

    def test_traffic_analyzer_agent_creation(self):
        """Test Case 7: Verify Traffic Analyzer Agent is created correctly"""
        from agents.traffic_analyzer_agent import create_traffic_analyzer_agent

        agent = create_traffic_analyzer_agent()

        assert agent.role == "Smart City Traffic and Transportation Analyst"
        assert agent.verbose == True

    def test_maintenance_planner_agent_creation(self):
        """Test Case 8: Verify Maintenance Planner Agent is created correctly"""
        from agents.maintenance_planner_agent import create_maintenance_planner_agent

        agent = create_maintenance_planner_agent()

        assert agent.role == "Smart City Infrastructure Maintenance Planner"
        assert agent.verbose == True


class TestTaskCreation:
    """Test cases for Task creation"""

    def test_infrastructure_monitoring_task_structure(self):
        """Test Case 9: Verify Infrastructure Monitoring Task has correct structure"""
        from tasks.infrastructure_monitoring_tasks import infrastructure_monitoring_task

        assert infrastructure_monitoring_task.description is not None
        assert infrastructure_monitoring_task.expected_output is not None
        assert infrastructure_monitoring_task.agent is not None

    def test_resource_optimization_task_structure(self):
        """Test Case 10: Verify Resource Optimization Task has correct structure"""
        from tasks.resource_optimization_tasks import resource_optimization_task

        assert resource_optimization_task.description is not None
        assert resource_optimization_task.expected_output is not None
        assert resource_optimization_task.agent is not None

    def test_traffic_analysis_task_structure(self):
        """Test Case 11: Verify Traffic Analysis Task has correct structure"""
        from tasks.traffic_analysis_tasks import traffic_analysis_task

        assert traffic_analysis_task.description is not None
        assert traffic_analysis_task.expected_output is not None
        assert traffic_analysis_task.agent is not None

    def test_maintenance_planning_task_structure(self):
        """Test Case 12: Verify Maintenance Planning Task has correct structure"""
        from tasks.maintenance_planning_tasks import maintenance_planning_task

        assert maintenance_planning_task.description is not None
        assert maintenance_planning_task.expected_output is not None
        assert maintenance_planning_task.agent is not None


class TestConfigurationFiles:
    """Test cases for configuration files"""

    def test_app_config_structure(self):
        """Test Case 13: Verify app_config.json has correct structure"""
        import json
        from pathlib import Path

        config_path = Path(__file__).parent / 'configs' / 'app_config.json'

        with open(config_path, 'r') as f:
            config = json.load(f)

        assert "llm_config" in config
        assert "smart_city_settings" in config
        assert "resource_optimization" in config
        assert "maintenance_priorities" in config


class TestUtilityFunctions:
    """Test cases for utility functions"""

    def test_llm_config_utility_returns_model(self):
        """Test Case 14: Verify get_llm_config returns model string"""
        from utils.llm_config import get_llm_config

        model = get_llm_config()

        assert isinstance(model, str)
        assert "gemini" in model.lower()

    def test_output_handler_processes_results(self, sample_infrastructure_data):
        """Test Case 15: Verify output handler can process results"""
        from utils.output_handler import process_and_save_results

        # Create a test result
        test_result = {
            "status": "completed",
            "results": sample_infrastructure_data
        }

        # This should return True if successful
        result = process_and_save_results(test_result)

        assert isinstance(result, bool)


# ==================== MAIN ====================

if __name__ == "__main__":
    # Run tests with pytest when executed directly
    pytest.main([__file__, "-v", "--tb=short"])
