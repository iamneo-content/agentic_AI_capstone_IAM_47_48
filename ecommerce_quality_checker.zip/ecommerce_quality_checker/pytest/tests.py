"""
Comprehensive Test Suite for E-commerce Product Quality Checker
Uses pytest framework with mock data
"""
import pytest
from unittest.mock import Mock, MagicMock, patch
from typing import Dict, Any

# Import modules to test
from state import ProductData, ProductQualityState, create_initial_state
from utils.validators import validate_product_data, validate_price, validate_url
from utils.helpers import (
    calculate_overall_score,
    determine_final_status,
    merge_issues,
    count_check_statuses
)
from utils.formatters import format_quality_report, format_json_report
from agents.description_agent import DescriptionQualityAgent
from agents.pricing_agent import PricingValidatorAgent
from agents.image_agent import ImageQualityAgent
from agents.category_agent import CategoryClassifierAgent
from agents.compliance_agent import ComplianceCheckerAgent
from agents.sentiment_agent import SentimentAnalyzerAgent
from analyzer.quality_analyzer import QualityAnalyzer
from analyzer.report_generator import ReportGenerator
from workflow.workflow_manager import WorkflowManager


# ============================================================================
# Mock Data Fixtures
# ============================================================================

@pytest.fixture
def valid_product() -> ProductData:
    """Valid product data for testing"""
    return {
        'product_id': 'TEST-001',
        'title': 'Premium Wireless Headphones',
        'description': 'High-quality wireless headphones with active noise cancellation',
        'price': 149.99,
        'category': 'Electronics',
        'images': [
            'https://example.com/image1.jpg',
            'https://example.com/image2.jpg',
            'https://example.com/image3.jpg'
        ],
        'specifications': {
            'Battery': '30 hours',
            'Bluetooth': '5.0'
        },
        'reviews': [
            {'rating': 5, 'text': 'Excellent product!'},
            {'rating': 4, 'text': 'Very good quality'}
        ]
    }


@pytest.fixture
def invalid_product() -> ProductData:
    """Invalid product data for testing"""
    return {
        'product_id': '',
        'title': 'AB',  # Too short
        'description': 'Short',  # Too short
        'price': -10,  # Invalid price
        'category': '',
        'images': [],
        'specifications': {},
        'reviews': []
    }


@pytest.fixture
def low_quality_product() -> ProductData:
    """Low quality product data"""
    return {
        'product_id': 'TEST-002',
        'title': 'Cheap Product',
        'description': 'This is a low quality product with minimal description',
        'price': 5.99,
        'category': 'Other',
        'images': ['https://example.com/image.jpg'],
        'specifications': {'color': 'red'},
        'reviews': [
            {'rating': 1, 'text': 'Terrible product'},
            {'rating': 2, 'text': 'Not worth it'}
        ]
    }


@pytest.fixture
def mock_gemini_service():
    """Mock Gemini service for testing"""
    mock_service = Mock()
    mock_service.analyze_with_structured_output = Mock(return_value={
        'score': 85.0,
        'status': 'passed',
        'issues': [],
        'suggestions': ['Consider adding more details'],
        'details': {}
    })
    return mock_service


@pytest.fixture
def quality_analyzer(mock_gemini_service):
    """Quality analyzer with mocked service"""
    return QualityAnalyzer(mock_gemini_service, use_llm=False)


@pytest.fixture
def workflow_manager(quality_analyzer):
    """Workflow manager for testing"""
    return WorkflowManager(quality_analyzer)


# ============================================================================
# Test Cases for Validators (utils/validators.py)
# ============================================================================

def test_validate_product_data_valid(valid_product):
    """Test Case 1: Validate valid product data"""
    is_valid, errors = validate_product_data(valid_product)
    assert is_valid is True
    assert len(errors) == 0


def test_validate_product_data_invalid(invalid_product):
    """Test Case 2: Validate invalid product data"""
    is_valid, errors = validate_product_data(invalid_product)
    assert is_valid is False
    assert len(errors) > 0


def test_validate_price_valid():
    """Test Case 3: Validate valid prices"""
    is_valid, errors = validate_price(99.99)
    assert is_valid is True
    assert len(errors) == 0

    is_valid, errors = validate_price(1000)
    assert is_valid is True


def test_validate_price_invalid():
    """Test Case 4: Validate invalid prices"""
    # Negative price
    is_valid, errors = validate_price(-10)
    assert is_valid is False
    assert len(errors) > 0

    # Zero price
    is_valid, errors = validate_price(0)
    assert is_valid is False

    # Non-numeric
    is_valid, errors = validate_price("invalid")
    assert is_valid is False


def test_validate_url():
    """Test Case 5: Validate URLs"""
    assert validate_url('https://example.com/image.jpg') is True
    assert validate_url('http://test.com') is True
    assert validate_url('invalid-url') is False
    assert validate_url('') is False
    assert validate_url(123) is False


# ============================================================================
# Test Cases for Helpers (utils/helpers.py)
# ============================================================================

def test_calculate_overall_score():
    """Test Case 6: Calculate overall score from quality results"""
    quality_results = [
        {'score': 80.0, 'status': 'passed'},
        {'score': 90.0, 'status': 'passed'},
        {'score': 70.0, 'status': 'warning'}
    ]
    overall_score = calculate_overall_score(quality_results)
    assert overall_score == 80.0  # (80 + 90 + 70) / 3


def test_determine_final_status():
    """Test Case 7: Determine final status based on score"""
    # High score - approved
    status = determine_final_status(85.0, [])
    assert status == 'approved'

    # Medium score - needs review
    status = determine_final_status(65.0, [])
    assert status == 'needs_review'

    # Low score - rejected
    status = determine_final_status(45.0, [])
    assert status == 'rejected'

    # Critical failures - rejected regardless of score
    status = determine_final_status(90.0, ['Critical issue'])
    assert status == 'rejected'


def test_merge_issues():
    """Test Case 8: Merge issues from multiple agents"""
    quality_results = [
        {
            'agent_name': 'Agent1',
            'issues': ['Issue 1', 'Issue 2']
        },
        {
            'agent_name': 'Agent2',
            'issues': ['Issue 3']
        }
    ]
    merged = merge_issues(quality_results)
    assert len(merged) == 3
    assert any('Agent1' in issue for issue in merged)


def test_count_check_statuses():
    """Test Case 9: Count check statuses"""
    quality_results = [
        {'status': 'passed'},
        {'status': 'passed'},
        {'status': 'failed'},
        {'status': 'warning'}
    ]
    counts = count_check_statuses(quality_results)
    assert counts['passed'] == 2
    assert counts['failed'] == 1
    assert counts['warning'] == 1


# ============================================================================
# Test Cases for Agents
# ============================================================================

def test_description_agent_quick_check(mock_gemini_service, valid_product):
    """Test Case 10: Description agent quick check"""
    agent = DescriptionQualityAgent(mock_gemini_service)
    result = agent.quick_check(valid_product)

    assert 'score' in result
    assert 'status' in result
    assert 'issues' in result
    assert 'suggestions' in result
    assert result['agent_name'] == 'Description Quality Agent'


def test_pricing_agent_quick_check(mock_gemini_service, valid_product):
    """Test Case 11: Pricing agent quick check"""
    agent = PricingValidatorAgent(mock_gemini_service)
    result = agent.quick_check(valid_product)

    assert result['score'] > 0
    assert result['status'] in ['passed', 'warning', 'failed']
    assert result['details']['price'] == valid_product['price']


def test_image_agent_quick_check(mock_gemini_service, valid_product):
    """Test Case 12: Image agent quick check"""
    agent = ImageQualityAgent(mock_gemini_service)
    result = agent.quick_check(valid_product)

    assert result['score'] > 0
    assert result['details']['image_count'] == len(valid_product['images'])


def test_category_agent_quick_check(mock_gemini_service, valid_product):
    """Test Case 13: Category agent quick check"""
    agent = CategoryClassifierAgent(mock_gemini_service)
    result = agent.quick_check(valid_product)

    assert 'score' in result
    assert result['details']['category'] == valid_product['category']


def test_compliance_agent_quick_check(mock_gemini_service, valid_product):
    """Test Case 14: Compliance agent quick check"""
    agent = ComplianceCheckerAgent(mock_gemini_service)
    result = agent.quick_check(valid_product)

    assert result['score'] >= 0
    assert isinstance(result['issues'], list)


def test_sentiment_agent_quick_check(mock_gemini_service, valid_product):
    """Test Case 15: Sentiment agent quick check with reviews"""
    agent = SentimentAnalyzerAgent(mock_gemini_service)
    result = agent.quick_check(valid_product)

    assert result['score'] > 0
    assert result['details']['review_count'] == len(valid_product['reviews'])


# ============================================================================
# Test Cases for Quality Analyzer
# ============================================================================

def test_quality_analyzer_run_all_checks(quality_analyzer, valid_product):
    """Test Case 16: Run all quality checks"""
    results = quality_analyzer.run_all_checks(valid_product)

    assert len(results) == 6  # 6 agents
    assert all('agent_name' in r for r in results)
    assert all('score' in r for r in results)


def test_quality_analyzer_analyze_product(quality_analyzer, valid_product):
    """Test Case 17: Complete product analysis"""
    analysis = quality_analyzer.analyze_product(valid_product)

    assert 'product' in analysis
    assert 'quality_results' in analysis
    assert 'overall_score' in analysis
    assert 'final_status' in analysis
    assert 'metadata' in analysis


# ============================================================================
# Test Cases for Workflow
# ============================================================================

def test_workflow_manager_execute(workflow_manager, valid_product):
    """Test Case 18: Execute complete workflow"""
    result = workflow_manager.execute_workflow(valid_product, generate_report=True)

    assert 'state' in result
    assert 'analysis' in result
    assert 'reports' in result
    assert result['state']['final_status'] in ['approved', 'needs_review', 'rejected']


def test_workflow_manager_quick_check(workflow_manager, valid_product):
    """Test Case 19: Execute quick check workflow"""
    result = workflow_manager.execute_quick_check(valid_product)

    assert 'state' in result
    assert 'analysis' in result
    assert result['analysis']['overall_score'] >= 0


def test_workflow_validation_only(workflow_manager, valid_product):
    """Test Case 20: Test validation-only workflow"""
    result = workflow_manager.validate_product_only(valid_product)

    assert 'valid' in result
    assert 'errors' in result
    assert result['valid'] is True


# ============================================================================
# Test Cases for State Management
# ============================================================================

def test_create_initial_state(valid_product):
    """Test Case 21: Create initial workflow state"""
    state = create_initial_state(valid_product)

    assert state['product'] == valid_product
    assert state['overall_score'] == 0.0
    assert state['final_status'] == 'pending'
    assert len(state['quality_results']) == 0
    assert len(state['errors']) == 0


# ============================================================================
# Test Cases for Report Generation
# ============================================================================

def test_report_generator_text_report():
    """Test Case 22: Generate text report"""
    generator = ReportGenerator()

    analysis = {
        'product': {'product_id': 'TEST', 'title': 'Test Product'},
        'overall_score': 85.0,
        'final_status': 'approved',
        'quality_results': [],
        'all_issues': [],
        'recommendations': [],
        'metadata': {'total_checks': 6}
    }

    report = generator.generate_text_report(analysis)
    assert 'Test Product' in report
    assert '85' in report


def test_report_generator_executive_summary():
    """Test Case 23: Generate executive summary"""
    generator = ReportGenerator()

    analysis = {
        'product': {'product_id': 'TEST', 'title': 'Test Product'},
        'overall_score': 85.0,
        'final_status': 'approved',
        'all_issues': ['Issue 1'],
        'recommendations': ['Rec 1'],
        'metadata': {'total_checks': 6, 'critical_issues_count': 0}
    }

    summary = generator.generate_executive_summary(analysis)
    assert summary['overall_score'] == 85.0
    assert summary['final_status'] == 'approved'
    assert 'APPROVE' in summary['recommendation']


# ============================================================================
# Test Case for Edge Cases
# ============================================================================

def test_empty_product_validation():
    """Test Case 24: Validate empty product data"""
    empty_product = {}
    is_valid, errors = validate_product_data(empty_product)
    assert is_valid is False
    assert len(errors) > 0


def test_product_with_no_reviews(mock_gemini_service):
    """Test Case 25: Test sentiment analysis with no reviews"""
    agent = SentimentAnalyzerAgent(mock_gemini_service)
    product = {
        'product_id': 'TEST',
        'title': 'No Review Product',
        'reviews': []
    }

    result = agent.quick_check(product)
    assert result['status'] == 'warning'
    assert result['details']['has_reviews'] is False


# ============================================================================
# Run all tests
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, '-v', '--tb=short'])
