"""
State definitions for E-commerce Product Quality Checker
"""
from typing import TypedDict, List, Dict, Optional, Annotated
from operator import add


class ProductData(TypedDict):
    """Product information structure"""
    product_id: str
    title: str
    description: str
    price: float
    category: str
    images: List[str]
    specifications: Dict[str, str]
    reviews: Optional[List[Dict[str, str]]]


class QualityCheckResult(TypedDict):
    """Result from a quality check"""
    agent_name: str
    status: str  # 'passed', 'failed', 'warning'
    score: float  # 0-100
    issues: List[str]
    suggestions: List[str]
    details: Dict[str, any]


class ProductQualityState(TypedDict):
    """
    State for the product quality checking workflow
    """
    # Input product data
    product: ProductData

    # Quality check results from different agents
    quality_results: Annotated[List[QualityCheckResult], add]

    # Overall quality score
    overall_score: float

    # Final status
    final_status: str  # 'approved', 'rejected', 'needs_review'

    # Issues found across all checks
    all_issues: Annotated[List[str], add]

    # Recommendations for improvement
    recommendations: Annotated[List[str], add]

    # Current step in workflow
    current_step: str

    # Errors encountered
    errors: Annotated[List[str], add]

    # Metadata
    metadata: Dict[str, any]


def create_initial_state(product: ProductData) -> ProductQualityState:
    """Create initial state for a product quality check"""
    return {
        "product": product,
        "quality_results": [],
        "overall_score": 0.0,
        "final_status": "pending",
        "all_issues": [],
        "recommendations": [],
        "current_step": "initialized",
        "errors": [],
        "metadata": {
            "started_at": None,
            "completed_at": None,
            "total_checks": 0,
            "passed_checks": 0,
            "failed_checks": 0
        }
    }
