"""
Agent Execution Node - Executes all quality checking agents
"""
from typing import Dict, Any
from state import ProductQualityState
from analyzer.quality_analyzer import QualityAnalyzer


def agent_execution_node(state: ProductQualityState, analyzer: QualityAnalyzer = None) -> ProductQualityState:
    """
    Execute all quality checking agents

    Args:
        state: Current workflow state
        analyzer: Quality analyzer instance (injected by workflow)

    Returns:
        Updated state
    """
    print("Executing Agent Execution Node...")

    # Update current step
    state['current_step'] = 'agent_execution'

    # Skip if validation failed
    if state.get('final_status') == 'rejected' and state.get('errors'):
        print("Skipping agent execution due to validation failure")
        return state

    if analyzer is None:
        error_msg = "Quality analyzer not provided"
        state['errors'].append(error_msg)
        print(f"Error: {error_msg}")
        return state

    try:
        # Run all quality checks
        product = state['product']
        quality_results = analyzer.run_all_checks(product)

        # Add results to state
        state['quality_results'].extend(quality_results)

        print(f"Executed {len(quality_results)} agent checks")

        # Update metadata
        state['metadata']['total_checks'] = len(quality_results)

    except Exception as e:
        error_msg = f"Agent execution failed: {str(e)}"
        state['errors'].append(error_msg)
        print(f"Error: {error_msg}")

    return state
