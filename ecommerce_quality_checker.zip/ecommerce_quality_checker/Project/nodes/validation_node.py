"""
Validation Node - Validates input product data
"""
from typing import Dict, Any
from state import ProductQualityState
from utils.validators import validate_product_data
from datetime import datetime


def validation_node(state: ProductQualityState) -> ProductQualityState:
    """
    Validate product data before processing

    Args:
        state: Current workflow state

    Returns:
        Updated state
    """
    print("Executing Validation Node...")

    product = state['product']

    # Update current step
    state['current_step'] = 'validation'

    # Set start time
    if not state['metadata'].get('started_at'):
        state['metadata']['started_at'] = datetime.now().isoformat()

    # Validate product data
    is_valid, validation_errors = validate_product_data(product)

    if not is_valid:
        # Add validation errors
        state['errors'].extend(validation_errors)
        state['final_status'] = 'rejected'

        # Add validation error result
        error_result = {
            'agent_name': 'Validation',
            'score': 0.0,
            'status': 'failed',
            'issues': validation_errors,
            'suggestions': ['Fix validation errors before resubmitting'],
            'details': {'validation_failed': True}
        }
        state['quality_results'].append(error_result)

        print(f"Validation failed: {len(validation_errors)} errors found")
    else:
        print("Validation passed")

    return state
