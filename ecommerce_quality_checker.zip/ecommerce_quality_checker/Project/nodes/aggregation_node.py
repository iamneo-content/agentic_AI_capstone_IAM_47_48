"""
Aggregation Node - Aggregates results from all agents
"""
from typing import Dict, Any
from state import ProductQualityState
from utils.helpers import (
    calculate_overall_score,
    merge_issues,
    merge_recommendations,
    count_check_statuses
)


def aggregation_node(state: ProductQualityState) -> ProductQualityState:
    """
    Aggregate results from all quality checks

    Args:
        state: Current workflow state

    Returns:
        Updated state
    """
    print("Executing Aggregation Node...")

    # Update current step
    state['current_step'] = 'aggregation'

    # Skip if no quality results
    quality_results = state.get('quality_results', [])
    if not quality_results:
        print("No quality results to aggregate")
        return state

    try:
        # Calculate overall score
        overall_score = calculate_overall_score(quality_results)
        state['overall_score'] = overall_score

        # Merge all issues
        all_issues = merge_issues(quality_results)
        state['all_issues'].extend(all_issues)

        # Merge all recommendations
        recommendations = merge_recommendations(quality_results)
        state['recommendations'].extend(recommendations)

        # Count check statuses
        status_counts = count_check_statuses(quality_results)
        state['metadata']['passed_checks'] = status_counts['passed']
        state['metadata']['failed_checks'] = status_counts['failed']
        state['metadata']['warning_checks'] = status_counts.get('warning', 0)

        print(f"Aggregated results - Overall Score: {overall_score:.1f}/100")
        print(f"Status counts - Passed: {status_counts['passed']}, "
              f"Failed: {status_counts['failed']}, "
              f"Warnings: {status_counts.get('warning', 0)}")

    except Exception as e:
        error_msg = f"Aggregation failed: {str(e)}"
        state['errors'].append(error_msg)
        print(f"Error: {error_msg}")

    return state
