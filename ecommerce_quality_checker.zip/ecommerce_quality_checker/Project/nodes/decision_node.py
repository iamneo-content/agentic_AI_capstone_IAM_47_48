"""
Decision Node - Makes final quality decision
"""
from typing import Dict, Any
from state import ProductQualityState
from utils.helpers import determine_final_status, extract_critical_issues
from datetime import datetime


def decision_node(state: ProductQualityState) -> ProductQualityState:
    """
    Make final quality decision based on aggregated results

    Args:
        state: Current workflow state

    Returns:
        Updated state with final decision
    """
    print("Executing Decision Node...")

    # Update current step
    state['current_step'] = 'decision'

    # Skip if already rejected due to validation
    if state.get('final_status') == 'rejected' and state.get('errors'):
        print("Final status already set to rejected due to errors")
        state['metadata']['completed_at'] = datetime.now().isoformat()
        return state

    try:
        # Get overall score
        overall_score = state.get('overall_score', 0.0)

        # Extract critical issues
        quality_results = state.get('quality_results', [])
        critical_issues = extract_critical_issues(quality_results)

        # Determine final status
        final_status = determine_final_status(overall_score, critical_issues)
        state['final_status'] = final_status

        # Add critical issues to all_issues if not already present
        for critical_issue in critical_issues:
            if critical_issue not in state['all_issues']:
                state['all_issues'].append(critical_issue)

        # Update metadata
        state['metadata']['critical_issues_count'] = len(critical_issues)
        state['metadata']['completed_at'] = datetime.now().isoformat()

        print(f"Final Decision: {final_status.upper()}")
        print(f"Overall Score: {overall_score:.1f}/100")
        print(f"Critical Issues: {len(critical_issues)}")

        # Add decision reasoning to metadata
        if final_status == 'approved':
            state['metadata']['decision_reason'] = f"High quality score ({overall_score:.1f}/100) with no critical issues"
        elif final_status == 'needs_review':
            state['metadata']['decision_reason'] = f"Moderate quality score ({overall_score:.1f}/100) requires review"
        else:
            if critical_issues:
                state['metadata']['decision_reason'] = f"Critical issues found: {len(critical_issues)}"
            else:
                state['metadata']['decision_reason'] = f"Low quality score ({overall_score:.1f}/100)"

    except Exception as e:
        error_msg = f"Decision making failed: {str(e)}"
        state['errors'].append(error_msg)
        state['final_status'] = 'rejected'
        state['metadata']['decision_reason'] = error_msg
        print(f"Error: {error_msg}")

    return state
