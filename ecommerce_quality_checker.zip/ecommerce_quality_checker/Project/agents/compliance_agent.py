"""
Compliance Checker Agent - Checks regulatory compliance
"""
from typing import Dict, Any, List
from services.gemini_service import GeminiService


class ComplianceCheckerAgent:
    """Agent for checking product compliance with regulations"""

    # Restricted/prohibited keywords
    PROHIBITED_CLAIMS = [
        'cure', 'cures', 'miracle', 'guaranteed results',
        'fda approved',  # when not actually approved
        'medical grade',  # when not certified
        'prescription strength'  # when OTC
    ]

    # Categories requiring special compliance
    REGULATED_CATEGORIES = [
        'Health & Beauty',
        'Baby Products',
        'Medical Devices',
        'Food & Supplements',
        'Electronics',
        'Toys & Games'
    ]

    def __init__(self, gemini_service: GeminiService):
        """
        Initialize Compliance Checker Agent

        Args:
            gemini_service: Gemini service instance
        """
        self.gemini_service = gemini_service
        self.agent_name = "Compliance Checker Agent"

    def analyze(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze product for compliance issues

        Args:
            product: Product data

        Returns:
            Quality check result
        """
        title = product.get('title', '')
        description = product.get('description', '')
        category = product.get('category', '')

        # Perform quick check first
        quick_result = self.quick_check(product)

        # Create analysis prompt for deeper compliance check
        prompt = f"""
Analyze this e-commerce product for compliance and regulatory issues:

Product: {title}
Category: {category}
Description: {description}

Check for:
1. Prohibited or misleading claims
2. Required disclosures and warnings
3. Age restrictions or safety warnings
4. Trademark or copyright concerns
5. Regulatory compliance for the category
6. Restricted or banned product keywords
7. Health and safety claims that require substantiation

Identify any compliance risks or required changes.
"""

        # Define output schema
        output_schema = {
            "score": "number (0-100)",
            "status": "string (passed/warning/failed)",
            "issues": ["list of compliance issues"],
            "suggestions": ["list of compliance recommendations"],
            "details": {
                "prohibited_claims_found": ["list of prohibited claims if any"],
                "missing_disclosures": ["list of missing required disclosures"],
                "regulatory_category": "boolean",
                "risk_level": "string (low/medium/high)",
                "required_warnings": ["list of warnings that should be added"]
            }
        }

        try:
            # Get structured analysis from Gemini
            result = self.gemini_service.analyze_with_structured_output(
                prompt=prompt,
                output_schema=output_schema,
                temperature=0.2  # Lower temperature for compliance
            )

            # Add agent name
            result['agent_name'] = self.agent_name

            # Merge with quick check results
            result['issues'] = list(set(result.get('issues', []) + quick_result['issues']))
            result['suggestions'] = list(set(result.get('suggestions', []) + quick_result['suggestions']))

            # Use lower score between LLM and quick check for safety
            llm_score = result.get('score', 100)
            result['score'] = min(llm_score, quick_result['score'])

            # Ensure required fields
            if 'status' not in result:
                result['status'] = quick_result['status']
            if 'details' not in result:
                result['details'] = {}

            return result

        except Exception as e:
            # Return quick check result on error
            quick_result['issues'].append(f"Deep compliance analysis failed: {str(e)}")
            return quick_result

    def quick_check(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform quick compliance validation

        Args:
            product: Product data

        Returns:
            Quick check result
        """
        title = product.get('title', '')
        description = product.get('description', '')
        category = product.get('category', '')

        issues = []
        suggestions = []
        score = 100.0

        text_to_check = f"{title} {description}".lower()

        # Check for prohibited claims
        prohibited_found = []
        prohibited_keywords = [
            ('cure', 'Claims to cure diseases'),
            ('miracle', 'Miracle product claims'),
            ('guaranteed weight loss', 'Guaranteed weight loss claims'),
            ('fda approved', 'FDA approval claims (verify if legitimate)'),
            ('medical grade', 'Medical grade claims (verify certification)'),
            ('treats cancer', 'Cancer treatment claims'),
            ('treats diabetes', 'Diabetes treatment claims')
        ]

        for keyword, description_text in prohibited_keywords:
            if keyword in text_to_check:
                prohibited_found.append(description_text)
                issues.append(f"Potentially prohibited claim: {description_text}")
                score -= 25

        # Check for regulated categories
        is_regulated = any(
            reg_cat.lower() in category.lower()
            for reg_cat in self.REGULATED_CATEGORIES
        )

        if is_regulated:
            suggestions.append(f"Category '{category}' requires extra compliance attention")

            # Additional checks for regulated categories
            if 'baby' in category.lower() or 'child' in text_to_check:
                if 'age' not in text_to_check and 'month' not in text_to_check:
                    suggestions.append("Consider adding age recommendations for baby/child products")
                    score -= 5

                if 'warning' not in text_to_check and 'safety' not in text_to_check:
                    suggestions.append("Consider adding safety warnings for baby/child products")
                    score -= 10

            if 'electronics' in category.lower():
                if 'warranty' not in text_to_check:
                    suggestions.append("Consider adding warranty information for electronics")
                    score -= 5

                if 'certification' not in text_to_check and 'certified' not in text_to_check:
                    suggestions.append("Consider mentioning safety certifications (UL, CE, FCC)")
                    score -= 5

        # Check for missing age restrictions on potential age-restricted items
        age_restricted_keywords = ['alcohol', 'tobacco', 'adult', 'mature']
        if any(kw in text_to_check for kw in age_restricted_keywords):
            if '18+' not in text_to_check and '21+' not in text_to_check and 'age' not in text_to_check:
                issues.append("Potentially age-restricted product missing age restriction notice")
                score -= 30
                suggestions.append("Add appropriate age restriction notice")

        # Check for misleading language
        misleading_keywords = ['free', 'guaranteed', 'best', 'number 1', '#1']
        misleading_count = sum(1 for kw in misleading_keywords if kw in text_to_check)

        if misleading_count >= 3:
            issues.append("Excessive use of potentially misleading superlatives")
            score -= 15
            suggestions.append("Reduce use of superlative claims or provide substantiation")

        # Determine status
        if len(prohibited_found) > 0:
            status = 'failed'
        elif score >= 80:
            status = 'passed'
        elif score >= 60:
            status = 'warning'
        else:
            status = 'failed'

        return {
            'agent_name': self.agent_name,
            'score': max(0, score),
            'status': status,
            'issues': issues,
            'suggestions': suggestions,
            'details': {
                'prohibited_claims_found': prohibited_found,
                'is_regulated_category': is_regulated,
                'quick_check': True
            }
        }

    def check_age_restriction(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Check if product requires age restriction

        Args:
            product: Product data

        Returns:
            Age restriction check result
        """
        text = f"{product.get('title', '')} {product.get('description', '')}".lower()

        age_restricted = False
        minimum_age = None
        reason = None

        if any(kw in text for kw in ['alcohol', 'beer', 'wine', 'liquor']):
            age_restricted = True
            minimum_age = 21
            reason = "Alcoholic beverage"
        elif any(kw in text for kw in ['tobacco', 'cigarette', 'cigar']):
            age_restricted = True
            minimum_age = 18
            reason = "Tobacco product"
        elif 'adult' in text or 'mature content' in text:
            age_restricted = True
            minimum_age = 18
            reason = "Adult content"

        return {
            'age_restricted': age_restricted,
            'minimum_age': minimum_age,
            'reason': reason
        }
