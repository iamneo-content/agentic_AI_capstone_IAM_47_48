"""
Pricing Validator Agent - Validates product pricing
"""
from typing import Dict, Any
from services.gemini_service import GeminiService


class PricingValidatorAgent:
    """Agent for validating product pricing"""

    def __init__(self, gemini_service: GeminiService):
        """
        Initialize Pricing Validator Agent

        Args:
            gemini_service: Gemini service instance
        """
        self.gemini_service = gemini_service
        self.agent_name = "Pricing Validator Agent"

    def analyze(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze product pricing

        Args:
            product: Product data

        Returns:
            Quality check result
        """
        price = product.get('price', 0)
        title = product.get('title', '')
        category = product.get('category', '')
        description = product.get('description', '')

        # Create analysis prompt
        prompt = f"""
Analyze the pricing for this e-commerce product:

Product: {title}
Category: {category}
Price: ${price}
Description: {description[:200]}...

Evaluate the pricing based on:
1. Price reasonableness for the category
2. Price competitiveness
3. Psychological pricing strategy
4. Price-value perception
5. Price format and presentation

Provide a score from 0-100 and identify any pricing issues or opportunities.
"""

        # Define output schema
        output_schema = {
            "score": "number (0-100)",
            "status": "string (passed/warning/failed)",
            "issues": ["list of pricing issues"],
            "suggestions": ["list of pricing suggestions"],
            "details": {
                "price_range_analysis": "string (underpriced/fair/overpriced)",
                "competitive_score": "number (0-100)",
                "psychological_pricing": "boolean",
                "price_perception": "string",
                "recommended_price_range": "string"
            }
        }

        try:
            # Get structured analysis from Gemini
            result = self.gemini_service.analyze_with_structured_output(
                prompt=prompt,
                output_schema=output_schema,
                temperature=0.3
            )

            # Add agent name
            result['agent_name'] = self.agent_name

            # Ensure required fields
            if 'score' not in result:
                result['score'] = 50.0
            if 'status' not in result:
                result['status'] = 'warning'
            if 'issues' not in result:
                result['issues'] = []
            if 'suggestions' not in result:
                result['suggestions'] = []
            if 'details' not in result:
                result['details'] = {}

            return result

        except Exception as e:
            # Fallback to quick check on error
            return self.quick_check(product)

    def quick_check(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform quick pricing validation without LLM

        Args:
            product: Product data

        Returns:
            Quick check result
        """
        price = product.get('price', 0)
        category = product.get('category', '')

        issues = []
        suggestions = []
        score = 100.0

        # Basic price validation
        if price <= 0:
            issues.append("Price must be greater than zero")
            score = 0
            status = 'failed'
        elif price < 1:
            issues.append("Price is very low (less than $1)")
            score -= 30
            suggestions.append("Verify the price is correct")
            status = 'warning'
        elif price > 100000:
            issues.append("Price is extremely high (over $100,000)")
            score -= 20
            suggestions.append("Verify the price is correct for this category")
            status = 'warning'
        else:
            # Check psychological pricing
            price_str = f"{price:.2f}"
            if price_str.endswith('.99') or price_str.endswith('.95'):
                suggestions.append("Using psychological pricing strategy (.99/.95)")
            else:
                suggestions.append("Consider psychological pricing (e.g., $X.99 instead of $X.00)")
                score -= 5

            # Price range recommendations by category
            category_lower = category.lower()
            if 'electronics' in category_lower or 'computer' in category_lower:
                if price < 10:
                    issues.append("Price seems low for electronics category")
                    score -= 15
            elif 'clothing' in category_lower or 'apparel' in category_lower:
                if price > 500:
                    suggestions.append("High price for clothing - ensure it's justified")
            elif 'books' in category_lower:
                if price > 100:
                    suggestions.append("High price for books category")
                    score -= 10

            status = 'passed' if score >= 70 else 'warning'

        return {
            'agent_name': self.agent_name,
            'score': max(0, score),
            'status': status,
            'issues': issues,
            'suggestions': suggestions,
            'details': {
                'price': price,
                'category': category,
                'price_valid': price > 0,
                'quick_check': True
            }
        }
