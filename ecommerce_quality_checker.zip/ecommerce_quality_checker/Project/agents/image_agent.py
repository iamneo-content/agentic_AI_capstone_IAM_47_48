"""
Image Quality Agent - Validates product images
"""
from typing import Dict, Any, List
from services.gemini_service import GeminiService
from utils.validators import validate_url


class ImageQualityAgent:
    """Agent for checking product image quality"""

    def __init__(self, gemini_service: GeminiService):
        """
        Initialize Image Quality Agent

        Args:
            gemini_service: Gemini service instance
        """
        self.gemini_service = gemini_service
        self.agent_name = "Image Quality Agent"

    def analyze(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze product images

        Args:
            product: Product data

        Returns:
            Quality check result
        """
        images = product.get('images', [])
        title = product.get('title', '')
        category = product.get('category', '')

        # First perform quick validation
        quick_result = self.quick_check(product)

        # If quick check fails critically, return immediately
        if quick_result['score'] == 0:
            return quick_result

        # Create analysis prompt for deeper analysis
        prompt = f"""
Analyze the image setup for this e-commerce product:

Product: {title}
Category: {category}
Number of Images: {len(images)}
Image URLs: {', '.join(images[:5])}

Evaluate based on:
1. Number of images (ideal is 3-7 images)
2. Image URL validity and accessibility
3. Expected image types for the category
4. Image diversity (multiple angles, close-ups, lifestyle shots)
5. Professional quality expectations

Provide recommendations for image optimization.
"""

        # Define output schema
        output_schema = {
            "score": "number (0-100)",
            "status": "string (passed/warning/failed)",
            "issues": ["list of image-related issues"],
            "suggestions": ["list of image improvement suggestions"],
            "details": {
                "image_count_assessment": "string",
                "url_validity": "string",
                "diversity_score": "number (0-100)",
                "recommended_image_count": "number"
            }
        }

        try:
            # Get structured analysis from Gemini
            result = self.gemini_service.analyze_with_structured_output(
                prompt=prompt,
                output_schema=output_schema,
                temperature=0.3
            )

            # Add agent name
            result['agent_name'] = self.agent_name

            # Merge with quick check results
            result['issues'] = list(set(result.get('issues', []) + quick_result['issues']))
            result['suggestions'] = list(set(result.get('suggestions', []) + quick_result['suggestions']))

            # Ensure required fields
            if 'score' not in result:
                result['score'] = quick_result['score']
            if 'status' not in result:
                result['status'] = quick_result['status']
            if 'details' not in result:
                result['details'] = {}

            return result

        except Exception as e:
            # Return quick check result on error
            quick_result['issues'].append(f"Deep analysis failed: {str(e)}")
            return quick_result

    def quick_check(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform quick image validation

        Args:
            product: Product data

        Returns:
            Quick check result
        """
        images = product.get('images', [])

        issues = []
        suggestions = []
        score = 100.0

        # Check if images exist
        if not images or len(images) == 0:
            issues.append("No product images provided")
            score = 0
            status = 'failed'
            suggestions.append("Add at least 3-5 high-quality product images")
        else:
            # Check number of images
            if len(images) < 3:
                issues.append(f"Only {len(images)} image(s) provided (recommended: 3-7)")
                score -= 30
                suggestions.append("Add more images showing different angles and details")
            elif len(images) > 10:
                suggestions.append("Too many images may slow page load - consider 5-7 key images")
                score -= 5

            # Validate image URLs
            invalid_urls = []
            for idx, img_url in enumerate(images):
                if not validate_url(img_url):
                    invalid_urls.append(f"Image {idx + 1}")

            if invalid_urls:
                issues.append(f"Invalid image URLs: {', '.join(invalid_urls)}")
                score -= 20 * len(invalid_urls)
                suggestions.append("Ensure all image URLs are valid and accessible")

            # Check for duplicate URLs
            if len(images) != len(set(images)):
                issues.append("Duplicate image URLs detected")
                score -= 10
                suggestions.append("Remove duplicate images")

            # Determine status
            if score >= 70:
                status = 'passed'
            elif score >= 40:
                status = 'warning'
            else:
                status = 'failed'

        return {
            'agent_name': self.agent_name,
            'score': max(0, score),
            'status': status,
            'issues': issues,
            'suggestions': suggestions,
            'details': {
                'image_count': len(images),
                'has_images': len(images) > 0,
                'quick_check': True
            }
        }

    def validate_image_urls(self, urls: List[str]) -> Dict[str, Any]:
        """
        Validate list of image URLs

        Args:
            urls: List of image URLs

        Returns:
            Validation result
        """
        valid_urls = []
        invalid_urls = []

        for url in urls:
            if validate_url(url):
                valid_urls.append(url)
            else:
                invalid_urls.append(url)

        return {
            'total': len(urls),
            'valid': len(valid_urls),
            'invalid': len(invalid_urls),
            'valid_urls': valid_urls,
            'invalid_urls': invalid_urls
        }
