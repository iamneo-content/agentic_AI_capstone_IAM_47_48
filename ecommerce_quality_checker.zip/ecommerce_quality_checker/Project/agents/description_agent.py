"""
Description Quality Agent - Analyzes product description quality
"""
from typing import Dict, Any
from services.gemini_service import GeminiService


class DescriptionQualityAgent:
    """Agent for checking product description quality"""

    def __init__(self, gemini_service: GeminiService):
        """
        Initialize Description Quality Agent

        Args:
            gemini_service: Gemini service instance
        """
        self.gemini_service = gemini_service
        self.agent_name = "Description Quality Agent"

    def analyze(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze product description quality

        Args:
            product: Product data

        Returns:
            Quality check result
        """
        title = product.get('title', '')
        description = product.get('description', '')

        # Create analysis prompt
        prompt = f"""
Analyze the following e-commerce product title and description for quality:

Title: {title}
Description: {description}

Evaluate based on these criteria:
1. Clarity and readability
2. Completeness of information
3. Grammar and spelling
4. Use of persuasive language
5. Length appropriateness
6. Keyword optimization
7. Presence of key product features

Provide a quality score from 0-100 and identify any issues or suggestions for improvement.
"""

        # Define output schema
        output_schema = {
            "score": "number (0-100)",
            "status": "string (passed/warning/failed)",
            "issues": ["list of issues found"],
            "suggestions": ["list of improvement suggestions"],
            "details": {
                "clarity_score": "number (0-100)",
                "completeness_score": "number (0-100)",
                "grammar_score": "number (0-100)",
                "length_analysis": "string (too short/appropriate/too long)",
                "keyword_presence": "boolean"
            }
        }

        try:
            # Get structured analysis from Gemini
            result = self.gemini_service.analyze_with_structured_output(
                prompt=prompt,
                output_schema=output_schema,
                temperature=0.3
            )

            # Add agent name
            result['agent_name'] = self.agent_name

            # Ensure required fields
            if 'score' not in result:
                result['score'] = 50.0
            if 'status' not in result:
                result['status'] = 'warning'
            if 'issues' not in result:
                result['issues'] = []
            if 'suggestions' not in result:
                result['suggestions'] = []
            if 'details' not in result:
                result['details'] = {}

            return result

        except Exception as e:
            # Return error result
            return {
                'agent_name': self.agent_name,
                'score': 0.0,
                'status': 'failed',
                'issues': [f"Analysis failed: {str(e)}"],
                'suggestions': ["Please check the description and try again"],
                'details': {'error': str(e)}
            }

    def quick_check(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform quick validation without LLM

        Args:
            product: Product data

        Returns:
            Quick check result
        """
        title = product.get('title', '')
        description = product.get('description', '')

        issues = []
        suggestions = []
        score = 100.0

        # Check title length
        if len(title) < 10:
            issues.append("Title is too short (less than 10 characters)")
            score -= 20
            suggestions.append("Expand the title to be more descriptive")
        elif len(title) > 200:
            issues.append("Title is too long (over 200 characters)")
            score -= 10
            suggestions.append("Shorten the title for better readability")

        # Check description length
        if len(description) < 50:
            issues.append("Description is too short (less than 50 characters)")
            score -= 30
            suggestions.append("Add more details about the product features and benefits")
        elif len(description) > 5000:
            issues.append("Description is too long (over 5000 characters)")
            score -= 10
            suggestions.append("Condense the description to key information")

        # Check for empty or generic content
        if not title.strip():
            issues.append("Title is empty")
            score -= 50
        if not description.strip():
            issues.append("Description is empty")
            score -= 50

        # Determine status
        if score >= 70:
            status = 'passed'
        elif score >= 50:
            status = 'warning'
        else:
            status = 'failed'

        return {
            'agent_name': self.agent_name,
            'score': max(0, score),
            'status': status,
            'issues': issues,
            'suggestions': suggestions,
            'details': {
                'title_length': len(title),
                'description_length': len(description),
                'quick_check': True
            }
        }
