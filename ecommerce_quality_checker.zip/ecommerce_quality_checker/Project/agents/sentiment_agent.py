"""
Sentiment Analyzer Agent - Analyzes product reviews and sentiment
"""
from typing import Dict, Any, List
from services.gemini_service import GeminiService


class SentimentAnalyzerAgent:
    """Agent for analyzing product review sentiment"""

    def __init__(self, gemini_service: GeminiService):
        """
        Initialize Sentiment Analyzer Agent

        Args:
            gemini_service: Gemini service instance
        """
        self.gemini_service = gemini_service
        self.agent_name = "Sentiment Analyzer Agent"

    def analyze(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze product reviews and sentiment

        Args:
            product: Product data

        Returns:
            Quality check result
        """
        reviews = product.get('reviews', [])
        title = product.get('title', '')

        # Perform quick check first
        quick_result = self.quick_check(product)

        # If no reviews, return quick result
        if not reviews or len(reviews) == 0:
            return quick_result

        # Create analysis prompt
        reviews_text = "\n".join([
            f"Review {i+1}: {review.get('text', '')} (Rating: {review.get('rating', 'N/A')})"
            for i, review in enumerate(reviews[:10])  # Analyze up to 10 reviews
        ])

        prompt = f"""
Analyze the customer reviews for this product:

Product: {title}
Number of Reviews: {len(reviews)}

Reviews:
{reviews_text}

Evaluate:
1. Overall sentiment (positive/neutral/negative)
2. Common themes and patterns
3. Product quality perception
4. Customer satisfaction level
5. Recurring issues or complaints
6. Strong points mentioned

Provide sentiment analysis and quality assessment based on reviews.
"""

        # Define output schema
        output_schema = {
            "score": "number (0-100)",
            "status": "string (passed/warning/failed)",
            "issues": ["list of concerns from reviews"],
            "suggestions": ["list of improvement suggestions based on feedback"],
            "details": {
                "overall_sentiment": "string (positive/neutral/negative)",
                "positive_percentage": "number (0-100)",
                "negative_percentage": "number (0-100)",
                "common_themes": ["list of common themes"],
                "satisfaction_score": "number (0-100)",
                "recurring_issues": ["list of recurring issues"]
            }
        }

        try:
            # Get structured analysis from Gemini
            result = self.gemini_service.analyze_with_structured_output(
                prompt=prompt,
                output_schema=output_schema,
                temperature=0.3
            )

            # Add agent name
            result['agent_name'] = self.agent_name

            # Merge with quick check
            result['issues'] = list(set(result.get('issues', []) + quick_result.get('issues', [])))
            result['suggestions'] = list(set(result.get('suggestions', []) + quick_result.get('suggestions', [])))

            # Ensure required fields
            if 'score' not in result:
                result['score'] = quick_result['score']
            if 'status' not in result:
                result['status'] = quick_result['status']
            if 'details' not in result:
                result['details'] = {}

            return result

        except Exception as e:
            # Return quick check result on error
            quick_result['issues'].append(f"Deep sentiment analysis failed: {str(e)}")
            return quick_result

    def quick_check(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform quick sentiment validation

        Args:
            product: Product data

        Returns:
            Quick check result
        """
        reviews = product.get('reviews', [])

        issues = []
        suggestions = []
        score = 100.0

        # Check if reviews exist
        if not reviews or len(reviews) == 0:
            suggestions.append("No reviews available - product quality cannot be verified by customer feedback")
            score = 70  # Not a failure, but lacks social proof
            status = 'warning'
        else:
            # Calculate basic statistics
            total_reviews = len(reviews)
            ratings = []

            for review in reviews:
                rating = review.get('rating')
                if rating is not None:
                    try:
                        ratings.append(float(rating))
                    except (ValueError, TypeError):
                        pass

            if ratings:
                avg_rating = sum(ratings) / len(ratings)
                low_ratings = sum(1 for r in ratings if r <= 2.0)
                high_ratings = sum(1 for r in ratings if r >= 4.0)

                # Calculate score based on average rating
                score = (avg_rating / 5.0) * 100

                # Check average rating
                if avg_rating < 2.5:
                    issues.append(f"Low average rating: {avg_rating:.1f}/5.0")
                    status = 'failed'
                    suggestions.append("Address customer concerns to improve ratings")
                elif avg_rating < 3.5:
                    issues.append(f"Below average rating: {avg_rating:.1f}/5.0")
                    status = 'warning'
                    suggestions.append("Work on improving product quality based on feedback")
                else:
                    status = 'passed'

                # Check for too many low ratings
                if total_reviews >= 5:
                    low_rating_percentage = (low_ratings / total_reviews) * 100
                    if low_rating_percentage > 30:
                        issues.append(f"High percentage of low ratings: {low_rating_percentage:.1f}%")
                        score -= 20
                        suggestions.append("Investigate and address common complaints")

                # Add positive note for good ratings
                if avg_rating >= 4.0:
                    suggestions.append(f"Good customer satisfaction with {avg_rating:.1f}/5.0 average rating")

            else:
                # Reviews exist but no ratings
                suggestions.append("Reviews present but ratings are missing")
                score = 75
                status = 'warning'

            # Check review count
            if total_reviews < 5:
                suggestions.append(f"Limited reviews ({total_reviews}) - encourage more customer feedback")
                score -= 10

        return {
            'agent_name': self.agent_name,
            'score': max(0, score),
            'status': status,
            'issues': issues,
            'suggestions': suggestions,
            'details': {
                'review_count': len(reviews),
                'has_reviews': len(reviews) > 0,
                'quick_check': True
            }
        }

    def analyze_review_text(self, review_text: str) -> Dict[str, Any]:
        """
        Analyze sentiment of a single review

        Args:
            review_text: Review text to analyze

        Returns:
            Sentiment analysis result
        """
        if not review_text or not review_text.strip():
            return {
                'sentiment': 'neutral',
                'confidence': 0.0,
                'keywords': []
            }

        # Simple keyword-based sentiment analysis
        positive_keywords = ['great', 'excellent', 'amazing', 'love', 'perfect', 'good', 'best', 'recommend']
        negative_keywords = ['bad', 'poor', 'terrible', 'awful', 'worst', 'hate', 'disappointed', 'broken']

        text_lower = review_text.lower()

        positive_count = sum(1 for kw in positive_keywords if kw in text_lower)
        negative_count = sum(1 for kw in negative_keywords if kw in text_lower)

        if positive_count > negative_count:
            sentiment = 'positive'
            confidence = min(100, (positive_count / (positive_count + negative_count)) * 100)
        elif negative_count > positive_count:
            sentiment = 'negative'
            confidence = min(100, (negative_count / (positive_count + negative_count)) * 100)
        else:
            sentiment = 'neutral'
            confidence = 50.0

        keywords_found = [kw for kw in positive_keywords + negative_keywords if kw in text_lower]

        return {
            'sentiment': sentiment,
            'confidence': confidence,
            'positive_count': positive_count,
            'negative_count': negative_count,
            'keywords': keywords_found
        }
