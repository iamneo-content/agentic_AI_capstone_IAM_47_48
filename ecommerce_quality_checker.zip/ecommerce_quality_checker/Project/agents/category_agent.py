"""
Category Classifier Agent - Validates product categorization
"""
from typing import Dict, Any, List
from services.gemini_service import GeminiService


class CategoryClassifierAgent:
    """Agent for validating product category classification"""

    # Common e-commerce categories
    VALID_CATEGORIES = [
        "Electronics",
        "Computers & Accessories",
        "Home & Kitchen",
        "Clothing & Apparel",
        "Books",
        "Toys & Games",
        "Sports & Outdoors",
        "Health & Beauty",
        "Automotive",
        "Office Products",
        "Garden & Outdoor",
        "Pet Supplies",
        "Jewelry & Watches",
        "Grocery & Gourmet Food",
        "Baby Products",
        "Music & Instruments",
        "Arts & Crafts",
        "Industrial & Scientific"
    ]

    def __init__(self, gemini_service: GeminiService):
        """
        Initialize Category Classifier Agent

        Args:
            gemini_service: Gemini service instance
        """
        self.gemini_service = gemini_service
        self.agent_name = "Category Classifier Agent"

    def analyze(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze product category classification

        Args:
            product: Product data

        Returns:
            Quality check result
        """
        title = product.get('title', '')
        description = product.get('description', '')
        category = product.get('category', '')
        specifications = product.get('specifications', {})

        # Create analysis prompt
        prompt = f"""
Analyze if this product is correctly categorized:

Product Title: {title}
Current Category: {category}
Description: {description[:300]}...
Specifications: {specifications}

Valid Categories: {', '.join(self.VALID_CATEGORIES)}

Evaluate:
1. Is the current category appropriate?
2. Would a different category be more suitable?
3. Is the category specific enough?
4. Does the product fit multiple categories?

Provide your assessment and recommendations.
"""

        # Define output schema
        output_schema = {
            "score": "number (0-100)",
            "status": "string (passed/warning/failed)",
            "issues": ["list of categorization issues"],
            "suggestions": ["list of category suggestions"],
            "details": {
                "category_match": "boolean",
                "confidence": "number (0-100)",
                "suggested_category": "string",
                "alternative_categories": ["list of alternative categories"],
                "specificity_score": "number (0-100)"
            }
        }

        try:
            # Get structured analysis from Gemini
            result = self.gemini_service.analyze_with_structured_output(
                prompt=prompt,
                output_schema=output_schema,
                temperature=0.3
            )

            # Add agent name
            result['agent_name'] = self.agent_name

            # Ensure required fields
            if 'score' not in result:
                result['score'] = 50.0
            if 'status' not in result:
                result['status'] = 'warning'
            if 'issues' not in result:
                result['issues'] = []
            if 'suggestions' not in result:
                result['suggestions'] = []
            if 'details' not in result:
                result['details'] = {}

            return result

        except Exception as e:
            # Fallback to quick check
            return self.quick_check(product)

    def quick_check(self, product: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform quick category validation

        Args:
            product: Product data

        Returns:
            Quick check result
        """
        category = product.get('category', '')
        title = product.get('title', '')

        issues = []
        suggestions = []
        score = 100.0

        # Check if category exists
        if not category or not category.strip():
            issues.append("Product category is missing")
            score = 0
            status = 'failed'
            suggestions.append("Assign a category to the product")
        else:
            # Check if category is in valid list (case-insensitive)
            category_valid = any(
                cat.lower() == category.lower()
                for cat in self.VALID_CATEGORIES
            )

            if not category_valid:
                issues.append(f"Category '{category}' not in standard category list")
                score -= 30
                suggestions.append(f"Use one of the standard categories: {', '.join(self.VALID_CATEGORIES[:5])}...")
                status = 'warning'
            else:
                # Category is valid
                status = 'passed'

            # Check for overly generic category
            generic_categories = ['Other', 'Miscellaneous', 'General']
            if any(gen.lower() in category.lower() for gen in generic_categories):
                issues.append("Category is too generic")
                score -= 20
                suggestions.append("Use a more specific category")

            # Simple keyword matching for basic validation
            title_lower = title.lower()
            category_lower = category.lower()

            # Electronics check
            if 'electronics' in category_lower:
                if not any(kw in title_lower for kw in ['phone', 'tablet', 'tv', 'camera', 'electronic', 'device']):
                    suggestions.append("Verify product matches Electronics category")
                    score -= 10

            # Clothing check
            elif 'clothing' in category_lower or 'apparel' in category_lower:
                if not any(kw in title_lower for kw in ['shirt', 'pants', 'dress', 'jacket', 'shoes', 'clothing']):
                    suggestions.append("Verify product matches Clothing category")
                    score -= 10

            # Books check
            elif 'books' in category_lower:
                if not any(kw in title_lower for kw in ['book', 'novel', 'guide', 'manual', 'textbook']):
                    suggestions.append("Verify product matches Books category")
                    score -= 10

            # Recalculate status based on score
            if score >= 70:
                status = 'passed'
            elif score >= 40:
                status = 'warning'
            else:
                status = 'failed'

        return {
            'agent_name': self.agent_name,
            'score': max(0, score),
            'status': status,
            'issues': issues,
            'suggestions': suggestions,
            'details': {
                'category': category,
                'category_valid': category in self.VALID_CATEGORIES,
                'quick_check': True
            }
        }

    def suggest_category(self, product: Dict[str, Any]) -> List[str]:
        """
        Suggest appropriate categories for a product

        Args:
            product: Product data

        Returns:
            List of suggested categories
        """
        title = product.get('title', '').lower()
        description = product.get('description', '').lower()

        text = f"{title} {description}"

        suggestions = []

        # Simple keyword-based suggestions
        if any(kw in text for kw in ['phone', 'laptop', 'computer', 'tablet', 'electronics']):
            suggestions.append('Electronics')

        if any(kw in text for kw in ['shirt', 'pants', 'dress', 'clothing', 'apparel', 'fashion']):
            suggestions.append('Clothing & Apparel')

        if any(kw in text for kw in ['book', 'novel', 'author', 'pages', 'reading']):
            suggestions.append('Books')

        if any(kw in text for kw in ['toy', 'game', 'play', 'children', 'kids']):
            suggestions.append('Toys & Games')

        if any(kw in text for kw in ['kitchen', 'home', 'furniture', 'decor']):
            suggestions.append('Home & Kitchen')

        return suggestions if suggestions else ['Please provide more product details for categorization']
