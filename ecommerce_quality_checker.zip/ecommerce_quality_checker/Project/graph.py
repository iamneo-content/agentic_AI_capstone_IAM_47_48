"""
LangGraph Workflow Definition for E-commerce Quality Checker
"""
from typing import Dict, Any
from langgraph.graph import StateGraph, END
from state import ProductQualityState
from nodes import validation_node, agent_execution_node, aggregation_node, decision_node
from analyzer.quality_analyzer import QualityAnalyzer


def create_quality_check_graph(analyzer: QualityAnalyzer) -> StateGraph:
    """
    Create LangGraph workflow for quality checking

    Args:
        analyzer: Quality analyzer instance

    Returns:
        Compiled StateGraph
    """

    # Create a new StateGraph
    workflow = StateGraph(ProductQualityState)

    # Define node functions with analyzer injection
    def validation_step(state: ProductQualityState) -> ProductQualityState:
        """Validation node wrapper"""
        return validation_node(state)

    def agent_execution_step(state: ProductQualityState) -> ProductQualityState:
        """Agent execution node wrapper with analyzer"""
        return agent_execution_node(state, analyzer)

    def aggregation_step(state: ProductQualityState) -> ProductQualityState:
        """Aggregation node wrapper"""
        return aggregation_node(state)

    def decision_step(state: ProductQualityState) -> ProductQualityState:
        """Decision node wrapper"""
        return decision_node(state)

    # Add nodes to the graph
    workflow.add_node("validate", validation_step)
    workflow.add_node("execute_agents", agent_execution_step)
    workflow.add_node("aggregate", aggregation_step)
    workflow.add_node("decide", decision_step)

    # Define edges (workflow flow)
    # Start -> Validation
    workflow.set_entry_point("validate")

    # Validation -> Agent Execution (conditional)
    def should_execute_agents(state: ProductQualityState) -> str:
        """Decide whether to execute agents based on validation"""
        if state.get('final_status') == 'rejected' and state.get('errors'):
            # Skip to decision if validation failed
            return "decide"
        return "execute_agents"

    workflow.add_conditional_edges(
        "validate",
        should_execute_agents,
        {
            "execute_agents": "execute_agents",
            "decide": "decide"
        }
    )

    # Agent Execution -> Aggregation
    workflow.add_edge("execute_agents", "aggregate")

    # Aggregation -> Decision
    workflow.add_edge("aggregate", "decide")

    # Decision -> END
    workflow.add_edge("decide", END)

    # Compile the graph
    compiled_graph = workflow.compile()

    return compiled_graph


def visualize_graph(graph: StateGraph, output_file: str = "workflow_graph.png"):
    """
    Visualize the workflow graph

    Args:
        graph: Compiled StateGraph
        output_file: Output file path for the visualization
    """
    try:
        from IPython.display import Image, display

        # Generate visualization
        viz = graph.get_graph().draw_mermaid_png()

        # Save to file
        with open(output_file, 'wb') as f:
            f.write(viz)

        print(f"Graph visualization saved to {output_file}")

        # Display if in Jupyter
        try:
            display(Image(viz))
        except:
            pass

    except ImportError:
        print("Visualization requires IPython and graphviz packages")
    except Exception as e:
        print(f"Visualization failed: {str(e)}")


def get_workflow_description() -> Dict[str, Any]:
    """
    Get description of the workflow

    Returns:
        Workflow description
    """
    return {
        "name": "E-commerce Product Quality Check Workflow",
        "description": "Multi-agent workflow for checking product quality",
        "steps": [
            {
                "name": "Validation",
                "description": "Validates product data structure and required fields",
                "node": "validate"
            },
            {
                "name": "Agent Execution",
                "description": "Executes all quality checking agents in parallel",
                "node": "execute_agents",
                "agents": [
                    "Description Quality Agent",
                    "Pricing Validator Agent",
                    "Image Quality Agent",
                    "Category Classifier Agent",
                    "Compliance Checker Agent",
                    "Sentiment Analyzer Agent"
                ]
            },
            {
                "name": "Aggregation",
                "description": "Aggregates results from all agents",
                "node": "aggregate"
            },
            {
                "name": "Decision",
                "description": "Makes final quality decision",
                "node": "decide"
            }
        ],
        "flow": "validate -> execute_agents -> aggregate -> decide -> END",
        "conditional_logic": {
            "validate": "Skip agent execution if validation fails"
        }
    }


class WorkflowExecutor:
    """Executor for running the LangGraph workflow"""

    def __init__(self, analyzer: QualityAnalyzer):
        """
        Initialize Workflow Executor

        Args:
            analyzer: Quality analyzer instance
        """
        self.analyzer = analyzer
        self.graph = create_quality_check_graph(analyzer)

    def execute(self, state: ProductQualityState) -> ProductQualityState:
        """
        Execute the workflow

        Args:
            state: Initial workflow state

        Returns:
            Final workflow state
        """
        try:
            # Run the graph
            result = self.graph.invoke(state)
            return result
        except Exception as e:
            print(f"Workflow execution failed: {str(e)}")
            state['errors'].append(f"Workflow execution error: {str(e)}")
            state['final_status'] = 'rejected'
            return state

    def stream_execute(self, state: ProductQualityState):
        """
        Execute workflow with streaming updates

        Args:
            state: Initial workflow state

        Yields:
            State updates at each step
        """
        try:
            for step_state in self.graph.stream(state):
                yield step_state
        except Exception as e:
            print(f"Workflow streaming failed: {str(e)}")
            state['errors'].append(f"Workflow streaming error: {str(e)}")
            yield state

    def get_graph(self) -> StateGraph:
        """
        Get the compiled graph

        Returns:
            Compiled StateGraph
        """
        return self.graph
