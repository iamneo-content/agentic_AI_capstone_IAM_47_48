"""
Workflow Manager - Manages the quality checking workflow execution
"""
from typing import Dict, Any, Optional
from state import ProductQualityState, ProductData, create_initial_state
from analyzer.quality_analyzer import QualityAnalyzer
from analyzer.report_generator import ReportGenerator


class WorkflowManager:
    """Manages the execution of quality checking workflow"""

    def __init__(self, analyzer: QualityAnalyzer):
        """
        Initialize Workflow Manager

        Args:
            analyzer: Quality analyzer instance
        """
        self.analyzer = analyzer
        self.report_generator = ReportGenerator()

    def execute_workflow(
        self,
        product: ProductData,
        generate_report: bool = True
    ) -> Dict[str, Any]:
        """
        Execute complete quality checking workflow

        Args:
            product: Product data to check
            generate_report: Whether to generate formatted report

        Returns:
            Workflow results including analysis and optional report
        """
        print(f"\n{'='*80}")
        print(f"Starting Quality Check Workflow for: {product.get('title', 'Unknown Product')}")
        print(f"{'='*80}\n")

        # Create initial state
        state = create_initial_state(product)

        # Execute workflow steps manually (simulating LangGraph flow)
        state = self._run_workflow(state)

        # Prepare result
        result = {
            'state': state,
            'analysis': {
                'product': state['product'],
                'quality_results': state['quality_results'],
                'overall_score': state['overall_score'],
                'final_status': state['final_status'],
                'all_issues': state['all_issues'],
                'recommendations': state['recommendations'],
                'metadata': state['metadata']
            }
        }

        # Generate reports if requested
        if generate_report:
            result['reports'] = {
                'summary': self.report_generator.generate_summary(result['analysis']),
                'executive_summary': self.report_generator.generate_executive_summary(result['analysis']),
                'text_report': self.report_generator.generate_text_report(result['analysis']),
                'json_report': self.report_generator.generate_json_report(result['analysis'])
            }

        print(f"\n{'='*80}")
        print(f"Workflow Completed - Status: {state['final_status'].upper()}")
        print(f"Overall Score: {state['overall_score']:.1f}/100")
        print(f"{'='*80}\n")

        return result

    def _run_workflow(self, state: ProductQualityState) -> ProductQualityState:
        """
        Run the workflow steps

        Args:
            state: Initial workflow state

        Returns:
            Final workflow state
        """
        from nodes import validation_node, aggregation_node, decision_node

        # Step 1: Validation
        print("Step 1: Validating product data...")
        state = validation_node(state)

        # Step 2: Agent Execution (if validation passed)
        if state['final_status'] != 'rejected':
            print("\nStep 2: Executing quality check agents...")
            # Run all quality checks using analyzer
            try:
                quality_results = self.analyzer.run_all_checks(state['product'])
                state['quality_results'].extend(quality_results)
                state['metadata']['total_checks'] = len(quality_results)
                print(f"Completed {len(quality_results)} quality checks")
            except Exception as e:
                error_msg = f"Agent execution failed: {str(e)}"
                state['errors'].append(error_msg)
                print(f"Error: {error_msg}")

        # Step 3: Aggregation
        if state['quality_results']:
            print("\nStep 3: Aggregating results...")
            state = aggregation_node(state)

        # Step 4: Decision
        print("\nStep 4: Making final decision...")
        state = decision_node(state)

        return state

    def execute_quick_check(self, product: ProductData) -> Dict[str, Any]:
        """
        Execute quick quality check without LLM

        Args:
            product: Product data to check

        Returns:
            Quick check results
        """
        print(f"\nExecuting Quick Check for: {product.get('title', 'Unknown Product')}\n")

        # Create analyzer with LLM disabled
        from services.gemini_service import GeminiService
        quick_analyzer = QualityAnalyzer(
            gemini_service=self.analyzer.gemini_service,
            use_llm=False
        )

        # Create initial state
        state = create_initial_state(product)

        # Execute workflow with quick analyzer
        from nodes import validation_node, aggregation_node, decision_node

        state = validation_node(state)

        if state['final_status'] != 'rejected':
            try:
                quality_results = quick_analyzer.run_all_checks(state['product'])
                state['quality_results'].extend(quality_results)
                state['metadata']['total_checks'] = len(quality_results)
            except Exception as e:
                state['errors'].append(f"Quick check failed: {str(e)}")

        if state['quality_results']:
            state = aggregation_node(state)

        state = decision_node(state)

        return {
            'state': state,
            'analysis': {
                'product': state['product'],
                'overall_score': state['overall_score'],
                'final_status': state['final_status'],
                'all_issues': state['all_issues'],
                'recommendations': state['recommendations']
            }
        }

    def get_workflow_status(self, state: ProductQualityState) -> str:
        """
        Get current workflow status

        Args:
            state: Current workflow state

        Returns:
            Status string
        """
        return state.get('current_step', 'unknown')

    def validate_product_only(self, product: ProductData) -> Dict[str, Any]:
        """
        Run only validation step

        Args:
            product: Product data to validate

        Returns:
            Validation results
        """
        from nodes import validation_node

        state = create_initial_state(product)
        state = validation_node(state)

        return {
            'valid': len(state['errors']) == 0,
            'errors': state['errors'],
            'status': state['final_status']
        }
