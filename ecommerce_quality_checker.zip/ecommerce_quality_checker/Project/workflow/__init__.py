"""
Workflow package for quality checking orchestration
"""
from .workflow_manager import WorkflowManager

__all__ = ['WorkflowManager']
