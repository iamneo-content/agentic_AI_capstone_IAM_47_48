"""
Main Entry Point for E-commerce Product Quality Checker
"""
import os
import sys
import json
from typing import Dict, Any, Optional

from services.gemini_service import GeminiService
from analyzer.quality_analyzer import QualityAnalyzer
from workflow.workflow_manager import WorkflowManager
from graph import WorkflowExecutor, get_workflow_description
from state import create_initial_state, ProductData


def load_sample_product() -> ProductData:
    """
    Load a sample product for testing

    Returns:
        Sample product data
    """
    return {
        'product_id': 'PROD-12345',
        'title': 'Premium Wireless Bluetooth Headphones with Noise Cancellation',
        'description': '''
            Experience superior sound quality with our premium wireless headphones.
            Features active noise cancellation, 30-hour battery life, and comfortable
            over-ear design. Perfect for travel, work, or leisure. Includes carrying case
            and audio cable for wired connection.
        ''',
        'price': 199.99,
        'category': 'Electronics',
        'images': [
            'https://example.com/images/headphones-main.jpg',
            'https://example.com/images/headphones-side.jpg',
            'https://example.com/images/headphones-case.jpg'
        ],
        'specifications': {
            'Battery Life': '30 hours',
            'Connectivity': 'Bluetooth 5.0',
            'Noise Cancellation': 'Active',
            'Weight': '250g',
            'Color': 'Black'
        },
        'reviews': [
            {'rating': 5, 'text': 'Great sound quality and comfortable to wear!'},
            {'rating': 4, 'text': 'Good product, battery life is excellent'},
            {'rating': 5, 'text': 'Best headphones I have ever owned'},
            {'rating': 4, 'text': 'Noise cancellation works well'}
        ]
    }


def initialize_system(api_key: Optional[str] = None, use_llm: bool = True) -> tuple:
    """
    Initialize the quality checking system

    Args:
        api_key: Google API key (optional, reads from env if not provided)
        use_llm: Whether to use LLM for deep analysis

    Returns:
        Tuple of (gemini_service, analyzer, workflow_manager)
    """
    try:
        # Initialize Gemini service
        gemini_service = GeminiService(api_key=api_key)
        print("[OK] Gemini service initialized")

        # Initialize Quality Analyzer
        analyzer = QualityAnalyzer(gemini_service, use_llm=use_llm)
        print(f"[OK] Quality Analyzer initialized (LLM: {use_llm})")

        # Initialize Workflow Manager
        workflow_manager = WorkflowManager(analyzer)
        print("[OK] Workflow Manager initialized")

        return gemini_service, analyzer, workflow_manager

    except Exception as e:
        print(f"[FAIL] Initialization failed: {str(e)}")
        print("\nPlease ensure GOOGLE_API_KEY environment variable is set or provide api_key parameter")
        sys.exit(1)


def run_quality_check(
    product: ProductData,
    workflow_manager: WorkflowManager,
    show_report: bool = True
) -> Dict[str, Any]:
    """
    Run quality check on a product

    Args:
        product: Product data
        workflow_manager: Workflow manager instance
        show_report: Whether to print the report

    Returns:
        Quality check results
    """
    # Execute workflow
    result = workflow_manager.execute_workflow(product, generate_report=True)

    # Print report if requested
    if show_report and 'reports' in result:
        print("\n" + "="*80)
        print("QUALITY CHECK REPORT")
        print("="*80 + "\n")
        print(result['reports']['text_report'])

    return result


def run_quick_check(
    product: ProductData,
    workflow_manager: WorkflowManager
) -> Dict[str, Any]:
    """
    Run quick quality check without LLM

    Args:
        product: Product data
        workflow_manager: Workflow manager instance

    Returns:
        Quick check results
    """
    result = workflow_manager.execute_quick_check(product)

    print("\n" + "="*80)
    print("QUICK CHECK SUMMARY")
    print("="*80)
    print(f"Product: {product.get('title', 'Unknown')}")
    print(f"Overall Score: {result['analysis']['overall_score']:.1f}/100")
    print(f"Status: {result['analysis']['final_status'].upper()}")
    print(f"Issues Found: {len(result['analysis']['all_issues'])}")
    print("="*80 + "\n")

    return result


def run_with_langgraph(
    product: ProductData,
    analyzer: QualityAnalyzer
) -> Dict[str, Any]:
    """
    Run quality check using LangGraph workflow executor

    Args:
        product: Product data
        analyzer: Quality analyzer instance

    Returns:
        Quality check results
    """
    print("\n" + "="*80)
    print("Running with LangGraph Workflow")
    print("="*80 + "\n")

    # Create workflow executor
    executor = WorkflowExecutor(analyzer)

    # Create initial state
    initial_state = create_initial_state(product)

    # Execute workflow
    final_state = executor.execute(initial_state)

    print("\n" + "="*80)
    print("LANGGRAPH WORKFLOW RESULTS")
    print("="*80)
    print(f"Final Status: {final_state['final_status'].upper()}")
    print(f"Overall Score: {final_state['overall_score']:.1f}/100")
    print(f"Total Checks: {final_state['metadata']['total_checks']}")
    print(f"Issues Found: {len(final_state['all_issues'])}")
    print("="*80 + "\n")

    return {'state': final_state}


def main():
    """Main execution function"""
    print("\n" + "="*80)
    print("E-COMMERCE PRODUCT QUALITY CHECKER")
    print("="*80 + "\n")

    # Check for API key
    api_key = os.getenv('GOOGLE_API_KEY')
    if not api_key:
        print("[WARNING] GOOGLE_API_KEY not set in environment")
        print("LLM-based analysis will be disabled. Only quick checks will run.\n")
        use_llm = False
    else:
        use_llm = True

    # Initialize system
    print("Initializing system...")
    try:
        gemini_service, analyzer, workflow_manager = initialize_system(
            api_key=api_key,
            use_llm=use_llm
        )
    except:
        # Fallback to quick check mode if initialization fails
        print("\nFalling back to quick check mode (no LLM)...")
        gemini_service = None
        try:
            # Create a dummy service for quick checks
            from services.gemini_service import GeminiService
            gemini_service = GeminiService(api_key="dummy_key")
        except:
            pass

        if gemini_service:
            analyzer = QualityAnalyzer(gemini_service, use_llm=False)
            workflow_manager = WorkflowManager(analyzer)
        else:
            print("Failed to initialize. Exiting.")
            return

    # Load sample product
    print("\nLoading sample product...")
    product = load_sample_product()
    print(f"[OK] Loaded: {product['title']}\n")

    # Display workflow description
    workflow_desc = get_workflow_description()
    print("Workflow Description:")
    print(f"  Name: {workflow_desc['name']}")
    print(f"  Flow: {workflow_desc['flow']}")
    print(f"  Steps: {len(workflow_desc['steps'])}\n")

    # Run quality check
    try:
        if use_llm:
            # Run full workflow with LLM
            print("Running FULL quality check with LLM analysis...")
            result = run_quality_check(product, workflow_manager, show_report=True)

            # Also demonstrate LangGraph execution
            print("\n" + "="*80)
            print("Demonstrating LangGraph Workflow Execution")
            print("="*80 + "\n")
            langgraph_result = run_with_langgraph(product, analyzer)

        else:
            # Run quick check without LLM
            print("Running QUICK quality check (no LLM)...")
            result = run_quick_check(product, workflow_manager)

        # Display executive summary
        if 'reports' in result:
            exec_summary = result['reports']['executive_summary']
            print("\n" + "="*80)
            print("EXECUTIVE SUMMARY")
            print("="*80)
            print(f"Recommendation: {exec_summary['recommendation']}")
            print(f"Critical Issues: {exec_summary['critical_issues_count']}")
            print("="*80 + "\n")

    except Exception as e:
        print(f"\n[FAIL] Quality check failed: {str(e)}")
        import traceback
        traceback.print_exc()

    print("\n" + "="*80)
    print("Quality check completed!")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
