"""
State schema for the Cybersecurity Threat Intelligence Platform.

This module defines the comprehensive state structure for threat detection,
analysis, and response workflows.
"""

from typing import TypedDict, List, Optional, Dict, Any, Set
from datetime import datetime
from enum import Enum


class ThreatLevel(str, Enum):
    """Threat severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class IncidentStatus(str, Enum):
    """Incident response status."""
    DETECTED = "detected"
    ANALYZING = "analyzing"
    INVESTIGATING = "investigating"
    REMEDIATING = "remediating"
    RESOLVED = "resolved"
    ESCALATED = "escalated"


class ComplianceFramework(str, Enum):
    """Supported compliance frameworks."""
    NIST = "nist_csf"
    ISO27001 = "iso_27001"
    GDPR = "gdpr"
    HIPAA = "hipaa"
    PCI_DSS = "pci_dss"


class ThreatIntelligenceState(TypedDict, total=False):
    """
    Comprehensive state schema for threat intelligence workflow.

    This state tracks the entire lifecycle of threat detection, analysis,
    and response with multiple specialized agents working in parallel.
    """

    # ============ Core Input/Output ============
    threat_input: str  # Original threat alert or query
    final_report: Optional[str]  # Comprehensive final report

    # ============ Threat Identification ============
    threat_indicators: List[Dict[str, Any]]  # IoCs, signatures, patterns
    threat_type: Optional[str]  # malware, phishing, ddos, intrusion, etc.
    threat_level: Optional[ThreatLevel]
    threat_confidence: Optional[float]  # 0.0 to 1.0

    # ============ Vulnerability Assessment ============
    vulnerabilities: List[Dict[str, Any]]  # CVEs, weaknesses, exposures
    affected_systems: List[str]  # Impacted assets
    attack_surface: Optional[Dict[str, Any]]  # Entry points and vectors

    # ============ Risk Analysis ============
    risk_score: Optional[float]  # Calculated risk score
    risk_factors: Optional[Dict[str, Any]]  # Contributing factors
    business_impact: Optional[str]  # Impact assessment
    likelihood_score: Optional[float]  # Probability of exploitation

    # ============ Incident Classification ============
    incident_category: Optional[str]  # Category of incident
    incident_status: Optional[IncidentStatus]
    incident_id: Optional[str]  # Unique incident identifier
    similar_incidents: List[str]  # Related incident IDs

    # ============ Forensics Investigation ============
    forensics_data: Optional[Dict[str, Any]]  # Detailed forensic analysis
    timeline: List[Dict[str, str]]  # Event timeline
    root_cause: Optional[str]  # Identified root cause
    attack_chain: List[str]  # Kill chain stages

    # ============ Threat Intelligence ============
    threat_intel: Optional[Dict[str, Any]]  # External threat data
    known_threat_actors: List[str]  # Identified threat actors
    ttps: List[str]  # Tactics, Techniques, Procedures
    iocs: List[Dict[str, str]]  # Indicators of Compromise

    # ============ Response Coordination ============
    response_plan: Optional[Dict[str, Any]]  # Action plan
    containment_actions: List[str]  # Immediate containment
    eradication_steps: List[str]  # Threat removal steps
    recovery_plan: Optional[Dict[str, Any]]  # Recovery procedures
    automated_actions: List[str]  # Automated response actions taken

    # ============ Compliance Checking ============
    compliance_status: Optional[Dict[str, Any]]  # Compliance assessment
    regulatory_requirements: List[str]  # Applicable regulations
    compliance_violations: List[str]  # Identified violations
    reporting_obligations: List[Dict[str, Any]]  # Required notifications

    # ============ Remediation ============
    remediation_plan: Optional[Dict[str, Any]]  # Detailed remediation
    patches_required: List[Dict[str, str]]  # Needed patches
    configuration_changes: List[str]  # Config updates
    estimated_remediation_time: Optional[str]  # Time estimate

    # ============ Human Escalation ============
    requires_escalation: bool  # Needs human intervention
    escalation_reason: Optional[str]  # Why escalation is needed
    escalation_urgency: Optional[ThreatLevel]  # Urgency level
    analyst_feedback: Optional[str]  # Human analyst input

    # ============ Workflow Control ============
    current_node: Optional[str]  # Current workflow node
    processing_mode: Optional[str]  # sequential, parallel
    nodes_completed: Set[str]  # Completed workflow nodes
    nodes_in_progress: Set[str]  # Currently executing nodes

    # ============ Conversation & History ============
    conversation_history: List[Dict[str, str]]  # All interactions
    analysis_history: List[Dict[str, Any]]  # Analysis iterations

    # ============ Metadata & Tracking ============
    metadata: Dict[str, Any]  # Additional context
    session_id: Optional[str]  # Session identifier
    thread_id: Optional[str]  # Thread for persistence
    timestamp: Optional[str]  # Last update timestamp
    error: Optional[str]  # Error information

    # ============ Metrics & Quality ============
    detection_accuracy: Optional[float]  # Detection quality
    false_positive_probability: Optional[float]  # FP likelihood
    investigation_depth: Optional[str]  # shallow, moderate, deep
    recommendations: List[str]  # Security recommendations


def create_initial_state(
    threat_input: str,
    session_id: Optional[str] = None,
    processing_mode: str = "sequential"
) -> ThreatIntelligenceState:
    """
    Create initial state for a new threat intelligence analysis.

    Args:
        threat_input: The threat alert or security event description
        session_id: Optional session identifier
        processing_mode: 'sequential' or 'parallel' processing

    Returns:
        Initialized ThreatIntelligenceState
    """
    import uuid

    incident_id = f"INC-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"

    return ThreatIntelligenceState(
        # Core
        threat_input=threat_input,
        final_report=None,

        # Threat identification
        threat_indicators=[],
        threat_type=None,
        threat_level=None,
        threat_confidence=None,

        # Vulnerability assessment
        vulnerabilities=[],
        affected_systems=[],
        attack_surface=None,

        # Risk analysis
        risk_score=None,
        risk_factors=None,
        business_impact=None,
        likelihood_score=None,

        # Incident classification
        incident_category=None,
        incident_status=IncidentStatus.DETECTED,
        incident_id=incident_id,
        similar_incidents=[],

        # Forensics
        forensics_data=None,
        timeline=[{
            "timestamp": datetime.now().isoformat(),
            "event": "Incident detected",
            "description": threat_input[:100]
        }],
        root_cause=None,
        attack_chain=[],

        # Threat intelligence
        threat_intel=None,
        known_threat_actors=[],
        ttps=[],
        iocs=[],

        # Response coordination
        response_plan=None,
        containment_actions=[],
        eradication_steps=[],
        recovery_plan=None,
        automated_actions=[],

        # Compliance
        compliance_status=None,
        regulatory_requirements=[],
        compliance_violations=[],
        reporting_obligations=[],

        # Remediation
        remediation_plan=None,
        patches_required=[],
        configuration_changes=[],
        estimated_remediation_time=None,

        # Escalation
        requires_escalation=False,
        escalation_reason=None,
        escalation_urgency=None,
        analyst_feedback=None,

        # Workflow
        current_node="start",
        processing_mode=processing_mode,
        nodes_completed=set(),
        nodes_in_progress=set(),

        # History
        conversation_history=[{
            "role": "system",
            "content": threat_input,
            "timestamp": datetime.now().isoformat()
        }],
        analysis_history=[],

        # Metadata
        metadata={
            "started_at": datetime.now().isoformat(),
            "incident_id": incident_id,
            "source": "cli",
            "version": "1.0"
        },
        session_id=session_id,
        thread_id=session_id,
        timestamp=datetime.now().isoformat(),
        error=None,

        # Metrics
        detection_accuracy=None,
        false_positive_probability=None,
        investigation_depth="moderate",
        recommendations=[]
    )


def update_timeline(
    state: ThreatIntelligenceState,
    event: str,
    description: str
) -> ThreatIntelligenceState:
    """Add an event to the incident timeline."""
    state["timeline"].append({
        "timestamp": datetime.now().isoformat(),
        "event": event,
        "description": description
    })
    state["timestamp"] = datetime.now().isoformat()
    return state


def add_threat_indicator(
    state: ThreatIntelligenceState,
    indicator_type: str,
    value: str,
    confidence: float,
    source: str = "automated"
) -> ThreatIntelligenceState:
    """Add a threat indicator to the state."""
    state["threat_indicators"].append({
        "type": indicator_type,
        "value": value,
        "confidence": confidence,
        "source": source,
        "timestamp": datetime.now().isoformat()
    })
    return state
