"""
Remediation Planner Agent - Create detailed remediation plans.
"""

import logging
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm

logger = logging.getLogger(__name__)


class RemediationPlannerAgent:
    """
    Agent responsible for creating detailed remediation plans.

    Plans long-term fixes, patches, configuration changes,
    and security improvements.
    """

    def __init__(self):
        """Initialize the remediation planner agent."""
        self.llm = get_llm(task_type="creative")
        self.parser = JsonOutputParser()
        logger.info("Remediation Planner Agent initialized")

    def create_plan(
        self,
        vulnerabilities: List[Dict[str, Any]],
        forensics_data: Dict[str, Any],
        response_plan: Dict[str, Any],
        threat_type: str
    ) -> Dict[str, Any]:
        """
        Create comprehensive remediation plan.

        Args:
            vulnerabilities: Identified vulnerabilities
            forensics_data: Forensic findings
            response_plan: Incident response plan
            threat_type: Type of threat

        Returns:
            Detailed remediation plan
        """
        logger.debug("Creating remediation plan")

        system_prompt = """You are an expert security remediation specialist.

Create a comprehensive remediation plan that addresses:
1. Immediate fixes (patches, hotfixes)
2. Configuration changes
3. Security controls to implement
4. Architecture improvements
5. Process improvements
6. Training and awareness needs
7. Monitoring enhancements

Organize by priority and timeline. Include specific actions, not generic advice.

Return ONLY valid JSON:
{
    "remediation_priority": "critical|high|medium|low",
    "estimated_total_time": "string (e.g., '2-3 weeks')",
    "immediate_fixes": [
        {
            "action": "string",
            "system": "string",
            "priority": "critical|high|medium",
            "estimated_time": "string",
            "complexity": "low|medium|high"
        }
    ],
    "patches_required": [
        {
            "patch_id": "string (CVE or KB number)",
            "affected_systems": ["string"],
            "criticality": "critical|high|medium",
            "testing_required": boolean
        }
    ],
    "configuration_changes": [
        {
            "system": "string",
            "change": "string",
            "justification": "string",
            "rollback_plan": "string"
        }
    ],
    "security_controls": [
        {
            "control_type": "preventive|detective|corrective",
            "control": "string",
            "implementation": "string",
            "cost_estimate": "low|medium|high"
        }
    ],
    "architecture_changes": ["string"],
    "process_improvements": ["string"],
    "training_needs": ["string"],
    "monitoring_enhancements": ["string"],
    "validation_steps": ["string"],
    "success_metrics": ["string"],
    "long_term_recommendations": ["string"]
}"""

        vuln_summary = "\n".join([
            f"- {v.get('name', 'Unknown')} (Severity: {v.get('severity', 'Unknown')})"
            for v in vulnerabilities[:10]
        ])

        human_prompt = f"""Remediation Planning Required:

Threat Type: {threat_type}

Vulnerabilities:
{vuln_summary if vuln_summary else 'None specifically identified'}

Root Cause: {forensics_data.get('root_cause', 'Under investigation')}

Persistence Mechanisms Found: {', '.join(forensics_data.get('persistence_mechanisms', [])) or 'None'}

Response Priority: {response_plan.get('response_priority', 'Unknown')}

Create comprehensive remediation plan."""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=human_prompt)
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Remediation plan created: Priority {result.get('remediation_priority')}")

            return result

        except Exception as e:
            logger.error(f"Error creating remediation plan: {str(e)}")
            return {
                "remediation_priority": "high",
                "estimated_total_time": "Unknown",
                "immediate_fixes": [],
                "patches_required": [],
                "configuration_changes": [],
                "security_controls": [],
                "architecture_changes": [],
                "process_improvements": ["Conduct security review"],
                "training_needs": ["Security awareness training"],
                "monitoring_enhancements": ["Implement enhanced logging"],
                "validation_steps": ["Verify all systems secure"],
                "success_metrics": ["No recurrence for 90 days"],
                "long_term_recommendations": ["Full security audit recommended"]
            }
