"""
Risk Analyzer Agent - Calculate comprehensive risk scores.
"""

import logging
from typing import Dict, Any, List

from services.risk_scoring_service import get_risk_scoring_service
from state import ThreatLevel

logger = logging.getLogger(__name__)


class RiskAnalyzerAgent:
    """
    Agent responsible for comprehensive risk analysis.

    Calculates risk scores, assesses business impact, and determines
    likelihood of successful exploitation.
    """

    def __init__(self):
        """Initialize the risk analyzer agent."""
        self.risk_service = get_risk_scoring_service()
        logger.info("Risk Analyzer Agent initialized")

    def analyze_risk(
        self,
        threat_type: str,
        threat_level: str,
        confidence: float,
        vulnerabilities: List[Dict[str, Any]],
        affected_systems: List[str]
    ) -> Dict[str, Any]:
        """
        Perform comprehensive risk analysis.

        Args:
            threat_type: Type of threat
            threat_level: Threat severity level
            confidence: Detection confidence
            vulnerabilities: Identified vulnerabilities
            affected_systems: Affected systems

        Returns:
            Risk analysis results
        """
        logger.debug(f"Analyzing risk for {threat_type}")

        # Use the risk scoring service
        risk_score_result = self.risk_service.calculate_risk_score(
            threat_type=threat_type,
            affected_systems=affected_systems,
            vulnerabilities=vulnerabilities,
            threat_level=threat_level,
            confidence=confidence
        )

        # Determine risk factors
        risk_factors = self._identify_risk_factors(
            threat_type,
            vulnerabilities,
            affected_systems
        )

        # Compile complete risk analysis
        return {
            **risk_score_result,
            "risk_factors": risk_factors,
            "analysis_summary": self._create_summary(risk_score_result, risk_factors)
        }

    def _identify_risk_factors(
        self,
        threat_type: str,
        vulnerabilities: List[Dict[str, Any]],
        affected_systems: List[str]
    ) -> Dict[str, Any]:
        """Identify contributing risk factors."""
        factors = {
            "high_severity_vulns": sum(
                1 for v in vulnerabilities
                if v.get("severity", "").lower() in ["critical", "high"]
            ),
            "multiple_systems_affected": len(affected_systems) > 1,
            "critical_systems_involved": any(
                "prod" in sys.lower() or "critical" in sys.lower()
                for sys in affected_systems
            ),
            "high_exploitability": any(
                v.get("exploitability", "").lower() == "easy"
                for v in vulnerabilities
            ),
            "active_threat": threat_type.lower() in [
                "ransomware", "apt", "data_breach", "intrusion"
            ]
        }

        return factors

    def _create_summary(
        self,
        risk_result: Dict[str, Any],
        risk_factors: Dict[str, Any]
    ) -> str:
        """Create human-readable risk summary."""
        score = risk_result["risk_score"]
        category = risk_result["risk_category"]

        summary = f"Risk Score: {score}/10.0 ({category.upper()})\n"
        summary += f"Likelihood: {risk_result['likelihood_score']}/1.0\n"
        summary += f"Business Impact: {risk_result['business_impact']}\n\n"

        summary += "Key Risk Factors:\n"
        for factor, present in risk_factors.items():
            if present:
                summary += f"- {factor.replace('_', ' ').title()}\n"

        summary += f"\nRecommendation: {risk_result['recommendation']}"

        return summary
