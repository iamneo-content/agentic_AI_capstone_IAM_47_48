"""
Threat Intelligence Agent - Enrich with external threat intelligence.
"""

import logging
from typing import Dict, Any, List

from services.threat_intel_service import get_threat_intel_service

logger = logging.getLogger(__name__)


class ThreatIntelAgent:
    """
    Agent responsible for threat intelligence enrichment.

    Queries external threat intelligence feeds, correlates indicators,
    identifies known threat actors and campaigns.
    """

    def __init__(self):
        """Initialize the threat intelligence agent."""
        self.intel_service = get_threat_intel_service()
        logger.info("Threat Intelligence Agent initialized")

    def enrich(
        self,
        threat_type: str,
        indicators: List[Dict[str, str]],
        forensics_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Enrich threat data with external intelligence.

        Args:
            threat_type: Type of threat
            indicators: Threat indicators
            forensics_data: Forensic investigation results

        Returns:
            Enriched threat intelligence
        """
        logger.debug(f"Enriching threat intelligence for {threat_type}")

        # Look up indicators
        ioc_results = []
        for indicator in indicators[:20]:  # Limit lookups
            ioc_type = indicator.get('type', 'unknown')
            ioc_value = indicator.get('value', '')

            if ioc_value:
                result = self.intel_service.lookup_ioc(ioc_value, ioc_type)
                if result.get('found'):
                    ioc_results.append(result)

        # Check for known malware
        malware_info = self.intel_service.get_malware_info(threat_type)

        # Check for known threat actors
        attacker_sophistication = forensics_data.get('attacker_sophistication', 'unknown')
        threat_actors = []

        # Simple heuristic for threat actor association
        if attacker_sophistication in ['high', 'advanced']:
            for actor_key in ['apt28', 'apt29', 'lazarus', 'apt41']:
                actor_info = self.intel_service.get_threat_actor_info(actor_key)
                if actor_info:
                    threat_actors.append(actor_info)
                    break

        # Get MITRE ATT&CK techniques
        keywords = [threat_type] + [
            stage.get('stage', '')
            for stage in forensics_data.get('attack_chain_stages', [])
        ]
        mitre_techniques = self.intel_service.get_mitre_techniques(keywords)

        # Correlate indicators
        correlation = self.intel_service.correlate_threats(indicators)

        # Compile TTPs (Tactics, Techniques, Procedures)
        ttps = []
        if malware_info:
            ttps.extend(malware_info.get('capabilities', []))

        for technique in mitre_techniques:
            ttps.append(f"{technique['id']}: {technique['name']}")

        # Build enriched intelligence
        enriched = {
            "iocs_enriched": ioc_results,
            "known_malware": malware_info,
            "threat_actors": threat_actors,
            "ttps": list(set(ttps))[:10],  # Unique, limited
            "mitre_techniques": mitre_techniques,
            "correlation": correlation,
            "intelligence_summary": self._create_summary(
                ioc_results, malware_info, threat_actors, correlation
            ),
            "threat_intel_sources": ["internal_analysis", "threat_feeds", "mitre_attack"],
            "confidence_level": self._calculate_confidence(ioc_results, malware_info, threat_actors)
        }

        logger.info(f"Intelligence enrichment complete: {len(ioc_results)} IoCs, {len(threat_actors)} actors")

        return enriched

    def _create_summary(
        self,
        iocs: List[Dict],
        malware: Dict,
        actors: List[Dict],
        correlation: Dict
    ) -> str:
        """Create threat intelligence summary."""
        summary = "Threat Intelligence Summary:\n\n"

        if iocs:
            summary += f"- {len(iocs)} malicious indicators identified\n"

        if malware:
            summary += f"- Known malware family: {malware.get('family', 'Unknown')}\n"
            summary += f"  Severity: {malware.get('severity', 'Unknown')}\n"

        if actors:
            summary += f"- Possible threat actor: {actors[0].get('name', 'Unknown')}\n"
            summary += f"  Origin: {actors[0].get('country', 'Unknown')}\n"

        if correlation.get('possible_campaigns'):
            summary += f"- Related to campaign: {correlation['possible_campaigns'][0]}\n"

        summary += f"\nCorrelation confidence: {correlation.get('confidence', 'unknown')}"

        return summary

    def _calculate_confidence(
        self,
        iocs: List[Dict],
        malware: Dict,
        actors: List[Dict]
    ) -> float:
        """Calculate overall intelligence confidence."""
        confidence = 0.5  # Base confidence

        if iocs:
            confidence += 0.2
        if malware:
            confidence += 0.15
        if actors:
            confidence += 0.15

        return min(1.0, confidence)
