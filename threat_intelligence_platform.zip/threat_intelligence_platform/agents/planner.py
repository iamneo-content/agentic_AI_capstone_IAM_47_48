"""
Planner Agent - Creates strategic analysis plan for threat investigation.
"""

import logging
from typing import Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm

logger = logging.getLogger(__name__)


class PlannerAgent:
    """
    Agent responsible for creating strategic analysis plan.

    Analyzes initial threat input and creates a comprehensive
    investigation and response plan.
    """

    def __init__(self):
        """Initialize the planner agent."""
        self.llm = get_llm(task_type="analysis")
        self.parser = JsonOutputParser()
        logger.info("Planner Agent initialized")

    def create_plan(self, threat_input: str) -> Dict[str, Any]:
        """
        Create strategic analysis plan for threat investigation.

        Args:
            threat_input: The threat alert or security event description

        Returns:
            Strategic plan with investigation priorities
        """
        logger.debug("Creating strategic analysis plan")

        system_prompt = """You are a senior security analyst responsible for planning threat investigations.

Analyze the threat input and create a strategic investigation plan.

Determine:
1. Investigation Complexity (low, medium, high, critical)
2. Priority Level (routine, elevated, high, critical)
3. Estimated Scope (localized, departmental, enterprise-wide)
4. Key Focus Areas (what to investigate first)
5. Special Considerations (any unique aspects requiring attention)
6. Recommended Investigation Depth (shallow, moderate, deep, comprehensive)

Return ONLY valid JSON:
{
    "complexity": "low|medium|high|critical",
    "priority": "routine|elevated|high|critical",
    "scope": "localized|departmental|enterprise-wide|critical-infrastructure",
    "focus_areas": ["string"],
    "special_considerations": ["string"],
    "investigation_depth": "shallow|moderate|deep|comprehensive",
    "estimated_urgency": "low|medium|high|critical",
    "requires_immediate_action": boolean,
    "plan_summary": "string"
}"""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Threat Alert:\n{threat_input}")
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Plan created: {result.get('complexity')} complexity, {result.get('priority')} priority")

            return result

        except Exception as e:
            logger.error(f"Error in planning: {str(e)}")
            return {
                "complexity": "medium",
                "priority": "elevated",
                "scope": "localized",
                "focus_areas": ["Initial assessment required"],
                "special_considerations": ["Planning error - proceed with standard analysis"],
                "investigation_depth": "moderate",
                "estimated_urgency": "medium",
                "requires_immediate_action": False,
                "plan_summary": f"Planning error: {str(e)} - proceeding with standard analysis"
            }
