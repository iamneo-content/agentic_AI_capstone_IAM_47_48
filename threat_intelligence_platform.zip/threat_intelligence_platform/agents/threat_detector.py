"""
Threat Detector Agent - Initial threat identification and analysis.
"""

import logging
from typing import Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm

logger = logging.getLogger(__name__)


class ThreatDetectorAgent:
    """
    Agent responsible for initial threat detection and identification.

    Analyzes security events and alerts to identify potential threats,
    extract indicators, and determine initial severity.
    """

    def __init__(self):
        """Initialize the threat detector agent."""
        self.llm = get_llm(task_type="classification")
        self.parser = JsonOutputParser()
        logger.info("Threat Detector Agent initialized")

    def analyze(self, threat_input: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Analyze input to detect and identify threats.

        Args:
            threat_input: The security alert or event description
            context: Additional context information

        Returns:
            Threat detection results
        """
        logger.debug(f"Analyzing threat input: {threat_input[:100]}...")

        system_prompt = """You are an expert security analyst specializing in threat detection.

Your task is to analyze security alerts and events to identify potential threats.

Analyze the input and provide:
1. Threat Type: Classify the threat (malware, phishing, intrusion, ddos, ransomware, data_breach, apt, policy_violation, etc.)
2. Threat Level: Assess severity (critical, high, medium, low, info)
3. Confidence: Your confidence in this assessment (0.0 to 1.0)
4. Indicators: Extract any indicators of compromise (IPs, domains, hashes, file names, etc.)
5. Initial Assessment: Brief description of the threat
6. Urgency: Whether immediate action is required (immediate, urgent, routine, monitor)

Return ONLY valid JSON with this exact structure:
{
    "threat_type": "string",
    "threat_level": "string",
    "confidence": float,
    "indicators": [
        {"type": "ip|domain|hash|file|url", "value": "string", "context": "string"}
    ],
    "initial_assessment": "string",
    "urgency": "string",
    "requires_immediate_action": boolean,
    "summary": "string"
}"""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Security Alert:\n{threat_input}")
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Threat detected: {result.get('threat_type')} (Level: {result.get('threat_level')})")

            return result

        except Exception as e:
            logger.error(f"Error in threat detection: {str(e)}")
            # Return fallback result
            return {
                "threat_type": "unknown",
                "threat_level": "medium",
                "confidence": 0.5,
                "indicators": [],
                "initial_assessment": "Error during analysis - requires manual review",
                "urgency": "urgent",
                "requires_immediate_action": True,
                "summary": f"Analysis error: {str(e)}"
            }
