"""
Forensics Agent - Deep investigation and root cause analysis.
"""

import logging
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm

logger = logging.getLogger(__name__)


class ForensicsAgent:
    """
    Agent responsible for digital forensics and deep investigation.

    Performs root cause analysis, reconstructs attack timeline,
    and identifies attack chain stages.
    """

    def __init__(self):
        """Initialize the forensics agent."""
        self.llm = get_llm(task_type="forensics")
        self.parser = JsonOutputParser()
        logger.info("Forensics Agent initialized")

    def investigate(
        self,
        threat_input: str,
        threat_type: str,
        indicators: List[Dict[str, str]],
        vulnerabilities: List[Dict[str, Any]],
        incident_category: str
    ) -> Dict[str, Any]:
        """
        Conduct forensic investigation.

        Args:
            threat_input: Threat description
            threat_type: Type of threat
            indicators: Threat indicators
            vulnerabilities: Identified vulnerabilities
            incident_category: Incident classification

        Returns:
            Forensic investigation results
        """
        logger.debug(f"Conducting forensic investigation for {threat_type}")

        system_prompt = """You are an expert digital forensics investigator.

Conduct a thorough forensic analysis to:
1. Determine Root Cause (what allowed this incident)
2. Reconstruct Attack Chain (kill chain stages)
3. Identify Initial Access Method
4. Map Lateral Movement (if applicable)
5. Determine Persistence Mechanisms
6. Identify Data Exfiltration (if applicable)
7. Assess Attacker Sophistication

Use the Cyber Kill Chain model:
1. Reconnaissance
2. Weaponization
3. Delivery
4. Exploitation
5. Installation
6. Command & Control
7. Actions on Objectives

Return ONLY valid JSON:
{
    "root_cause": "detailed explanation",
    "initial_access_method": "string",
    "attack_chain_stages": [
        {
            "stage": "kill chain stage",
            "description": "what happened",
            "timestamp_estimate": "relative or specific",
            "evidence": ["indicators"]
        }
    ],
    "lateral_movement": {
        "occurred": boolean,
        "methods": ["string"],
        "compromised_systems": ["string"]
    },
    "persistence_mechanisms": ["string"],
    "data_exfiltration": {
        "occurred": boolean,
        "data_types": ["string"],
        "volume_estimate": "string"
    },
    "attacker_sophistication": "low|moderate|high|advanced",
    "forensic_artifacts": ["string"],
    "investigation_completeness": "preliminary|moderate|comprehensive",
    "recommendations": ["string"]
}"""

        indicators_str = "\n".join([
            f"- {ind.get('type')}: {ind.get('value')}"
            for ind in indicators[:10]  # Limit for context
        ])

        human_prompt = f"""Incident Details:
Type: {threat_type}
Category: {incident_category}

Threat Description:
{threat_input}

Known Indicators:
{indicators_str}

Vulnerabilities: {len(vulnerabilities)} identified

Perform forensic analysis."""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=human_prompt)
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Forensic investigation complete: {result.get('investigation_completeness')}")

            return result

        except Exception as e:
            logger.error(f"Error in forensic investigation: {str(e)}")
            return {
                "root_cause": "Unable to determine - requires manual forensic analysis",
                "initial_access_method": "unknown",
                "attack_chain_stages": [],
                "lateral_movement": {"occurred": False, "methods": [], "compromised_systems": []},
                "persistence_mechanisms": [],
                "data_exfiltration": {"occurred": False, "data_types": [], "volume_estimate": "unknown"},
                "attacker_sophistication": "moderate",
                "forensic_artifacts": [],
                "investigation_completeness": "preliminary",
                "recommendations": ["Conduct manual forensic analysis"]
            }
