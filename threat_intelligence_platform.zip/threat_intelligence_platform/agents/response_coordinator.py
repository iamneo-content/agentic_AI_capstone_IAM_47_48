"""
Response Coordinator Agent - Orchestrate incident response actions.
"""

import logging
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm

logger = logging.getLogger(__name__)


class ResponseCoordinatorAgent:
    """
    Agent responsible for coordinating incident response.

    Creates response plans, coordinates containment actions,
    and manages eradication and recovery procedures.
    """

    def __init__(self):
        """Initialize the response coordinator agent."""
        self.llm = get_llm(task_type="analysis")
        self.parser = JsonOutputParser()
        logger.info("Response Coordinator Agent initialized")

    def create_response_plan(
        self,
        threat_type: str,
        threat_level: str,
        risk_score: float,
        affected_systems: List[str],
        forensics_data: Dict[str, Any],
        incident_category: str
    ) -> Dict[str, Any]:
        """
        Create comprehensive incident response plan.

        Args:
            threat_type: Type of threat
            threat_level: Severity level
            risk_score: Calculated risk score
            affected_systems: Impacted systems
            forensics_data: Forensic investigation results
            incident_category: Incident classification

        Returns:
            Response plan with containment, eradication, and recovery steps
        """
        logger.debug(f"Creating response plan for {threat_type}")

        system_prompt = """You are an expert incident response coordinator.

Create a comprehensive incident response plan following the NIST Incident Response framework:
1. Detection & Analysis (already completed)
2. Containment (immediate and long-term)
3. Eradication (threat removal)
4. Recovery (restore operations)
5. Post-Incident Activities

Your response plan must include:
- Immediate containment actions (what to do RIGHT NOW)
- Short-term containment (stabilize situation)
- Eradication steps (remove threat completely)
- Recovery procedures (restore services)
- Automated actions that can be taken
- Manual steps requiring human intervention
- Timeline estimates
- Success criteria

Return ONLY valid JSON:
{
    "response_priority": "critical|high|medium|low",
    "immediate_actions": [
        {
            "action": "string",
            "automated": boolean,
            "priority": "critical|high|medium",
            "estimated_time": "string"
        }
    ],
    "containment_strategy": {
        "approach": "isolation|segmentation|blocking|monitoring",
        "steps": ["string"],
        "affected_services": ["string"],
        "business_impact": "string"
    },
    "eradication_plan": {
        "steps": ["string"],
        "tools_required": ["string"],
        "estimated_duration": "string"
    },
    "recovery_plan": {
        "phases": [
            {
                "phase": "string",
                "steps": ["string"],
                "validation": "string"
            }
        ],
        "estimated_recovery_time": "string"
    },
    "automated_actions_recommended": ["string"],
    "manual_actions_required": ["string"],
    "escalation_needed": boolean,
    "escalation_reason": "string or null",
    "coordination_requirements": ["string"],
    "success_criteria": ["string"]
}"""

        human_prompt = f"""Incident Response Required:

Threat Type: {threat_type}
Threat Level: {threat_level}
Risk Score: {risk_score}/10.0
Incident Category: {incident_category}

Affected Systems: {', '.join(affected_systems[:5])}
{f'... and {len(affected_systems)-5} more' if len(affected_systems) > 5 else ''}

Root Cause: {forensics_data.get('root_cause', 'Under investigation')}
Attacker Sophistication: {forensics_data.get('attacker_sophistication', 'unknown')}

Create incident response plan."""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=human_prompt)
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Response plan created: Priority {result.get('response_priority')}")

            return result

        except Exception as e:
            logger.error(f"Error creating response plan: {str(e)}")
            return {
                "response_priority": "high",
                "immediate_actions": [
                    {
                        "action": "Isolate affected systems",
                        "automated": False,
                        "priority": "critical",
                        "estimated_time": "Immediate"
                    }
                ],
                "containment_strategy": {
                    "approach": "isolation",
                    "steps": ["Manual intervention required"],
                    "affected_services": affected_systems,
                    "business_impact": "To be determined"
                },
                "eradication_plan": {
                    "steps": ["Requires manual planning"],
                    "tools_required": [],
                    "estimated_duration": "Unknown"
                },
                "recovery_plan": {
                    "phases": [],
                    "estimated_recovery_time": "Unknown"
                },
                "automated_actions_recommended": [],
                "manual_actions_required": ["Full incident response plan creation"],
                "escalation_needed": True,
                "escalation_reason": "Error creating automated response plan",
                "coordination_requirements": ["Security team", "IT operations"],
                "success_criteria": []
            }
