"""
Report Generator Agent - Create comprehensive security reports.
"""

import logging
from typing import Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class ReportGeneratorAgent:
    """
    Agent responsible for generating comprehensive security reports.

    Creates executive summaries, technical reports, and incident
    documentation from all analysis data.
    """

    def __init__(self):
        """Initialize the report generator agent."""
        logger.info("Report Generator Agent initialized")

    def generate_report(
        self,
        state: Dict[str, Any],
        report_type: str = "comprehensive"
    ) -> str:
        """
        Generate security incident report.

        Args:
            state: Complete threat intelligence state
            report_type: Type of report (executive, technical, comprehensive)

        Returns:
            Formatted security report
        """
        logger.debug(f"Generating {report_type} report")

        if report_type == "executive":
            return self._generate_executive_summary(state)
        elif report_type == "technical":
            return self._generate_technical_report(state)
        else:
            return self._generate_comprehensive_report(state)

    def _generate_comprehensive_report(self, state: Dict[str, Any]) -> str:
        """Generate comprehensive security report."""
        report = []

        # Convert enums to strings
        incident_status = state.get('incident_status', 'Unknown')
        if hasattr(incident_status, 'value'):
            incident_status = incident_status.value

        threat_level = state.get('threat_level', 'Unknown')
        if hasattr(threat_level, 'value'):
            threat_level = threat_level.value

        # Header
        report.append("=" * 80)
        report.append("SECURITY INCIDENT REPORT")
        report.append("=" * 80)
        report.append(f"\nIncident ID: {state.get('incident_id', 'N/A')}")
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"Status: {str(incident_status).upper()}")
        report.append("\n" + "=" * 80)

        # Executive Summary
        report.append("\n## EXECUTIVE SUMMARY\n")
        report.append(f"Threat Type: {str(state.get('threat_type', 'Unknown')).upper()}")
        report.append(f"Threat Level: {str(threat_level).upper()}")
        report.append(f"Risk Score: {state.get('risk_score', 'N/A')}/10.0")
        report.append(f"Confidence: {state.get('threat_confidence', 0) * 100:.0f}%")
        report.append(f"\n{state.get('threat_input', 'No description available')}")

        # Risk Analysis
        report.append("\n" + "-" * 80)
        report.append("\n## RISK ANALYSIS\n")
        risk_factors = state.get('risk_factors') or {}
        report.append(f"Business Impact: {state.get('business_impact', 'Unknown')}")
        report.append(f"Likelihood Score: {state.get('likelihood_score', 'N/A')}")
        if risk_factors:
            report.append(f"\nRisk Factors:")
            for factor, present in risk_factors.items():
                if present:
                    report.append(f"  [X] {factor.replace('_', ' ').title()}")
        else:
            report.append("\nRisk Factors: Not yet analyzed")

        # Incident Classification
        report.append("\n" + "-" * 80)
        report.append("\n## INCIDENT CLASSIFICATION\n")
        report.append(f"Category: {state.get('incident_category', 'Unknown')}")
        affected_systems = state.get('affected_systems', [])
        report.append(f"Affected Systems: {len(affected_systems)}")
        for system in affected_systems[:5]:
            report.append(f"  - {system}")
        if len(affected_systems) > 5:
            report.append(f"  ... and {len(affected_systems) - 5} more")

        # Threat Intelligence
        report.append("\n" + "-" * 80)
        report.append("\n## THREAT INTELLIGENCE\n")
        threat_intel = state.get('threat_intel', {})
        if threat_intel:
            report.append(threat_intel.get('intelligence_summary', 'No intelligence data available'))

            ttps = threat_intel.get('ttps', [])
            if ttps:
                report.append(f"\nTactics, Techniques, and Procedures ({len(ttps)}):")
                for ttp in ttps[:5]:
                    report.append(f"  - {ttp}")

        # Vulnerabilities
        report.append("\n" + "-" * 80)
        report.append("\n## VULNERABILITIES\n")
        vulnerabilities = state.get('vulnerabilities', [])
        report.append(f"Total Vulnerabilities: {len(vulnerabilities)}")
        for vuln in vulnerabilities[:5]:
            report.append(f"\n{vuln.get('name', 'Unknown')}")
            report.append(f"  Severity: {vuln.get('severity', 'Unknown')}")
            report.append(f"  CVSS: {vuln.get('cvss_score', 'N/A')}")
            report.append(f"  Description: {vuln.get('description', 'N/A')}")

        # Forensics
        report.append("\n" + "-" * 80)
        report.append("\n## FORENSIC ANALYSIS\n")
        forensics = state.get('forensics_data', {})
        if forensics:
            report.append(f"Root Cause: {forensics.get('root_cause', 'Unknown')}")
            report.append(f"Initial Access: {forensics.get('initial_access_method', 'Unknown')}")
            report.append(f"Attacker Sophistication: {forensics.get('attacker_sophistication', 'Unknown')}")

            attack_chain = forensics.get('attack_chain_stages', [])
            if attack_chain:
                report.append(f"\nAttack Chain ({len(attack_chain)} stages):")
                for stage in attack_chain:
                    report.append(f"  {stage.get('stage', 'Unknown')}: {stage.get('description', 'N/A')}")

        # Response Plan
        report.append("\n" + "-" * 80)
        report.append("\n## RESPONSE PLAN\n")
        response_plan = state.get('response_plan', {})
        if response_plan:
            report.append(f"Priority: {response_plan.get('response_priority', 'Unknown').upper()}")

            immediate_actions = response_plan.get('immediate_actions', [])
            if immediate_actions:
                report.append(f"\nImmediate Actions ({len(immediate_actions)}):")
                for action in immediate_actions[:5]:
                    report.append(f"  - [{action.get('priority', 'N/A').upper()}] {action.get('action', 'N/A')}")

        # Remediation
        report.append("\n" + "-" * 80)
        report.append("\n## REMEDIATION PLAN\n")
        remediation = state.get('remediation_plan', {})
        if remediation:
            report.append(f"Priority: {remediation.get('remediation_priority', 'Unknown').upper()}")
            report.append(f"Estimated Time: {remediation.get('estimated_total_time', 'Unknown')}")

            patches = remediation.get('patches_required', [])
            if patches:
                report.append(f"\nPatches Required ({len(patches)}):")
                for patch in patches[:5]:
                    report.append(f"  - {patch.get('patch_id', 'Unknown')} (Priority: {patch.get('criticality', 'Unknown')})")

        # Compliance
        report.append("\n" + "-" * 80)
        report.append("\n## COMPLIANCE & REGULATORY\n")
        compliance = state.get('compliance_status', {})
        if compliance:
            report.append(f"Overall Status: {compliance.get('overall', 'Unknown').upper()}")
            reporting_required = state.get('reporting_obligations', [])
            if reporting_required:
                report.append(f"\nReporting Obligations ({len(reporting_required)}):")
                for obligation in reporting_required:
                    report.append(f"  - {obligation.get('authority', 'Unknown')}: {obligation.get('deadline', 'TBD')}")

        # Recommendations
        report.append("\n" + "-" * 80)
        report.append("\n## RECOMMENDATIONS\n")
        recommendations = state.get('recommendations', [])
        if recommendations:
            for i, rec in enumerate(recommendations, 1):
                report.append(f"{i}. {rec}")
        else:
            report.append("Refer to remediation plan for detailed recommendations.")

        # Footer
        report.append("\n" + "=" * 80)
        report.append("END OF REPORT")
        report.append("=" * 80)

        return "\n".join(report)

    def _generate_executive_summary(self, state: Dict[str, Any]) -> str:
        """Generate executive summary."""
        summary = []

        summary.append("EXECUTIVE SUMMARY - SECURITY INCIDENT")
        summary.append("=" * 60)
        summary.append(f"\nIncident: {state.get('incident_id', 'N/A')}")
        summary.append(f"Threat: {state.get('threat_type', 'Unknown').upper()}")
        summary.append(f"Risk: {state.get('risk_score', 'N/A')}/10.0 ({state.get('threat_level', 'Unknown').upper()})")
        summary.append(f"\n{state.get('business_impact', 'Impact assessment pending')}")
        summary.append(f"\nStatus: {state.get('incident_status', 'Unknown').upper()}")

        response_plan = state.get('response_plan', {})
        if response_plan and response_plan.get('immediate_actions'):
            summary.append(f"\nImmediate Action Required: YES")
        else:
            summary.append(f"\nImmediate Action Required: Under Review")

        summary.append("\n" + "=" * 60)

        return "\n".join(summary)

    def _generate_technical_report(self, state: Dict[str, Any]) -> str:
        """Generate technical report."""
        # For brevity, use comprehensive report
        return self._generate_comprehensive_report(state)
