"""
Incident Classifier Agent - Categorize and classify security incidents.
"""

import logging
from typing import Dict, Any
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm
from state import IncidentStatus

logger = logging.getLogger(__name__)


class IncidentClassifierAgent:
    """
    Agent responsible for incident classification and categorization.

    Classifies security incidents according to standard taxonomies
    and identifies similar historical incidents.
    """

    def __init__(self):
        """Initialize the incident classifier agent."""
        self.llm = get_llm(task_type="classification")
        self.parser = JsonOutputParser()
        logger.info("Incident Classifier Agent initialized")

    def classify(
        self,
        threat_input: str,
        threat_type: str,
        threat_level: str,
        indicators: list
    ) -> Dict[str, Any]:
        """
        Classify the security incident.

        Args:
            threat_input: Original threat description
            threat_type: Identified threat type
            threat_level: Threat severity
            indicators: Threat indicators

        Returns:
            Classification results
        """
        logger.debug(f"Classifying incident: {threat_type}")

        system_prompt = """You are an expert security incident classifier.

Classify security incidents using standard taxonomies and determine:
1. Incident Category (according to NIST categories)
2. Sub-category for detailed classification
3. Incident Severity (matches or refines threat level)
4. Attack Vector (how the attack was delivered)
5. Target Type (what was targeted)
6. Impact Scope (localized, widespread, critical infrastructure)
7. Similar Incident Patterns (references to known incident types)

Standard NIST Categories:
- Unauthorized Access
- Denial of Service
- Malicious Code
- Improper Usage
- Scans/Probes/Attempted Access
- Investigation

Return ONLY valid JSON:
{
    "category": "string (NIST category)",
    "sub_category": "string",
    "severity": "critical|high|medium|low",
    "attack_vector": "email|web|network|physical|supply_chain|insider",
    "target_type": "endpoint|server|network|data|application|user",
    "impact_scope": "localized|departmental|organizational|critical_infrastructure",
    "incident_phase": "initial_access|execution|persistence|lateral_movement|exfiltration|impact",
    "similar_patterns": ["string"],
    "classification_confidence": float,
    "requires_reporting": boolean,
    "classification_notes": "string"
}"""

        human_prompt = f"""Threat Input: {threat_input}

Threat Type: {threat_type}
Threat Level: {threat_level}
Indicators Found: {len(indicators)}

Classify this incident."""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=human_prompt)
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Incident classified: {result.get('category')} - {result.get('sub_category')}")

            return result

        except Exception as e:
            logger.error(f"Error in incident classification: {str(e)}")
            return {
                "category": "Investigation",
                "sub_category": "Requires Manual Review",
                "severity": threat_level,
                "attack_vector": "unknown",
                "target_type": "unknown",
                "impact_scope": "localized",
                "incident_phase": "initial_access",
                "similar_patterns": [],
                "classification_confidence": 0.3,
                "requires_reporting": True,
                "classification_notes": f"Classification error: {str(e)}"
            }
