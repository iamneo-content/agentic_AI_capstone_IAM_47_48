"""
Compliance Checker Agent - Assess regulatory compliance requirements.
"""

import logging
from typing import Dict, Any, List
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from services.llm_service import get_llm
from state import ComplianceFramework

logger = logging.getLogger(__name__)


class ComplianceCheckerAgent:
    """
    Agent responsible for compliance checking and regulatory assessment.

    Evaluates incidents against compliance frameworks (NIST, ISO 27001,
    GDPR, HIPAA, PCI DSS) and identifies reporting obligations.
    """

    def __init__(self):
        """Initialize the compliance checker agent."""
        self.llm = get_llm(task_type="analysis")
        self.parser = JsonOutputParser()
        logger.info("Compliance Checker Agent initialized")

    def check_compliance(
        self,
        threat_type: str,
        incident_category: str,
        affected_systems: List[str],
        data_exfiltration: Dict[str, Any],
        threat_level: str
    ) -> Dict[str, Any]:
        """
        Check compliance requirements and obligations.

        Args:
            threat_type: Type of threat
            incident_category: Incident classification
            affected_systems: Impacted systems
            data_exfiltration: Data breach information
            threat_level: Severity level

        Returns:
            Compliance assessment results
        """
        logger.debug("Checking compliance requirements")

        system_prompt = """You are an expert compliance and regulatory specialist.

Assess security incidents against major compliance frameworks:
- NIST Cybersecurity Framework
- ISO 27001/27002
- GDPR (Data Protection)
- HIPAA (Healthcare)
- PCI DSS (Payment Card)
- SOX (Financial)

Determine:
1. Applicable Frameworks
2. Compliance Violations (if any)
3. Reporting Requirements
4. Notification Obligations (customers, regulators, law enforcement)
5. Timeline for Reporting
6. Documentation Requirements

Return ONLY valid JSON:
{
    "applicable_frameworks": ["nist_csf", "iso_27001", "gdpr", "hipaa", "pci_dss", "sox"],
    "compliance_status": {
        "overall": "compliant|partial|non_compliant|under_review",
        "by_framework": {
            "framework_name": {
                "status": "compliant|violated",
                "violations": ["string"],
                "controls_affected": ["string"]
            }
        }
    },
    "reporting_required": boolean,
    "reporting_obligations": [
        {
            "authority": "string (e.g., 'Data Protection Authority', 'Law Enforcement')",
            "framework": "string",
            "deadline": "string (e.g., '72 hours', '30 days')",
            "trigger": "string (what triggered this requirement)",
            "mandatory": boolean
        }
    ],
    "customer_notification_required": boolean,
    "notification_timeline": "string or null",
    "documentation_requirements": ["string"],
    "legal_review_recommended": boolean,
    "compliance_risk_level": "critical|high|medium|low",
    "remediation_for_compliance": ["string"]
}"""

        data_breach = data_exfiltration.get('occurred', False)
        data_types = data_exfiltration.get('data_types', [])

        human_prompt = f"""Incident Compliance Assessment:

Threat Type: {threat_type}
Incident Category: {incident_category}
Threat Level: {threat_level}

Affected Systems: {', '.join(affected_systems[:5])}
Data Breach Occurred: {data_breach}
Data Types Affected: {', '.join(data_types) if data_types else 'None identified'}

Assess compliance obligations."""

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=human_prompt)
        ]

        try:
            response = self.llm.invoke(messages)
            result = self.parser.parse(response.content)

            logger.info(f"Compliance check complete: {result.get('compliance_status', {}).get('overall')}")

            return result

        except Exception as e:
            logger.error(f"Error in compliance checking: {str(e)}")
            return {
                "applicable_frameworks": ["nist_csf"],
                "compliance_status": {
                    "overall": "under_review",
                    "by_framework": {}
                },
                "reporting_required": True,
                "reporting_obligations": [],
                "customer_notification_required": False,
                "notification_timeline": None,
                "documentation_requirements": ["Incident report", "Remediation documentation"],
                "legal_review_recommended": True,
                "compliance_risk_level": "high",
                "remediation_for_compliance": ["Complete compliance assessment manually"]
            }
