"""
Main CLI Interface for Threat Intelligence Platform
--------------------------------------------------

Interactive command-line interface for advanced multi-agent
cybersecurity threat analysis with human-in-the-loop support.
"""

import os
import sys
import logging
import uuid
from typing import Optional
from dotenv import load_dotenv

from state import create_initial_state, ThreatIntelligenceState
from graph import get_graph

# -------------------------------------------------------------------
# Color support (optional)
# -------------------------------------------------------------------
try:
    from colorama import init, Fore, Style, Back
    init(autoreset=True)
    COLORS_AVAILABLE = True
except ImportError:
    COLORS_AVAILABLE = False

    class DummyColor:
        def __getattr__(self, name):
            return ""

    Fore = Style = Back = DummyColor()

# -------------------------------------------------------------------
# Logging configuration
# -------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("threat_intelligence.log"),
        logging.StreamHandler(),
    ],
)

logger = logging.getLogger(__name__)


class ThreatIntelligenceCLI:
    """
    Interactive CLI for the Threat Intelligence Platform.
    """

    def __init__(self):
        load_dotenv()

        if not os.getenv("GOOGLE_API_KEY"):
            print(f"{Fore.RED}Error: GOOGLE_API_KEY not found in environment{Style.RESET_ALL}")
            print("Please create a .env file with your Google API key")
            sys.exit(1)

        self.graph = get_graph(use_checkpointer=True)
        self.current_session_id: Optional[str] = None

        logger.info("Threat Intelligence Platform CLI initialized")

    # ------------------------------------------------------------------
    # UI helpers
    # ------------------------------------------------------------------
    def print_header(self):
        print(
            f"""
{Fore.CYAN}{'=' * 80}
{Fore.CYAN}{Style.BRIGHT}THREAT INTELLIGENCE PLATFORM - Advanced Security Analysis{Style.RESET_ALL}
{Fore.CYAN}{'=' * 80}

{Fore.GREEN}Features:{Style.RESET_ALL}
  - Automated threat detection and classification
  - Vulnerability assessment and risk scoring
  - Forensic investigation and root cause analysis
  - Threat intelligence enrichment
  - Incident response coordination
  - Compliance checks and remediation planning
  - Human analyst escalation and review

{Fore.YELLOW}Commands:{Style.RESET_ALL}
  - Describe a threat or paste an alert
  - new       → start a new analysis
  - help      → show this screen
  - examples  → show example threats
  - exit/quit → exit the platform

{Fore.CYAN}{'-' * 80}
"""
        )

    def print_examples(self):
        print(
            f"""
{Fore.CYAN}{'=' * 80}
{Fore.CYAN}Example Threat Scenarios{Style.RESET_ALL}
{Fore.CYAN}{'=' * 80}

{Fore.YELLOW}1. Ransomware Attack{Style.RESET_ALL}
"Multiple servers showing encrypted files with .locked extension.
Ransom note demanding 50 BTC."

{Fore.YELLOW}2. Phishing Campaign{Style.RESET_ALL}
"Employees receiving suspicious emails with malicious links."

{Fore.YELLOW}3. Data Breach{Style.RESET_ALL}
"Unusual outbound traffic to IP 192.168.100.50.
Customer data exfiltration detected."

{Fore.YELLOW}4. APT Intrusion{Style.RESET_ALL}
"Lateral movement detected. Unknown processes creating scheduled tasks."

{Fore.CYAN}{'-' * 80}
"""
        )

    def print_node_activity(self, node: str):
        icons = {
            "plan": "[PLAN]",
            "detect": "[DETECT]",
            "scan_vulnerabilities": "[VULN]",
            "analyze_risk": "[RISK]",
            "classify": "[CLASS]",
            "investigate": "[FORENSIC]",
            "enrich_intel": "[INTEL]",
            "coordinate_response": "[RESPONSE]",
            "check_compliance": "[COMPLY]",
            "plan_remediation": "[REMEDY]",
            "generate_report": "[REPORT]",
            "analyst_review": "[ANALYST]",
        }

        icon = icons.get(node, "[PROC]")
        print(f"{Fore.BLUE}{icon} {node.replace('_', ' ').title()}...{Style.RESET_ALL}")

    def print_progress(self, state: ThreatIntelligenceState):
        current_node = state.get("current_node")

        if not current_node:
            return

        self.print_node_activity(current_node)

        if current_node == "detect":
            if state.get("threat_type"):
                level = state.get("threat_level", "Unknown")
                if hasattr(level, "value"):
                    level = level.value
                print(f"  {Fore.YELLOW}Threat Type:{Style.RESET_ALL} {state['threat_type']}")
                print(f"  {Fore.YELLOW}Severity:{Style.RESET_ALL} {level}")
                print(
                    f"  {Fore.YELLOW}Confidence:{Style.RESET_ALL} "
                    f"{state.get('threat_confidence', 0) * 100:.0f}%"
                )

        elif current_node == "analyze_risk":
            if state.get("risk_score") is not None:
                print(f"  {Fore.YELLOW}Risk Score:{Style.RESET_ALL} {state['risk_score']}/10.0")
                print(
                    f"  {Fore.YELLOW}Likelihood:{Style.RESET_ALL} "
                    f"{state.get('likelihood_score', 0):.2f}"
                )

        elif current_node == "investigate":
            if state.get("root_cause"):
                print(
                    f"  {Fore.YELLOW}Root Cause:{Style.RESET_ALL} "
                    f"{state['root_cause'][:80]}..."
                )

        elif current_node == "enrich_intel":
            actors = state.get("known_threat_actors", [])
            if actors:
                print(f"  {Fore.YELLOW}Threat Actor:{Style.RESET_ALL} {actors[0]}")

    def print_final_report(self, report: str):
        print(f"\n{Fore.GREEN}{Style.BRIGHT}{'=' * 80}{Style.RESET_ALL}")
        print(f"{Fore.GREEN}{Style.BRIGHT}SECURITY ANALYSIS COMPLETE{Style.RESET_ALL}")
        print(f"{Fore.GREEN}{Style.BRIGHT}{'=' * 80}{Style.RESET_ALL}\n")
        print(report)

    # ------------------------------------------------------------------
    # Workflow execution
    # ------------------------------------------------------------------
    def process_threat(self, threat_input: str):
        if not self.current_session_id:
            self.current_session_id = f"session_{uuid.uuid4().hex[:8]}"
            logger.info(f"New session created: {self.current_session_id}")

        initial_state = create_initial_state(
            threat_input=threat_input,
            session_id=self.current_session_id,
            processing_mode="sequential",
        )

        config = {"configurable": {"thread_id": self.current_session_id}}

        try:
            print(f"\n{Fore.CYAN}{'-' * 80}")
            print(f"{Fore.YELLOW}Initiating Security Analysis...")
            print(f"{Fore.CYAN}{'-' * 80}{Style.RESET_ALL}\n")

            for event in self.graph.stream(initial_state, config, stream_mode="values"):
                self.print_progress(event)

            state = self.graph.get_state(config)

            if state.next and "analyst_review" in state.next:
                self._handle_analyst_review(config)
                state = self.graph.get_state(config)

            if state.values.get("final_report"):
                self.print_final_report(state.values["final_report"])
            else:
                print(f"{Fore.YELLOW}Analysis completed but no report generated{Style.RESET_ALL}")
                logger.warning("No final report found in final state")

        except Exception as exc:
            logger.error("Error during threat processing", exc_info=True)
            print(f"{Fore.RED}[ERROR] {exc}{Style.RESET_ALL}")

    def _handle_analyst_review(self, config: dict):
        state = self.graph.get_state(config)
        data = state.values

        print(f"\n{Fore.YELLOW}{'=' * 80}")
        print(f"{Fore.YELLOW}{Style.BRIGHT}HUMAN ANALYST REVIEW REQUIRED{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}{'=' * 80}{Style.RESET_ALL}\n")

        print(f"{Fore.CYAN}Escalation Reason:{Style.RESET_ALL}")
        print(f"  {data.get('escalation_reason', 'Manual review requested')}\n")

        level = data.get("threat_level", "Unknown")
        if hasattr(level, "value"):
            level = level.value

        print(f"{Fore.CYAN}Threat Summary:{Style.RESET_ALL}")
        print(f"  Type: {data.get('threat_type', 'Unknown')}")
        print(f"  Level: {level}")
        print(f"  Risk Score: {data.get('risk_score', 'N/A')}/10.0\n")

        feedback = input(f"{Fore.CYAN}Analyst>{Style.RESET_ALL} ").strip()
        if not feedback or feedback.lower() in {"skip", "continue"}:
            feedback = "Analyst reviewed - continue with automated analysis"

        self.graph.update_state(config, {"analyst_feedback": feedback})

        print(f"\n{Fore.YELLOW}Processing analyst feedback...{Style.RESET_ALL}\n")

        for event in self.graph.stream(None, config, stream_mode="values"):
            self.print_progress(event)

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------
    def run(self):
        self.print_header()

        while True:
            try:
                user_input = input(f"\n{Fore.GREEN}Threat>{Style.RESET_ALL} ").strip()
                if not user_input:
                    continue

                cmd = user_input.lower()

                if cmd in {"exit", "quit"}:
                    print(f"\n{Fore.CYAN}Exiting platform. Stay secure!{Style.RESET_ALL}\n")
                    break
                elif cmd == "new":
                    self.current_session_id = None
                    print(f"{Fore.GREEN}✓ New analysis session started{Style.RESET_ALL}")
                elif cmd == "help":
                    self.print_header()
                elif cmd == "examples":
                    self.print_examples()
                else:
                    self.process_threat(user_input)

            except KeyboardInterrupt:
                print(f"\n{Fore.YELLOW}Session interrupted{Style.RESET_ALL}")
                break
            except EOFError:
                break


def main():
    try:
        cli = ThreatIntelligenceCLI()
        cli.run()
    except KeyboardInterrupt:
        print("\nSession terminated. Goodbye!")
        sys.exit(0)
    except Exception:
        logger.error("Fatal error", exc_info=True)
        print("Fatal error occurred. Check logs.")
        sys.exit(1)


if __name__ == "__main__":
    main()
