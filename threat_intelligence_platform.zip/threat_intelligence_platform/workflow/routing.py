"""
Routing logic for threat intelligence workflow.

Determines conditional paths through the graph based on
threat severity, escalation needs, and analysis results.
"""

import logging
from typing import Literal
from state import ThreatIntelligenceState

logger = logging.getLogger(__name__)


def should_escalate_after_detection(
    state: ThreatIntelligenceState
) -> Literal["continue", "escalate"]:
    """
    Determine if escalation needed after initial detection.

    Args:
        state: Current state

    Returns:
        "continue" to proceed with analysis or "escalate" for immediate human review
    """
    # Check if immediate escalation flagged
    if state.get("requires_escalation"):
        logger.info(f"Escalation required: {state.get('escalation_reason')}")
        return "escalate"

    # Check for critical threat level with high confidence
    threat_level = state.get("threat_level", "medium")
    confidence = state.get("threat_confidence", 0.0)

    # Convert enum to string if needed
    threat_level_str = threat_level.value if hasattr(threat_level, 'value') else str(threat_level)

    # Only escalate for critical threats with very high confidence (>0.9)
    # This allows most threats to go through analysis first
    if threat_level_str == "critical" and confidence > 0.9:
        logger.info("Critical threat with very high confidence - escalating for early analyst review")
        state["requires_escalation"] = True
        state["escalation_reason"] = "Critical threat requires immediate analyst review"
        return "escalate"

    # Check for detection errors
    if state.get("error"):
        logger.warning(f"Error detected: {state.get('error')}")
        # Don't escalate on errors, continue with analysis
        # but log for review

    return "continue"


def should_escalate_after_response(
    state: ThreatIntelligenceState
) -> Literal["continue", "escalate"]:
    """
    Determine if escalation needed after response planning.

    Args:
        state: Current state

    Returns:
        "continue" for automated handling or "escalate" for human oversight
    """
    # Check if response plan requires escalation
    response_plan = state.get("response_plan", {})

    if response_plan.get("escalation_needed"):
        logger.info(f"Response escalation: {response_plan.get('escalation_reason')}")
        state["requires_escalation"] = True
        state["escalation_reason"] = response_plan.get(
            "escalation_reason",
            "Response plan requires human oversight"
        )
        return "escalate"

    # Check for very high risk scores
    risk_score = state.get("risk_score", 0.0)
    # Handle None risk_score defensively
    if risk_score is None:
        risk_score = 0.0
    if risk_score >= 9.0:
        logger.info(f"High risk score ({risk_score}) - escalating")
        state["requires_escalation"] = True
        state["escalation_reason"] = f"Risk score of {risk_score}/10.0 requires human review"
        return "escalate"

    # Check if there are critical manual actions
    manual_actions = response_plan.get("manual_actions_required", [])
    if len(manual_actions) > 5:
        logger.info(f"{len(manual_actions)} manual actions required - escalating")
        state["requires_escalation"] = True
        state["escalation_reason"] = "Extensive manual intervention required"
        return "escalate"

    return "continue"


def route_to_final(
    state: ThreatIntelligenceState
) -> Literal["report", "escalate"]:
    """
    Final routing decision after all analysis.

    Args:
        state: Current state

    Returns:
        "report" to generate final report or "escalate" for human review
    """
    # If escalation still flagged, route to analyst
    if state.get("requires_escalation"):
        logger.info("Final escalation to human analyst")
        return "escalate"

    # Otherwise, generate final report
    logger.info("Proceeding to final report generation")
    return "report"


def determine_processing_priority(state: ThreatIntelligenceState) -> str:
    """
    Determine processing priority for workflow optimization.

    Args:
        state: Current state

    Returns:
        Priority level: "critical", "high", "normal"
    """
    threat_level = state.get("threat_level", "medium")
    risk_score = state.get("risk_score", 0.0)

    if threat_level == "critical" or risk_score >= 9.0:
        return "critical"
    elif threat_level == "high" or risk_score >= 7.0:
        return "high"
    else:
        return "normal"
