"""Workflow routing and orchestration logic."""

from .routing import (
    should_escalate_after_detection,
    should_escalate_after_response,
    route_to_final
)

__all__ = [
    'should_escalate_after_detection',
    'should_escalate_after_response',
    'route_to_final'
]
