"""Utility functions for threat intelligence platform."""
