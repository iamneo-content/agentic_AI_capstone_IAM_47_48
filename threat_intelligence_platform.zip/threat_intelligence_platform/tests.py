"""
Comprehensive test suite for Threat Intelligence Platform.

Tests cover: state, agents, nodes, workflow, graph, and main components.
Total: 15 test cases
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime

# Import components to test
from state import (
    create_initial_state,
    ThreatIntelligenceState,
    ThreatLevel,
    IncidentStatus,
    update_timeline
)
from graph import create_threat_intelligence_graph, get_graph
from workflow.routing import (
    should_escalate_after_detection,
    should_escalate_after_response,
    route_to_final
)


# ============================================================================
# STATE TESTS (3 tests)
# ============================================================================

def test_create_initial_state():
    """Test 1: Verify initial state creation with correct defaults."""
    threat_input = "Test ransomware attack"
    session_id = "test_session_001"

    state = create_initial_state(
        threat_input=threat_input,
        session_id=session_id,
        processing_mode="sequential"
    )

    # Verify basic fields
    assert state["threat_input"] == threat_input
    assert state["session_id"] == session_id
    assert state["processing_mode"] == "sequential"

    # Verify default lists are initialized
    assert isinstance(state["conversation_history"], list)
    assert isinstance(state["recommendations"], list)
    assert isinstance(state["timeline"], list)
    assert isinstance(state["vulnerabilities"], list)

    # Verify default status
    assert state["incident_status"] == IncidentStatus.DETECTED
    assert state["requires_escalation"] is False


def test_threat_level_enum():
    """Test 2: Verify ThreatLevel enum values."""
    assert ThreatLevel.CRITICAL.value == "critical"
    assert ThreatLevel.HIGH.value == "high"
    assert ThreatLevel.MEDIUM.value == "medium"
    assert ThreatLevel.LOW.value == "low"
    assert ThreatLevel.INFO.value == "info"


def test_update_timeline():
    """Test 3: Verify timeline updates work correctly."""
    state = create_initial_state("test threat", "session_001")

    # Initial state already has one timeline entry, so check the added one
    initial_count = len(state["timeline"])
    update_timeline(state, "Test Event", "Test event description")

    assert len(state["timeline"]) == initial_count + 1
    latest_event = state["timeline"][-1]
    assert latest_event["event"] == "Test Event"
    assert latest_event["description"] == "Test event description"
    assert "timestamp" in latest_event


# ============================================================================
# AGENT TESTS (3 tests)
# ============================================================================

def test_threat_detector_agent():
    """Test 4: Verify ThreatDetectorAgent basic functionality."""
    from agents.threat_detector import ThreatDetectorAgent

    # Mock at the agent module level
    with patch('agents.threat_detector.get_llm') as mock_get_llm:
        # Mock LLM response - note severity maps to threat_level
        mock_llm = Mock()
        mock_llm.invoke.return_value = Mock(
            content='{"threat_type": "ransomware", "severity": "critical", "confidence": 0.95, "indicators": []}'
        )
        mock_get_llm.return_value = mock_llm

        agent = ThreatDetectorAgent()
        # Correct method name is 'analyze', not 'detect_threat'
        result = agent.analyze("Ransomware detected on server")

        assert result["threat_type"] == "ransomware"
        # The agent converts severity to threat_level
        assert "threat_level" in result or "severity" in result
        assert result.get("confidence", 0) >= 0.9


@patch('services.risk_scoring_service.RiskScoringService.calculate_risk_score')
def test_risk_analyzer_agent(mock_calculate_risk):
    """Test 5: Verify RiskAnalyzerAgent calculates risk scores."""
    from agents.risk_analyzer import RiskAnalyzerAgent

    # Mock risk scoring service
    mock_calculate_risk.return_value = {
        "risk_score": 8.5,
        "risk_category": "high",
        "likelihood_score": 0.75,
        "business_impact": "High impact",
        "recommendation": "Immediate action required"
    }

    agent = RiskAnalyzerAgent()
    result = agent.analyze_risk(
        threat_type="ransomware",
        threat_level="critical",
        confidence=0.9,
        vulnerabilities=[{"severity": "high"}],
        affected_systems=["server1", "server2"]
    )

    assert result["risk_score"] == 8.5
    assert result["risk_category"] == "high"
    assert result["likelihood_score"] == 0.75


def test_report_generator_agent():
    """Test 6: Verify ReportGeneratorAgent generates reports."""
    from agents.report_generator import ReportGeneratorAgent

    # Mock the _generate_comprehensive_report method directly
    with patch.object(ReportGeneratorAgent, '_generate_comprehensive_report', return_value="# SECURITY INCIDENT REPORT\n\n## Summary\nTest report content"):
        agent = ReportGeneratorAgent()
        state = create_initial_state("test threat", "session_001")
        state["threat_type"] = "ransomware"
        state["risk_score"] = 9.0
        state["threat_level"] = ThreatLevel.CRITICAL
        state["incident_category"] = "Malware"

        report = agent.generate_report(state)

        assert report is not None
        assert len(report) > 50
        assert "REPORT" in report


# ============================================================================
# NODE TESTS (3 tests)
# ============================================================================

def test_detection_node():
    """Test 7: Verify detection_node processes threats correctly."""
    from nodes.detection_node import detection_node

    with patch('nodes.detection_node.ThreatDetectorAgent') as MockAgent:
        # Mock the agent instance and its method
        mock_instance = Mock()
        # Correct method name is 'analyze'
        mock_instance.analyze.return_value = {
            "threat_type": "malware",
            "threat_level": ThreatLevel.HIGH,
            "confidence": 0.85,
            "indicators": ["suspicious_file.exe"]
        }
        MockAgent.return_value = mock_instance

        state = create_initial_state("Malware detected", "session_001")
        result_state = detection_node(state)

        assert result_state["threat_type"] == "malware"
        assert result_state["threat_level"] == ThreatLevel.HIGH
        assert result_state["threat_confidence"] == 0.85
        assert result_state["current_node"] == "detection"


@patch('agents.risk_analyzer.RiskAnalyzerAgent.analyze_risk')
def test_risk_analysis_node(mock_analyze):
    """Test 8: Verify risk_analysis_node calculates risk correctly."""
    from nodes.risk_analysis_node import risk_analysis_node

    # Mock risk analysis
    mock_analyze.return_value = {
        "risk_score": 7.5,
        "risk_factors": {"critical_systems": True},
        "business_impact": "High impact",
        "likelihood_score": 0.8,
        "recommendation": "Urgent action needed"
    }

    state = create_initial_state("test threat", "session_001")
    state["threat_type"] = "ransomware"
    state["threat_level"] = ThreatLevel.HIGH

    result_state = risk_analysis_node(state)

    assert result_state["risk_score"] == 7.5
    assert result_state["current_node"] == "risk_analysis"
    assert "Urgent action needed" in result_state["recommendations"]


def test_risk_analysis_node_error_handling():
    """Test 9: Verify risk_analysis_node handles errors gracefully."""
    from nodes.risk_analysis_node import risk_analysis_node

    with patch('agents.risk_analyzer.RiskAnalyzerAgent.analyze_risk', side_effect=Exception("Test error")):
        state = create_initial_state("test threat", "session_001")
        result_state = risk_analysis_node(state)

        # Should set default values on error
        assert result_state["risk_score"] == 5.0  # Default medium risk
        assert "error" in result_state
        assert result_state["likelihood_score"] == 0.5


# ============================================================================
# WORKFLOW/ROUTING TESTS (3 tests)
# ============================================================================

def test_should_escalate_after_detection_critical():
    """Test 10: Verify escalation triggers for critical threats."""
    state = create_initial_state("test threat", "session_001")
    state["threat_level"] = ThreatLevel.CRITICAL
    state["threat_confidence"] = 0.95

    result = should_escalate_after_detection(state)

    assert result == "escalate"
    assert state["requires_escalation"] is True


def test_should_escalate_after_detection_continue():
    """Test 11: Verify workflow continues for low threats."""
    state = create_initial_state("test threat", "session_001")
    state["threat_level"] = ThreatLevel.LOW
    state["threat_confidence"] = 0.5

    result = should_escalate_after_detection(state)

    assert result == "continue"


def test_route_to_final_with_escalation():
    """Test 12: Verify final routing handles escalation flag."""
    state = create_initial_state("test threat", "session_001")

    # Test with escalation required
    state["requires_escalation"] = True
    result = route_to_final(state)
    assert result == "escalate"

    # Test without escalation
    state["requires_escalation"] = False
    result = route_to_final(state)
    assert result == "report"


# ============================================================================
# GRAPH TESTS (2 tests)
# ============================================================================

def test_create_threat_intelligence_graph():
    """Test 13: Verify graph creation without errors."""
    graph = create_threat_intelligence_graph(use_checkpointer=False)

    assert graph is not None

    # Verify graph has nodes by checking the compiled graph structure
    graph_dict = graph.get_graph()
    assert len(graph_dict.nodes) > 10  # Should have all our nodes


def test_get_graph_singleton():
    """Test 14: Verify graph singleton pattern works."""
    graph1 = get_graph(use_checkpointer=False)
    graph2 = get_graph(use_checkpointer=False)

    # Should return the same instance
    assert graph1 is graph2

    # Force recreate should return new instance
    graph3 = get_graph(use_checkpointer=False, force_recreate=True)
    assert graph3 is not graph1


# ============================================================================
# INTEGRATION TEST (1 test)
# ============================================================================

def test_full_workflow_low_severity():
    """Test 15: Integration test - verify graph structure is valid."""
    # This test verifies the graph is properly constructed
    # without actually running it (to avoid API calls)

    graph = create_threat_intelligence_graph(use_checkpointer=False)

    # Verify graph structure
    assert graph is not None

    graph_dict = graph.get_graph()

    # Verify key nodes exist
    node_names = [node.id for node in graph_dict.nodes.values()]

    expected_nodes = [
        "plan",
        "detect",
        "scan_vulnerabilities",
        "analyze_risk",
        "classify",
        "investigate",
        "enrich_intel",
        "coordinate_response",
        "check_compliance",
        "plan_remediation",
        "generate_report",
        "analyst_review"
    ]

    for expected_node in expected_nodes:
        assert expected_node in node_names, f"Missing node: {expected_node}"

    # Verify there are connections between nodes (edges)
    assert len(graph_dict.edges) > 0


# ============================================================================
# PYTEST FIXTURES AND CONFIGURATION
# ============================================================================

@pytest.fixture
def sample_state():
    """Fixture: Provide a sample state for tests."""
    return create_initial_state(
        threat_input="Test threat for unit testing",
        session_id="test_session_fixture",
        processing_mode="sequential"
    )


@pytest.fixture
def mock_llm_service():
    """Fixture: Mock LLM service for tests."""
    with patch('services.llm_service.get_llm') as mock:
        mock_llm = Mock()
        mock_llm.invoke.return_value = Mock(content='{"status": "success"}')
        mock.return_value = mock_llm
        yield mock


if __name__ == "__main__":
    # Allow running pytest from command line
    pytest.main([__file__, "-v", "--tb=short"])
