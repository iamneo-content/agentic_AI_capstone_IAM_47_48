"""
Risk Scoring Service for calculating threat risk scores.

Implements CVSS-like scoring and custom risk assessment algorithms.
"""

import logging
from typing import Dict, List, Any, Optional
from enum import Enum

logger = logging.getLogger(__name__)


class RiskCategory(str, Enum):
    """Risk categories for threats."""
    CRITICAL = "critical"  # 9.0 - 10.0
    HIGH = "high"         # 7.0 - 8.9
    MEDIUM = "medium"     # 4.0 - 6.9
    LOW = "low"           # 0.1 - 3.9
    NONE = "none"         # 0.0


class RiskScoringService:
    """
    Service for calculating comprehensive risk scores.

    Uses a multi-factor approach combining:
    - Threat severity
    - Asset value
    - Vulnerability exploitability
    - Business impact
    - Likelihood of exploitation
    """

    def __init__(self):
        """Initialize risk scoring service."""
        logger.info("Risk Scoring Service initialized")

        # Asset value weights
        self.asset_values = {
            "critical_infrastructure": 1.0,
            "production_server": 0.9,
            "database": 0.95,
            "user_endpoint": 0.5,
            "development": 0.3,
            "unknown": 0.5
        }

        # Threat type base scores
        self.threat_base_scores = {
            "ransomware": 9.5,
            "data_breach": 9.0,
            "apt": 8.5,
            "malware": 7.5,
            "phishing": 6.5,
            "ddos": 6.0,
            "intrusion_attempt": 5.5,
            "policy_violation": 3.0,
            "unknown": 5.0
        }

    def calculate_risk_score(
        self,
        threat_type: str,
        affected_systems: List[str],
        vulnerabilities: List[Dict[str, Any]],
        threat_level: str,
        confidence: float = 0.8
    ) -> Dict[str, Any]:
        """
        Calculate comprehensive risk score.

        Args:
            threat_type: Type of threat
            affected_systems: List of impacted systems
            vulnerabilities: Identified vulnerabilities
            threat_level: Threat severity level
            confidence: Detection confidence

        Returns:
            Risk scoring results with detailed breakdown
        """
        logger.debug(f"Calculating risk score for {threat_type}")

        # 1. Base threat score
        base_score = self.threat_base_scores.get(
            threat_type.lower(),
            self.threat_base_scores["unknown"]
        )

        # 2. Asset impact multiplier
        asset_multiplier = self._calculate_asset_impact(affected_systems)

        # 3. Vulnerability score
        vuln_score = self._calculate_vulnerability_score(vulnerabilities)

        # 4. Threat level adjustment
        level_adjustment = self._get_level_adjustment(threat_level)

        # 5. Calculate final score
        raw_score = (
            (base_score * 0.4) +          # Base threat weight
            (asset_multiplier * 10 * 0.3) + # Asset impact weight
            (vuln_score * 0.2) +           # Vulnerability weight
            (level_adjustment * 0.1)       # Level adjustment weight
        )

        # Apply confidence factor
        final_score = raw_score * confidence

        # Cap at 10.0
        final_score = min(10.0, max(0.0, final_score))

        # Determine risk category
        risk_category = self._get_risk_category(final_score)

        # Calculate likelihood of exploitation
        likelihood = self._calculate_likelihood(
            threat_type,
            vulnerabilities,
            confidence
        )

        # Business impact assessment
        business_impact = self._assess_business_impact(
            final_score,
            affected_systems,
            threat_type
        )

        return {
            "risk_score": round(final_score, 2),
            "risk_category": risk_category,
            "likelihood_score": round(likelihood, 2),
            "business_impact": business_impact,
            "breakdown": {
                "base_score": round(base_score, 2),
                "asset_impact": round(asset_multiplier, 2),
                "vulnerability_score": round(vuln_score, 2),
                "level_adjustment": round(level_adjustment, 2),
                "confidence_factor": round(confidence, 2)
            },
            "affected_assets_count": len(affected_systems),
            "vulnerability_count": len(vulnerabilities),
            "recommendation": self._get_recommendation(risk_category)
        }

    def _calculate_asset_impact(self, affected_systems: List[str]) -> float:
        """Calculate impact based on affected assets."""
        if not affected_systems:
            return 0.5

        total_value = 0.0
        for system in affected_systems:
            # Try to determine asset type from system name
            system_lower = system.lower()
            for asset_type, value in self.asset_values.items():
                if asset_type.replace("_", "") in system_lower.replace("_", "").replace("-", ""):
                    total_value += value
                    break
            else:
                total_value += self.asset_values["unknown"]

        # Average value with bonus for multiple systems
        avg_value = total_value / len(affected_systems)
        multi_system_bonus = min(0.2, len(affected_systems) * 0.05)

        return min(1.0, avg_value + multi_system_bonus)

    def _calculate_vulnerability_score(self, vulnerabilities: List[Dict[str, Any]]) -> float:
        """Calculate score based on vulnerabilities."""
        if not vulnerabilities:
            return 5.0  # Default moderate score

        scores = []
        for vuln in vulnerabilities:
            # Try to extract CVSS score or estimate
            cvss = vuln.get("cvss_score") or vuln.get("severity_score") or 5.0
            if isinstance(cvss, str):
                # Parse severity strings
                severity_map = {
                    "critical": 9.5,
                    "high": 8.0,
                    "medium": 5.5,
                    "low": 3.0
                }
                cvss = severity_map.get(cvss.lower(), 5.0)
            # Ensure cvss is not None before converting to float
            if cvss is None:
                cvss = 5.0
            scores.append(float(cvss))

        # Use highest vulnerability score
        return max(scores) if scores else 5.0

    def _get_level_adjustment(self, threat_level: str) -> float:
        """Get adjustment factor based on threat level."""
        adjustments = {
            "critical": 10.0,
            "high": 8.0,
            "medium": 5.0,
            "low": 3.0,
            "info": 1.0
        }
        return adjustments.get(threat_level.lower(), 5.0)

    def _get_risk_category(self, score: float) -> RiskCategory:
        """Determine risk category from score."""
        if score >= 9.0:
            return RiskCategory.CRITICAL
        elif score >= 7.0:
            return RiskCategory.HIGH
        elif score >= 4.0:
            return RiskCategory.MEDIUM
        elif score > 0.0:
            return RiskCategory.LOW
        else:
            return RiskCategory.NONE

    def _calculate_likelihood(
        self,
        threat_type: str,
        vulnerabilities: List[Dict[str, Any]],
        confidence: float
    ) -> float:
        """Calculate likelihood of successful exploitation."""
        # Base likelihood by threat type
        base_likelihood = {
            "ransomware": 0.8,
            "phishing": 0.7,
            "malware": 0.75,
            "intrusion_attempt": 0.6,
            "ddos": 0.85,
            "data_breach": 0.7,
            "apt": 0.65
        }.get(threat_type.lower(), 0.5)

        # Adjust based on vulnerabilities
        if vulnerabilities:
            # More vulnerabilities = higher likelihood
            vuln_factor = min(0.3, len(vulnerabilities) * 0.1)
            base_likelihood += vuln_factor

        # Apply confidence
        final_likelihood = base_likelihood * confidence

        return min(1.0, max(0.0, final_likelihood))

    def _assess_business_impact(
        self,
        risk_score: float,
        affected_systems: List[str],
        threat_type: str
    ) -> str:
        """Assess potential business impact."""
        if risk_score >= 9.0:
            return "Severe - Critical business operations at risk, potential data loss, regulatory violations, and significant financial impact"
        elif risk_score >= 7.0:
            return "High - Major disruption to business operations, potential data compromise, and financial losses"
        elif risk_score >= 4.0:
            return "Moderate - Limited business impact, possible service degradation, minimal data exposure"
        else:
            return "Low - Minimal business impact, no significant operational disruption expected"

    def _get_recommendation(self, risk_category: RiskCategory) -> str:
        """Get action recommendation based on risk category."""
        recommendations = {
            RiskCategory.CRITICAL: "IMMEDIATE ACTION REQUIRED - Isolate affected systems, engage incident response team, notify leadership",
            RiskCategory.HIGH: "URGENT - Implement containment measures, begin investigation, prepare incident response",
            RiskCategory.MEDIUM: "TIMELY RESPONSE - Investigate within 24 hours, implement mitigation controls",
            RiskCategory.LOW: "ROUTINE - Monitor and investigate as part of normal operations",
            RiskCategory.NONE: "NO ACTION - Continue monitoring"
        }
        return recommendations.get(risk_category, "INVESTIGATE")


# Singleton instance
_risk_scoring_service = None


def get_risk_scoring_service() -> RiskScoringService:
    """Get or create the risk scoring service singleton."""
    global _risk_scoring_service
    if _risk_scoring_service is None:
        _risk_scoring_service = RiskScoringService()
    return _risk_scoring_service
