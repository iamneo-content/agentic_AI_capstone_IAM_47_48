"""
Threat Intelligence Service for external threat data lookup.

This service integrates with threat intelligence feeds and databases
to enrich threat analysis with known indicators and actor information.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class ThreatIntelligenceService:
    """
    Service for querying threat intelligence databases.

    In production, this would integrate with:
    - VirusTotal API
    - AlienVault OTX
    - MITRE ATT&CK
    - Abuse.ch feeds
    - Commercial threat intel feeds
    """

    def __init__(self):
        """Initialize threat intelligence service."""
        self.cache = {}
        self.cache_ttl = timedelta(hours=1)
        logger.info("Threat Intelligence Service initialized")

        # Simulated threat actor database
        self.threat_actors = {
            "apt28": {
                "name": "APT28 (Fancy Bear)",
                "country": "Russia",
                "targets": ["government", "military", "defense"],
                "ttps": ["spearphishing", "credential harvesting", "lateral movement"]
            },
            "apt29": {
                "name": "APT29 (Cozy Bear)",
                "country": "Russia",
                "targets": ["government", "research", "healthcare"],
                "ttps": ["supply chain compromise", "cloud exploitation"]
            },
            "lazarus": {
                "name": "Lazarus Group",
                "country": "North Korea",
                "targets": ["financial", "cryptocurrency", "defense"],
                "ttps": ["ransomware", "financial fraud", "destructive attacks"]
            },
            "apt41": {
                "name": "APT41 (Double Dragon)",
                "country": "China",
                "targets": ["healthcare", "telecommunications", "technology"],
                "ttps": ["supply chain attacks", "ransomware", "espionage"]
            }
        }

        # Common malware families
        self.malware_families = {
            "emotet": {
                "type": "trojan",
                "severity": "high",
                "capabilities": ["botnet", "spam", "credential theft"],
                "iocs": ["malicious macros", "powershell execution"]
            },
            "trickbot": {
                "type": "banking trojan",
                "severity": "high",
                "capabilities": ["credential theft", "ransomware delivery"],
                "iocs": ["lateral movement", "admin share access"]
            },
            "ryuk": {
                "type": "ransomware",
                "severity": "critical",
                "capabilities": ["file encryption", "data exfiltration"],
                "iocs": ["scheduled tasks", "service manipulation"]
            },
            "cobalt_strike": {
                "type": "post-exploitation",
                "severity": "critical",
                "capabilities": ["c2 communication", "lateral movement"],
                "iocs": ["beacon activity", "named pipes"]
            }
        }

    def lookup_ioc(self, ioc: str, ioc_type: str) -> Dict[str, Any]:
        """
        Look up an Indicator of Compromise.

        Args:
            ioc: The indicator value (IP, domain, hash, etc.)
            ioc_type: Type of indicator (ip, domain, hash, url)

        Returns:
            Threat intelligence data for the IoC
        """
        logger.debug(f"Looking up IoC: {ioc} (type: {ioc_type})")

        # Simulated threat intelligence lookup
        result = {
            "ioc": ioc,
            "type": ioc_type,
            "found": False,
            "reputation": "unknown",
            "threat_level": "unknown",
            "sources": []
        }

        # Simulate some known malicious indicators
        malicious_patterns = {
            "ip": ["192.168.100", "10.0.0", "suspicious"],
            "domain": ["evil", "malware", "phishing", "bad"],
            "hash": ["deadbeef", "badcode"],
            "url": ["malicious", "exploit"]
        }

        if ioc_type in malicious_patterns:
            for pattern in malicious_patterns[ioc_type]:
                if pattern.lower() in ioc.lower():
                    result.update({
                        "found": True,
                        "reputation": "malicious",
                        "threat_level": "high",
                        "sources": ["threat_feed", "community"],
                        "first_seen": (datetime.now() - timedelta(days=30)).isoformat(),
                        "last_seen": datetime.now().isoformat(),
                        "related_campaigns": ["simulated_campaign"]
                    })
                    break

        return result

    def get_threat_actor_info(self, actor_name: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a known threat actor.

        Args:
            actor_name: Name or identifier of threat actor

        Returns:
            Threat actor information or None
        """
        actor_name_lower = actor_name.lower()
        for key, info in self.threat_actors.items():
            if key in actor_name_lower or actor_name_lower in info["name"].lower():
                return {
                    "id": key,
                    **info,
                    "last_activity": datetime.now().isoformat()
                }
        return None

    def get_malware_info(self, malware_name: str) -> Optional[Dict[str, Any]]:
        """
        Get information about known malware.

        Args:
            malware_name: Name of malware family

        Returns:
            Malware information or None
        """
        malware_name_lower = malware_name.lower()
        for key, info in self.malware_families.items():
            if key in malware_name_lower or malware_name_lower in key:
                return {
                    "family": key,
                    **info,
                    "last_updated": datetime.now().isoformat()
                }
        return None

    def get_mitre_techniques(self, keywords: List[str]) -> List[Dict[str, str]]:
        """
        Map keywords to MITRE ATT&CK techniques.

        Args:
            keywords: List of behavior keywords

        Returns:
            List of relevant MITRE techniques
        """
        # Simulated MITRE ATT&CK mapping
        technique_map = {
            "phishing": [
                {"id": "T1566", "name": "Phishing", "tactic": "Initial Access"},
                {"id": "T1566.001", "name": "Spearphishing Attachment", "tactic": "Initial Access"}
            ],
            "lateral": [
                {"id": "T1021", "name": "Remote Services", "tactic": "Lateral Movement"},
                {"id": "T1570", "name": "Lateral Tool Transfer", "tactic": "Lateral Movement"}
            ],
            "credential": [
                {"id": "T1003", "name": "OS Credential Dumping", "tactic": "Credential Access"},
                {"id": "T1110", "name": "Brute Force", "tactic": "Credential Access"}
            ],
            "ransomware": [
                {"id": "T1486", "name": "Data Encrypted for Impact", "tactic": "Impact"},
                {"id": "T1490", "name": "Inhibit System Recovery", "tactic": "Impact"}
            ],
            "malware": [
                {"id": "T1204", "name": "User Execution", "tactic": "Execution"},
                {"id": "T1059", "name": "Command and Scripting Interpreter", "tactic": "Execution"}
            ]
        }

        techniques = []
        for keyword in keywords:
            keyword_lower = keyword.lower()
            for key, techs in technique_map.items():
                if key in keyword_lower:
                    techniques.extend(techs)

        return techniques

    def correlate_threats(self, indicators: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Correlate multiple indicators to identify campaigns.

        Args:
            indicators: List of threat indicators

        Returns:
            Correlation analysis results
        """
        logger.debug(f"Correlating {len(indicators)} indicators")

        # Simulated correlation
        correlation = {
            "related_indicators": len(indicators),
            "correlation_score": min(0.95, len(indicators) * 0.15),
            "possible_campaigns": [],
            "threat_actors": [],
            "confidence": "medium"
        }

        # If multiple indicators, suggest possible campaign
        if len(indicators) >= 3:
            correlation["possible_campaigns"].append("coordinated_attack_2024")
            correlation["confidence"] = "high"

        return correlation


# Singleton instance
_threat_intel_service = None


def get_threat_intel_service() -> ThreatIntelligenceService:
    """Get or create the threat intelligence service singleton."""
    global _threat_intel_service
    if _threat_intel_service is None:
        _threat_intel_service = ThreatIntelligenceService()
    return _threat_intel_service
