"""
LLM service for threat intelligence platform.

Provides access to language models for various security analysis tasks.
"""

import os
import logging
from typing import Optional
from langchain_google_genai import ChatGoogleGenerativeAI

logger = logging.getLogger(__name__)


class LLMService:
    """Service for managing LLM instances."""

    def __init__(self):
        """Initialize the LLM service."""
        self.api_key = os.getenv("GOOGLE_API_KEY")
        if not self.api_key:
            logger.warning("GOOGLE_API_KEY not found in environment")

        # Different model configurations for different tasks
        self._models = {}

    def get_model(
        self,
        model_name: str = "gemini-2.5-flash-lite",
        temperature: float = 0.1,
        task_type: str = "analysis"
    ) -> ChatGoogleGenerativeAI:
        """
        Get an LLM instance for a specific task.

        Args:
            model_name: Name of the model to use
            temperature: Model temperature (lower = more focused)
            task_type: Type of task (analysis, creative, classification)

        Returns:
            ChatGoogleGenerativeAI instance
        """
        # Adjust temperature based on task type
        temp_map = {
            "analysis": 0.1,      # Very focused for security analysis
            "classification": 0.0,  # Deterministic for classification
            "creative": 0.3,      # Slightly creative for recommendations
            "forensics": 0.05,    # Highly focused for forensics
        }

        temperature = temp_map.get(task_type, temperature)

        cache_key = f"{model_name}_{temperature}_{task_type}"

        if cache_key not in self._models:
            logger.debug(f"Creating new LLM instance: {cache_key}")
            self._models[cache_key] = ChatGoogleGenerativeAI(
                model=model_name,
                temperature=temperature,
                google_api_key=self.api_key,
                convert_system_message_to_human=True
            )

        return self._models[cache_key]


# Singleton instance
_llm_service = None


def get_llm_service() -> LLMService:
    """Get or create the LLM service singleton."""
    global _llm_service
    if _llm_service is None:
        _llm_service = LLMService()
    return _llm_service


def get_llm(task_type: str = "analysis") -> ChatGoogleGenerativeAI:
    """
    Convenience function to get an LLM for a specific task.

    Args:
        task_type: Type of task (analysis, creative, classification)

    Returns:
        ChatGoogleGenerativeAI instance
    """
    service = get_llm_service()
    return service.get_model(task_type=task_type)
