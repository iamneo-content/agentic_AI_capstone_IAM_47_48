"""
Memory service for state persistence and checkpointing.
"""

import logging
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


class MemoryService:
    """Service for managing workflow memory and checkpoints."""

    def __init__(self):
        """Initialize memory service."""
        self.checkpointer = MemorySaver()
        logger.info("Memory service initialized with MemorySaver")

    def get_checkpointer(self):
        """Get the checkpointer instance."""
        return self.checkpointer


# Singleton instance
_memory_service = None


def get_memory_service() -> MemoryService:
    """Get or create the memory service singleton."""
    global _memory_service
    if _memory_service is None:
        _memory_service = MemoryService()
    return _memory_service
