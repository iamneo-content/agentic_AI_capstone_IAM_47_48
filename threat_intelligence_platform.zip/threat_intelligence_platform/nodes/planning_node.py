"""Planning node - Strategic analysis planning."""

import logging
from state import ThreatIntelligenceState, update_timeline
from agents.planner import PlannerAgent

logger = logging.getLogger(__name__)


def planning_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Create strategic analysis plan.

    Args:
        state: Current state

    Returns:
        Updated state with strategic plan
    """
    logger.info("Executing planning node")

    state["current_node"] = "planning"

    agent = PlannerAgent()

    try:
        result = agent.create_plan(state["threat_input"])

        # Store plan in metadata
        if "metadata" not in state:
            state["metadata"] = {}

        state["metadata"]["analysis_plan"] = result
        state["investigation_depth"] = result.get("investigation_depth", "moderate")

        # Update timeline
        update_timeline(
            state,
            "Strategic Plan Created",
            f"Complexity: {result.get('complexity')}, Priority: {result.get('priority')}"
        )

        # Check if immediate action required
        if result.get("requires_immediate_action"):
            state["requires_escalation"] = True
            state["escalation_reason"] = "Immediate action required based on initial assessment"
            state["escalation_urgency"] = result.get("estimated_urgency")

        logger.info(f"Plan created: {result.get('complexity')} complexity")

    except Exception as e:
        logger.error(f"Error in planning node: {str(e)}")
        state["error"] = f"Planning error: {str(e)}"

    return state
