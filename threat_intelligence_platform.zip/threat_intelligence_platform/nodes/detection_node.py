"""Detection node - Initial threat detection."""

import logging
from state import ThreatIntelligenceState, update_timeline, add_threat_indicator, ThreatLevel
from agents.threat_detector import ThreatDetectorAgent

logger = logging.getLogger(__name__)


def detection_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Execute threat detection.

    Args:
        state: Current state

    Returns:
        Updated state with detection results
    """
    logger.info("Executing detection node")

    state["current_node"] = "detection"

    agent = ThreatDetectorAgent()

    try:
        result = agent.analyze(state["threat_input"])

        # Update state with detection results
        state["threat_type"] = result.get("threat_type")
        state["threat_level"] = ThreatLevel(result.get("threat_level", "medium"))
        state["threat_confidence"] = result.get("confidence", 0.5)

        # Add indicators
        for indicator in result.get("indicators", []):
            add_threat_indicator(
                state,
                indicator.get("type"),
                indicator.get("value"),
                result.get("confidence", 0.5)
            )

        # Update timeline
        update_timeline(
            state,
            "Threat Detection Complete",
            f"Identified as {result.get('threat_type')} with {result.get('threat_level')} severity"
        )

        # Check if immediate escalation needed
        if result.get("requires_immediate_action"):
            state["requires_escalation"] = True
            state["escalation_reason"] = "Immediate threat requires human analyst review"
            state["escalation_urgency"] = state["threat_level"]

        logger.info(f"Threat detected: {state['threat_type']} ({state['threat_level']})")

    except Exception as e:
        logger.error(f"Error in detection node: {str(e)}")
        state["error"] = f"Detection error: {str(e)}"
        state["requires_escalation"] = True
        state["escalation_reason"] = "Detection analysis failed"

    return state
