"""Risk analysis node."""

import logging
from state import ThreatIntelligenceState, update_timeline
from agents.risk_analyzer import RiskAnalyzerAgent

logger = logging.getLogger(__name__)


def risk_analysis_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Execute risk analysis.

    Args:
        state: Current state

    Returns:
        Updated state with risk assessment
    """
    logger.info("Executing risk analysis node")

    state["current_node"] = "risk_analysis"

    agent = RiskAnalyzerAgent()

    try:
        result = agent.analyze_risk(
            threat_type=state.get("threat_type", "unknown"),
            threat_level=state.get("threat_level", "medium"),
            confidence=state.get("threat_confidence", 0.5),
            vulnerabilities=state.get("vulnerabilities", []),
            affected_systems=state.get("affected_systems", [])
        )

        # Update state with risk analysis
        state["risk_score"] = result.get("risk_score")
        state["risk_factors"] = result.get("risk_factors")
        state["business_impact"] = result.get("business_impact")
        state["likelihood_score"] = result.get("likelihood_score")

        # Update timeline
        update_timeline(
            state,
            "Risk Analysis Complete",
            f"Risk Score: {result.get('risk_score')}/10.0 ({result.get('risk_category')})"
        )

        # Add recommendation
        if result.get("recommendation"):
            state["recommendations"].append(result["recommendation"])

        logger.info(f"Risk score calculated: {state['risk_score']}/10.0")

    except Exception as e:
        logger.error(f"Error in risk analysis node: {str(e)}")
        state["error"] = f"Risk analysis error: {str(e)}"

        # Set default values when risk analysis fails
        state["risk_score"] = 5.0  # Default medium risk
        state["risk_factors"] = {}
        state["business_impact"] = "Unable to assess - requires manual review"
        state["likelihood_score"] = 0.5

    return state
