"""Incident response coordination node."""

import logging
from state import ThreatIntelligenceState, update_timeline, IncidentStatus
from agents.response_coordinator import ResponseCoordinatorAgent

logger = logging.getLogger(__name__)


def response_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Create and coordinate incident response.

    Args:
        state: Current state

    Returns:
        Updated state with response plan
    """
    logger.info("Executing response coordination node")

    state["current_node"] = "response_coordination"
    state["incident_status"] = IncidentStatus.REMEDIATING

    agent = ResponseCoordinatorAgent()

    try:
        result = agent.create_response_plan(
            threat_type=state.get("threat_type", "unknown"),
            threat_level=state.get("threat_level", "medium"),
            risk_score=state.get("risk_score", 5.0),
            affected_systems=state.get("affected_systems", []),
            forensics_data=state.get("forensics_data", {}),
            incident_category=state.get("incident_category", "Unknown")
        )

        # Update state
        state["response_plan"] = result
        state["containment_actions"] = result.get("containment_strategy", {}).get("steps", [])
        state["eradication_steps"] = result.get("eradication_plan", {}).get("steps", [])
        state["recovery_plan"] = result.get("recovery_plan")
        state["automated_actions"] = result.get("automated_actions_recommended", [])

        # Check if escalation needed
        if result.get("escalation_needed"):
            state["requires_escalation"] = True
            state["escalation_reason"] = result.get("escalation_reason", "Response requires human oversight")
            state["escalation_urgency"] = state.get("threat_level")

        # Update timeline
        update_timeline(
            state,
            "Response Plan Created",
            f"Priority: {result.get('response_priority')} - {len(result.get('immediate_actions', []))} immediate actions"
        )

        logger.info(f"Response plan created: Priority {result.get('response_priority')}")

    except Exception as e:
        logger.error(f"Error in response node: {str(e)}")
        state["error"] = f"Response coordination error: {str(e)}"
        state["requires_escalation"] = True
        state["escalation_reason"] = "Response planning failed"

    return state
