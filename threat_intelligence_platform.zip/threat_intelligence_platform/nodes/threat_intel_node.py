"""Threat intelligence enrichment node."""

import logging
from state import ThreatIntelligenceState, update_timeline
from agents.threat_intel_agent import ThreatIntelAgent

logger = logging.getLogger(__name__)


def threat_intel_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Enrich with threat intelligence.

    Args:
        state: Current state

    Returns:
        Updated state with threat intelligence
    """
    logger.info("Executing threat intelligence node")

    state["current_node"] = "threat_intelligence"

    agent = ThreatIntelAgent()

    try:
        result = agent.enrich(
            threat_type=state.get("threat_type", "unknown"),
            indicators=state.get("threat_indicators", []),
            forensics_data=state.get("forensics_data", {})
        )

        # Update state
        state["threat_intel"] = result
        state["known_threat_actors"] = [
            actor.get("name", "Unknown")
            for actor in result.get("threat_actors", [])
        ]
        state["ttps"] = result.get("ttps", [])
        state["iocs"] = result.get("iocs_enriched", [])

        # Update timeline
        actors_found = len(result.get("threat_actors", []))
        update_timeline(
            state,
            "Threat Intelligence Enrichment Complete",
            f"Enriched with external intelligence: {actors_found} threat actors identified"
        )

        logger.info(f"Threat intelligence enriched: {actors_found} actors, {len(state['ttps'])} TTPs")

    except Exception as e:
        logger.error(f"Error in threat intelligence node: {str(e)}")
        state["error"] = f"Threat intelligence error: {str(e)}"

    return state
