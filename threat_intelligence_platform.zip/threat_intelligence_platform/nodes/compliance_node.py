"""Compliance checking node."""

import logging
from state import ThreatIntelligenceState, update_timeline
from agents.compliance_checker import ComplianceCheckerAgent

logger = logging.getLogger(__name__)


def compliance_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Check compliance requirements.

    Args:
        state: Current state

    Returns:
        Updated state with compliance assessment
    """
    logger.info("Executing compliance checking node")

    state["current_node"] = "compliance_checking"

    agent = ComplianceCheckerAgent()

    try:
        # Get data exfiltration info from forensics
        forensics = state.get("forensics_data", {})
        data_exfiltration = forensics.get("data_exfiltration", {
            "occurred": False,
            "data_types": [],
            "volume_estimate": "unknown"
        })

        result = agent.check_compliance(
            threat_type=state.get("threat_type", "unknown"),
            incident_category=state.get("incident_category", "Unknown"),
            affected_systems=state.get("affected_systems", []),
            data_exfiltration=data_exfiltration,
            threat_level=state.get("threat_level", "medium")
        )

        # Update state
        state["compliance_status"] = result.get("compliance_status")
        state["regulatory_requirements"] = result.get("applicable_frameworks", [])
        state["compliance_violations"] = result.get("compliance_status", {}).get("violations", [])
        state["reporting_obligations"] = result.get("reporting_obligations", [])

        # Update timeline
        reporting_count = len(result.get("reporting_obligations", []))
        update_timeline(
            state,
            "Compliance Assessment Complete",
            f"Status: {result.get('compliance_status', {}).get('overall', 'Unknown')} - {reporting_count} reporting obligations"
        )

        # Add compliance recommendations
        for remediation in result.get("remediation_for_compliance", []):
            state["recommendations"].append(f"Compliance: {remediation}")

        logger.info(f"Compliance check complete: {reporting_count} obligations")

    except Exception as e:
        logger.error(f"Error in compliance node: {str(e)}")
        state["error"] = f"Compliance checking error: {str(e)}"

    return state
