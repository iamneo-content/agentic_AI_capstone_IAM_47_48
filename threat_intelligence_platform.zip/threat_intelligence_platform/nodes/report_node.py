"""Report generation node."""

import logging
from state import ThreatIntelligenceState, update_timeline, IncidentStatus
from agents.report_generator import ReportGeneratorAgent

logger = logging.getLogger(__name__)


def report_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Generate final security report.

    Args:
        state: Current state

    Returns:
        Updated state with final report
    """
    logger.info("Executing report generation node")

    state["current_node"] = "report_generation"

    agent = ReportGeneratorAgent()

    try:
        # Generate comprehensive report
        report = agent.generate_report(state, report_type="comprehensive")

        state["final_report"] = report

        # Mark incident as resolved (or escalated)
        if state.get("requires_escalation"):
            state["incident_status"] = IncidentStatus.ESCALATED
        else:
            state["incident_status"] = IncidentStatus.RESOLVED

        # Final timeline entry
        update_timeline(
            state,
            "Analysis Complete",
            f"Final status: {state['incident_status']}"
        )

        logger.info("Final report generated")

    except Exception as e:
        logger.error(f"Error in report node: {str(e)}")
        state["error"] = f"Report generation error: {str(e)}"
        state["final_report"] = f"Error generating report: {str(e)}\nPlease review state manually."

    return state
