"""Incident classification node."""

import logging
from state import ThreatIntelligenceState, update_timeline, IncidentStatus
from agents.incident_classifier import IncidentClassifierAgent

logger = logging.getLogger(__name__)


def classification_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Execute incident classification.

    Args:
        state: Current state

    Returns:
        Updated state with classification
    """
    logger.info("Executing classification node")

    state["current_node"] = "classification"
    state["incident_status"] = IncidentStatus.ANALYZING

    agent = IncidentClassifierAgent()

    try:
        result = agent.classify(
            threat_input=state["threat_input"],
            threat_type=state.get("threat_type", "unknown"),
            threat_level=state.get("threat_level", "medium"),
            indicators=state.get("threat_indicators", [])
        )

        # Update state
        state["incident_category"] = result.get("category")

        # Update timeline
        update_timeline(
            state,
            "Incident Classified",
            f"Category: {result.get('category')} - {result.get('sub_category')}"
        )

        # Check if reporting required
        if result.get("requires_reporting"):
            state["recommendations"].append(
                f"Incident reporting required: {result.get('category')}"
            )

        logger.info(f"Incident classified: {state['incident_category']}")

    except Exception as e:
        logger.error(f"Error in classification node: {str(e)}")
        state["error"] = f"Classification error: {str(e)}"

    return state
