"""Forensics investigation node."""

import logging
from state import ThreatIntelligenceState, update_timeline, IncidentStatus
from agents.forensics_agent import ForensicsAgent

logger = logging.getLogger(__name__)


def forensics_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Execute forensic investigation.

    Args:
        state: Current state

    Returns:
        Updated state with forensic findings
    """
    logger.info("Executing forensics node")

    state["current_node"] = "forensics"
    state["incident_status"] = IncidentStatus.INVESTIGATING

    agent = ForensicsAgent()

    try:
        result = agent.investigate(
            threat_input=state["threat_input"],
            threat_type=state.get("threat_type", "unknown"),
            indicators=state.get("threat_indicators", []),
            vulnerabilities=state.get("vulnerabilities", []),
            incident_category=state.get("incident_category", "Unknown")
        )

        # Update state
        state["forensics_data"] = result
        state["root_cause"] = result.get("root_cause")
        state["attack_chain"] = [
            stage.get("stage", "Unknown")
            for stage in result.get("attack_chain_stages", [])
        ]

        # Update timeline with attack chain
        for stage in result.get("attack_chain_stages", []):
            update_timeline(
                state,
                f"Attack Stage: {stage.get('stage')}",
                stage.get("description", "No description")
            )

        # Update timeline for investigation complete
        update_timeline(
            state,
            "Forensic Investigation Complete",
            f"Root cause identified: {result.get('root_cause', 'Unknown')[:100]}"
        )

        logger.info("Forensic investigation complete")

    except Exception as e:
        logger.error(f"Error in forensics node: {str(e)}")
        state["error"] = f"Forensic investigation error: {str(e)}"

    return state
