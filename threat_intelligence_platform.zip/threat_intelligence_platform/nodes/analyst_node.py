"""Human analyst intervention node."""

import logging
from state import ThreatIntelligenceState, update_timeline, IncidentStatus

logger = logging.getLogger(__name__)


def analyst_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Handle human analyst intervention.

    This node is executed after human analyst provides feedback.

    Args:
        state: Current state (with analyst feedback)

    Returns:
        Updated state
    """
    logger.info("Executing analyst intervention node")

    state["current_node"] = "analyst_intervention"

    analyst_feedback = state.get("analyst_feedback", "")

    if analyst_feedback:
        # Add feedback to conversation history
        state["conversation_history"].append({
            "role": "analyst",
            "content": analyst_feedback,
            "timestamp": state.get("timestamp")
        })

        # Update timeline
        update_timeline(
            state,
            "Human Analyst Review",
            f"Analyst feedback: {analyst_feedback[:100]}"
        )

        # Add to recommendations
        state["recommendations"].append(f"Analyst: {analyst_feedback}")

        logger.info("Analyst feedback incorporated")
    else:
        logger.warning("Analyst node executed without feedback")

    # Continue with report generation
    state["requires_escalation"] = False

    return state
