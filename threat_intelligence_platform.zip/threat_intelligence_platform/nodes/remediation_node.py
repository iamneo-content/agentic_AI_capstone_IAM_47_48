"""Remediation planning node."""

import logging
from state import ThreatIntelligenceState, update_timeline
from agents.remediation_planner import RemediationPlannerAgent

logger = logging.getLogger(__name__)


def remediation_node(state: ThreatIntelligenceState) -> ThreatIntelligenceState:
    """
    Create remediation plan.

    Args:
        state: Current state

    Returns:
        Updated state with remediation plan
    """
    logger.info("Executing remediation planning node")

    state["current_node"] = "remediation_planning"

    agent = RemediationPlannerAgent()

    try:
        result = agent.create_plan(
            vulnerabilities=state.get("vulnerabilities", []),
            forensics_data=state.get("forensics_data", {}),
            response_plan=state.get("response_plan", {}),
            threat_type=state.get("threat_type", "unknown")
        )

        # Update state
        state["remediation_plan"] = result
        state["patches_required"] = result.get("patches_required", [])
        state["configuration_changes"] = result.get("configuration_changes", [])
        state["estimated_remediation_time"] = result.get("estimated_total_time")

        # Update timeline
        patches_count = len(result.get("patches_required", []))
        update_timeline(
            state,
            "Remediation Plan Created",
            f"Priority: {result.get('remediation_priority')} - {patches_count} patches required"
        )

        # Add long-term recommendations
        for recommendation in result.get("long_term_recommendations", []):
            state["recommendations"].append(f"Long-term: {recommendation}")

        logger.info(f"Remediation plan created: {patches_count} patches")

    except Exception as e:
        logger.error(f"Error in remediation node: {str(e)}")
        state["error"] = f"Remediation planning error: {str(e)}"

    return state
