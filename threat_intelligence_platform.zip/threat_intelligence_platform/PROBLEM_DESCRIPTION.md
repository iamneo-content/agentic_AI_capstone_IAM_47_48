THREAT INTELLIGENCE PLATFORM - PROBLEM DESCRIPTION
===================================================

PROBLEM STATEMENT
=================

Organizations face an overwhelming number of security threats daily, requiring rapid detection, analysis, and response. Manual threat analysis is time-consuming, error-prone, and cannot scale to handle the volume of modern cybersecurity incidents. Security teams need an automated, intelligent system that can:

1. Automatically detect and classify security threats from various inputs
2. Assess vulnerabilities and calculate risk scores using industry-standard methodologies
3. Perform forensic investigation to determine root causes and attack chains
4. Enrich threat data with external intelligence about known threat actors and TTPs
5. Generate automated incident response plans with containment and remediation steps
6. Ensure compliance with multiple regulatory frameworks (NIST, GDPR, HIPAA, PCI DSS)
7. Provide human-in-the-loop oversight for critical incidents requiring analyst review
8. Generate comprehensive security reports for both technical teams and executive leadership

The solution must coordinate multiple specialized AI agents working together through a sophisticated workflow, with the ability to pause for human analyst intervention when dealing with critical threats.


SOLUTION OVERVIEW
=================

The Threat Intelligence Platform is an advanced multi-agent cybersecurity system that automates threat detection, analysis, and response using LangGraph workflows powered by Google Gemini AI. The system employs 10+ specialized agents coordinated through a state graph, with conditional routing based on threat severity and risk levels.


PROJECT FILE STRUCTURE
======================

threat_intelligence_platform/
  |
  +-- agents/
  |     |-- threat_detector.py          (Initial threat identification)
  |     |-- vulnerability_scanner.py    (System vulnerability assessment)
  |     |-- risk_analyzer.py            (Risk scoring and calculation)
  |     |-- incident_classifier.py      (Threat categorization)
  |     |-- forensics_agent.py          (Deep investigation)
  |     |-- threat_intel_agent.py       (External intelligence enrichment)
  |     |-- response_coordinator.py     (Incident response orchestration)
  |     |-- compliance_checker.py       (Regulatory compliance assessment)
  |     |-- remediation_planner.py      (Remediation strategy creation)
  |     |-- report_generator.py         (Comprehensive reporting)
  |     |-- planner.py                  (Initial analysis planning)
  |
  +-- nodes/
  |     |-- detection_node.py           (Threat detection workflow node)
  |     |-- vulnerability_node.py       (Vulnerability scanning node)
  |     |-- risk_analysis_node.py       (Risk assessment node)
  |     |-- classification_node.py      (Classification node)
  |     |-- forensics_node.py           (Forensic analysis node)
  |     |-- threat_intel_node.py        (Intelligence enrichment node)
  |     |-- response_node.py            (Response coordination node)
  |     |-- compliance_node.py          (Compliance checking node)
  |     |-- remediation_node.py         (Remediation planning node)
  |     |-- report_node.py              (Report generation node)
  |     |-- analyst_node.py             (Human analyst intervention node)
  |     |-- planning_node.py            (Planning node)
  |
  +-- services/
  |     |-- llm_service.py              (LLM model management)
  |     |-- memory_service.py           (State persistence)
  |     |-- threat_intel_service.py     (Threat intelligence database)
  |     |-- risk_scoring_service.py     (Risk calculation algorithms)
  |
  +-- workflow/
  |     |-- routing.py                  (Conditional workflow routing)
  |
  +-- utils/
  |     (Utility functions)
  |
  +-- data/
  |     (Runtime data storage)
  |
  +-- reports/
  |     (Generated security reports)
  |
  +-- main.py                            (CLI entry point)
  +-- graph.py                           (Workflow graph construction)
  +-- state.py                           (State schema definitions)
  +-- requirements.txt                   (Python dependencies)
  +-- .env                               (API configuration)


CORE FILES AND THEIR PURPOSE
=============================

1. state.py - State Management
------------------------------

Purpose: Defines the complete state schema for the threat intelligence workflow, including all data structures, enums, and state manipulation functions.

Key Components:

  ThreatLevel (Enum)
    - CRITICAL: Severe threats requiring immediate action
    - HIGH: Serious threats requiring urgent response
    - MEDIUM: Moderate threats requiring timely attention
    - LOW: Minor threats for routine monitoring
    - INFO: Informational events

  IncidentStatus (Enum)
    - DETECTED: Initial threat detection
    - INVESTIGATING: Under analysis
    - REMEDIATING: Response actions in progress
    - RESOLVED: Incident closed
    - ESCALATED: Sent to human analysts

  ThreatIntelligenceState (TypedDict)
    Contains 50+ fields including:
    - threat_input: Original threat description
    - threat_type: Classified threat category
    - threat_level: Severity assessment
    - risk_score: Calculated risk value (0-10)
    - vulnerabilities: List of identified vulnerabilities
    - incident_id: Unique incident identifier
    - timeline: Chronological event list
    - recommendations: Security recommendations
    - final_report: Generated comprehensive report

Important Functions:

  create_initial_state(threat_input, session_id, processing_mode)
    Parameters:
      - threat_input (str): Description of the security threat
      - session_id (str): Unique session identifier
      - processing_mode (str): "sequential" or "parallel"
    Returns: Complete initialized state dictionary

  update_timeline(state, event, description)
    Parameters:
      - state (dict): Current workflow state
      - event (str): Event name
      - description (str): Event details
    Returns: None (modifies state in-place)


2. graph.py - Workflow Graph Construction
------------------------------------------

Purpose: Constructs the LangGraph workflow with all nodes, edges, and conditional routing logic.

Important Functions:

  create_threat_intelligence_graph(use_checkpointer)
    Parameters:
      - use_checkpointer (bool): Enable state persistence
    Returns: Compiled LangGraph workflow

    Workflow Structure:
      plan -> detect -> [conditional] -> scan_vulnerabilities ->
      analyze_risk -> classify -> investigate -> enrich_intel ->
      coordinate_response -> [conditional] -> check_compliance ->
      plan_remediation -> [conditional] -> generate_report

    Conditional branches for analyst_review based on:
      - Critical threat detection
      - High risk scores (>= 9.0)
      - Processing errors

  get_graph(use_checkpointer, force_recreate)
    Parameters:
      - use_checkpointer (bool): Enable checkpointing
      - force_recreate (bool): Force new graph creation
    Returns: Singleton graph instance


3. main.py - Interactive CLI Interface
---------------------------------------

Purpose: Provides command-line interface for threat analysis with human-in-the-loop support.

Key Class: ThreatIntelligenceCLI

  Important Methods:

    __init__(self)
      Parameters: None
      Purpose: Initialize CLI, load environment, create graph
      Validates GOOGLE_API_KEY environment variable

    process_threat(self, threat_input)
      Parameters:
        - threat_input (str): Threat description
      Purpose: Execute full threat analysis workflow
      Returns: None (displays results)

    print_final_report(self, report)
      Parameters:
        - report (str): Generated security report
      Purpose: Display formatted final report

    _handle_analyst_review(self, config)
      Parameters:
        - config (dict): Graph execution configuration
      Purpose: Manage human analyst intervention
      Prompts analyst for feedback and resumes workflow


4. workflow/routing.py - Conditional Routing Logic
--------------------------------------------------

Purpose: Implements decision logic for workflow branching based on threat characteristics.

Important Functions:

  should_escalate_after_detection(state)
    Parameters:
      - state (ThreatIntelligenceState): Current state
    Returns: "continue" or "escalate"

    Escalation criteria:
      - requires_escalation flag is set
      - Critical threat level with confidence > 0.9
      - Processing errors detected

  should_escalate_after_response(state)
    Parameters:
      - state (ThreatIntelligenceState): Current state
    Returns: "continue" or "escalate"

    Escalation criteria:
      - Response plan requires escalation
      - Risk score >= 9.0
      - More than 5 manual actions required

  route_to_final(state)
    Parameters:
      - state (ThreatIntelligenceState): Current state
    Returns: "report" or "escalate"

    Routes to analyst if requires_escalation is True


5. agents/threat_detector.py - Threat Detection Agent
-----------------------------------------------------

Purpose: Initial threat identification and classification using LLM analysis.

Key Class: ThreatDetectorAgent

  Important Methods:

    analyze(self, threat_input, context)
      Parameters:
        - threat_input (str): Raw threat description
        - context (dict): Additional context information
      Returns: Dictionary with threat analysis results
        - threat_type: Classified threat category
        - threat_level: ThreatLevel enum value
        - confidence: Detection confidence (0-1)
        - indicators: List of threat indicators


6. agents/risk_analyzer.py - Risk Analysis Agent
------------------------------------------------

Purpose: Calculate comprehensive risk scores using multi-factor analysis.

Key Class: RiskAnalyzerAgent

  Important Methods:

    analyze_risk(self, threat_type, threat_level, confidence, vulnerabilities, affected_systems)
      Parameters:
        - threat_type (str): Type of threat
        - threat_level (str): Severity level
        - confidence (float): Detection confidence
        - vulnerabilities (list): Identified vulnerabilities
        - affected_systems (list): List of affected systems
      Returns: Risk analysis dictionary
        - risk_score: Calculated score (0-10)
        - risk_category: "critical", "high", "medium", "low"
        - likelihood_score: Exploitation likelihood (0-1)
        - business_impact: Impact description
        - recommendation: Action recommendation


7. services/risk_scoring_service.py - Risk Calculation Service
--------------------------------------------------------------

Purpose: Implements CVSS-like scoring algorithms and risk quantification.

Key Class: RiskScoringService

  Important Methods:

    calculate_risk_score(self, threat_type, affected_systems, vulnerabilities, threat_level, confidence)
      Parameters:
        - threat_type (str): Threat classification
        - affected_systems (list): Impacted systems
        - vulnerabilities (list): Vulnerability data
        - threat_level (str): Severity assessment
        - confidence (float): Detection confidence
      Returns: Risk score dictionary with breakdown

      Calculation formula:
        raw_score = (base_score * 0.4) + (asset_impact * 10 * 0.3) +
                    (vuln_score * 0.2) + (level_adjustment * 0.1)
        final_score = raw_score * confidence
        capped at 10.0


8. agents/report_generator.py - Report Generation Agent
-------------------------------------------------------

Purpose: Generate comprehensive security reports for different audiences.

Key Class: ReportGeneratorAgent

  Important Methods:

    generate_report(self, state, report_type, audience)
      Parameters:
        - state (dict): Complete workflow state
        - report_type (str): "comprehensive", "executive", "technical"
        - audience (str): Target audience
      Returns: Formatted markdown report string

      Report sections:
        - Executive Summary
        - Threat Analysis
        - Risk Assessment
        - Technical Details (IOCs, TTPs, CVEs)
        - Incident Response Plan
        - Compliance Impact
        - Remediation Recommendations
        - Timeline of Events


9. nodes/detection_node.py - Detection Workflow Node
----------------------------------------------------

Purpose: Wrapper node that executes threat detection agent in workflow.

Important Function:

  detection_node(state)
    Parameters:
      - state (ThreatIntelligenceState): Current state
    Returns: Updated state with detection results

    Updates state fields:
      - current_node: "detection"
      - threat_type: Detected threat type
      - threat_level: Severity level
      - threat_confidence: Detection confidence
      - threat_indicators: List of indicators


10. agents/vulnerability_scanner.py
-----------------------------------
VulnerabilityAgentScanner.scan(threat_type, threat_indicators, threat_input)
Returns: {vulnerabilities: [], affected_systems: [], attack_surface: {}, exploitability_assessment, remediation_urgency}

11. agents/incident_classifier.py
----------------------------------
IncidentClassifierAgent.classify(threat_input, threat_type, threat_level, indicators)
Returns: {category (NIST), sub_category, severity, attack_vector, target_type, impact_scope, classification_confidence}

12. agents/forensics_agent.py
------------------------------
ForensicsAgent.investigate(threat_input, threat_type, indicators, vulnerabilities, incident_category)
Returns: {root_cause, initial_access_method, attack_chain_stages, lateral_movement, persistence_mechanisms,
data_exfiltration, attacker_sophistication, investigation_completeness}
Note: Limits indicators to first 10

13. agents/threat_intel_agent.py
---------------------------------
ThreatIntelAgent.enrich(threat_type, indicators, forensics_data)
Returns: {iocs_enriched, known_malware, threat_actors (APT28/29/Lazarus/APT41), ttps, mitre_techniques, correlation, confidence_level}
Note: Limits indicators to 20, TTPs to 10

14. agents/response_coordinator.py
-----------------------------------
ResponseCoordinatorAgent.create_response_plan(threat_type, threat_level, risk_score, affected_systems, forensics_data, incident_category)
Returns: {response_priority, immediate_actions, containment_strategy, eradication_plan, recovery_plan,
automated_actions_recommended, manual_actions_required, escalation_needed}
Note: Limits affected_systems to first 5

15. agents/compliance_checker.py
---------------------------------
ComplianceCheckerAgent.check_compliance(threat_type, incident_category, affected_systems, data_exfiltration, threat_level)
Returns: {applicable_frameworks (NIST/ISO/GDPR/HIPAA/PCI/SOX), compliance_status, reporting_required,
reporting_obligations, customer_notification_required, compliance_risk_level}

16. agents/remediation_planner.py
----------------------------------
RemediationPlannerAgent.create_plan(vulnerabilities, forensics_data, response_plan, threat_type)
Returns: {remediation_priority, immediate_fixes, patches_required, configuration_changes, security_controls,
architecture_changes, validation_steps, success_metrics}
Note: Limits vulnerabilities to first 10

17. agents/planner.py
---------------------
PlannerAgent.create_plan(threat_input)
Returns: {complexity, priority, scope, focus_areas, investigation_depth, estimated_urgency, requires_immediate_action}

18. services/llm_service.py
----------------------------
LLMService.get_model(model_name, temperature, task_type)
Temperature mapping: analysis=0.1, classification=0.0, creative=0.3, forensics=0.05
Singleton functions: get_llm_service(), get_llm(task_type)

19. services/memory_service.py
-------------------------------
MemoryService.get_checkpointer() - Returns MemorySaver for state persistence
Singleton: get_memory_service()

20. services/threat_intel_service.py
-------------------------------------
Methods:
- lookup_ioc(ioc, ioc_type) - Pattern matching for IP/domain/hash/URL
- get_threat_actor_info(actor_name) - Returns info for APT28/29/Lazarus/APT41
- get_malware_info(malware_name) - Returns info for emotet/trickbot/ryuk/cobalt_strike
- get_mitre_techniques(keywords) - Maps keywords to ATT&CK techniques
- correlate_threats(indicators) - Suggests campaigns if 3+ indicators

21-31. nodes/*.py - Workflow Nodes
-----------------------------------
Pattern: Each node calls its agent, updates state fields, logs timeline event, handles errors

21. vulnerability_node - Updates: vulnerabilities, affected_systems, attack_surface
22. risk_analysis_node - Updates: risk_score, risk_category, likelihood_score, business_impact
23. classification_node - Updates: incident_category, attack_vector, target_type, impact_scope
24. forensics_node - Updates: forensics_analysis, root_cause, attack_chain
25. threat_intel_node - Updates: threat_intelligence, ttps, mitre_techniques
26. response_node - Updates: response_plan, requires_escalation (if risk>=9.0 or manual_actions>5)
27. compliance_node - Updates: compliance_status, reporting_obligations, applicable_frameworks
28. remediation_node - Updates: remediation_plan, recommendations
29. report_node - Updates: final_report, incident_status="RESOLVED"
30. analyst_node - Updates: conversation_history, recommendations, requires_escalation=False
31. planning_node - Updates: metadata["analysis_plan"], investigation_depth, may set requires_escalation



INSTALLATION AND SETUP
======================

Step 1: Install Dependencies
-----------------------------

Command:
  pip install -r requirements.txt

This installs:
  - langgraph (workflow orchestration)
  - langchain (LLM integration)
  - langchain-google-genai (Google Gemini API)
  - python-dotenv (environment variable management)
  - colorama (colored CLI output)
  - pytest (testing framework)


Step 2: Configure API Key
--------------------------

Edit .env file:
  GOOGLE_API_KEY=your_api_key_here

Obtain API key from:
  https://makersuite.google.com/app/apikey


Step 3: Verify Installation
---------------------------

Command:
  python3 -m pytest tests.py -v

Expected output:
  15 passed in ~3 seconds


RUNNING THE APPLICATION
========================

Method 1: Interactive CLI (Recommended)
----------------------------------------

Command:
  python3 main.py

Interactive prompts:
  Threat> [Enter threat description]
  Analyst> [Provide feedback when prompted]

Example session:

  Threat> Multiple servers showing encrypted files with .locked extension.
          Ransom note found demanding 50 BTC. Critical production databases affected.

  [System analyzes threat through multiple stages]

  HUMAN ANALYST REVIEW REQUIRED

  Escalation Reason:
    Immediate threat requires human analyst review

  Threat Summary:
    Type: ransomware
    Level: critical
    Risk Score: 9.2/10.0

  Please provide your analysis or guidance:
  Analyst> Proceed with automated incident response and containment

  [System continues analysis]

  SECURITY ANALYSIS COMPLETE

  [Full security report displayed]



EXPECTED OUTPUT - SAMPLE THREAT ANALYSIS
=========================================

Input Threat:
  User reported slow computer performance and occasional browser pop-ups.
  System still operational.

Analysis Workflow:
  [PLAN] Planning...
  [DETECT] Detection...
    +- Threat Type: policy_violation
    +- Severity: low
    +- Confidence: 70 percent
  [VULN] Vulnerability Assessment...
  [RISK] Risk Analysis...
    +- Risk Score: 3.2/10.0
  [CLASS] Classification...
  [FORENSIC] Forensics...
  [INTEL] Threat Intelligence...
  [RESPONSE] Response Coordination...
  [COMPLY] Compliance Checking...
  [REMEDY] Remediation Planning...
  [REPORT] Report Generation...

Final Security Report:

  SECURITY INCIDENT REPORT

  INCIDENT SUMMARY

  Incident ID: INC-20251219-A1B2C3D4
  Severity: LOW
  Status: RESOLVED
  Timestamp: 2025-12-19 15:30:00

  EXECUTIVE SUMMARY

  A low-severity policy violation was detected involving unauthorized
  software usage leading to system performance degradation. The incident
  has been contained and remediated with minimal business impact.

  Threat Type: Policy Violation
  Risk Score: 3.2/10.0 (LOW)
  Business Impact: Minimal - No significant operational disruption

  THREAT ANALYSIS

  Initial Detection:
    User-reported symptoms indicate potential adware or unauthorized
    application installation. Browser pop-ups suggest browser hijacking
    or adware infection.

  Classification:
    Category: Improper Usage
    Subcategory: Unauthorized Software
    NIST Category: Malicious Code

  Confidence Level: 70 percent

  RISK ASSESSMENT

  Risk Score Breakdown:
    Base Threat Score: 3.0/10.0
    Asset Impact: 0.5/1.0
    Vulnerability Score: 4.0/10.0
    Likelihood: 0.25/1.0

  Risk Factors:
    - Single user endpoint affected
    - No critical systems involved
    - Low exploitability
    - Contained to single system

  TECHNICAL DETAILS

  Affected Systems:
    - User workstation (1 system)

  Vulnerabilities Identified:
    - Outdated browser version
    - Missing security updates
    - Insufficient endpoint protection

  Indicators of Compromise (IOCs):
    - Browser pop-up advertisements
    - Performance degradation
    - Unauthorized browser extensions

  FORENSIC ANALYSIS

  Root Cause:
    User installed unauthorized browser extension or adware through
    deceptive download link. Insufficient endpoint controls allowed
    installation without administrative review.

  Attack Chain:
    1. User visited compromised website
    2. Deceptive download prompt displayed
    3. User installed malicious browser extension
    4. Extension injected advertisements
    5. System performance impacted

  INCIDENT RESPONSE PLAN

  Containment Actions:
    1. Isolate affected workstation from network
    2. Disable unauthorized browser extensions
    3. Terminate suspicious processes
    4. Block malicious domains at firewall

  Eradication Steps:
    1. Remove unauthorized browser extensions
    2. Clear browser cache and cookies
    3. Run malware scan with updated definitions
    4. Remove identified threats
    5. Apply pending security updates

  Recovery Plan:
    1. Verify system clean with secondary scan
    2. Restore browser settings to defaults
    3. Reconnect to network
    4. Monitor for 48 hours
    5. User training on safe browsing

  COMPLIANCE IMPACT

  Regulatory Requirements:
    - No GDPR notification required (no data breach)
    - No HIPAA impact (no PHI involved)
    - No PCI DSS violations

  Compliance Status: COMPLIANT

  RECOMMENDATIONS

  Immediate Actions:
    1. Remove unauthorized software immediately
    2. Update browser to latest version
    3. Install approved ad-blocking extension
    4. Run full system malware scan

  Short-term (1-7 days):
    1. Deploy endpoint protection updates
    2. Implement application whitelisting
    3. Conduct user security awareness training
    4. Review and update acceptable use policy

  Long-term (1-3 months):
    1. Implement DNS filtering solution
    2. Deploy next-generation endpoint protection
    3. Establish regular security training program
    4. Implement browser security baseline

  TIMELINE

  2025-12-19 15:25:00 - Incident detected
  2025-12-19 15:26:00 - Threat classified as policy violation
  2025-12-19 15:27:00 - Risk analysis complete: 3.2/10.0
  2025-12-19 15:28:00 - Forensic investigation completed
  2025-12-19 15:29:00 - Response plan created
  2025-12-19 15:30:00 - Remediation plan finalized
  2025-12-19 15:30:00 - Report generated

  CONCLUSION

  This low-severity incident was successfully contained and remediated
  with minimal business impact. Enhanced endpoint controls and user
  training will prevent recurrence.

  Report generated by Threat Intelligence Platform
  Analyzed by: AI Security Analysis System
  Report Date: 2025-12-19


WORKFLOW EXECUTION DETAILS
===========================

For Low-Severity Threats:

  Total Nodes Executed: 10-12
  API Calls Required: 10-15
  Average Processing Time: 30-60 seconds
  Analyst Reviews Required: 0-1

  Path:
    plan -> detect -> scan_vulnerabilities -> analyze_risk ->
    classify -> investigate -> enrich_intel -> coordinate_response ->
    check_compliance -> plan_remediation -> generate_report


For Critical-Severity Threats:

  Total Nodes Executed: 12-15
  API Calls Required: 18-25
  Average Processing Time: 60-120 seconds
  Analyst Reviews Required: 1-2

  Path:
    plan -> detect -> [ANALYST REVIEW 1] -> scan_vulnerabilities ->
    analyze_risk -> classify -> investigate -> enrich_intel ->
    coordinate_response -> [ANALYST REVIEW 2] -> check_compliance ->
    plan_remediation -> generate_report


Error Handling:

  If any node encounters an error:
    1. Error logged to threat_intelligence.log
    2. Default values set for critical fields
    3. Workflow continues with degraded data
    4. Error reported in final report
    5. Escalation triggered for manual review