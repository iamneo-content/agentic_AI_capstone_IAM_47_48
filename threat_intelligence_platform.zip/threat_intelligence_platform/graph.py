"""
Graph Construction for Threat Intelligence Platform
---------------------------------------------------

Creates the LangGraph workflow with all nodes, edges, routing logic,
checkpointing, and optional visualization.
"""

import logging
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from state import ThreatIntelligenceState
from nodes import (
    planning_node,
    detection_node,
    vulnerability_node,
    risk_analysis_node,
    classification_node,
    forensics_node,
    threat_intel_node,
    response_node,
    compliance_node,
    remediation_node,
    report_node,
    analyst_node,
)
from workflow.routing import (
    should_escalate_after_detection,
    should_escalate_after_response,
    route_to_final,
)
from services.memory_service import get_memory_service

logger = logging.getLogger(__name__)

# Singleton graph instance
_graph_instance = None


def create_threat_intelligence_graph(use_checkpointer: bool = True):
    """
    Create and compile the threat intelligence workflow graph.
    """
    logger.info("Creating threat intelligence workflow graph")

    # Create StateGraph
    workflow = StateGraph(ThreatIntelligenceState)

    # Add nodes
    workflow.add_node("plan", planning_node)

    workflow.add_node("detect", detection_node)
    workflow.add_node("scan_vulnerabilities", vulnerability_node)
    workflow.add_node("analyze_risk", risk_analysis_node)
    workflow.add_node("classify", classification_node)
    workflow.add_node("investigate", forensics_node)
    workflow.add_node("enrich_intel", threat_intel_node)

    workflow.add_node("coordinate_response", response_node)
    workflow.add_node("check_compliance", compliance_node)
    workflow.add_node("plan_remediation", remediation_node)

    workflow.add_node("generate_report", report_node)
    workflow.add_node("analyst_review", analyst_node)

    # Entry point
    workflow.set_entry_point("plan")

    # Sequential edges
    workflow.add_edge("plan", "detect")

    workflow.add_conditional_edges(
        "detect",
        should_escalate_after_detection,
        {
            "continue": "scan_vulnerabilities",
            "escalate": "analyst_review",
        },
    )

    workflow.add_edge("scan_vulnerabilities", "analyze_risk")
    workflow.add_edge("analyze_risk", "classify")

    workflow.add_edge("classify", "investigate")
    workflow.add_edge("investigate", "enrich_intel")

    workflow.add_edge("enrich_intel", "coordinate_response")

    workflow.add_conditional_edges(
        "coordinate_response",
        should_escalate_after_response,
        {
            "continue": "check_compliance",
            "escalate": "analyst_review",
        },
    )

    workflow.add_edge("check_compliance", "plan_remediation")

    workflow.add_conditional_edges(
        "plan_remediation",
        route_to_final,
        {
            "report": "generate_report",
            "escalate": "analyst_review",
        },
    )

    # Terminal edges
    workflow.add_edge("generate_report", END)

    # Resume workflow after analyst review
    workflow.add_edge("analyst_review", "scan_vulnerabilities")

    # Compile graph
    logger.debug("Compiling threat intelligence graph")

    if use_checkpointer:
        memory_service = get_memory_service()
        checkpointer = memory_service.get_checkpointer()

        graph = workflow.compile(
            checkpointer=checkpointer,
            interrupt_before=["analyst_review"],
        )
    else:
        graph = workflow.compile()

    logger.info("Threat intelligence graph compiled successfully")
    return graph


def get_graph(use_checkpointer: bool = True, force_recreate: bool = False):
    """
    Get or create the singleton threat intelligence graph.
    """
    global _graph_instance

    if _graph_instance is None or force_recreate:
        _graph_instance = create_threat_intelligence_graph(
            use_checkpointer=use_checkpointer
        )

    return _graph_instance


def visualize_graph(graph, output_path: str = "threat_intel_graph.png") -> bool:
    """
    Visualize the graph structure and save as PNG.
    """
    try:
        img_data = graph.get_graph().draw_mermaid_png()
        with open(output_path, "wb") as f:
            f.write(img_data)

        logger.info(f"Graph visualization saved to {output_path}")
        return True

    except Exception as exc:
        logger.error(f"Error creating graph visualization: {exc}")
        return False


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    graph = create_threat_intelligence_graph(use_checkpointer=False)
    print("✓ Threat Intelligence Graph created successfully")

    if visualize_graph(graph):
        print("✓ Graph visualization saved")
