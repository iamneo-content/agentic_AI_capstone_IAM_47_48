"""Visual Quality Analysis for Social Media"""
import logging
from typing import Dict, Any, Optional
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("visual_quality_analyzer")

class VisualQualityAnalyzer:
    """Analyzes quality of visual content (images/videos) for social media posts"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"VisualQualityAnalyzer initialized with model: {model_name}")

    def analyze(self, image_url: Optional[str], video_url: Optional[str], platform: str) -> Dict[str, Any]:
        """
        Analyze visual content quality

        Args:
            image_url: URL of image (if applicable)
            video_url: URL of video (if applicable)
            platform: Social media platform

        Returns:
            Dictionary with visual quality analysis results
        """
        if not image_url and not video_url:
            logger.info("No visual content to analyze")
            return self._no_visual_content()

        visual_type = "video" if video_url else "image"
        visual_ref = video_url or image_url

        logger.info(f"Analyzing {visual_type} quality for {platform}")

        try:
            prompt = f"""Analyze the visual quality of this {visual_type} for a {platform} social media post.

PLATFORM: {platform}
VISUAL TYPE: {visual_type}

Evaluate:
1. Image/video quality and resolution
2. Composition and framing
3. Lighting and color balance
4. Subject clarity and focus
5. Aesthetic appeal
6. Platform-specific format requirements
7. Engagement potential of visual
8. Brand consistency (if applicable)
9. Text overlay readability (if present)
10. Accessibility considerations

Platform-specific considerations:
- Instagram: Square (1:1), Portrait (4:5), Landscape (1.91:1)
- Twitter: 16:9 optimal
- LinkedIn: 1.91:1 for images
- TikTok: 9:16 vertical video
- Facebook: 1.91:1 for link posts

Provide your analysis in the following JSON format:
{{
    "quality_score": <float 1-10>,
    "resolution_quality": "<low|medium|high|excellent>",
    "composition_score": <float 1-10>,
    "lighting_score": <float 1-10>,
    "color_balance": "<poor|fair|good|excellent>",
    "aesthetic_appeal": <float 1-10>,
    "format_compliance": <float 0-1>,
    "aspect_ratio": "<ratio or 'non-standard'>",
    "engagement_potential": <float 0-1>,
    "accessibility_score": <float 0-1>,
    "strengths": ["strength1", "strength2", "strength3"],
    "weaknesses": ["weakness1", "weakness2"],
    "improvements": ["improvement1", "improvement2", "improvement3"],
    "platform_optimization": ["suggestion1", "suggestion2"],
    "technical_issues": ["issue1", "issue2"],
    "analysis": "Brief visual quality analysis"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response to extract JSON
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            result["has_visual"] = True
            result["visual_type"] = visual_type

            logger.info(f"Visual quality analysis complete: score={result.get('quality_score'):.1f}, "
                       f"composition={result.get('composition_score'):.1f}")

            return result

        except Exception as e:
            logger.error(f"Error analyzing visual quality: {e}")
            return self._fallback_visual_analysis(visual_type, platform)

    def _no_visual_content(self) -> Dict[str, Any]:
        """Return analysis when no visual content is present"""
        return {
            "has_visual": False,
            "quality_score": 0.0,
            "resolution_quality": "none",
            "composition_score": 0.0,
            "lighting_score": 0.0,
            "color_balance": "none",
            "aesthetic_appeal": 0.0,
            "format_compliance": 0.0,
            "aspect_ratio": "none",
            "engagement_potential": 0.3,
            "accessibility_score": 1.0,
            "visual_type": "none",
            "strengths": [],
            "weaknesses": ["No visual content"],
            "improvements": [
                "Add high-quality image or video",
                "Visual content significantly increases engagement",
                "Consider creating platform-optimized graphics"
            ],
            "platform_optimization": [
                "Text-only posts have lower engagement",
                "Add compelling visuals to stand out in feeds"
            ],
            "technical_issues": [],
            "analysis": "No visual content detected. Adding images or videos can significantly improve engagement."
        }

    def _fallback_visual_analysis(self, visual_type: str, platform: str) -> Dict[str, Any]:
        """Fallback basic visual analysis"""
        logger.info("Using fallback visual analysis")

        # Assume decent quality if visual is present
        base_score = 7.0

        return {
            "has_visual": True,
            "visual_type": visual_type,
            "quality_score": base_score,
            "resolution_quality": "medium",
            "composition_score": 7.0,
            "lighting_score": 7.0,
            "color_balance": "good",
            "aesthetic_appeal": 7.0,
            "format_compliance": 0.8,
            "aspect_ratio": "standard",
            "engagement_potential": 0.7,
            "accessibility_score": 0.7,
            "strengths": [
                f"{visual_type.capitalize()} content present",
                "Adds visual interest to post"
            ],
            "weaknesses": [
                "Unable to perform detailed technical analysis"
            ],
            "improvements": [
                "Ensure high resolution (minimum 1080px)",
                "Check lighting and exposure",
                "Optimize for mobile viewing"
            ],
            "platform_optimization": [
                f"Verify {platform} aspect ratio requirements",
                "Test visual on mobile devices",
                "Consider adding text overlay for context"
            ],
            "technical_issues": [],
            "analysis": f"Basic {visual_type} quality assessment. Visual content detected and appears suitable for posting."
        }
