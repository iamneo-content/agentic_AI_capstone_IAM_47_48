"""Hashtag Optimization Analyzer"""
import logging
import re
from typing import Dict, Any, List
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("hashtag_optimizer")

class HashtagOptimizer:
    """Optimizes hashtags for social media posts"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"HashtagOptimizer initialized with model: {model_name}")

    def optimize(self, content: str, platform: str, existing_hashtags: List[str] = None) -> Dict[str, Any]:
        """
        Optimize hashtags for a social media post

        Args:
            content: Post text content
            platform: Social media platform
            existing_hashtags: List of existing hashtags in the post

        Returns:
            Dictionary with hashtag optimization results
        """
        logger.info(f"Optimizing hashtags for {platform} post")

        if existing_hashtags is None:
            existing_hashtags = self._extract_hashtags(content)

        try:
            optimal_count = get_config_value("OPTIMAL_HASHTAGS", 10)
            max_hashtags = get_config_value("MAX_HASHTAGS", 30)

            prompt = f"""Analyze and optimize hashtags for the following social media post.

PLATFORM: {platform}
EXISTING HASHTAGS: {existing_hashtags if existing_hashtags else "None"}
POST CONTENT:
{content}

Platform-specific guidelines:
- Instagram: 10-30 hashtags optimal
- Twitter: 1-2 hashtags optimal
- LinkedIn: 3-5 hashtags optimal
- TikTok: 3-5 hashtags optimal
- Facebook: 1-3 hashtags optimal

Provide hashtag recommendations considering:
1. Relevance to content
2. Trending vs evergreen hashtags
3. Competition level (niche vs broad)
4. Platform best practices
5. Target audience reach
6. Hashtag mix (branded, community, trending)

Provide your analysis in the following JSON format:
{{
    "hashtag_score": <float 1-10 rating existing hashtags>,
    "suggested_hashtags": ["#hashtag1", "#hashtag2", "#hashtag3", ...],
    "trending_hashtags": ["#trending1", "#trending2"],
    "niche_hashtags": ["#niche1", "#niche2"],
    "branded_hashtags": ["#brand1"],
    "optimal_count": <number of hashtags recommended>,
    "hashtags_to_remove": ["#remove1", "#remove2"],
    "hashtags_to_add": ["#add1", "#add2", "#add3"],
    "reach_estimate": "<low|medium|high|very high>",
    "competition_level": "<low|medium|high>",
    "recommendations": ["recommendation1", "recommendation2"],
    "analysis": "Brief explanation of hashtag strategy"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response to extract JSON
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            # Ensure hashtags have # prefix
            result["suggested_hashtags"] = [
                tag if tag.startswith("#") else f"#{tag}"
                for tag in result.get("suggested_hashtags", [])
            ]

            logger.info(f"Hashtag optimization complete: score={result.get('hashtag_score'):.1f}, "
                       f"suggested={len(result.get('suggested_hashtags', []))} hashtags")

            return result

        except Exception as e:
            logger.error(f"Error optimizing hashtags: {e}")
            return self._fallback_hashtag_optimization(content, platform, existing_hashtags)

    def _extract_hashtags(self, content: str) -> List[str]:
        """Extract hashtags from content"""
        hashtag_pattern = r'#\w+'
        hashtags = re.findall(hashtag_pattern, content)
        return hashtags

    def _fallback_hashtag_optimization(self, content: str, platform: str, existing_hashtags: List[str]) -> Dict[str, Any]:
        """Fallback basic hashtag optimization"""
        logger.info("Using fallback hashtag optimization")

        # Platform-specific defaults
        platform_hashtags = {
            "instagram": ["#instagood", "#photooftheday", "#love", "#instagram", "#follow"],
            "twitter": ["#trending", "#news"],
            "facebook": ["#facebook", "#social"],
            "linkedin": ["#linkedin", "#professional", "#business"],
            "tiktok": ["#fyp", "#foryou", "#viral"]
        }

        suggested = platform_hashtags.get(platform.lower(), ["#social", "#content"])

        # Extract keywords from content
        words = re.findall(r'\b[a-zA-Z]{4,}\b', content.lower())
        keyword_hashtags = [f"#{word}" for word in words[:3]]

        all_suggestions = list(set(suggested + keyword_hashtags))[:10]

        existing_count = len(existing_hashtags) if existing_hashtags else 0
        score = min(7.0, 5.0 + (existing_count * 0.3))

        return {
            "hashtag_score": score,
            "suggested_hashtags": all_suggestions,
            "trending_hashtags": suggested[:2],
            "niche_hashtags": keyword_hashtags,
            "branded_hashtags": [],
            "optimal_count": 10 if platform.lower() == "instagram" else 3,
            "hashtags_to_remove": [],
            "hashtags_to_add": all_suggestions[:5],
            "reach_estimate": "medium",
            "competition_level": "medium",
            "recommendations": [
                "Mix popular and niche hashtags",
                "Research trending hashtags in your niche",
                "Create a branded hashtag"
            ],
            "analysis": "Basic hashtag suggestions based on platform best practices"
        }
