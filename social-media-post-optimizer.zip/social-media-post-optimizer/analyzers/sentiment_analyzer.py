"""Sentiment Analysis for Social Media Posts"""
import logging
from typing import Dict, Any
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("sentiment_analyzer")

class SentimentAnalyzer:
    """Analyzes sentiment and emotional tone of social media posts"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"SentimentAnalyzer initialized with model: {model_name}")

    def analyze(self, content: str, platform: str) -> Dict[str, Any]:
        """
        Analyze sentiment and emotional tone of post content

        Args:
            content: Post text content
            platform: Social media platform

        Returns:
            Dictionary with sentiment analysis results
        """
        logger.info(f"Analyzing sentiment for {platform} post")

        try:
            prompt = f"""Analyze the sentiment and emotional tone of the following social media post.

PLATFORM: {platform}
POST CONTENT:
{content}

Analyze:
1. Overall sentiment (positive, negative, neutral, mixed)
2. Emotional tone (joy, sadness, anger, fear, surprise, trust, etc.)
3. Formality level (casual, semi-formal, formal)
4. Authenticity and relatability
5. Tone appropriateness for platform
6. Potential controversial elements
7. Brand voice consistency

Provide your analysis in the following JSON format:
{{
    "sentiment_score": <float 0-1, where 0=very negative, 0.5=neutral, 1=very positive>,
    "sentiment_label": "<positive|negative|neutral|mixed>",
    "confidence": <float 0-1>,
    "emotions": {{
        "joy": <float 0-1>,
        "trust": <float 0-1>,
        "fear": <float 0-1>,
        "surprise": <float 0-1>,
        "sadness": <float 0-1>,
        "anger": <float 0-1>
    }},
    "dominant_emotion": "<emotion_name>",
    "formality_level": "<casual|semi-formal|formal>",
    "authenticity_score": <float 0-1>,
    "tone_appropriateness": <float 0-1>,
    "controversial_risk": "<low|medium|high>",
    "controversial_elements": ["element1", "element2"],
    "positive_aspects": ["aspect1", "aspect2"],
    "concerns": ["concern1", "concern2"],
    "suggestions": ["suggestion1", "suggestion2"],
    "analysis": "Brief sentiment analysis summary"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response to extract JSON
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Sentiment analysis complete: {result.get('sentiment_label')}, "
                       f"score={result.get('sentiment_score'):.2f}, "
                       f"dominant={result.get('dominant_emotion')}")

            return result

        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return self._fallback_sentiment_analysis(content)

    def _fallback_sentiment_analysis(self, content: str) -> Dict[str, Any]:
        """Fallback basic sentiment analysis"""
        logger.info("Using fallback sentiment analysis")

        content_lower = content.lower()

        # Simple keyword-based sentiment
        positive_words = ["great", "awesome", "love", "amazing", "happy", "excited", "wonderful", "fantastic"]
        negative_words = ["bad", "terrible", "hate", "awful", "sad", "angry", "disappointed", "poor"]

        positive_count = sum(1 for word in positive_words if word in content_lower)
        negative_count = sum(1 for word in negative_words if word in content_lower)

        if positive_count > negative_count:
            sentiment_label = "positive"
            sentiment_score = 0.7
        elif negative_count > positive_count:
            sentiment_label = "negative"
            sentiment_score = 0.3
        else:
            sentiment_label = "neutral"
            sentiment_score = 0.5

        # Check for exclamation marks and questions
        exclamations = content.count("!")
        questions = content.count("?")

        joy_score = min(0.8, 0.3 + (exclamations * 0.1) + (positive_count * 0.1))
        trust_score = 0.5

        return {
            "sentiment_score": sentiment_score,
            "sentiment_label": sentiment_label,
            "confidence": 0.6,
            "emotions": {
                "joy": joy_score,
                "trust": trust_score,
                "fear": 0.1,
                "surprise": min(0.5, questions * 0.15),
                "sadness": min(0.5, negative_count * 0.15),
                "anger": 0.1
            },
            "dominant_emotion": "joy" if joy_score > 0.5 else "trust",
            "formality_level": "casual",
            "authenticity_score": 0.7,
            "tone_appropriateness": 0.75,
            "controversial_risk": "low",
            "controversial_elements": [],
            "positive_aspects": ["Engaging tone"] if positive_count > 0 else [],
            "concerns": ["Limited emotional depth"] if positive_count == 0 and negative_count == 0 else [],
            "suggestions": [
                "Add more emotional language",
                "Consider your audience's preferences"
            ],
            "analysis": f"Basic sentiment analysis indicates {sentiment_label} tone"
        }
