"""Engagement Prediction Analyzer"""
import logging
from typing import Dict, Any
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("engagement_predictor")

class EngagementPredictor:
    """Predicts engagement potential of social media posts"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"EngagementPredictor initialized with model: {model_name}")

    def predict(self, content: str, platform: str, has_visual: bool = False) -> Dict[str, Any]:
        """
        Predict engagement potential of a post

        Args:
            content: Post text content
            platform: Social media platform (instagram, twitter, facebook, linkedin, tiktok)
            has_visual: Whether the post includes image/video

        Returns:
            Dictionary with engagement prediction results
        """
        logger.info(f"Predicting engagement for {platform} post")

        try:
            prompt = f"""Analyze the following social media post and predict its engagement potential.

PLATFORM: {platform}
HAS VISUAL CONTENT: {'Yes' if has_visual else 'No'}
POST CONTENT:
{content}

Evaluate the post based on:
1. Content quality and relevance
2. Emotional appeal and storytelling
3. Call-to-action effectiveness
4. Length appropriateness for platform
5. Use of trending topics or keywords
6. Potential virality factors
7. Authenticity and relatability

Provide your analysis in the following JSON format:
{{
    "engagement_score": <float 1-10>,
    "predicted_likes": "<low|medium|high|very high>",
    "predicted_comments": "<low|medium|high|very high>",
    "predicted_shares": "<low|medium|high|very high>",
    "virality_potential": <float 0-1>,
    "strengths": ["strength1", "strength2", "strength3"],
    "weaknesses": ["weakness1", "weakness2"],
    "improvement_suggestions": ["suggestion1", "suggestion2", "suggestion3"],
    "target_audience_match": <float 0-1>,
    "key_insights": "Brief analysis of engagement potential"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response to extract JSON
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Engagement prediction complete: score={result.get('engagement_score'):.1f}, "
                       f"virality={result.get('virality_potential'):.2f}")

            return result

        except Exception as e:
            logger.error(f"Error predicting engagement: {e}")
            return self._fallback_prediction(content, has_visual)

    def _fallback_prediction(self, content: str, has_visual: bool) -> Dict[str, Any]:
        """Fallback basic engagement prediction"""
        logger.info("Using fallback engagement prediction")

        content_length = len(content)
        has_question = "?" in content
        has_cta = any(word in content.lower() for word in ["click", "link", "check", "visit", "comment", "share"])

        # Simple scoring
        score = 5.0
        if has_visual:
            score += 1.5
        if 50 <= content_length <= 300:
            score += 1.0
        if has_question or has_cta:
            score += 0.5

        score = min(score, 10.0)

        engagement_level = "medium"
        if score >= 8:
            engagement_level = "high"
        elif score >= 6:
            engagement_level = "medium"
        else:
            engagement_level = "low"

        return {
            "engagement_score": score,
            "predicted_likes": engagement_level,
            "predicted_comments": engagement_level,
            "predicted_shares": "low" if score < 7 else "medium",
            "virality_potential": (score - 5) / 5,
            "strengths": ["Content provided"] + (["Visual content included"] if has_visual else []),
            "weaknesses": ["Unable to perform detailed analysis"],
            "improvement_suggestions": ["Add compelling visuals", "Include clear call-to-action"],
            "target_audience_match": 0.7,
            "key_insights": "Basic engagement estimation based on content characteristics"
        }
