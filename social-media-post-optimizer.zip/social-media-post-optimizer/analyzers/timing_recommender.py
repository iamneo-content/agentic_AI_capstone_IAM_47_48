"""Timing Recommendation Analyzer"""
import logging
from typing import Dict, Any, List
from datetime import datetime, timedelta
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("timing_recommender")

class TimingRecommender:
    """Recommends optimal posting times for social media"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"TimingRecommender initialized with model: {model_name}")

    def recommend(self, platform: str, content_type: str, target_audience: str, account_type: str) -> Dict[str, Any]:
        """
        Recommend optimal posting times

        Args:
            platform: Social media platform
            content_type: Type of content (image, video, text, carousel, etc.)
            target_audience: Target audience demographic
            account_type: Type of account (personal, business, influencer)

        Returns:
            Dictionary with timing recommendations
        """
        logger.info(f"Recommending posting times for {platform} ({account_type})")

        try:
            timezone = get_config_value("TIMEZONE", "America/New_York")

            prompt = f"""Recommend optimal posting times for a social media post.

PLATFORM: {platform}
CONTENT TYPE: {content_type}
TARGET AUDIENCE: {target_audience}
ACCOUNT TYPE: {account_type}
TIMEZONE: {timezone}

Consider:
1. Platform-specific peak engagement times
2. Target audience behavior patterns
3. Day of week effectiveness
4. Content type performance timing
5. Competition and feed saturation
6. Global vs local audience reach

Provide recommendations in the following JSON format:
{{
    "best_times": [
        {{"day": "Monday", "time": "09:00", "reason": "High engagement during morning commute"}},
        {{"day": "Monday", "time": "19:00", "reason": "Evening leisure browsing peak"}},
        {{"day": "Wednesday", "time": "12:00", "reason": "Lunch break engagement"}}
    ],
    "avoid_times": [
        {{"day": "Saturday", "time": "03:00", "reason": "Very low activity period"}},
        {{"day": "Sunday", "time": "05:00", "reason": "Minimal user presence"}}
    ],
    "optimal_days": ["Monday", "Wednesday", "Thursday"],
    "worst_days": ["Saturday", "Sunday"],
    "posting_frequency": "<1-3 per day|3-5 per day|5+ per day>",
    "peak_engagement_windows": [
        {{"start": "09:00", "end": "11:00", "quality": "high"}},
        {{"start": "19:00", "end": "21:00", "quality": "very high"}}
    ],
    "platform_insights": "Platform-specific timing insights",
    "audience_insights": "Audience behavior patterns",
    "recommendations": ["recommendation1", "recommendation2"],
    "best_overall_time": "Wednesday at 12:00"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response to extract JSON
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Timing recommendations generated: "
                       f"best_time={result.get('best_overall_time')}, "
                       f"{len(result.get('best_times', []))} time slots recommended")

            return result

        except Exception as e:
            logger.error(f"Error recommending timing: {e}")
            return self._fallback_timing_recommendation(platform, account_type)

    def _fallback_timing_recommendation(self, platform: str, account_type: str) -> Dict[str, Any]:
        """Fallback basic timing recommendations"""
        logger.info("Using fallback timing recommendations")

        # Platform-specific defaults based on research
        platform_times = {
            "instagram": {
                "best_times": [
                    {"day": "Monday", "time": "11:00", "reason": "Late morning engagement peak"},
                    {"day": "Wednesday", "time": "14:00", "reason": "Midweek afternoon activity"},
                    {"day": "Friday", "time": "10:00", "reason": "Weekend anticipation browsing"}
                ],
                "optimal_days": ["Monday", "Wednesday", "Friday"],
                "best_overall_time": "Wednesday at 14:00"
            },
            "twitter": {
                "best_times": [
                    {"day": "Monday", "time": "12:00", "reason": "Lunch break scrolling"},
                    {"day": "Wednesday", "time": "09:00", "reason": "Morning news check"},
                    {"day": "Friday", "time": "17:00", "reason": "End of workday engagement"}
                ],
                "optimal_days": ["Monday", "Wednesday", "Friday"],
                "best_overall_time": "Monday at 12:00"
            },
            "linkedin": {
                "best_times": [
                    {"day": "Tuesday", "time": "10:00", "reason": "Business hours peak"},
                    {"day": "Wednesday", "time": "12:00", "reason": "Lunch networking time"},
                    {"day": "Thursday", "time": "14:00", "reason": "Afternoon professional browsing"}
                ],
                "optimal_days": ["Tuesday", "Wednesday", "Thursday"],
                "best_overall_time": "Wednesday at 12:00"
            },
            "facebook": {
                "best_times": [
                    {"day": "Monday", "time": "15:00", "reason": "Afternoon engagement spike"},
                    {"day": "Thursday", "time": "20:00", "reason": "Evening leisure browsing"},
                    {"day": "Friday", "time": "13:00", "reason": "Pre-weekend activity"}
                ],
                "optimal_days": ["Monday", "Thursday", "Friday"],
                "best_overall_time": "Thursday at 20:00"
            },
            "tiktok": {
                "best_times": [
                    {"day": "Tuesday", "time": "18:00", "reason": "After school/work scrolling"},
                    {"day": "Thursday", "time": "19:00", "reason": "Peak evening engagement"},
                    {"day": "Friday", "time": "16:00", "reason": "Weekend warm-up period"}
                ],
                "optimal_days": ["Tuesday", "Thursday", "Friday"],
                "best_overall_time": "Thursday at 19:00"
            }
        }

        platform_data = platform_times.get(platform.lower(), platform_times["instagram"])

        return {
            "best_times": platform_data["best_times"],
            "avoid_times": [
                {"day": "Saturday", "time": "03:00", "reason": "Very low activity period"},
                {"day": "Sunday", "time": "05:00", "reason": "Minimal user presence"}
            ],
            "optimal_days": platform_data["optimal_days"],
            "worst_days": ["Late Saturday", "Early Sunday"],
            "posting_frequency": "1-3 per day" if account_type == "personal" else "3-5 per day",
            "peak_engagement_windows": [
                {"start": "09:00", "end": "11:00", "quality": "high"},
                {"start": "14:00", "end": "16:00", "quality": "high"},
                {"start": "19:00", "end": "21:00", "quality": "very high"}
            ],
            "platform_insights": f"Based on general {platform} user behavior patterns",
            "audience_insights": "Timing optimized for general audience in your timezone",
            "recommendations": [
                "Test different posting times and track engagement",
                "Consider your specific audience's schedule",
                "Post consistently at chosen times"
            ],
            "best_overall_time": platform_data["best_overall_time"]
        }
