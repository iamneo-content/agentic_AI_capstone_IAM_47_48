"""Hashtag Optimizer Agent - Coordinates hashtag optimization"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.hashtag_optimizer import HashtagOptimizer

logger = logging.getLogger("hashtag_agent")


class HashtagAgent(BaseAgent):
    """Agent that coordinates hashtag optimization using HashtagOptimizer"""

    def __init__(self):
        super().__init__("HashtagAgent")
        self.analyzer = HashtagOptimizer()
        self.log("Initialized with HashtagOptimizer")

    def analyze(self, post_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Optimize hashtags for post

        Args:
            post_data: Post data containing content and platform

        Returns:
            Hashtag optimization results
        """
        self.log("Starting hashtag optimization")

        try:
            content = post_data.get("post_content", "")
            platform = post_data.get("platform", "instagram")

            result = self.analyzer.optimize(content, platform)

            suggested = result.get("suggested_hashtags", [])
            self.log(f"Suggested {len(suggested)} hashtags")
            return result

        except Exception as e:
            self.log(f"Error in hashtag optimization: {e}", "error")
            return {
                "hashtag_score": 0,
                "suggested_hashtags": [],
                "error": str(e)
            }
