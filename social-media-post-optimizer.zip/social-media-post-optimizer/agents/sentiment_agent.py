"""Sentiment Analyzer Agent - Coordinates sentiment analysis"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.sentiment_analyzer import SentimentAnalyzer

logger = logging.getLogger("sentiment_agent")


class SentimentAgent(BaseAgent):
    """Agent that coordinates sentiment analysis using SentimentAnalyzer"""

    def __init__(self):
        super().__init__("SentimentAgent")
        self.analyzer = SentimentAnalyzer()
        self.log("Initialized with SentimentAnalyzer")

    def analyze(self, post_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze post sentiment

        Args:
            post_data: Post data containing content and platform

        Returns:
            Sentiment analysis results
        """
        self.log("Starting sentiment analysis")

        try:
            content = post_data.get("post_content", "")
            platform = post_data.get("platform", "instagram")

            result = self.analyzer.analyze(content, platform)

            sentiment = result.get("sentiment_label", "neutral")
            self.log(f"Sentiment: {sentiment}")
            return result

        except Exception as e:
            self.log(f"Error in sentiment analysis: {e}", "error")
            return {
                "sentiment_score": 0.5,
                "sentiment_label": "neutral",
                "error": str(e)
            }
