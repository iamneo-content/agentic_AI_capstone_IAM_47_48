"""Visual Quality Agent - Coordinates visual quality analysis"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.visual_quality_analyzer import VisualQualityAnalyzer

logger = logging.getLogger("visual_quality_agent")


class VisualQualityAgent(BaseAgent):
    """Agent that coordinates visual quality analysis using VisualQualityAnalyzer"""

    def __init__(self):
        super().__init__("VisualQualityAgent")
        self.analyzer = VisualQualityAnalyzer()
        self.log("Initialized with VisualQualityAnalyzer")

    def analyze(self, post_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze visual content quality

        Args:
            post_data: Post data containing image_url, video_url, platform

        Returns:
            Visual quality analysis results
        """
        self.log("Starting visual quality analysis")

        try:
            image_url = post_data.get("image_url", "")
            video_url = post_data.get("video_url", "")
            platform = post_data.get("platform", "instagram")

            result = self.analyzer.analyze(image_url, video_url, platform)

            score = result.get("quality_score", 0)
            self.log(f"Visual quality score: {score}/10")
            return result

        except Exception as e:
            self.log(f"Error in visual quality analysis: {e}", "error")
            return {
                "quality_score": 0,
                "has_visual": False,
                "error": str(e)
            }
