"""Engagement Predictor Agent - Coordinates engagement prediction"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.engagement_predictor import EngagementPredictor

logger = logging.getLogger("engagement_agent")


class EngagementAgent(BaseAgent):
    """Agent that coordinates engagement prediction using EngagementPredictor"""

    def __init__(self):
        super().__init__("EngagementAgent")
        self.analyzer = EngagementPredictor()
        self.log("Initialized with EngagementPredictor")

    def analyze(self, post_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict post engagement

        Args:
            post_data: Post data containing content, platform, etc.

        Returns:
            Engagement prediction results
        """
        self.log("Starting engagement prediction")

        try:
            content = post_data.get("post_content", "")
            platform = post_data.get("platform", "instagram")
            has_visual = bool(post_data.get("image_url") or post_data.get("video_url"))

            result = self.analyzer.predict(content, platform, has_visual)

            self.log(f"Engagement score: {result.get('engagement_score', 0)}/10")
            return result

        except Exception as e:
            self.log(f"Error in engagement prediction: {e}", "error")
            return {
                "engagement_score": 0,
                "error": str(e)
            }
