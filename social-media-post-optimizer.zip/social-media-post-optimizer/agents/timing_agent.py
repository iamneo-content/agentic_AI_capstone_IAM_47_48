"""Timing Recommender Agent - Coordinates timing recommendations"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.timing_recommender import TimingRecommender

logger = logging.getLogger("timing_agent")


class TimingAgent(BaseAgent):
    """Agent that coordinates timing recommendations using TimingRecommender"""

    def __init__(self):
        super().__init__("TimingAgent")
        self.analyzer = TimingRecommender()
        self.log("Initialized with TimingRecommender")

    def analyze(self, post_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Recommend optimal posting times

        Args:
            post_data: Post data containing platform, audience, etc.

        Returns:
            Timing recommendation results
        """
        self.log("Starting timing recommendations")

        try:
            platform = post_data.get("platform", "instagram")
            content_type = "video" if post_data.get("video_url") else ("image" if post_data.get("image_url") else "text")
            target_audience = post_data.get("target_audience", "general")

            from config import get_config_value
            account_type = get_config_value("ACCOUNT_TYPE", "personal")

            result = self.analyzer.recommend(platform, content_type, target_audience, account_type)

            times = result.get("best_times", [])
            self.log(f"Recommended {len(times)} optimal posting times")
            return result

        except Exception as e:
            self.log(f"Error in timing recommendations: {e}", "error")
            return {
                "best_times": [],
                "error": str(e)
            }
