"""Coordinator Agent - Coordinates final post optimization"""
import logging
from typing import Dict, Any, List
from agents.base_agent import BaseAgent

logger = logging.getLogger("coordinator_agent")


class CoordinatorAgent(BaseAgent):
    """Coordinates all analyzers and makes final optimization decisions"""

    def __init__(self):
        super().__init__("CoordinatorAgent")
        self.log("Initialized")

    def analyze(
        self,
        engagement_results: List[Dict[str, Any]],
        hashtag_results: List[Dict[str, Any]],
        sentiment_results: List[Dict[str, Any]],
        timing_results: List[Dict[str, Any]],
        visual_results: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Make final optimization decisions based on all analysis results

        Args:
            engagement_results: Engagement prediction results
            hashtag_results: Hashtag optimization results
            sentiment_results: Sentiment analysis results
            timing_results: Timing recommendation results
            visual_results: Visual quality analysis results

        Returns:
            Complete optimization recommendations
        """
        self.log("=" * 70)
        self.log("FINAL POST OPTIMIZATION")
        self.log("=" * 70)

        try:
            # Extract scores from results
            engagement_score = engagement_results[0].get("engagement_score", 0) if engagement_results else 0
            hashtag_score = hashtag_results[0].get("hashtag_score", 0) if hashtag_results else 0
            sentiment_score = sentiment_results[0].get("sentiment_score", 0.5) if sentiment_results else 0.5
            visual_score = visual_results[0].get("quality_score", 0) if visual_results else 0
            suggested_hashtags = hashtag_results[0].get("suggested_hashtags", []) if hashtag_results else []
            best_times = timing_results[0].get("best_times", []) if timing_results else []

            # Calculate overall score with weighted components
            weights = {
                "engagement": 0.30,
                "hashtag": 0.20,
                "sentiment": 0.20,
                "visual": 0.20,
                "timing": 0.10
            }

            # Normalize sentiment to 0-10 scale
            sentiment_norm = sentiment_score * 10
            timing_norm = 8.0  # Assume timing recommendations are good

            overall_score = (
                engagement_score * weights["engagement"] +
                hashtag_score * weights["hashtag"] +
                sentiment_norm * weights["sentiment"] +
                visual_score * weights["visual"] +
                timing_norm * weights["timing"]
            )

            # Determine optimization grade
            if overall_score >= 9.0:
                grade = "Excellent"
            elif overall_score >= 8.0:
                grade = "Very Good"
            elif overall_score >= 7.0:
                grade = "Good"
            elif overall_score >= 6.0:
                grade = "Fair"
            else:
                grade = "Needs Improvement"

            # Determine if ready to post
            from config import get_config_value
            threshold = get_config_value("OVERALL_SCORE_THRESHOLD", 7.5)
            ready_to_post = overall_score >= threshold

            # Generate optimizations
            optimizations = self._generate_optimizations(
                engagement_score, hashtag_score, sentiment_score, visual_score,
                engagement_results, hashtag_results, sentiment_results, visual_results
            )

            # Select optimal posting time
            recommended_time_str = None
            if best_times:
                best_time = best_times[0]
                recommended_time_str = f"{best_time.get('day')} at {best_time.get('time')}"

            # Build coordination summary
            coordination_summary = {
                "analyses_completed": [
                    "Engagement Prediction",
                    "Hashtag Optimization",
                    "Sentiment Analysis",
                    "Timing Recommendations",
                    "Visual Quality Analysis"
                ],
                "engagement_score": engagement_score,
                "hashtag_score": hashtag_score,
                "sentiment_score": sentiment_score,
                "visual_score": visual_score,
                "overall_score": overall_score,
                "grade": grade
            }

            self.log(f"Overall Score: {overall_score:.2f}/10")
            self.log(f"Grade: {grade}")
            self.log(f"Ready to Post: {'YES' if ready_to_post else 'NO - NEEDS OPTIMIZATION'}")
            self.log(f"Generated {len(optimizations)} optimization recommendations")
            self.log("=" * 70)

            return {
                "coordination_summary": coordination_summary,
                "overall_score": overall_score,
                "optimization_grade": grade,
                "ready_to_post": ready_to_post,
                "optimizations": optimizations,
                "optimized_hashtags": suggested_hashtags[:10],
                "recommended_posting_time": recommended_time_str
            }

        except Exception as e:
            self.log(f"Error in coordination: {e}", "error")
            return {
                "error": str(e),
                "overall_score": 0,
                "optimization_grade": "Error",
                "ready_to_post": False,
                "optimizations": []
            }

    def _generate_optimizations(self, eng_score, hash_score, sent_score, vis_score,
                                eng_results, hash_results, sent_results, vis_results):
        """Generate comprehensive optimization recommendations"""
        optimizations = []

        # Engagement optimizations
        if eng_score < 7.0:
            optimizations.append({
                "category": "Engagement",
                "priority": "high",
                "suggestion": "Improve content hook and call-to-action to boost engagement",
                "specific_actions": eng_results[0].get("improvement_suggestions", []) if eng_results else []
            })

        # Hashtag optimizations
        if hash_score < 7.0:
            optimizations.append({
                "category": "Hashtags",
                "priority": "medium",
                "suggestion": "Optimize hashtag strategy for better reach",
                "specific_actions": hash_results[0].get("recommendations", []) if hash_results else []
            })

        # Sentiment optimizations
        if sent_score < 0.5:
            optimizations.append({
                "category": "Sentiment",
                "priority": "high",
                "suggestion": "Adjust tone to be more positive and engaging",
                "specific_actions": sent_results[0].get("suggestions", []) if sent_results else []
            })

        # Visual optimizations
        if vis_results and not vis_results[0].get("has_visual", False):
            optimizations.append({
                "category": "Visual Content",
                "priority": "high",
                "suggestion": "Add high-quality visual content to increase engagement by 2-3x",
                "specific_actions": ["Create or select relevant image", "Optimize for platform dimensions"]
            })
        elif vis_score < 7.0:
            optimizations.append({
                "category": "Visual Quality",
                "priority": "medium",
                "suggestion": "Improve visual content quality",
                "specific_actions": vis_results[0].get("improvements", []) if vis_results else []
            })

        # Add positive feedback if score is high
        if not optimizations:
            optimizations.append({
                "category": "Overall",
                "priority": "low",
                "suggestion": "Post is well-optimized and ready to publish",
                "specific_actions": ["Maintain current quality standards", "Track performance metrics"]
            })

        return optimizations
