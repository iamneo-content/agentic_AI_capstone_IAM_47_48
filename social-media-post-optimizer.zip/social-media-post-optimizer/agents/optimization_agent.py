"""Social Media Post Optimization Agent"""
import logging
from typing import Dict, Any, List
from state import PostState
from analyzers import (
    EngagementPredictor,
    HashtagOptimizer,
    SentimentAnalyzer,
    TimingRecommender,
    VisualQualityAnalyzer
)

logger = logging.getLogger("optimization_agent")

class OptimizationAgent:
    """Coordinates all analyzers and makes final optimization decisions"""

    def __init__(self):
        self.engagement_predictor = EngagementPredictor()
        self.hashtag_optimizer = HashtagOptimizer()
        self.sentiment_analyzer = SentimentAnalyzer()
        self.timing_recommender = TimingRecommender()
        self.visual_analyzer = VisualQualityAnalyzer()
        logger.info("OptimizationAgent initialized with all analyzers")

    def optimize_post(self, state: PostState) -> PostState:
        """
        Make final optimization decisions and generate recommendations

        Args:
            state: Current post state with analysis results

        Returns:
            Updated state with optimization recommendations
        """
        logger.info("=" * 70)
        logger.info("FINAL POST OPTIMIZATION")
        logger.info("=" * 70)

        try:
            # Calculate overall score with weighted components
            weights = {
                "engagement": 0.30,
                "hashtag": 0.20,
                "sentiment": 0.20,
                "visual": 0.20,
                "timing": 0.10  # Timing is binary (good/bad), less weighted
            }

            # Normalize scores to 0-10 scale
            engagement_norm = state.engagement_score
            hashtag_norm = state.hashtag_score
            sentiment_norm = state.sentiment_score * 10  # Convert 0-1 to 0-10
            visual_norm = state.visual_quality_score if state.visual_quality_score > 0 else 5.0  # Default if no visual
            timing_norm = 8.0  # Assume timing recommendations are good

            overall_score = (
                engagement_norm * weights["engagement"] +
                hashtag_norm * weights["hashtag"] +
                sentiment_norm * weights["sentiment"] +
                visual_norm * weights["visual"] +
                timing_norm * weights["timing"]
            )

            # Determine optimization grade
            if overall_score >= 9.0:
                grade = "Excellent"
            elif overall_score >= 8.0:
                grade = "Very Good"
            elif overall_score >= 7.0:
                grade = "Good"
            elif overall_score >= 6.0:
                grade = "Fair"
            else:
                grade = "Needs Improvement"

            # Determine if ready to post
            from config import get_config_value
            threshold = get_config_value("OVERALL_SCORE_THRESHOLD", 7.5)
            ready_to_post = overall_score >= threshold

            # Generate comprehensive optimizations
            optimizations = self._generate_optimizations(state)

            # Generate optimized content
            optimized_content = self._generate_optimized_content(state)

            # Select best hashtags
            optimal_hashtag_count = get_config_value("OPTIMAL_HASHTAGS", 10)
            optimized_hashtags = state.suggested_hashtags[:optimal_hashtag_count]

            # Select recommended posting time
            recommended_time = state.best_posting_times[0] if state.best_posting_times else None
            recommended_time_str = None
            if recommended_time:
                recommended_time_str = f"{recommended_time.get('day')} at {recommended_time.get('time')}"

            # Update state
            state.overall_score = overall_score
            state.optimization_grade = grade
            state.ready_to_post = ready_to_post
            state.optimizations = optimizations
            state.optimized_content = optimized_content
            state.optimized_hashtags = optimized_hashtags
            state.recommended_posting_time = recommended_time_str

            logger.info(f"Overall Score: {overall_score:.2f}/10")
            logger.info(f"Grade: {grade}")
            logger.info(f"Ready to Post: {'YES' if ready_to_post else 'NO - NEEDS OPTIMIZATION'}")
            logger.info(f"Generated {len(optimizations)} optimization recommendations")
            logger.info("=" * 70)

            return state

        except Exception as e:
            logger.error(f"Error in post optimization: {e}")
            state.error = str(e)
            return state

    def _generate_optimizations(self, state: PostState) -> List[Dict[str, Any]]:
        """Generate comprehensive optimization recommendations"""
        optimizations = []

        # Engagement optimizations
        if state.engagement_score < 7.0:
            optimizations.append({
                "category": "Engagement",
                "priority": "high",
                "suggestion": "Improve content hook and call-to-action to boost engagement",
                "specific_actions": state.engagement_prediction.get("improvement_suggestions", [])
            })

        # Hashtag optimizations
        if state.hashtag_score < 7.0:
            optimizations.append({
                "category": "Hashtags",
                "priority": "medium",
                "suggestion": "Optimize hashtag strategy for better reach",
                "specific_actions": state.hashtag_analysis.get("recommendations", [])
            })

        # Sentiment optimizations
        if state.sentiment_score < 0.5:
            optimizations.append({
                "category": "Sentiment",
                "priority": "high",
                "suggestion": "Adjust tone to be more positive and engaging",
                "specific_actions": state.sentiment_analysis.get("suggestions", [])
            })
        elif state.sentiment_analysis.get("controversial_risk") == "high":
            optimizations.append({
                "category": "Sentiment",
                "priority": "critical",
                "suggestion": "Review potentially controversial content",
                "specific_actions": state.sentiment_analysis.get("controversial_elements", [])
            })

        # Visual optimizations
        if not state.visual_analysis.get("has_visual", False):
            optimizations.append({
                "category": "Visual Content",
                "priority": "high",
                "suggestion": "Add high-quality visual content to increase engagement by 2-3x",
                "specific_actions": ["Create or select relevant image", "Optimize for platform dimensions"]
            })
        elif state.visual_quality_score < 7.0:
            optimizations.append({
                "category": "Visual Quality",
                "priority": "medium",
                "suggestion": "Improve visual content quality",
                "specific_actions": state.visual_analysis.get("improvements", [])
            })

        # Timing optimization
        if state.best_posting_times:
            best_time = state.best_posting_times[0]
            optimizations.append({
                "category": "Timing",
                "priority": "medium",
                "suggestion": f"Schedule post for {best_time.get('day')} at {best_time.get('time')}",
                "specific_actions": [best_time.get("reason", "Optimal engagement window")]
            })

        # Add positive feedback if score is high
        if state.overall_score >= 8.0:
            optimizations.insert(0, {
                "category": "Overall",
                "priority": "low",
                "suggestion": "Post is well-optimized and ready to publish",
                "specific_actions": ["Maintain current quality standards", "Track performance metrics"]
            })

        return optimizations

    def _generate_optimized_content(self, state: PostState) -> str:
        """Generate optimized version of content"""
        original_content = state.post_content

        # Add suggested hashtags if not already present
        if state.suggested_hashtags and not any("#" in original_content for _ in range(3)):
            hashtag_line = " ".join(state.optimized_hashtags[:10])
            optimized = f"{original_content}\n\n{hashtag_line}"
        else:
            optimized = original_content

        # Add call-to-action if engagement is low
        if state.engagement_score < 7.0:
            cta_suggestions = [
                "What do you think? Comment below! 👇",
                "Double tap if you agree! ❤️",
                "Share your thoughts in the comments!",
                "Tag someone who needs to see this!"
            ]
            # Pick first CTA that's not already in content
            for cta in cta_suggestions:
                if cta.lower() not in optimized.lower():
                    optimized += f"\n\n{cta}"
                    break

        return optimized
