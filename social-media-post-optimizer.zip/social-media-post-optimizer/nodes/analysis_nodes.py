"""Workflow Node Functions"""
import logging
from state import PostState
from agents import (
    EngagementAgent,
    HashtagAgent,
    SentimentAgent,
    TimingAgent,
    VisualQualityAgent,
    CoordinatorAgent
)

logger = logging.getLogger("nodes")

def predict_engagement(state: PostState) -> PostState:
    """Node: Predict post engagement using agent"""
    logger.info("NODE: Predicting engagement")
    try:
        agent = EngagementAgent()
        post_data = {
            "post_content": state.post_content,
            "platform": state.platform,
            "image_url": state.image_url,
            "video_url": state.video_url
        }
        result = agent.analyze(post_data)

        state.engagement_score = result.get("engagement_score", 0)
        state.engagement_prediction = result
        state.metadata["engagement_analysis_complete"] = True

        logger.info(f"Engagement score: {state.engagement_score}/10")
        return state
    except Exception as e:
        logger.error(f"Error in predict_engagement: {e}")
        state.error = str(e)
        return state

def optimize_hashtags(state: PostState) -> PostState:
    """Node: Optimize hashtags using agent"""
    logger.info("NODE: Optimizing hashtags")
    try:
        agent = HashtagAgent()
        post_data = {
            "post_content": state.post_content,
            "platform": state.platform
        }
        result = agent.analyze(post_data)

        state.hashtag_score = result.get("hashtag_score", 0)
        state.suggested_hashtags = result.get("suggested_hashtags", [])
        state.hashtag_analysis = result
        state.metadata["hashtag_optimization_complete"] = True

        logger.info(f"Hashtag score: {state.hashtag_score}/10, "
                   f"suggested {len(state.suggested_hashtags)} hashtags")
        return state
    except Exception as e:
        logger.error(f"Error in optimize_hashtags: {e}")
        state.error = str(e)
        return state

def analyze_sentiment(state: PostState) -> PostState:
    """Node: Analyze sentiment using agent"""
    logger.info("NODE: Analyzing sentiment")
    try:
        agent = SentimentAgent()
        post_data = {
            "post_content": state.post_content,
            "platform": state.platform
        }
        result = agent.analyze(post_data)

        state.sentiment_score = result.get("sentiment_score", 0.5)
        state.sentiment_label = result.get("sentiment_label", "neutral")
        state.sentiment_analysis = result
        state.metadata["sentiment_analysis_complete"] = True

        # Add warnings for controversial content
        if result.get("controversial_risk") == "high":
            state.warnings.append("High controversial risk detected")
        if result.get("controversial_elements"):
            state.warnings.extend(result.get("controversial_elements", []))

        logger.info(f"Sentiment: {state.sentiment_label}, score: {state.sentiment_score:.2f}")
        return state
    except Exception as e:
        logger.error(f"Error in analyze_sentiment: {e}")
        state.error = str(e)
        return state

def recommend_timing(state: PostState) -> PostState:
    """Node: Recommend optimal posting times using agent"""
    logger.info("NODE: Recommending posting times")
    try:
        agent = TimingAgent()
        post_data = {
            "platform": state.platform,
            "image_url": state.image_url,
            "video_url": state.video_url,
            "target_audience": state.target_audience
        }
        result = agent.analyze(post_data)

        state.best_posting_times = result.get("best_times", [])
        state.timing_analysis = result
        state.metadata["timing_analysis_complete"] = True

        logger.info(f"Recommended {len(state.best_posting_times)} optimal posting times")
        return state
    except Exception as e:
        logger.error(f"Error in recommend_timing: {e}")
        state.error = str(e)
        return state

def analyze_visual_quality(state: PostState) -> PostState:
    """Node: Analyze visual content quality using agent"""
    logger.info("NODE: Analyzing visual quality")
    try:
        agent = VisualQualityAgent()
        post_data = {
            "image_url": state.image_url,
            "video_url": state.video_url,
            "platform": state.platform
        }
        result = agent.analyze(post_data)

        state.visual_quality_score = result.get("quality_score", 0)
        state.visual_analysis = result
        state.metadata["visual_analysis_complete"] = True

        if not result.get("has_visual", False):
            state.warnings.append("No visual content - posts with visuals get 2-3x more engagement")

        logger.info(f"Visual quality score: {state.visual_quality_score}/10")
        return state
    except Exception as e:
        logger.error(f"Error in analyze_visual_quality: {e}")
        state.error = str(e)
        return state

def final_optimization(state: PostState) -> PostState:
    """Node: Perform final optimization using coordinator agent"""
    logger.info("NODE: Performing final optimization")
    try:
        # Prepare results for coordinator
        engagement_results = [state.engagement_prediction] if hasattr(state, 'engagement_prediction') else []
        hashtag_results = [state.hashtag_analysis] if hasattr(state, 'hashtag_analysis') else []
        sentiment_results = [state.sentiment_analysis] if hasattr(state, 'sentiment_analysis') else []
        timing_results = [state.timing_analysis] if hasattr(state, 'timing_analysis') else []
        visual_results = [state.visual_analysis] if hasattr(state, 'visual_analysis') else []

        agent = CoordinatorAgent()
        result = agent.analyze(
            engagement_results,
            hashtag_results,
            sentiment_results,
            timing_results,
            visual_results
        )

        state.overall_score = result.get("overall_score", 0)
        state.optimization_grade = result.get("optimization_grade", "Unknown")
        state.ready_to_post = result.get("ready_to_post", False)
        state.optimizations = result.get("optimizations", [])
        state.optimized_hashtags = result.get("optimized_hashtags", [])
        state.recommended_posting_time = result.get("recommended_posting_time", None)
        state.coordination_summary = result.get("coordination_summary", {})
        state.metadata["final_optimization_complete"] = True

        return state
    except Exception as e:
        logger.error(f"Error in final_optimization: {e}")
        state.error = str(e)
        return state

def send_report(state: PostState) -> PostState:
    """Node: Send optimization report via email"""
    logger.info("NODE: Sending report")
    try:
        from services.email_service import send_optimization_report

        success = send_optimization_report(state)

        if success:
            state.notification_sent = True
            logger.info("Report sent successfully")
        else:
            logger.warning("Failed to send report")

        state.metadata["report_complete"] = True
        return state
    except Exception as e:
        logger.error(f"Error in send_report: {e}")
        # Don't fail the workflow if report fails
        state.metadata["report_error"] = str(e)
        return state
