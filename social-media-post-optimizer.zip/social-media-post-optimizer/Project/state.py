"""Social Media Post State Management"""
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class PostState:
    """
    Represents the state of a social media post through the optimization workflow
    """
    # Input data
    post_id: str
    post_content: str
    platform: str = "instagram"
    image_url: Optional[str] = None
    video_url: Optional[str] = None
    target_audience: str = "general"

    # Metadata
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Analysis results
    engagement_score: float = 0.0
    engagement_prediction: Dict[str, Any] = field(default_factory=dict)

    hashtag_score: float = 0.0
    suggested_hashtags: List[str] = field(default_factory=list)
    hashtag_analysis: Dict[str, Any] = field(default_factory=dict)

    sentiment_score: float = 0.5
    sentiment_label: str = "neutral"
    sentiment_analysis: Dict[str, Any] = field(default_factory=dict)

    best_posting_times: List[Dict[str, Any]] = field(default_factory=list)
    timing_analysis: Dict[str, Any] = field(default_factory=dict)

    visual_quality_score: float = 0.0
    visual_analysis: Dict[str, Any] = field(default_factory=dict)

    # Overall assessment
    overall_score: float = 0.0
    optimization_grade: str = "Unknown"
    ready_to_post: bool = False

    # Recommendations
    optimizations: List[Dict[str, Any]] = field(default_factory=list)
    content_suggestions: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    # Optimized version
    optimized_content: Optional[str] = None
    optimized_hashtags: List[str] = field(default_factory=list)
    recommended_posting_time: Optional[str] = None

    # Workflow status
    workflow_complete: bool = False
    notification_sent: bool = False
    error: Optional[str] = None

    def clone(self) -> 'PostState':
        """Create a deep copy of the state"""
        import copy
        return copy.deepcopy(self)

    def merge_from(self, other: 'PostState') -> None:
        """Merge data from another state (for parallel node results)"""
        if other is None:
            return

        # Merge scores
        if other.engagement_score > 0:
            self.engagement_score = other.engagement_score
            self.engagement_prediction = other.engagement_prediction

        if other.hashtag_score > 0:
            self.hashtag_score = other.hashtag_score
            self.suggested_hashtags = other.suggested_hashtags
            self.hashtag_analysis = other.hashtag_analysis

        if other.sentiment_score != 0.5:
            self.sentiment_score = other.sentiment_score
            self.sentiment_label = other.sentiment_label
            self.sentiment_analysis = other.sentiment_analysis

        if other.best_posting_times:
            self.best_posting_times = other.best_posting_times
            self.timing_analysis = other.timing_analysis

        if other.visual_quality_score > 0:
            self.visual_quality_score = other.visual_quality_score
            self.visual_analysis = other.visual_analysis

        # Merge lists
        if other.optimizations:
            self.optimizations.extend(other.optimizations)

        if other.content_suggestions:
            self.content_suggestions.extend(other.content_suggestions)

        if other.warnings:
            self.warnings.extend(other.warnings)

        # Merge metadata
        self.metadata.update(other.metadata)

        # Merge error if present
        if other.error:
            self.error = other.error

    def to_dict(self) -> Dict[str, Any]:
        """Convert state to dictionary"""
        return {
            "post_id": self.post_id,
            "post_content": self.post_content,
            "platform": self.platform,
            "engagement_score": self.engagement_score,
            "hashtag_score": self.hashtag_score,
            "sentiment_score": self.sentiment_score,
            "sentiment_label": self.sentiment_label,
            "visual_quality_score": self.visual_quality_score,
            "overall_score": self.overall_score,
            "optimization_grade": self.optimization_grade,
            "ready_to_post": self.ready_to_post,
            "suggested_hashtags": self.suggested_hashtags,
            "best_posting_times": self.best_posting_times,
            "optimizations": self.optimizations,
            "optimized_content": self.optimized_content,
            "recommended_posting_time": self.recommended_posting_time,
            "warnings": self.warnings,
            "timestamp": self.timestamp
        }

    def get_summary(self) -> str:
        """Get a human-readable summary"""
        summary = f"""
Social Media Post Analysis Summary
{'=' * 60}
Post ID: {self.post_id}
Platform: {self.platform}
Timestamp: {self.timestamp}

Overall Score: {self.overall_score:.1f}/10
Grade: {self.optimization_grade}
Ready to Post: {'✅ Yes' if self.ready_to_post else '⚠️ Needs Optimization'}

Detailed Scores:
- Engagement Prediction: {self.engagement_score:.1f}/10
- Hashtag Optimization: {self.hashtag_score:.1f}/10
- Sentiment Analysis: {self.sentiment_score * 10:.1f}/10
- Visual Quality: {self.visual_quality_score:.1f}/10

Recommended Posting Time: {self.recommended_posting_time or 'Not determined'}
Suggested Hashtags: {len(self.suggested_hashtags)} hashtags

{len(self.optimizations)} optimization suggestions available
{len(self.warnings)} warnings found
{'=' * 60}
        """
        return summary.strip()
