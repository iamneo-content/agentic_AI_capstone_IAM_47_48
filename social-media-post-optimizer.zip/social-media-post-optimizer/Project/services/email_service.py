"""Email Notification Service"""
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
from state import PostState
from config import get_config_value

logger = logging.getLogger("email_service")

def send_optimization_report(state: PostState) -> bool:
    """
    Send post optimization report via email

    Args:
        state: PostState containing optimization results

    Returns:
        bool: True if email sent successfully, False otherwise
    """
    try:
        # Get email configuration
        smtp_server = get_config_value("SMTP_SERVER", "smtp.gmail.com")
        smtp_port = get_config_value("SMTP_PORT", 587)
        email_from = get_config_value("EMAIL_FROM")
        email_password = get_config_value("EMAIL_PASSWORD")
        email_to = get_config_value("EMAIL_TO")

        if not all([email_from, email_password, email_to]):
            logger.warning("Email configuration incomplete - skipping notification")
            return False

        # Create email message
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"Post Optimization Report: {state.post_id} - {state.optimization_grade}"
        msg["From"] = email_from
        msg["To"] = email_to

        # Create email body
        html_body = _create_html_report(state)
        text_body = _create_text_report(state)

        # Attach both plain text and HTML versions
        part1 = MIMEText(text_body, "plain")
        part2 = MIMEText(html_body, "html")
        msg.attach(part1)
        msg.attach(part2)

        # Send email
        logger.info(f"Sending optimization report to {email_to}")
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(email_from, email_password)
            server.send_message(msg)

        logger.info("Email sent successfully")
        return True

    except Exception as e:
        logger.error(f"Error sending email: {e}")
        return False

def _create_html_report(state: PostState) -> str:
    """Create HTML email body"""
    status_icon = "✅" if state.ready_to_post else "⚠️"
    status_text = "READY TO POST" if state.ready_to_post else "NEEDS OPTIMIZATION"
    status_color = "#28a745" if state.ready_to_post else "#ffc107"

    # Format optimizations
    optimizations_html = ""
    for opt in state.optimizations[:8]:
        priority = opt.get("priority", "low").upper()
        priority_class = f"priority-{opt.get('priority', 'low')}"
        category = opt.get("category", "General")
        suggestion = opt.get("suggestion", "")

        optimizations_html += f"""
        <tr>
            <td><span class="{priority_class}">{priority}</span></td>
            <td>{category}</td>
            <td>{suggestion}</td>
        </tr>
        """

    # Format hashtags
    hashtags_html = " ".join(state.optimized_hashtags[:15]) if state.optimized_hashtags else "No hashtags suggested"

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
            .container {{ max-width: 900px; margin: 0 auto; padding: 20px; }}
            .header {{ background-color: {status_color}; color: white; padding: 20px; border-radius: 5px; text-align: center; }}
            .score-section {{ display: flex; justify-content: space-around; margin: 20px 0; }}
            .score-box {{ background-color: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center; flex: 1; margin: 0 10px; }}
            .score-value {{ font-size: 32px; font-weight: bold; color: #007bff; }}
            .content-box {{ background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-left: 4px solid #007bff; }}
            table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
            th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background-color: #007bff; color: white; }}
            .priority-critical {{ background-color: #dc3545; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px; }}
            .priority-high {{ background-color: #fd7e14; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px; }}
            .priority-medium {{ background-color: #ffc107; color: #333; padding: 3px 8px; border-radius: 3px; font-size: 11px; }}
            .priority-low {{ background-color: #28a745; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px; }}
            .hashtags {{ color: #007bff; font-family: monospace; }}
            .timing {{ background-color: #e7f3ff; padding: 10px; border-radius: 5px; margin: 10px 0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>{status_icon} Social Media Post Optimization Report</h1>
                <h2>Post ID: {state.post_id}</h2>
                <h3>{status_text}</h3>
            </div>

            <div class="score-section">
                <div class="score-box">
                    <div>Overall Score</div>
                    <div class="score-value">{state.overall_score:.1f}</div>
                    <div>Grade: {state.optimization_grade}</div>
                </div>
                <div class="score-box">
                    <div>Engagement</div>
                    <div class="score-value">{state.engagement_score:.1f}</div>
                </div>
                <div class="score-box">
                    <div>Sentiment</div>
                    <div class="score-value">{state.sentiment_score * 10:.1f}</div>
                    <div>{state.sentiment_label.capitalize()}</div>
                </div>
            </div>

            <div class="content-box">
                <h3>Original Content</h3>
                <p>{state.post_content}</p>
            </div>

            <div class="content-box">
                <h3>Optimized Content</h3>
                <p>{state.optimized_content or state.post_content}</p>
            </div>

            <div class="timing">
                <h3>📅 Best Posting Time</h3>
                <p><strong>{state.recommended_posting_time or "Schedule based on your audience"}</strong></p>
            </div>

            <h3>🏷️ Recommended Hashtags</h3>
            <div class="hashtags">
                <p>{hashtags_html}</p>
            </div>

            <h3>💡 Optimization Recommendations</h3>
            <table>
                <tr>
                    <th>Priority</th>
                    <th>Category</th>
                    <th>Suggestion</th>
                </tr>
                {optimizations_html}
            </table>

            <h3>Detailed Scores</h3>
            <table>
                <tr>
                    <th>Category</th>
                    <th>Score</th>
                </tr>
                <tr>
                    <td>Engagement Prediction</td>
                    <td>{state.engagement_score:.1f}/10</td>
                </tr>
                <tr>
                    <td>Hashtag Optimization</td>
                    <td>{state.hashtag_score:.1f}/10</td>
                </tr>
                <tr>
                    <td>Sentiment Analysis</td>
                    <td>{state.sentiment_score * 10:.1f}/10</td>
                </tr>
                <tr>
                    <td>Visual Quality</td>
                    <td>{state.visual_quality_score:.1f}/10</td>
                </tr>
            </table>

            <p style="color: #6c757d; font-size: 12px; margin-top: 30px;">
                This is an automated optimization report generated by the Social Media Post Optimizer.
            </p>
        </div>
    </body>
    </html>
    """
    return html

def _create_text_report(state: PostState) -> str:
    """Create plain text email body"""
    status_icon = "✓" if state.ready_to_post else "!"
    status_text = "READY TO POST" if state.ready_to_post else "NEEDS OPTIMIZATION"

    optimizations_text = "\n".join([
        f"  [{opt.get('priority', 'low').upper()}] {opt.get('category', 'General')}: {opt.get('suggestion', '')}"
        for opt in state.optimizations[:8]
    ])

    hashtags_text = " ".join(state.optimized_hashtags[:15]) if state.optimized_hashtags else "No hashtags suggested"

    text = f"""
SOCIAL MEDIA POST OPTIMIZATION REPORT
{'=' * 70}

Post ID: {state.post_id}
Platform: {state.platform}
Status: {status_icon} {status_text}

OVERALL SCORE: {state.overall_score:.1f}/10
Grade: {state.optimization_grade}

{'=' * 70}
DETAILED SCORES:
  - Engagement Prediction: {state.engagement_score:.1f}/10
  - Hashtag Optimization: {state.hashtag_score:.1f}/10
  - Sentiment Analysis: {state.sentiment_score * 10:.1f}/10 ({state.sentiment_label})
  - Visual Quality: {state.visual_quality_score:.1f}/10

{'=' * 70}
BEST POSTING TIME:
  {state.recommended_posting_time or "Schedule based on your audience"}

RECOMMENDED HASHTAGS:
  {hashtags_text}

{'=' * 70}
OPTIMIZATION RECOMMENDATIONS:
{optimizations_text}

{'=' * 70}
ORIGINAL CONTENT:
{state.post_content}

OPTIMIZED CONTENT:
{state.optimized_content or state.post_content}

{'=' * 70}
This is an automated optimization report.
    """
    return text
