"""Post Data Service"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("post_service")

def load_post_data(post_id: str) -> Optional[Dict[str, Any]]:
    """
    Load post data from storage or return mock data

    Args:
        post_id: Post identifier

    Returns:
        Post data dictionary or None if not found
    """
    logger.info(f"Loading post data for: {post_id}")
    return create_sample_post(post_id)

def create_sample_post(post_id: str = "POST001", platform: str = "instagram") -> Dict[str, Any]:
    """
    Create sample post data for demonstration

    Args:
        post_id: Post identifier
        platform: Social media platform

    Returns:
        Post data dictionary
    """
    sample_posts = {
        "POST001": {
            "post_id": "POST001",
            "platform": "instagram",
            "content": """Just launched our new sustainable product line! 🌱

We've been working on this for months and couldn't be more excited to share it with you. Each item is made from 100% recycled materials and designed to last a lifetime.

What sustainability practices are most important to you? Let us know in the comments!

#sustainability #ecofriendly #sustainable #zerowaste #climateaction #gogreen #plasticfree #savetheplanet #environment #recycle""",
            "image_url": "https://example.com/images/sustainable-products.jpg",
            "video_url": None,
            "target_audience": "general"
        },
        "POST002": {
            "post_id": "POST002",
            "platform": "twitter",
            "content": """Hot take: Remote work is here to stay and companies that don't adapt will lose top talent.

What's your take?""",
            "image_url": None,
            "video_url": None,
            "target_audience": "professional"
        },
        "POST003": {
            "post_id": "POST003",
            "platform": "linkedin",
            "content": """Excited to announce that I'll be speaking at TechConf 2025!

I'll be sharing insights on building scalable AI systems and the lessons learned from deploying machine learning models in production.

Looking forward to connecting with fellow tech enthusiasts and innovators. See you there!

#TechConf2025 #AI #MachineLearning #TechLeadership #Innovation""",
            "image_url": "https://example.com/images/conference-speaker.jpg",
            "video_url": None,
            "target_audience": "professional"
        },
        "POST004": {
            "post_id": "POST004",
            "platform": "tiktok",
            "content": """POV: When you finally understand that difficult concept 🤯

Drop a 🔥 if you've been there!

#studytok #studentlife #college #study #studymotivation""",
            "image_url": None,
            "video_url": "https://example.com/videos/study-motivation.mp4",
            "target_audience": "youth"
        },
        "POST005": {
            "post_id": "POST005",
            "platform": "facebook",
            "content": """🎉 GIVEAWAY ALERT! 🎉

We're celebrating 10K followers with an amazing giveaway!

To enter:
1. Like this post
2. Follow our page
3. Tag 3 friends in the comments
4. Share to your story (optional but increases your chances!)

Winner will be announced next Friday. Good luck everyone! 🍀

#giveaway #contest #win #free #followers #celebration""",
            "image_url": "https://example.com/images/giveaway.jpg",
            "video_url": None,
            "target_audience": "general"
        },
        "POST006": {
            "post_id": "POST006",
            "platform": "instagram",
            "content": """Morning coffee thoughts ☕

Sometimes you just need to slow down and appreciate the little things.""",
            "image_url": "https://example.com/images/coffee.jpg",
            "video_url": None,
            "target_audience": "general"
        },
        "POST007": {
            "post_id": "POST007",
            "platform": "linkedin",
            "content": """The 5 biggest mistakes I made in my first year as a founder (and how I fixed them):

1. Not delegating early enough
2. Ignoring customer feedback
3. Perfectionism over progress
4. Underestimating cashflow needs
5. Trying to do everything alone

What would you add to this list?""",
            "image_url": None,
            "video_url": None,
            "target_audience": "business"
        }
    }

    if post_id in sample_posts:
        logger.info(f"Loaded sample post: {post_id}")
        return sample_posts[post_id]

    # Return generic post for unknown IDs
    logger.info(f"Creating generic sample post for {post_id}")
    return {
        "post_id": post_id,
        "platform": platform,
        "content": f"This is a sample social media post for {platform}. Share your thoughts in the comments! 💭",
        "image_url": None,
        "video_url": None,
        "target_audience": "general"
    }

def get_available_samples() -> list:
    """Get list of available sample post IDs"""
    return [
        "POST001 - Instagram sustainable product launch",
        "POST002 - Twitter hot take on remote work",
        "POST003 - LinkedIn conference announcement",
        "POST004 - TikTok study motivation",
        "POST005 - Facebook giveaway",
        "POST006 - Instagram coffee moment",
        "POST007 - LinkedIn founder mistakes"
    ]
