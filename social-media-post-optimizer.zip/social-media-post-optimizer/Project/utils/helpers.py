"""Helper Utilities"""
from datetime import datetime
from typing import Union

def format_score(score: Union[int, float], max_score: int = 10) -> str:
    """
    Format a score for display

    Args:
        score: The score value
        max_score: Maximum possible score

    Returns:
        Formatted score string
    """
    if score is None:
        return "N/A"
    return f"{score:.1f}/{max_score}"

def get_timestamp() -> str:
    """
    Get current timestamp in ISO format

    Returns:
        ISO formatted timestamp string
    """
    return datetime.now().isoformat()

def truncate_text(text: str, max_length: int = 100) -> str:
    """
    Truncate text to specified length

    Args:
        text: Text to truncate
        max_length: Maximum length

    Returns:
        Truncated text with ellipsis if needed
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."

def extract_emojis(text: str) -> list:
    """
    Extract emojis from text

    Args:
        text: Text to analyze

    Returns:
        List of emojis found
    """
    import re
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # emoticons
        "\U0001F300-\U0001F5FF"  # symbols & pictographs
        "\U0001F680-\U0001F6FF"  # transport & map symbols
        "\U0001F1E0-\U0001F1FF"  # flags (iOS)
        "\U00002702-\U000027B0"
        "\U000024C2-\U0001F251"
        "]+",
        flags=re.UNICODE
    )
    return emoji_pattern.findall(text)

def count_words(text: str) -> int:
    """
    Count words in text

    Args:
        text: Text to analyze

    Returns:
        Word count
    """
    return len(text.split())

def format_hashtags(hashtags: list, max_display: int = 10) -> str:
    """
    Format hashtags for display

    Args:
        hashtags: List of hashtags
        max_display: Maximum number to display

    Returns:
        Formatted hashtag string
    """
    if not hashtags:
        return "No hashtags"

    display_tags = hashtags[:max_display]
    result = " ".join(display_tags)

    if len(hashtags) > max_display:
        result += f" ... and {len(hashtags) - max_display} more"

    return result
