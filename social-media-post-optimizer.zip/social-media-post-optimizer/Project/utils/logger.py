"""Logging Configuration"""
import logging
import os
from datetime import datetime
from config import get_config_value

def setup_logging():
    """Configure application logging"""
    log_level = get_config_value("LOG_LEVEL", "INFO")
    log_file = get_config_value("LOG_FILE", "logs/social_media_optimizer.log")

    # Create logs directory if it doesn't exist
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    # Configure logging format
    log_format = "%(asctime)s | %(levelname)-8s | %(name)-25s | %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    # Configure root logger
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

    # Set specific loggers to appropriate levels
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("google").setLevel(logging.WARNING)

    logger = logging.getLogger(__name__)
    logger.info("=" * 70)
    logger.info(f"Logging initialized - Level: {log_level}, File: {log_file}")
    logger.info("=" * 70)
