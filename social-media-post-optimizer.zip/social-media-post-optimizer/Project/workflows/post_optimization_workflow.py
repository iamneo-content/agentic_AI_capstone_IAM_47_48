"""Social Media Post Optimization Workflow Definition"""
import logging
from graph import SocialMediaOptimizationGraph
from nodes import (
    predict_engagement,
    optimize_hashtags,
    analyze_sentiment,
    recommend_timing,
    analyze_visual_quality,
    final_optimization,
    send_report
)

logger = logging.getLogger("workflow")

def create_post_optimization_workflow(max_workers: int = 5) -> SocialMediaOptimizationGraph:
    """
    Create the social media post optimization workflow graph

    The workflow is structured in 3 stages:
    1. Parallel Analysis Stage: All post aspects analyzed concurrently
       - Engagement prediction
       - Hashtag optimization
       - Sentiment analysis
       - Timing recommendations
       - Visual quality analysis
    2. Optimization Stage: Final optimization and recommendations
    3. Reporting Stage: Send optimization report

    Args:
        max_workers: Maximum number of parallel workers for concurrent analysis

    Returns:
        SocialMediaOptimizationGraph configured with the workflow stages
    """
    logger.info("Creating social media post optimization workflow")

    # Stage 1: Parallel analysis of all post aspects
    analysis_stage = [
        predict_engagement,
        optimize_hashtags,
        analyze_sentiment,
        recommend_timing,
        analyze_visual_quality
    ]

    # Stage 2: Final optimization (requires all analyses to be complete)
    optimization_stage = [
        final_optimization
    ]

    # Stage 3: Send report
    reporting_stage = [
        send_report
    ]

    # Combine all stages
    stages = [
        analysis_stage,
        optimization_stage,
        reporting_stage
    ]

    logger.info(f"Workflow created with {len(stages)} stages:")
    logger.info(f"  Stage 1: {len(analysis_stage)} parallel analyzers")
    logger.info(f"  Stage 2: Final optimization")
    logger.info(f"  Stage 3: Report generation")

    return SocialMediaOptimizationGraph(stages=stages, max_workers=max_workers)
