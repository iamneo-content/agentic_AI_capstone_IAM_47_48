# Agent Communication Diagram

## Detailed Agent-to-Agent Communication Flow

```mermaid
graph TB
    %% Input State
    PS[PostState<br/>Input Data]

    %% Stage 1: Workflow Nodes (Parallel Execution)
    subgraph Stage1[" STAGE 1: Parallel Analysis "]
        EN[predict_engagement<br/>Node]
        HN[optimize_hashtags<br/>Node]
        SN[analyze_sentiment<br/>Node]
        TN[recommend_timing<br/>Node]
        VN[analyze_visual_quality<br/>Node]
    end

    %% Stage 1: Analysis Agents
    subgraph Agents1[" Analysis Agents "]
        EA[EngagementAgent<br/>+ EngagementPredictor]
        HA[HashtagAgent<br/>+ HashtagOptimizer]
        SA[SentimentAgent<br/>+ SentimentAnalyzer]
        TA[TimingAgent<br/>+ TimingRecommender]
        VA[VisualQualityAgent<br/>+ VisualQualityAnalyzer]
    end

    %% Stage 2: Coordinator
    subgraph Stage2[" STAGE 2: Coordination "]
        FN[final_optimization<br/>Node]
        CA[CoordinatorAgent<br/>Aggregates Results]
    end

    %% Stage 3: Reporting
    subgraph Stage3[" STAGE 3: Reporting "]
        RN[send_report<br/>Node]
        ES[EmailService]
    end

    %% Final Output
    FS[PostState<br/>Optimized Output]

    %% State flows to nodes
    PS -->|Clone State| EN
    PS -->|Clone State| HN
    PS -->|Clone State| SN
    PS -->|Clone State| TN
    PS -->|Clone State| VN

    %% Nodes invoke agents
    EN -->|Invokes| EA
    HN -->|Invokes| HA
    SN -->|Invokes| SA
    TN -->|Invokes| TA
    VN -->|Invokes| VA

    %% Agents send results to coordinator
    EA -->|Engagement Results| CA
    HA -->|Hashtag Results| CA
    SA -->|Sentiment Results| CA
    TA -->|Timing Results| CA
    VA -->|Visual Results| CA

    %% Coordinator processes
    FN -->|Invokes| CA
    CA -->|Final Recommendations| FN

    %% Reporting
    FN --> RN
    RN -->|Invokes| ES
    ES -->|Email Report| FS

    %% Styling
    classDef stateStyle fill:#90EE90,stroke:#228B22,color:#000
    classDef nodeStyle fill:#FFD700,stroke:#B8860B,color:#000
    classDef agentStyle fill:#4A90E2,stroke:#2E5C8A,color:#fff
    classDef coordStyle fill:#E24A4A,stroke:#8A2E2E,color:#fff
    classDef serviceStyle fill:#9370DB,stroke:#4B0082,color:#fff

    class PS,FS stateStyle
    class EN,HN,SN,TN,VN,FN,RN nodeStyle
    class EA,HA,SA,TA,VA agentStyle
    class CA coordStyle
    class ES serviceStyle
```

## Architecture Overview

### Stage 1: Parallel Analysis
**Workflow Nodes** invoke **Analysis Agents** concurrently (ThreadPoolExecutor):
- `predict_engagement` → `EngagementAgent` → Uses `EngagementPredictor`
- `optimize_hashtags` → `HashtagAgent` → Uses `HashtagOptimizer`
- `analyze_sentiment` → `SentimentAgent` → Uses `SentimentAnalyzer`
- `recommend_timing` → `TimingAgent` → Uses `TimingRecommender`
- `analyze_visual_quality` → `VisualQualityAgent` → Uses `VisualQualityAnalyzer`

**No inter-agent communication** - Each agent works independently on a cloned state.

### Stage 2: Coordination (Agent-to-Agent Communication)
**All 5 analysis agents** send their results to the **CoordinatorAgent**:
- `EngagementAgent` → Engagement predictions → `CoordinatorAgent`
- `HashtagAgent` → Hashtag optimization → `CoordinatorAgent`
- `SentimentAgent` → Sentiment analysis → `CoordinatorAgent`
- `TimingAgent` → Timing recommendations → `CoordinatorAgent`
- `VisualQualityAgent` → Visual quality assessment → `CoordinatorAgent`

The `CoordinatorAgent`:
- Aggregates all analysis results
- Calculates overall score (weighted: 30% engagement, 20% hashtag, 20% sentiment, 20% visual, 10% timing)
- Generates optimization recommendations
- Determines if post is ready to publish

### Stage 3: Reporting
- `send_report` node invokes `EmailService`
- Sends comprehensive optimization report via email
- Updates final `PostState` with notification status

## Key Communication Pattern
```
Analysis Agents (5) → CoordinatorAgent (1) → Final Output
     [Parallel]              [Sequential]
```
