#!/usr/bin/env python3
"""
Social Media Post Optimizer
Main Entry Point
"""
import sys
import argparse
import logging
from datetime import datetime

from utils.logger import setup_logging
from config import get_config, validate_config, get_config_value
from state import PostState
from workflows import create_post_optimization_workflow
from services import load_post_data, get_available_samples

logger = logging.getLogger("main")

def optimize_post(
    post_id: str = None,
    content: str = None,
    platform: str = None,
    image_url: str = None,
    video_url: str = None,
    skip_email: bool = False
) -> PostState:
    """
    Optimize a social media post

    Args:
        post_id: Post identifier (for loading saved posts)
        content: Post text content
        platform: Social media platform
        image_url: URL of image (if applicable)
        video_url: URL of video (if applicable)
        skip_email: If True, skip sending email report

    Returns:
        PostState with complete optimization results
    """
    logger.info(f"Starting optimization for post: {post_id or 'custom'}")

    # Load post data or create from provided content
    if post_id:
        post_data = load_post_data(post_id)
        if not post_data:
            logger.error(f"Post {post_id} not found")
            sys.exit(1)
    elif content:
        post_data = {
            "post_id": f"CUSTOM_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "content": content,
            "platform": platform or get_config_value("PLATFORM", "instagram"),
            "image_url": image_url,
            "video_url": video_url,
            "target_audience": get_config_value("TARGET_AUDIENCE", "general")
        }
    else:
        logger.error("Either post_id or content must be provided")
        sys.exit(1)

    logger.info(f"Post loaded: {post_data.get('post_id')}")
    logger.info(f"Platform: {post_data.get('platform')}")

    # Create initial state
    initial_state = PostState(
        post_id=post_data["post_id"],
        post_content=post_data["content"],
        platform=post_data["platform"],
        image_url=post_data.get("image_url"),
        video_url=post_data.get("video_url"),
        target_audience=post_data.get("target_audience", "general"),
        timestamp=datetime.now().isoformat()
    )

    # Create and run workflow
    logger.info("Creating optimization workflow...")
    workflow = create_post_optimization_workflow(max_workers=5)

    logger.info("Executing post optimization workflow...")
    final_state = workflow.run(initial_state)

    # Display results
    print_results(final_state)

    return final_state

def print_results(state: PostState):
    """Print optimization results to console"""
    print("\n" + "=" * 70)
    print("SOCIAL MEDIA POST OPTIMIZATION RESULTS")
    print("=" * 70)
    print(f"Post ID: {state.post_id}")
    print(f"Platform: {state.platform}")
    print(f"Timestamp: {state.timestamp}")
    print("-" * 70)
    print(f"\nOVERALL SCORE: {state.overall_score:.1f}/10")
    print(f"Grade: {state.optimization_grade}")
    print(f"Status: {'✅ READY TO POST' if state.ready_to_post else '⚠️  NEEDS OPTIMIZATION'}")
    print("\n" + "-" * 70)
    print("DETAILED SCORES:")
    print(f"  Engagement Prediction: {state.engagement_score:.1f}/10")
    print(f"  Hashtag Optimization:  {state.hashtag_score:.1f}/10")
    print(f"  Sentiment Analysis:    {state.sentiment_score * 10:.1f}/10 ({state.sentiment_label})")
    print(f"  Visual Quality:        {state.visual_quality_score:.1f}/10")

    if state.warnings:
        print("\n" + "-" * 70)
        print("⚠️  WARNINGS:")
        for warning in state.warnings[:5]:
            print(f"  - {warning}")

    if state.best_posting_times:
        print("\n" + "-" * 70)
        print("📅 BEST POSTING TIMES:")
        for time_slot in state.best_posting_times[:3]:
            print(f"  - {time_slot.get('day')} at {time_slot.get('time')}")
            print(f"    → {time_slot.get('reason')}")

    if state.recommended_posting_time:
        print(f"\n🎯 RECOMMENDED: {state.recommended_posting_time}")

    if state.suggested_hashtags:
        print("\n" + "-" * 70)
        print("🏷️  SUGGESTED HASHTAGS:")
        hashtags_display = " ".join(state.suggested_hashtags[:15])
        print(f"  {hashtags_display}")
        if len(state.suggested_hashtags) > 15:
            print(f"  ... and {len(state.suggested_hashtags) - 15} more")

    if state.optimizations:
        print("\n" + "-" * 70)
        print("💡 OPTIMIZATION RECOMMENDATIONS:")
        for i, opt in enumerate(state.optimizations[:5], 1):
            priority = opt.get('priority', 'low').upper()
            category = opt.get('category', 'General')
            suggestion = opt.get('suggestion', '')
            print(f"  {i}. [{priority}] {category}")
            print(f"     {suggestion}")

    if state.optimized_content and state.optimized_content != state.post_content:
        print("\n" + "-" * 70)
        print("✨ OPTIMIZED CONTENT:")
        print(f"  {state.optimized_content[:200]}{'...' if len(state.optimized_content) > 200 else ''}")

    print("\n" + "=" * 70)

    if state.notification_sent:
        print("📧 Email report sent successfully")
    elif state.metadata.get("report_error"):
        print(f"⚠️  Email report failed: {state.metadata.get('report_error')}")

    print("=" * 70 + "\n")

def list_samples():
    """List available sample posts"""
    print("\nAvailable Sample Posts:")
    print("=" * 70)
    for sample in get_available_samples():
        print(f"  {sample}")
    print("=" * 70 + "\n")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Social Media Post Optimizer - AI-powered post analysis and optimization",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Optimize a sample post
  python main.py POST001

  # Optimize custom content
  python main.py --content "Your post content here" --platform instagram

  # With image
  python main.py --content "Check out this photo!" --platform instagram --image https://example.com/pic.jpg

  # Skip email report
  python main.py POST001 --skip-email

  # List available samples
  python main.py --list-samples

For more information, see README.md
        """
    )

    parser.add_argument(
        "post_id",
        nargs="?",
        help="Post ID to optimize (e.g., POST001)"
    )

    parser.add_argument(
        "--content",
        help="Custom post content to optimize"
    )

    parser.add_argument(
        "--platform",
        choices=["instagram", "twitter", "facebook", "linkedin", "tiktok"],
        help="Social media platform"
    )

    parser.add_argument(
        "--image",
        dest="image_url",
        help="Image URL"
    )

    parser.add_argument(
        "--video",
        dest="video_url",
        help="Video URL"
    )

    parser.add_argument(
        "--skip-email",
        action="store_true",
        help="Skip sending email report"
    )

    parser.add_argument(
        "--list-samples",
        action="store_true",
        help="List available sample posts"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging"
    )

    args = parser.parse_args()

    # Setup logging
    setup_logging()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # List samples if requested
    if args.list_samples:
        list_samples()
        sys.exit(0)

    # Validate inputs
    if not args.post_id and not args.content:
        parser.print_help()
        print("\nError: Either post_id or --content must be provided")
        sys.exit(1)

    try:
        # Validate configuration
        logger.info("Validating configuration...")
        config = get_config()

        # Note: We don't fail on missing email config if skip_email is True
        if not args.skip_email:
            try:
                validate_config()
            except ValueError as e:
                logger.warning(f"Email configuration incomplete: {e}")
                logger.warning("Continuing without email notifications")
                args.skip_email = True

        # Run optimization
        optimize_post(
            post_id=args.post_id,
            content=args.content,
            platform=args.platform,
            image_url=args.image_url,
            video_url=args.video_url,
            skip_email=args.skip_email
        )

        logger.info("Optimization completed successfully")
        sys.exit(0)

    except KeyboardInterrupt:
        logger.info("Optimization interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Optimization failed: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
