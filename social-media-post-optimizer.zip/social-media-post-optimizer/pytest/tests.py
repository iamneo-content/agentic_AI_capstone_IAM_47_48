#!/usr/bin/env python3
"""
Comprehensive Test Suite for Social Media Post Optimizer

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import PostState
    from graph import SocialMediaOptimizationGraph
    from workflows.post_optimization_workflow import create_post_optimization_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.engagement_agent import EngagementAgent
    from agents.hashtag_agent import HashtagAgent
    from agents.sentiment_agent import SentimentAgent
    from agents.timing_agent import TimingAgent
    from agents.visual_quality_agent import VisualQualityAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.sentiment_analyzer import SentimentAnalyzer
    from analyzers.engagement_predictor import EngagementPredictor
    from analyzers.hashtag_optimizer import HashtagOptimizer
    from analyzers.timing_recommender import TimingRecommender
    from analyzers.visual_quality_analyzer import VisualQualityAnalyzer

    # Import nodes
    from nodes.analysis_nodes import (
        predict_engagement,
        optimize_hashtags,
        analyze_sentiment,
        recommend_timing,
        analyze_visual_quality,
        final_optimization,
        send_report
    )

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestSocialMediaPostOptimizerArchitecture(unittest.TestCase):
    """Test suite for Social Media Post Optimizer Architecture"""

    SAMPLE_POST = {
        "post_id": "TEST-123",
        "post_content": "Check out this amazing new product! #awesome #newrelease",
        "platform": "instagram",
        "target_audience": "millennials",
        "post_type": "promotional",
        "image_url": "https://example.com/image.jpg",
        "video_url": None,
        "scheduled_time": "2024-01-15 14:00:00"
    }

    def setUp(self):
        """Setup test environment"""
        self.sample_post = self.SAMPLE_POST.copy()

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test PostState dataclass creation"""
        logger.info("Testing PostState creation...")

        state = PostState(
            post_id="TEST-123",
            post_content="Test post",
            platform="instagram"
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.post_id, "TEST-123", "Post ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test PostState clone method"""
        logger.info("Testing PostState clone...")

        state = PostState(post_id="TEST-123", post_content="Test", platform="instagram")
        state.engagement_prediction = {"test": "data"}

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.post_id, state.post_id, "Post ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_sentiment_analyzer(self):
        """Test SentimentAnalyzer (pure tool)"""
        logger.info("Testing SentimentAnalyzer...")

        analyzer = SentimentAnalyzer()
        results = analyzer.analyze(self.sample_post["post_content"], "instagram")

        self.assertIsNotNone(results, "Sentiment analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("sentiment_score", results, "Results should contain sentiment_score")

        logger.info("✓ SentimentAnalyzer tests passed")

    def test_engagement_predictor(self):
        """Test EngagementPredictor (pure tool)"""
        logger.info("Testing EngagementPredictor...")

        analyzer = EngagementPredictor()
        results = analyzer.predict(self.sample_post["post_content"], "instagram", True)

        self.assertIsNotNone(results, "Engagement prediction results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("engagement_score", results, "Results should contain engagement_score")

        logger.info("✓ EngagementPredictor tests passed")

    def test_hashtag_optimizer(self):
        """Test HashtagOptimizer (pure tool)"""
        logger.info("Testing HashtagOptimizer...")

        analyzer = HashtagOptimizer()
        results = analyzer.optimize(self.sample_post["post_content"], "instagram")

        self.assertIsNotNone(results, "Hashtag optimization results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("hashtag_score", results, "Results should contain hashtag_score")

        logger.info("✓ HashtagOptimizer tests passed")

    def test_timing_recommender(self):
        """Test TimingRecommender (pure tool)"""
        logger.info("Testing TimingRecommender...")

        analyzer = TimingRecommender()
        results = analyzer.recommend("instagram", "image", "millennials", "personal")

        self.assertIsNotNone(results, "Timing recommendation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("best_times", results, "Results should contain best_times")

        logger.info("✓ TimingRecommender tests passed")

    def test_visual_quality_analyzer(self):
        """Test VisualQualityAnalyzer (pure tool)"""
        logger.info("Testing VisualQualityAnalyzer...")

        analyzer = VisualQualityAnalyzer()
        results = analyzer.analyze("https://example.com/image.jpg", None, "instagram")

        self.assertIsNotNone(results, "Visual quality analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("quality_score", results, "Results should contain quality_score")

        logger.info("✓ VisualQualityAnalyzer tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_engagement_agent(self):
        """Test EngagementAgent (coordinator)"""
        logger.info("Testing EngagementAgent...")

        agent = EngagementAgent()
        results = agent.analyze(self.sample_post)

        self.assertIsNotNone(results, "Engagement agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, EngagementPredictor, "Should use EngagementPredictor")

        logger.info("✓ EngagementAgent tests passed")

    def test_hashtag_agent(self):
        """Test HashtagAgent (coordinator)"""
        logger.info("Testing HashtagAgent...")

        agent = HashtagAgent()
        results = agent.analyze(self.sample_post)

        self.assertIsNotNone(results, "Hashtag agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, HashtagOptimizer, "Should use HashtagOptimizer")

        logger.info("✓ HashtagAgent tests passed")

    def test_sentiment_agent(self):
        """Test SentimentAgent (coordinator)"""
        logger.info("Testing SentimentAgent...")

        agent = SentimentAgent()
        results = agent.analyze(self.sample_post)

        self.assertIsNotNone(results, "Sentiment agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, SentimentAnalyzer, "Should use SentimentAnalyzer")

        logger.info("✓ SentimentAgent tests passed")

    def test_timing_agent(self):
        """Test TimingAgent (coordinator)"""
        logger.info("Testing TimingAgent...")

        agent = TimingAgent()
        results = agent.analyze(self.sample_post)

        self.assertIsNotNone(results, "Timing agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, TimingRecommender, "Should use TimingRecommender")

        logger.info("✓ TimingAgent tests passed")

    def test_visual_quality_agent(self):
        """Test VisualQualityAgent (coordinator)"""
        logger.info("Testing VisualQualityAgent...")

        agent = VisualQualityAgent()
        results = agent.analyze(self.sample_post)

        self.assertIsNotNone(results, "Visual quality agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, VisualQualityAnalyzer, "Should use VisualQualityAnalyzer")

        logger.info("✓ VisualQualityAgent tests passed")

    def test_coordinator_agent(self):
        """Test CoordinatorAgent"""
        logger.info("Testing CoordinatorAgent...")

        # Create mock results
        engagement_results = [{"engagement_score": 8.5}]
        hashtag_results = [{"hashtag_score": 8.0, "suggested_hashtags": ["#test"]}]
        sentiment_results = [{"sentiment_score": 0.85, "sentiment_label": "positive"}]
        timing_results = [{"best_times": [{"day": "Monday", "time": "14:00"}]}]
        visual_results = [{"quality_score": 8.0, "has_visual": True}]

        agent = CoordinatorAgent()
        result = agent.analyze(
            engagement_results,
            hashtag_results,
            sentiment_results,
            timing_results,
            visual_results
        )

        self.assertIsNotNone(result, "Coordinator result should not be None")
        self.assertIn("coordination_summary", result, "Result should contain coordination_summary")

        summary = result["coordination_summary"]
        self.assertIn("analyses_completed", summary, "Summary should contain analyses_completed")
        self.assertEqual(len(summary["analyses_completed"]), 5, "Should have 5 completed analyses")

        logger.info("✓ CoordinatorAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_predict_engagement_node(self):
        """Test predict_engagement node (thin wrapper)"""
        logger.info("Testing predict_engagement node...")

        state = PostState(
            post_id="TEST-POST",
            post_content=self.sample_post["post_content"],
            platform="instagram",
            image_url=self.sample_post["image_url"]
        )

        result = predict_engagement(state)

        self.assertIsNotNone(result, "Engagement node result should not be None")
        self.assertIsInstance(result, PostState, "Result should be PostState")
        self.assertTrue(result.metadata.get("engagement_analysis_complete"), "Should mark analysis as complete")

        logger.info("✓ predict_engagement node tests passed")

    def test_optimize_hashtags_node(self):
        """Test optimize_hashtags node (thin wrapper)"""
        logger.info("Testing optimize_hashtags node...")

        state = PostState(
            post_id="TEST-POST",
            post_content=self.sample_post["post_content"],
            platform="instagram"
        )

        result = optimize_hashtags(state)

        self.assertIsNotNone(result, "Hashtag node result should not be None")
        self.assertIsInstance(result, PostState, "Result should be PostState")
        self.assertTrue(result.metadata.get("hashtag_optimization_complete"), "Should mark optimization as complete")

        logger.info("✓ optimize_hashtags node tests passed")

    def test_final_optimization_node(self):
        """Test final_optimization node (uses coordinator)"""
        logger.info("Testing final_optimization node...")

        state = PostState(
            post_id="TEST-POST",
            post_content=self.sample_post["post_content"],
            platform="instagram"
        )
        state.engagement_prediction = {"engagement_score": 8.5}
        state.hashtag_analysis = {"hashtag_score": 8.0, "suggested_hashtags": ["#test"]}
        state.sentiment_analysis = {"sentiment_score": 0.85}
        state.timing_analysis = {"best_times": []}
        state.visual_analysis = {"quality_score": 8.0, "has_visual": True}

        result = final_optimization(state)

        self.assertIsNotNone(result, "Final optimization result should not be None")
        self.assertIsInstance(result, PostState, "Result should be PostState")
        self.assertIsNotNone(result.overall_score, "Should have overall score")
        self.assertIsNotNone(result.ready_to_post, "Should have ready status")

        logger.info("✓ final_optimization node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_optimization_graph_creation(self):
        """Test SocialMediaOptimizationGraph class creation"""
        logger.info("Testing SocialMediaOptimizationGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = SocialMediaOptimizationGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ SocialMediaOptimizationGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = create_post_optimization_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, SocialMediaOptimizationGraph, "Workflow should be SocialMediaOptimizationGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        engagement_agent = EngagementAgent()
        self.assertIsNotNone(engagement_agent.analyzer, "EngagementAgent should have an analyzer")
        self.assertIsInstance(engagement_agent.analyzer, EngagementPredictor, "Should use EngagementPredictor")

        hashtag_agent = HashtagAgent()
        self.assertIsNotNone(hashtag_agent.analyzer, "HashtagAgent should have an analyzer")
        self.assertIsInstance(hashtag_agent.analyzer, HashtagOptimizer, "Should use HashtagOptimizer")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = PostState(
            post_id="TEST-POST",
            post_content="Test content",
            platform="instagram"
        )

        # Test that nodes return PostState
        result = predict_engagement(state)
        self.assertIsInstance(result, PostState, "Node should return PostState")

        result = optimize_hashtags(state)
        self.assertIsInstance(result, PostState, "Node should return PostState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Social Media Post Optimizer - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
