# Social Media Post Optimizer 📱

An AI-powered multi-agent system that analyzes and optimizes social media posts for maximum engagement using LangGraph and Google Gemini AI.

## Overview

This intelligent system evaluates social media posts across multiple dimensions and provides actionable recommendations to boost engagement:

- **Engagement Predictor**: Predicts post performance and engagement potential
- **Hashtag Optimizer**: Suggests optimal hashtags for maximum reach
- **Sentiment Analyzer**: Evaluates emotional tone and appropriateness
- **Timing Recommender**: Recommends best posting times based on platform and audience
- **Visual Quality Agent**: Analyzes image/video quality and format compliance

The system uses **parallel processing** with LangGraph to analyze all aspects concurrently, then generates a comprehensive optimization report with specific, actionable recommendations.

## Features

- **Multi-Agent Analysis**: 5 specialized AI agents working in parallel
- **Platform-Specific**: Optimized for Instagram, Twitter, Facebook, LinkedIn, and TikTok
- **AI-Powered**: Uses Google Gemini 2.0 Flash for intelligent insights
- **Comprehensive Scoring**: Overall optimization score with detailed breakdowns
- **Actionable Recommendations**: Prioritized suggestions for improvement
- **Best Posting Times**: Data-driven timing recommendations
- **Hashtag Strategy**: Smart hashtag suggestions based on reach and relevance
- **Content Optimization**: Auto-generated improved content versions
- **Email Reports**: Beautiful HTML email reports
- **Sample Posts**: 7 pre-loaded sample posts for testing

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                       POST INPUT                                │
│        (Content, Platform, Visual Media, Audience)              │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                 STAGE 1: PARALLEL ANALYSIS                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  Engagement  │  │   Hashtag    │  │  Sentiment   │          │
│  │  Predictor   │  │  Optimizer   │  │   Analyzer   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│  ┌──────────────┐  ┌──────────────┐                            │
│  │    Timing    │  │    Visual    │                            │
│  │ Recommender  │  │   Quality    │                            │
│  └──────────────┘  └──────────────┘                            │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│           STAGE 2: FINAL OPTIMIZATION                           │
│              (OptimizationAgent)                                │
│  • Calculate overall score                                      │
│  • Generate recommendations                                     │
│  • Create optimized content                                     │
│  • Select best hashtags & timing                                │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│              STAGE 3: REPORT GENERATION                         │
│                  (Email Notification)                           │
└─────────────────────────────────────────────────────────────────┘
```

## Installation

### Prerequisites

- Python 3.8 or higher
- Google Gemini API key ([Get one here](https://makersuite.google.com/app/apikey))
- Gmail account for email reports (optional)

### Setup

1. **Navigate to project directory**:
   ```bash
   cd social-media-post-optimizer
   ```

2. **Create virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment**:
   ```bash
   cp .env.example .env
   ```

   Edit `.env` and add your API key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   PLATFORM=instagram
   TARGET_AUDIENCE=general

   # Optional: Email configuration
   EMAIL_FROM=your-email@gmail.com
   EMAIL_PASSWORD=your_gmail_app_password
   EMAIL_TO=recipient@example.com
   ```

## Quick Start

### Optimize a Sample Post

```bash
# List available samples
python main.py --list-samples

# Optimize a sample
python main.py POST001
```

### Optimize Custom Content

```bash
# Basic usage
python main.py --content "Your amazing post content here! 🚀" --platform instagram

# With image
python main.py --content "Check out this view!" --platform instagram --image https://example.com/photo.jpg

# With video
python main.py --content "New tutorial!" --platform tiktok --video https://example.com/video.mp4
```

### Without Email Reports

```bash
python main.py POST001 --skip-email
```

## Sample Posts

The system includes 7 pre-configured sample posts for testing:

- **POST001**: Instagram sustainable product launch
- **POST002**: Twitter hot take on remote work
- **POST003**: LinkedIn conference announcement
- **POST004**: TikTok study motivation
- **POST005**: Facebook giveaway
- **POST006**: Instagram coffee moment
- **POST007**: LinkedIn founder mistakes

## Configuration

All configuration is managed through the `.env` file. See `.env.example` for all options.

### Key Configuration Options

| Variable | Description | Default |
|----------|-------------|---------|
| `GEMINI_API_KEY` | Google Gemini API key (required) | - |
| `PLATFORM` | Default social media platform | `instagram` |
| `TARGET_AUDIENCE` | Target audience type | `general` |
| `ENGAGEMENT_THRESHOLD` | Minimum engagement score | `7.0` |
| `HASHTAG_SCORE_THRESHOLD` | Minimum hashtag score | `7.0` |
| `OVERALL_SCORE_THRESHOLD` | Minimum score for "ready to post" | `7.5` |
| `OPTIMAL_HASHTAGS` | Number of hashtags to suggest | `10` |
| `TIMEZONE` | Your timezone | `America/New_York` |
| `ACCOUNT_TYPE` | Account type for timing | `personal` |

### Platform Options

- `instagram` - Instagram posts
- `twitter` - Twitter/X posts
- `facebook` - Facebook posts
- `linkedin` - LinkedIn posts
- `tiktok` - TikTok content

### Audience Options

- `general` - General audience
- `business` - Business/B2B audience
- `youth` - Young adult audience
- `professional` - Professional audience

## Project Structure

```
social-media-post-optimizer/
├── analyzers/              # AI-powered analyzers
│   ├── engagement_predictor.py
│   ├── hashtag_optimizer.py
│   ├── sentiment_analyzer.py
│   ├── timing_recommender.py
│   └── visual_quality_analyzer.py
├── agents/                 # Coordination agent
│   └── optimization_agent.py
├── nodes/                  # Workflow nodes
│   └── analysis_nodes.py
├── workflows/              # LangGraph workflows
│   └── post_optimization_workflow.py
├── services/               # External services
│   ├── email_service.py
│   └── post_service.py
├── utils/                  # Utilities
│   ├── logger.py
│   └── helpers.py
├── examples/               # Example posts
├── config.py              # Configuration management
├── state.py               # State management
├── graph.py               # Graph execution engine
├── main.py                # Entry point
├── requirements.txt       # Dependencies
└── .env.example           # Environment template
```

## How It Works

### 1. Post Input
User provides post content, platform, and optional media (image/video).

### 2. Parallel Analysis (Stage 1)
Five AI agents analyze different aspects concurrently:

- **Engagement Predictor**: Analyzes content quality, emotional appeal, CTAs, and virality potential
- **Hashtag Optimizer**: Evaluates existing hashtags and suggests optimal mix of trending/niche tags
- **Sentiment Analyzer**: Evaluates tone, formality, authenticity, and controversial risk
- **Timing Recommender**: Suggests best posting times based on platform, audience, and content type
- **Visual Quality Agent**: Analyzes image/video quality, composition, format compliance

### 3. Final Optimization (Stage 2)
The Optimization Agent:
- Calculates weighted overall score
- Generates prioritized recommendations
- Creates optimized content version
- Selects best hashtags and posting time

### 4. Report Generation (Stage 3)
Beautiful HTML email report with all insights and recommendations.

## Understanding Results

### Overall Score Grades

| Score | Grade | Meaning |
|-------|-------|---------|
| 9.0-10.0 | Excellent | Ready to post, expect high engagement |
| 8.0-8.9 | Very Good | Minor tweaks will maximize performance |
| 7.0-7.9 | Good | Solid post, some improvements recommended |
| 6.0-6.9 | Fair | Needs optimization before posting |
| < 6.0 | Needs Improvement | Significant changes required |

### Score Components

- **Engagement** (30% weight): Content quality, CTAs, hook effectiveness
- **Hashtags** (20% weight): Relevance, reach potential, mix quality
- **Sentiment** (20% weight): Tone, authenticity, appropriateness
- **Visual** (20% weight): Image/video quality, format compliance
- **Timing** (10% weight): Optimal posting schedule

## Usage Examples

See [USAGE.md](USAGE.md) for detailed examples and tutorials.

## Extending the System

### Adding a New Platform

1. Update platform choices in `main.py`
2. Add platform-specific rules in analyzers
3. Update timing recommendations for new platform

### Adding Custom Analyzers

1. Create analyzer in `analyzers/` directory
2. Implement `analyze()` method
3. Add to workflow in `workflows/post_optimization_workflow.py`
4. Update state management in `state.py`

### Customizing Scoring Weights

Edit weights in `agents/optimization_agent.py`:

```python
weights = {
    "engagement": 0.30,  # Adjust as needed
    "hashtag": 0.20,
    "sentiment": 0.20,
    "visual": 0.20,
    "timing": 0.10
}
```

## Best Practices

### 1. Test with Samples First
```bash
python main.py --list-samples
python main.py POST001
```

### 2. Optimize Before Posting
Run optimization on draft posts before scheduling to maximize engagement.

### 3. Track Performance
Compare predicted engagement with actual results to fine-tune.

### 4. Platform-Specific Content
Use `--platform` flag to get platform-optimized recommendations.

### 5. Adjust Thresholds
Tune thresholds in `.env` based on your quality standards.

## Troubleshooting

### Issue: "GEMINI_API_KEY not configured"
**Solution**: Add your API key to `.env` file.

### Issue: Low engagement scores
**Analysis**: Review specific analyzer scores to identify weaknesses.
**Solution**: Follow prioritized recommendations in the output.

### Issue: Email reports not sending
**Solution**:
- Verify Gmail app password (not regular password)
- Enable 2FA and generate app password
- Or use `--skip-email` flag

### Logs
Check `logs/social_media_optimizer.log` for detailed execution information.

## Requirements

Key dependencies (see `requirements.txt` for complete list):

- `langgraph>=0.2.0` - Multi-agent workflow orchestration
- `langchain-core>=0.3.0` - LangChain core functionality
- `google-generativeai>=0.3.0` - Google Gemini AI
- `pytz>=2021.3` - Timezone handling
- `python-dotenv>=0.15.0` - Environment configuration

## Performance

- **Analysis Time**: 10-30 seconds per post
- **Parallel Execution**: All 5 analyzers run concurrently
- **API Calls**: 5-6 Gemini API calls per optimization
- **Success Rate**: 95%+ with valid API key

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## Support

For issues or questions:

- Check [USAGE.md](USAGE.md) for detailed examples
- Review logs in `logs/social_media_optimizer.log`
- Open an issue on GitHub

## Acknowledgments

Built with:
- [LangGraph](https://github.com/langchain-ai/langgraph) - Multi-agent orchestration
- [Google Gemini](https://ai.google.dev/) - AI-powered analysis
- [LangChain](https://github.com/langchain-ai/langchain) - LLM framework

---

**Made with ❤️ for social media creators, marketers, and agencies**
