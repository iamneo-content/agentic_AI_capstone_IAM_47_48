## Usage Guide

Complete guide for using the Social Media Post Optimizer.

## Table of Contents

- [Basic Usage](#basic-usage)
- [Command Line Options](#command-line-options)
- [Sample Posts](#sample-posts)
- [Understanding Results](#understanding-results)
- [Platform-Specific Tips](#platform-specific-tips)
- [Advanced Usage](#advanced-usage)
- [Best Practices](#best-practices)

## Basic Usage

### Quick Start with Sample Posts

List available sample posts:
```bash
python main.py --list-samples
```

Optimize a sample post:
```bash
python main.py POST001
```

### Optimize Your Own Content

Basic text post:
```bash
python main.py --content "Your post content goes here! Share your thoughts 💭" --platform instagram
```

Post with image:
```bash
python main.py --content "Check out this amazing sunset! 🌅" --platform instagram --image https://example.com/sunset.jpg
```

Post with video:
```bash
python main.py --content "New tutorial is live! Learn these tips 🎯" --platform tiktok --video https://example.com/tutorial.mp4
```

## Command Line Options

```
python main.py [OPTIONS] [POST_ID]

Positional Arguments:
  POST_ID                  Sample post ID to optimize (POST001-POST007)

Optional Arguments:
  --content TEXT           Custom post content to optimize
  --platform PLATFORM      Social media platform
                          Choices: instagram, twitter, facebook, linkedin, tiktok
  --image URL             Image URL for the post
  --video URL             Video URL for the post
  --skip-email            Skip sending email report
  --list-samples          List all available sample posts
  -v, --verbose           Enable verbose logging
  -h, --help              Show help message
```

### Examples

```bash
# Sample post
python main.py POST001

# Custom Instagram post
python main.py --content "New product launch! 🚀" --platform instagram

# LinkedIn post with verbose logging
python main.py --content "Excited to announce..." --platform linkedin --verbose

# TikTok video post
python main.py --content "POV: When you..." --platform tiktok --video https://example.com/vid.mp4

# Skip email notification
python main.py POST003 --skip-email

# Combine options
python main.py --content "My thoughts on AI" --platform twitter --skip-email --verbose
```

## Sample Posts

### POST001 - Instagram Sustainable Product Launch
**Platform**: Instagram
**Type**: Product announcement with image
**Content**: Environmental/sustainability theme
**Best For**: Brand announcements, product launches

```bash
python main.py POST001
```

### POST002 - Twitter Hot Take
**Platform**: Twitter
**Type**: Opinion/discussion starter
**Content**: Remote work debate
**Best For**: Engagement, conversations

```bash
python main.py POST002
```

### POST003 - LinkedIn Conference Announcement
**Platform**: LinkedIn
**Type**: Professional announcement with image
**Content**: Speaking engagement
**Best For**: Professional updates, thought leadership

```bash
python main.py POST003
```

### POST004 - TikTok Study Motivation
**Platform**: TikTok
**Type**: POV video content
**Content**: Student/youth focused
**Best For**: Trending content, relatable moments

```bash
python main.py POST004
```

### POST005 - Facebook Giveaway
**Platform**: Facebook
**Type**: Contest/giveaway with image
**Content**: Engagement campaign
**Best For**: Community building, followers growth

```bash
python main.py POST005
```

### POST006 - Instagram Coffee Moment
**Platform**: Instagram
**Type**: Lifestyle/aesthetic post
**Content**: Minimalist, reflective
**Best For**: Personal branding, lifestyle content

```bash
python main.py POST006
```

### POST007 - LinkedIn Founder Mistakes
**Platform**: LinkedIn
**Type**: Educational list post
**Content**: Entrepreneurship lessons
**Best For**: Thought leadership, engagement

```bash
python main.py POST007
```

## Understanding Results

### Terminal Output Example

```
======================================================================
SOCIAL MEDIA POST OPTIMIZATION RESULTS
======================================================================
Post ID: POST001
Platform: instagram
Timestamp: 2025-01-17T15:30:00

OVERALL SCORE: 8.5/10
Grade: Very Good
Status: ✅ READY TO POST

----------------------------------------------------------------------
DETAILED SCORES:
  Engagement Prediction: 8.7/10
  Hashtag Optimization:  8.2/10
  Sentiment Analysis:    9.0/10 (positive)
  Visual Quality:        8.5/10

----------------------------------------------------------------------
📅 BEST POSTING TIMES:
  - Monday at 11:00
    → Late morning engagement peak
  - Wednesday at 14:00
    → Midweek afternoon activity
  - Friday at 10:00
    → Weekend anticipation browsing

🎯 RECOMMENDED: Wednesday at 14:00

----------------------------------------------------------------------
🏷️  SUGGESTED HASHTAGS:
  #sustainability #ecofriendly #sustainable #zerowaste #climateaction
  #gogreen #plasticfree #savetheplanet #environment #recycle

----------------------------------------------------------------------
💡 OPTIMIZATION RECOMMENDATIONS:
  1. [LOW] Overall
     Post is well-optimized and ready to publish
  2. [MEDIUM] Timing
     Schedule post for Wednesday at 14:00

======================================================================
```

### Score Interpretation

#### Overall Score

| Range | Grade | Action |
|-------|-------|--------|
| 9.0-10.0 | Excellent | Post immediately, expect viral potential |
| 8.0-8.9 | Very Good | Ready to post, minor tweaks optional |
| 7.0-7.9 | Good | Post with confidence, note suggestions |
| 6.0-6.9 | Fair | Implement recommendations before posting |
| <6.0 | Needs Improvement | Significant revision required |

#### Component Scores

**Engagement (Weight: 30%)**
- What it measures: Content quality, hook, CTA, virality potential
- High score: Strong hook, clear CTA, emotional appeal
- Low score: Weak opening, no engagement prompt, generic content

**Hashtags (Weight: 20%)**
- What it measures: Relevance, reach potential, mix quality
- High score: Good mix of trending/niche, relevant to content
- Low score: Too generic, irrelevant, or missing hashtags

**Sentiment (Weight: 20%)**
- What it measures: Tone, authenticity, appropriateness
- High score: Positive, authentic, appropriate for platform
- Low score: Negative tone, controversial elements, off-brand

**Visual (Weight: 20%)**
- What it measures: Image/video quality, format, composition
- High score: High resolution, good composition, platform-optimized
- Low score: Low quality, wrong aspect ratio, or no visual

**Timing (Weight: 10%)**
- What it measures: Optimal posting schedule
- Note: Recommendations provided, doesn't heavily impact score

### Recommendation Priority Levels

- **CRITICAL**: Must address before posting
- **HIGH**: Strongly recommended to improve
- **MEDIUM**: Will improve performance if addressed
- **LOW**: Optional enhancements

## Platform-Specific Tips

### Instagram 📸

**Best Practices:**
- Use 10-30 hashtags (optimal: 10-15)
- Post at 11 AM or 2 PM weekdays
- Include high-quality visuals (required)
- Use Stories for behind-the-scenes
- Aspect ratios: 1:1 (square), 4:5 (portrait), 1.91:1 (landscape)

**Optimization Example:**
```bash
python main.py --content "Behind the scenes of our photoshoot! ✨" --platform instagram --image https://example.com/bts.jpg
```

**Expected Results:**
- Higher weight on visual quality
- More hashtag recommendations (10+)
- Emphasis on aesthetic and storytelling

### Twitter/X 🐦

**Best Practices:**
- Keep it concise (280 characters max)
- Use 1-2 hashtags only
- Post at 12 PM or 5-6 PM weekdays
- Ask questions to drive engagement
- Use threads for longer content

**Optimization Example:**
```bash
python main.py --content "Hot take: The future of work is async-first. Thoughts? 🤔" --platform twitter
```

**Expected Results:**
- Focus on engagement and controversy
- Minimal hashtag suggestions (1-2)
- Emphasis on conversation starters

### LinkedIn 💼

**Best Practices:**
- Professional tone required
- Use 3-5 hashtags
- Post Tuesday-Thursday, 8 AM or 12 PM
- Longer form content performs well
- Share insights and experiences

**Optimization Example:**
```bash
python main.py --content "5 lessons from my first year as a founder..." --platform linkedin
```

**Expected Results:**
- Emphasis on professional tone
- Focus on thought leadership
- Business-hours timing recommendations

### TikTok 🎵

**Best Practices:**
- Short, engaging videos (15-60 seconds)
- Use 3-5 relevant hashtags
- Post 6-10 PM, especially Thu-Fri
- Trending sounds and challenges
- 9:16 vertical video format required

**Optimization Example:**
```bash
python main.py --content "POV: When you finally understand calculus 🤯 #studytok" --platform tiktok --video https://example.com/vid.mp4
```

**Expected Results:**
- High engagement prediction weight
- Trending hashtag suggestions
- Evening posting time recommendations

### Facebook 👥

**Best Practices:**
- More casual, conversational tone
- Use 1-3 hashtags
- Post 1-3 PM weekdays
- Visual content highly recommended
- Community engagement focus

**Optimization Example:**
```bash
python main.py --content "Who remembers this? Tag a friend! 😊" --platform facebook --image https://example.com/memory.jpg
```

**Expected Results:**
- Emphasis on community engagement
- CTA for sharing/tagging
- Afternoon timing recommendations

## Advanced Usage

### Batch Optimization

Create a script to optimize multiple posts:

```python
#!/usr/bin/env python3
from main import optimize_post

posts = [
    {"id": "POST001", "skip_email": True},
    {"id": "POST002", "skip_email": True},
    {"id": "POST003", "skip_email": True}
]

results = []
for post in posts:
    result = optimize_post(post_id=post["id"], skip_email=post["skip_email"])
    results.append({
        "id": result.post_id,
        "score": result.overall_score,
        "ready": result.ready_to_post
    })

# Summary report
print("\nBatch Optimization Summary:")
for r in results:
    status = "✅" if r["ready"] else "⚠️"
    print(f"{status} {r['id']}: {r['score']:.1f}/10")
```

### Programmatic Usage

Import and use in your Python code:

```python
from main import optimize_post

# Optimize a post
result = optimize_post(
    content="Your post content here",
    platform="instagram",
    image_url="https://example.com/image.jpg",
    skip_email=True
)

# Access results
print(f"Score: {result.overall_score}")
print(f"Ready: {result.ready_to_post}")
print(f"Best time: {result.recommended_posting_time}")
print(f"Hashtags: {result.optimized_hashtags}")

# Get recommendations
for rec in result.optimizations:
    print(f"[{rec['priority']}] {rec['suggestion']}")
```

### Custom Configuration

Create a custom `.env` for specific use cases:

**High-Quality Brand Account:**
```env
ENGAGEMENT_THRESHOLD=8.5
SENTIMENT_THRESHOLD=0.7
VISUAL_QUALITY_THRESHOLD=8.5
OVERALL_SCORE_THRESHOLD=8.5
```

**Casual Personal Account:**
```env
ENGAGEMENT_THRESHOLD=6.5
SENTIMENT_THRESHOLD=0.5
VISUAL_QUALITY_THRESHOLD=6.0
OVERALL_SCORE_THRESHOLD=6.5
```

**Influencer Account:**
```env
ACCOUNT_TYPE=influencer
OPTIMAL_HASHTAGS=15
MAX_HASHTAGS=30
EMOJI_PREFERENCE=high
```

### Integration with Scheduling Tools

Export results for use with scheduling platforms:

```python
import json
from main import optimize_post

result = optimize_post(post_id="POST001", skip_email=True)

# Export to JSON
export_data = {
    "content": result.optimized_content,
    "platform": result.platform,
    "hashtags": result.optimized_hashtags,
    "schedule_time": result.recommended_posting_time,
    "score": result.overall_score
}

with open("scheduled_post.json", "w") as f:
    json.dump(export_data, f, indent=2)

print("Post data exported for scheduling")
```

## Best Practices

### 1. Pre-Flight Check

Always optimize before scheduling:
```bash
python main.py --content "Your draft post" --platform instagram
```

Review recommendations and iterate until score ≥ 8.0.

### 2. A/B Testing

Optimize multiple versions:
```bash
python main.py --content "Version A: Discover our new..." --platform instagram --skip-email
python main.py --content "Version B: Just dropped:..." --platform instagram --skip-email
```

Compare scores and pick the winner.

### 3. Hashtag Research

```bash
# Test different hashtag strategies
python main.py --content "Post with trending tags #trending #viral" --platform instagram
python main.py --content "Post with niche tags #specifictopic #community" --platform instagram
```

### 4. Timing Experiments

Track performance by posting at recommended times vs. other times to validate recommendations.

### 5. Quality Threshold

Set your quality bar:
- **Critical posts**: Score ≥ 9.0
- **Regular posts**: Score ≥ 8.0
- **Casual posts**: Score ≥ 7.0

## Troubleshooting

### Low Engagement Score

**Symptoms**: Engagement score < 7.0

**Common Causes**:
- Weak opening hook
- No call-to-action
- Generic/boring content
- Too long or too short

**Solutions**:
1. Add a strong question or statement at the start
2. Include clear CTA ("Comment below!", "Share if you agree!")
3. Make it personal and relatable
4. Optimize length for platform

### Poor Hashtag Score

**Symptoms**: Hashtag score < 7.0

**Common Causes**:
- Too generic (#love, #instagood only)
- Irrelevant hashtags
- Wrong number for platform
- No niche hashtags

**Solutions**:
1. Mix popular and niche hashtags
2. Research industry-specific tags
3. Follow platform best practices (IG: 10-30, Twitter: 1-2)
4. Use suggested hashtags from optimization

### Low Sentiment Score

**Symptoms**: Sentiment score < 0.5 or negative label

**Common Causes**:
- Negative language
- Complaints without solution
- Controversial without context
- Inappropriate tone for platform

**Solutions**:
1. Reframe negatives as positives
2. Add constructive elements
3. Match platform's tone expectations
4. Review controversial risk warnings

### No Visual Content Warning

**Symptoms**: "No visual content" warning

**Impact**:
- Visual posts get 2-3x more engagement
- Lower overall score
- Reduced reach potential

**Solutions**:
1. Add relevant image: `--image URL`
2. Add video content: `--video URL`
3. Create custom graphics
4. Use stock photos if needed

### Email Report Failures

**Symptoms**: "Email report failed" message

**Common Causes**:
- Missing email credentials
- Wrong Gmail app password
- 2FA not enabled
- SMTP settings incorrect

**Solutions**:
```bash
# Quick fix: Skip email
python main.py POST001 --skip-email

# Long-term fix:
# 1. Enable 2FA on Google Account
# 2. Generate App Password
# 3. Update .env with app password (not regular password)
# 4. Verify SMTP settings
```

## Performance Tips

### Optimize API Usage

The system makes 5-6 API calls per optimization. To reduce costs:

1. **Use --skip-email** for testing:
   ```bash
   python main.py --content "Test post" --platform instagram --skip-email
   ```

2. **Test with samples** before custom content:
   ```bash
   python main.py POST001  # Uses cached patterns
   ```

3. **Batch similar content**:
   Group similar posts and optimize in one session.

### Speed Optimization

Average optimization takes 15-30 seconds. To speed up:

1. **Use faster model** (if available):
   ```env
   GEMINI_MODEL=gemini-1.5-flash  # Faster but less accurate
   ```

2. **Reduce parallel workers**:
   Edit `workflows/post_optimization_workflow.py`:
   ```python
   create_post_optimization_workflow(max_workers=3)  # Default is 5
   ```

3. **Skip email**:
   ```bash
   python main.py POST001 --skip-email  # Saves 2-3 seconds
   ```

## FAQ

**Q: How accurate are engagement predictions?**
A: Predictions are based on content analysis and platform best practices. Actual engagement depends on many factors including follower count, posting history, and timing. Use as a relative guide.

**Q: Can I optimize already-posted content?**
A: Yes! Use it to analyze past posts and learn what works for future content.

**Q: Do I need visual content?**
A: Not required, but highly recommended. Posts with visuals typically get 2-3x more engagement.

**Q: Can I customize the AI prompts?**
A: Yes, edit the prompts in each analyzer file (`analyzers/*.py`).

**Q: How often should I optimize?**
A: Optimize every post before scheduling for best results.

**Q: Does it work for Instagram Reels/Stories?**
A: Optimized for feed posts. Reels and Stories have different dynamics but many insights still apply.

**Q: Can I use this for ads?**
A: Yes! The optimization principles apply to both organic and paid content.

**Q: What about multiple images (carousels)?**
A: Currently optimized for single image. Carousel-specific features coming soon.

## Next Steps

1. **Start with samples**: `python main.py --list-samples`
2. **Try your content**: `python main.py --content "..." --platform ...`
3. **Read README**: Check [README.md](README.md) for architecture details
4. **Customize**: Adjust `.env` settings for your needs
5. **Integrate**: Use programmatically in your workflow
6. **Track**: Compare predictions with actual results

## Getting Help

- Review logs: `logs/social_media_optimizer.log`
- Check configuration: `.env` file
- Test with samples: `python main.py POST001`
- Enable verbose mode: `--verbose` flag

Happy optimizing! 🚀📱
