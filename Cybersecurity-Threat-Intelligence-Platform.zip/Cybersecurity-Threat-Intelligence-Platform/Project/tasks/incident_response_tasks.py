"""
Incident Response Tasks

Tasks for coordinating incident response and threat remediation.
"""

from crewai import Task
from agents.incident_response_agent import create_incident_response_agent

incident_response_task = Task(
    description="""Develop and coordinate incident response plans to contain and remediate threats.

    Your tasks:
    1. Activate incident response procedures based on threat severity
    2. Coordinate containment actions to isolate affected systems
    3. Implement network segmentation to prevent lateral movement
    4. Deploy patches and security updates to vulnerable systems
    5. Conduct forensic evidence collection and preservation
    6. Remove malware and eradicate threat actor presence
    7. Restore systems from clean backups when necessary
    8. Reset compromised credentials and strengthen authentication
    9. Monitor for re-infection and persistent threats
    10. Document incident timeline and lessons learned

    Focus on rapid containment and complete threat eradication.""",

    expected_output="""A comprehensive incident response plan containing:
    - Incident severity classification and escalation level
    - Immediate containment actions and isolations required
    - Network segmentation and access control changes
    - Systems requiring patching, updates, or reimaging
    - Forensic investigation procedures and evidence collection
    - Malware removal and system cleaning steps
    - Recovery procedures and backup restoration plans
    - Credential resets and authentication hardening
    - Monitoring requirements for persistent threats
    - Communication plan for stakeholders and management
    - Lessons learned and post-incident review recommendations""",

    agent=create_incident_response_agent()
)
