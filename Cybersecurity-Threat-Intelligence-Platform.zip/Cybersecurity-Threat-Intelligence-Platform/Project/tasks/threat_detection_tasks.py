"""
Threat Detection Tasks

Tasks for detecting cybersecurity threats across systems and networks.
"""

from crewai import Task
from agents.threat_detection_agent import create_threat_detection_agent

threat_detection_task = Task(
    description="""Monitor and detect cybersecurity threats across all organizational systems.

    Your tasks:
    1. Monitor network traffic for suspicious activities and anomalies
    2. Analyze endpoint logs for malware indicators and unusual behaviors
    3. Review firewall logs and IDS/IPS alerts for attack signatures
    4. Scan email systems for phishing attempts and malicious attachments
    5. Check web application logs for exploitation attempts
    6. Correlate events from SIEM systems to identify attack patterns
    7. Identify indicators of compromise (IOCs) including suspicious IPs, domains, and file hashes
    8. Detect brute force attempts, unauthorized access, and privilege escalation
    9. Monitor for data exfiltration and command-and-control communications
    10. Track threat actor TTPs using MITRE ATT&CK framework

    Focus on early detection and real-time threat identification.""",

    expected_output="""A comprehensive threat detection report containing:
    - Total security events analyzed
    - Number of threats detected by severity (critical, high, medium, low)
    - Threat severity score and attack success rate
    - Compromised systems count and blocked attacks
    - Threat sources (external IPs, internal hosts, unknown)
    - Attack vectors identified (phishing, web exploits, malware, etc.)
    - Indicators of compromise (IOCs)
    - Top targeted assets and systems
    - Active threat actors and APT groups detected
    - Detection effectiveness metrics (MTTD, MTTR)
    - Immediate recommended actions""",

    agent=create_threat_detection_agent()
)
