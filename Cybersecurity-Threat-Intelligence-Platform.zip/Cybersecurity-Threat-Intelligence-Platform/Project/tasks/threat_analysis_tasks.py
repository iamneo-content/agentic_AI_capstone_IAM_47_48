"""
Threat Analysis Tasks

Tasks for analyzing detected threats and assessing their impact.
"""

from crewai import Task
from agents.threat_analysis_agent import create_threat_analysis_agent

threat_analysis_task = Task(
    description="""Analyze detected threats to assess severity, impact, and attack patterns.

    Your tasks:
    1. Assess severity and risk level of each detected threat
    2. Analyze attack patterns and threat actor techniques (TTPs)
    3. Identify potential impact on business operations and data
    4. Correlate threats with known threat intelligence and CVEs
    5. Attribute attacks to specific threat actors or APT groups when possible
    6. Analyze malware samples and determine capabilities
    7. Evaluate lateral movement potential and attack progression
    8. Assess data breach risk and sensitive information exposure
    9. Identify vulnerable systems and attack surface areas
    10. Prioritize threats based on risk to organization

    Focus on actionable intelligence for security response.""",

    expected_output="""A detailed threat analysis report containing:
    - Threat severity classification and risk scores
    - Attack pattern analysis and TTPs identified
    - Business impact assessment (financial, operational, reputational)
    - Threat actor attribution and motivation analysis
    - Malware analysis findings and capabilities
    - Attack kill chain analysis and current stage
    - Vulnerable systems and affected assets
    - Data breach risk assessment
    - Threat prioritization matrix
    - Recommended security controls and mitigations""",

    agent=create_threat_analysis_agent()
)
