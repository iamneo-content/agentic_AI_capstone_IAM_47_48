"""
Security Recommendation Tasks

Tasks for providing security improvements and strategic recommendations.
"""

from crewai import Task
from agents.security_recommendation_agent import create_security_recommendation_agent

security_recommendation_task = Task(
    description="""Provide strategic security recommendations to strengthen defenses and prevent future incidents.

    Your tasks:
    1. Identify security gaps and control weaknesses exploited by threats
    2. Recommend technical controls (firewall rules, EDR, MFA, encryption)
    3. Suggest administrative controls (policies, procedures, access management)
    4. Develop security awareness training for identified attack vectors
    5. Recommend vulnerability management and patch management improvements
    6. Design network security architecture enhancements
    7. Propose threat intelligence integration and automation
    8. Suggest security monitoring and detection improvements
    9. Develop zero trust architecture recommendations
    10. Create security roadmap with prioritized initiatives

    Focus on practical, cost-effective recommendations aligned with business goals.""",

    expected_output="""A comprehensive security recommendation report containing:
    - Security gaps and vulnerabilities identified
    - Technical control recommendations (firewall, EDR, SIEM, etc.)
    - Administrative control recommendations (policies, procedures)
    - Security awareness training needs and topics
    - Vulnerability and patch management improvements
    - Network security architecture enhancements
    - Threat intelligence integration opportunities
    - Security monitoring and detection upgrades
    - Zero trust architecture implementation plan
    - Prioritized security roadmap with timelines and costs
    - Expected risk reduction and ROI for each recommendation
    - Quick wins vs. long-term strategic improvements""",

    agent=create_security_recommendation_agent()
)
