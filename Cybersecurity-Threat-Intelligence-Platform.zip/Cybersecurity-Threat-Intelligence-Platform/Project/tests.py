"""
Comprehensive Test Suite for Cybersecurity Threat Intelligence Platform

This test suite covers all major components of the platform including:
- Tools (ThreatDetectionTool)
- Agents (Threat Detection, Analysis, Incident Response, Security Recommendation)
- Tasks (All threat intelligence tasks)
- Flow (ThreatIntelligenceFlow)
- Configuration files
- Utilities
"""

import pytest
import json
import os
from pathlib import Path
from datetime import datetime

# Import tools
from tools.threat_detection_tool import ThreatDetectionTool

# Import agents
from agents.threat_detection_agent import create_threat_detection_agent
from agents.threat_analysis_agent import create_threat_analysis_agent
from agents.incident_response_agent import create_incident_response_agent
from agents.security_recommendation_agent import create_security_recommendation_agent

# Import tasks
from tasks.threat_detection_tasks import threat_detection_task
from tasks.threat_analysis_tasks import threat_analysis_task
from tasks.incident_response_tasks import incident_response_task
from tasks.security_recommendation_tasks import security_recommendation_task

# Import flow
from flows.threat_intelligence_flow import ThreatIntelligenceFlow

# Import utilities
from utils.llm_config import get_llm_config
from utils.output_handler import process_and_save_results


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def sample_threat_category():
    """Sample threat category for testing."""
    return "malware"


@pytest.fixture
def sample_threat_data():
    """Sample threat data for testing."""
    return {
        "threats_detected": 92,
        "critical_threats": 8,
        "high_threats": 25,
        "severity_score": 72.0,
        "compromised_systems": 4,
        "blocked_attacks": 285
    }


@pytest.fixture
def config_file_path():
    """Path to configuration file."""
    return Path(__file__).parent / "configs" / "app_config.json"


# ============================================================================
# TOOL TESTS
# ============================================================================

class TestThreatDetectionTool:
    """Test suite for ThreatDetectionTool."""

    def test_threat_detection_tool_initialization(self):
        """Test that ThreatDetectionTool initializes correctly."""
        tool = ThreatDetectionTool()
        assert tool is not None
        assert tool.name == "Cybersecurity Threat Detection System"
        assert hasattr(tool, '_run')

    def test_threat_detection_tool_returns_valid_structure(self, sample_threat_category):
        """Test that threat detection tool returns a valid report structure."""
        tool = ThreatDetectionTool()
        result = tool._run(threat_category=sample_threat_category)

        assert isinstance(result, str)
        assert "Cybersecurity Threat Intelligence Report" in result
        assert "Threat Detection Summary" in result
        assert "Threats Detected" in result
        assert "CRITICAL" in result

    def test_threat_detection_tool_different_categories(self):
        """Test tool with different threat categories."""
        tool = ThreatDetectionTool()
        categories = ["malware", "phishing", "ransomware", "ddos", "data_breach"]

        for category in categories:
            result = tool._run(threat_category=category)
            assert isinstance(result, str)
            assert len(result) > 0
            assert category.upper() in result


# ============================================================================
# AGENT TESTS
# ============================================================================

class TestAgents:
    """Test suite for all threat intelligence agents."""

    def test_threat_detection_agent_creation(self):
        """Test Threat Detection Agent creation."""
        agent = create_threat_detection_agent()
        assert agent is not None
        assert agent.role == "Cybersecurity Threat Detection Specialist"
        assert len(agent.tools) > 0

    def test_threat_analysis_agent_creation(self):
        """Test Threat Analysis Agent creation."""
        agent = create_threat_analysis_agent()
        assert agent is not None
        assert agent.role == "Threat Intelligence Analyst"
        assert hasattr(agent, 'goal')

    def test_incident_response_agent_creation(self):
        """Test Incident Response Agent creation."""
        agent = create_incident_response_agent()
        assert agent is not None
        assert agent.role == "Incident Response Coordinator"
        assert hasattr(agent, 'backstory')

    def test_security_recommendation_agent_creation(self):
        """Test Security Recommendation Agent creation."""
        agent = create_security_recommendation_agent()
        assert agent is not None
        assert agent.role == "Security Architecture and Strategy Advisor"
        assert hasattr(agent, 'llm')


# ============================================================================
# TASK TESTS
# ============================================================================

class TestTasks:
    """Test suite for all threat intelligence tasks."""

    def test_threat_detection_task_structure(self):
        """Test threat detection task structure."""
        task = threat_detection_task
        assert task is not None
        assert hasattr(task, 'description')
        assert hasattr(task, 'expected_output')
        assert hasattr(task, 'agent')
        assert len(task.description) > 0

    def test_threat_analysis_task_structure(self):
        """Test threat analysis task structure."""
        task = threat_analysis_task
        assert task is not None
        assert hasattr(task, 'description')
        assert hasattr(task, 'expected_output')
        assert "severity" in task.description.lower()

    def test_incident_response_task_structure(self):
        """Test incident response task structure."""
        task = incident_response_task
        assert task is not None
        assert hasattr(task, 'description')
        assert "incident response" in task.description.lower()

    def test_security_recommendation_task_structure(self):
        """Test security recommendation task structure."""
        task = security_recommendation_task
        assert task is not None
        assert hasattr(task, 'description')
        assert "recommendation" in task.description.lower()


# ============================================================================
# FLOW TESTS
# ============================================================================

class TestThreatIntelligenceFlow:
    """Test suite for ThreatIntelligenceFlow."""

    def test_flow_initialization(self):
        """Test flow initializes correctly."""
        flow = ThreatIntelligenceFlow(verbose=False)
        assert flow is not None
        assert hasattr(flow, 'threat_data')
        assert hasattr(flow, 'threat_severity_score')
        assert hasattr(flow, 'threat_analysis')
        assert hasattr(flow, 'critical_threats')
        assert flow.execution_start is not None

    def test_flow_has_required_methods(self):
        """Test flow has all required step methods."""
        flow = ThreatIntelligenceFlow(verbose=False)
        assert hasattr(flow, 'detect_threats')
        assert hasattr(flow, 'analyze_threats')
        assert hasattr(flow, 'respond_to_incidents')
        assert hasattr(flow, 'recommend_security_improvements')
        assert hasattr(flow, 'finalize_intelligence')

    def test_flow_parsing_methods(self):
        """Test flow has parsing methods for each step."""
        flow = ThreatIntelligenceFlow(verbose=False)
        assert hasattr(flow, '_parse_threat_data')
        assert hasattr(flow, '_parse_threat_analysis')
        assert hasattr(flow, '_parse_incident_response')
        assert hasattr(flow, '_parse_security_recommendations')

    def test_flow_parse_threat_data(self):
        """Test threat data parsing returns valid structure."""
        flow = ThreatIntelligenceFlow(verbose=False)
        result = flow._parse_threat_data("sample result")
        assert isinstance(result, dict)
        assert 'threats_detected' in result
        assert 'severity_score' in result
        assert 'critical_threats' in result

    def test_flow_parse_threat_analysis(self):
        """Test threat analysis parsing returns valid structure."""
        flow = ThreatIntelligenceFlow(verbose=False)
        result = flow._parse_threat_analysis("sample result")
        assert isinstance(result, dict)
        assert 'critical_threats' in result
        assert 'attack_patterns' in result
        assert 'threat_actors' in result


# ============================================================================
# CONFIGURATION TESTS
# ============================================================================

class TestConfiguration:
    """Test suite for configuration files."""

    def test_config_file_exists(self, config_file_path):
        """Test that configuration file exists."""
        assert config_file_path.exists()
        assert config_file_path.is_file()

    def test_config_file_valid_json(self, config_file_path):
        """Test that configuration file is valid JSON."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        assert isinstance(config, dict)

    def test_config_has_threat_intelligence_settings(self, config_file_path):
        """Test configuration has threat intelligence settings."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        assert 'threat_intelligence_settings' in config

    def test_config_threat_categories(self, config_file_path):
        """Test configuration has threat categories defined."""
        with open(config_file_path, 'r') as f:
            config = json.load(f)
        settings = config['threat_intelligence_settings']
        assert 'threat_categories' in settings
        assert isinstance(settings['threat_categories'], list)
        assert len(settings['threat_categories']) > 0


# ============================================================================
# UTILITY TESTS
# ============================================================================

class TestUtilities:
    """Test suite for utility functions."""

    def test_get_llm_config(self):
        """Test LLM configuration retrieval."""
        config = get_llm_config()
        assert config is not None
        assert isinstance(config, str)
        assert "gemini" in config.lower()

    def test_process_and_save_results_with_dict(self, sample_threat_data):
        """Test result processing with dictionary data."""
        result = process_and_save_results(sample_threat_data)
        assert isinstance(result, bool)

    def test_process_and_save_results_with_string(self):
        """Test result processing with string data."""
        result = process_and_save_results("test result")
        assert isinstance(result, bool)


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestIntegration:
    """Integration tests for the complete platform."""

    def test_output_directory_creation(self):
        """Test that output directory can be created."""
        output_dir = Path(__file__).parent / "outputs"
        output_dir.mkdir(parents=True, exist_ok=True)
        assert output_dir.exists()
        assert output_dir.is_dir()

    def test_agents_and_tasks_compatibility(self):
        """Test that agents and tasks are compatible."""
        # Each task should have an agent
        assert threat_detection_task.agent is not None
        assert threat_analysis_task.agent is not None
        assert incident_response_task.agent is not None
        assert security_recommendation_task.agent is not None


# ============================================================================
# RUN TESTS
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
