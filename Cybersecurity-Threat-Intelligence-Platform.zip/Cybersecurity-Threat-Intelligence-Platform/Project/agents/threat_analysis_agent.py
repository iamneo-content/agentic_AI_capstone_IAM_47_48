"""
Threat Analysis Agent

This agent analyzes detected threats to assess their severity and impact.
"""

from crewai import Agent
from utils.llm_config import get_llm_config


def create_threat_analysis_agent():
    """
    Create the Threat Analysis Agent.

    This agent analyzes detected threats to determine their severity, impact,
    and potential damage to the organization.

    Returns:
        Configured Agent for threat analysis
    """
    llm = get_llm_config()

    agent = Agent(
        role="Threat Intelligence Analyst",
        goal="Analyze detected threats to assess severity, impact, attack patterns, and provide actionable intelligence for security response",
        backstory="""You are a senior threat intelligence analyst with deep expertise in cyber threat
        analysis, malware reverse engineering, and attack attribution. You excel at analyzing threat
        actor behaviors, understanding attack campaigns, and assessing the business impact of security
        incidents. Your skills include threat modeling, risk assessment, vulnerability analysis, and
        correlating threat intelligence from multiple sources. You understand APT groups, ransomware
        operations, nation-state attacks, and organized cybercrime. Your analytical approach helps
        organizations understand the 'who, what, when, where, why, and how' of cyber threats.""",
        llm=llm,
        tools=[],
        verbose=True
    )

    return agent
