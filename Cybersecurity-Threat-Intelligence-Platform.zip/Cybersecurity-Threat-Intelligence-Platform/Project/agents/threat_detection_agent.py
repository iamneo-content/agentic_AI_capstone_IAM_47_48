"""
Threat Detection Agent

This agent monitors and detects cybersecurity threats across the organization.
"""

from crewai import Agent
from tools.threat_detection_tool import ThreatDetectionTool
from utils.llm_config import get_llm_config


def create_threat_detection_agent():
    """
    Create the Threat Detection Agent.

    This agent monitors network traffic, endpoints, and systems to detect
    cybersecurity threats in real-time.

    Returns:
        Configured Agent for threat detection
    """
    llm = get_llm_config()

    threat_detection_tool = ThreatDetectionTool()

    agent = Agent(
        role="Cybersecurity Threat Detection Specialist",
        goal="Monitor and detect cybersecurity threats across all systems, networks, and endpoints to identify potential security incidents before they cause damage",
        backstory="""You are an elite cybersecurity analyst with extensive experience in threat
        detection, network security monitoring, and intrusion detection. You excel at analyzing
        security events from SIEM systems, firewalls, IDS/IPS, endpoint detection tools, and threat
        intelligence feeds. Your expertise includes malware analysis, phishing detection, anomaly
        detection, and identifying indicators of compromise (IOCs). You stay updated on the latest
        threat actor tactics, techniques, and procedures (TTPs) from MITRE ATT&CK framework. Your
        vigilance and attention to detail help protect organizations from sophisticated cyber attacks.""",
        llm=llm,
        tools=[threat_detection_tool],
        verbose=True
    )

    return agent
