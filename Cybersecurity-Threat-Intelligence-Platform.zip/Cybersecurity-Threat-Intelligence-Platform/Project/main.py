"""
Cybersecurity Threat Intelligence Platform - Main Entry Point

This module serves as the entry point for the Cybersecurity Threat Intelligence Platform
using CrewAI Flow for multi-agent orchestration.
"""

import logging
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

from flows.threat_intelligence_flow import ThreatIntelligenceFlow

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def ensure_output_directory() -> Path:
    """Ensure the output directory exists."""
    output_dir = Path(__file__).parent / "outputs"
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def process_and_save_results(result: Dict[str, Any]) -> bool:
    """Process and save the flow execution results."""
    try:
        output_dir = ensure_output_directory()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = output_dir / f"threat_intelligence_report_{timestamp}.json"

        # Save results to JSON
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, default=str)

        logger.info(f"📄 Results saved to: {output_file}")

        # Display summary
        if result.get("status") == "completed":
            logger.info("\n" + "="*70)
            logger.info("📊 THREAT INTELLIGENCE SUMMARY")
            logger.info("="*70)

            results = result.get("results", {})

            logger.info(f"⚠️  Threat Severity Score: {results.get('threat_severity_score', 0):.1f}/100")
            logger.info(f"🚨 Critical Threats Identified: {results.get('critical_threats', 0)}")

            threat_data = results.get("threat_data", {})
            logger.info(f"🔍 Total Threats Detected: {threat_data.get('threats_detected', 0)}")
            logger.info(f"🛡️  Blocked Attacks: {threat_data.get('blocked_attacks', 0)}")
            logger.info(f"💻 Compromised Systems: {threat_data.get('compromised_systems', 0)}")

            incident_plan = results.get("incident_response_plan", {})
            actions = incident_plan.get("actions", [])
            logger.info(f"🔧 Response Actions: {len(actions)}")

            security_recs = results.get("security_recommendations", {})
            recommendations = security_recs.get("recommendations", [])
            logger.info(f"💡 Security Recommendations: {len(recommendations)}")

            metrics = result.get("metrics", {})
            logger.info(f"⏱️  Total Execution Time: {result.get('execution_time', 0):.2f}s")

            logger.info("="*70)

            return True

        else:
            logger.error("❌ Flow execution did not complete successfully")
            return False

    except Exception as e:
        logger.error(f"❌ Error processing results: {e}")
        return False


def main():
    """Main execution function."""
    logger.info("="*70)
    logger.info("🛡️  CYBERSECURITY THREAT INTELLIGENCE PLATFORM")
    logger.info("="*70)
    logger.info("🚀 Initializing multi-agent threat intelligence system...")
    logger.info("="*70 + "\n")

    try:
        # Initialize and run the flow
        flow = ThreatIntelligenceFlow(verbose=True)
        result = flow.kickoff()

        # Process and save results
        if process_and_save_results(result):
            logger.info("\n✅ SUCCESS: Threat Intelligence Platform completed successfully!")
            return result
        else:
            logger.error("\n❌ FAILURE: Flow execution encountered errors")
            return None

    except Exception as e:
        logger.error(f"\n❌ CRITICAL ERROR: {e}", exc_info=True)
        return None


if __name__ == "__main__":
    main()
