"""
Threat Detection Tool

A tool for detecting and monitoring cybersecurity threats across the network.
"""

from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import random


class ThreatDetectionInput(BaseModel):
    """Input schema for Threat Detection Tool."""
    threat_category: str = Field(..., description="Category of threat: malware, phishing, ransomware, ddos, data_breach, insider_threat, zero_day, apt")


class ThreatDetectionTool(BaseTool):
    name: str = "Cybersecurity Threat Detection System"
    description: str = (
        "Detects and monitors cybersecurity threats across network, endpoints, and systems. "
        "Provides real-time threat intelligence and security alerts."
    )
    args_schema: Type[BaseModel] = ThreatDetectionInput

    def _run(self, threat_category: str) -> str:
        """
        Simulate threat detection and monitoring.

        Args:
            threat_category: Category of threat to monitor

        Returns:
            Formatted threat detection report
        """
        # Simulate threat detection data
        total_events = random.randint(5000, 15000)
        threats_detected = random.randint(25, 150)
        critical_threats = random.randint(2, 12)
        high_threats = random.randint(8, 35)
        medium_threats = random.randint(15, 60)
        low_threats = random.randint(10, 50)

        threat_severity_score = random.uniform(55, 85)
        attack_success_rate = random.uniform(0.5, 3.5)

        threat_sources = {
            "external_ips": random.randint(50, 200),
            "internal_hosts": random.randint(5, 25),
            "unknown_sources": random.randint(10, 40)
        }

        attack_vectors = {
            "email_phishing": random.randint(30, 80),
            "web_exploits": random.randint(20, 60),
            "malicious_downloads": random.randint(15, 45),
            "brute_force_attempts": random.randint(100, 300),
            "sql_injection": random.randint(10, 40),
            "xss_attacks": random.randint(8, 30)
        }

        compromised_systems = random.randint(1, 8)
        blocked_attacks = random.randint(100, 400)

        indicators_of_compromise = {
            "suspicious_ips": random.randint(40, 120),
            "malicious_domains": random.randint(25, 85),
            "file_hashes": random.randint(30, 100),
            "unusual_processes": random.randint(15, 50)
        }

        result = f"""
Cybersecurity Threat Intelligence Report - {threat_category.upper()}
{'='*70}

Threat Detection Summary:
- Total Security Events Analyzed: {total_events:,}
- Threats Detected: {threats_detected}
- Threat Severity Score: {threat_severity_score:.1f}/100
- Attack Success Rate: {attack_success_rate:.2f}%
- Systems Compromised: {compromised_systems}
- Attacks Blocked: {blocked_attacks}

Threat Severity Breakdown:
- CRITICAL: {critical_threats} threats (immediate action required)
- HIGH: {high_threats} threats (urgent response needed)
- MEDIUM: {medium_threats} threats (investigation required)
- LOW: {low_threats} threats (monitoring recommended)

Threat Sources:
- External IP Addresses: {threat_sources['external_ips']}
- Internal Hosts: {threat_sources['internal_hosts']}
- Unknown Sources: {threat_sources['unknown_sources']}

Attack Vectors Identified:
- Email Phishing Attempts: {attack_vectors['email_phishing']}
- Web Application Exploits: {attack_vectors['web_exploits']}
- Malicious Downloads: {attack_vectors['malicious_downloads']}
- Brute Force Login Attempts: {attack_vectors['brute_force_attempts']}
- SQL Injection Attempts: {attack_vectors['sql_injection']}
- Cross-Site Scripting (XSS): {attack_vectors['xss_attacks']}

Indicators of Compromise (IOCs):
- Suspicious IP Addresses: {indicators_of_compromise['suspicious_ips']}
- Malicious Domains: {indicators_of_compromise['malicious_domains']}
- Malicious File Hashes: {indicators_of_compromise['file_hashes']}
- Unusual Processes: {indicators_of_compromise['unusual_processes']}

Top Targeted Assets:
- Web Servers: {random.randint(20, 60)} attacks
- Database Servers: {random.randint(15, 45)} attacks
- Email Systems: {random.randint(25, 70)} attacks
- User Workstations: {random.randint(30, 90)} attacks
- Cloud Infrastructure: {random.randint(18, 55)} attacks

Threat Intelligence:
- Active Threat Actors: {random.randint(8, 25)}
- Known APT Groups Detected: {random.randint(2, 8)}
- Zero-Day Exploits: {random.randint(0, 3)}
- Malware Families Identified: {random.randint(10, 30)}

Network Security Status:
- Firewall Events: {random.randint(10000, 50000):,}
- IDS/IPS Alerts: {random.randint(500, 2000):,}
- Failed Authentication Attempts: {random.randint(200, 800)}
- Unauthorized Access Attempts: {random.randint(50, 200)}

Detection Effectiveness:
- True Positive Rate: {random.uniform(85, 95):.1f}%
- False Positive Rate: {random.uniform(3, 8):.1f}%
- Mean Time to Detect (MTTD): {random.uniform(2, 8):.1f} hours
- Mean Time to Respond (MTTR): {random.uniform(4, 12):.1f} hours

Recommended Actions:
- Isolate compromised systems immediately
- Block malicious IP addresses and domains
- Update security signatures and threat feeds
- Conduct forensic analysis on affected systems
- Implement additional monitoring for critical assets
"""
        return result
