"""
Content Analysis Agent

This agent analyzes content for violations using specialized AI tools for images, videos, text, and audio.
"""

from crewai import Agent
from tools.image_analyzer import ImageAnalyzerTool
from tools.video_analyzer import VideoAnalyzerTool
from tools.text_analyzer import TextAnalyzerTool
from tools.audio_analyzer import AudioAnalyzerTool
from utils.llm_config import get_llm_config


def create_content_analysis_agent():
    """
    Create the Content Analysis Agent.

    This agent analyzes content for policy violations including violence, nudity,
    hate speech, harassment, and other inappropriate content using specialized AI tools.

    Returns:
        Configured Agent for content analysis
    """
    llm = get_llm_config()

    image_analyzer = ImageAnalyzerTool()
    video_analyzer = VideoAnalyzerTool()
    text_analyzer = TextAnalyzerTool()
    audio_analyzer = AudioAnalyzerTool()

    agent = Agent(
        role="Content Analysis Specialist",
        goal="Analyze content for policy violations using AI-powered detection tools across all media types",
        backstory="""You are an expert AI content analyst with extensive experience in computer vision,
        natural language processing, and audio analysis. You specialize in detecting inappropriate content
        including violence, nudity, hate speech, harassment, and other violations. You use state-of-the-art
        AI models to analyze images, videos, text, and audio with high accuracy. Your expertise ensures
        comprehensive detection of policy violations while minimizing false positives.""",
        llm=llm,
        tools=[image_analyzer, video_analyzer, text_analyzer, audio_analyzer],
        verbose=True
    )

    return agent
