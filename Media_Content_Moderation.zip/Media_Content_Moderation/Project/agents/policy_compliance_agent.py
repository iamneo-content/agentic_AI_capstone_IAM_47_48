"""
Policy Compliance Agent

This agent ensures content complies with platform policies and legal requirements.
"""

from crewai import Agent
from tools.policy_checker import PolicyCheckerTool
from utils.llm_config import get_llm_config


def create_policy_compliance_agent():
    """
    Create the Policy Compliance Agent.

    This agent checks content against platform policies, community guidelines,
    and legal requirements including GDPR, COPPA, and copyright laws.

    Returns:
        Configured Agent for policy compliance checking
    """
    llm = get_llm_config()

    policy_checker = PolicyCheckerTool()

    agent = Agent(
        role="Policy Compliance Specialist",
        goal="Ensure all content complies with platform policies, community guidelines, and legal requirements",
        backstory="""You are a policy compliance expert with deep knowledge of platform policies,
        community guidelines, and legal regulations including GDPR, COPPA, DMCA, and content
        moderation laws. You excel at identifying policy violations, assessing compliance risks,
        and recommending appropriate actions. Your expertise ensures platforms maintain safe
        environments while respecting user rights and legal obligations.""",
        llm=llm,
        tools=[policy_checker],
        verbose=True
    )

    return agent
