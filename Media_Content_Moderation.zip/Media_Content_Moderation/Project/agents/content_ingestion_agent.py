"""
Content Ingestion Agent

This agent fetches and prepares content from various sources for moderation analysis.
"""

from crewai import Agent
from tools.content_fetcher import ContentFetcherTool
from utils.llm_config import get_llm_config


def create_content_ingestion_agent():
    """
    Create the Content Ingestion Agent.

    This agent fetches content from various sources (URLs, uploads, platforms)
    and prepares it for moderation analysis with comprehensive metadata.

    Returns:
        Configured Agent for content ingestion
    """
    llm = get_llm_config()

    content_fetcher = ContentFetcherTool()

    agent = Agent(
        role="Content Ingestion Specialist",
        goal="Fetch and prepare content from all sources for comprehensive moderation analysis",
        backstory="""You are an expert content ingestion specialist with deep knowledge of
        various content delivery systems, streaming platforms, and file formats. You excel at
        fetching content from diverse sources, extracting metadata, categorizing content types,
        and ensuring content is properly prepared for analysis. Your attention to detail ensures
        no critical metadata is missed and content is properly classified.""",
        llm=llm,
        tools=[content_fetcher],
        verbose=True
    )

    return agent
