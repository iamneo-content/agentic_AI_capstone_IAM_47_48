"""
Moderation Decision Agent

This agent makes final moderation decisions and generates comprehensive reports.
"""

from crewai import Agent
from tools.moderation_report_generator import ModerationReportGeneratorTool
from utils.llm_config import get_llm_config


def create_moderation_decision_agent():
    """
    Create the Moderation Decision Agent.

    This agent synthesizes all analysis results and makes final moderation decisions,
    generating comprehensive reports with recommendations and audit trails.

    Returns:
        Configured Agent for moderation decisions
    """
    llm = get_llm_config()

    report_generator = ModerationReportGeneratorTool()

    agent = Agent(
        role="Moderation Decision Specialist",
        goal="Make final moderation decisions and generate comprehensive reports with recommendations",
        backstory="""You are a senior content moderation specialist with years of experience in
        content review, policy enforcement, and decision-making. You excel at synthesizing complex
        analysis results, weighing multiple factors, and making balanced decisions that protect
        users while respecting content creators. You generate detailed reports with clear
        recommendations, confidence scores, and audit trails. Your decisions are fair, consistent,
        and well-documented.""",
        llm=llm,
        tools=[report_generator],
        verbose=True
    )

    return agent
