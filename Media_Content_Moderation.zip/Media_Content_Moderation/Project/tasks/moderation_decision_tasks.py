"""
Moderation Decision Task

This task defines the workflow for making final moderation decisions and generating reports.
"""

from crewai import Task
from agents.moderation_decision_agent import create_moderation_decision_agent

agent = create_moderation_decision_agent()

moderation_decision_task = Task(
    description="""Make final moderation decisions and generate comprehensive reports.

    Your responsibilities:
    1. Synthesize all analysis results from previous stages:
       - Content ingestion metadata
       - Violation detection findings
       - Policy compliance assessment
    2. Make final moderation decision:
       - APPROVE: Content is safe and compliant
       - REJECT: Content violates policies and must be removed
       - REVIEW: Content requires human review for final decision
    3. Calculate decision confidence score
    4. Determine if human review is required
    5. Generate comprehensive moderation report using the Report Generator Tool
    6. Provide actionable recommendations:
       - Content approval/rejection
       - User notification requirements
       - Content restrictions or labels
       - Appeals process information
    7. Create detailed audit trail
    8. Document decision rationale
    9. Assign priority level for human review (if needed)

    Use the Moderation Report Generator Tool to create the final report.
    Ensure decisions are fair, consistent, and well-documented.""",
    agent=agent,
    expected_output="""A comprehensive moderation decision report including:
    - Content ID and final decision (APPROVE/REJECT/REVIEW)
    - Decision confidence score (0.0 to 1.0)
    - Detailed decision rationale and justification
    - Summary of all analysis findings
    - Human review requirement (yes/no) and priority
    - Actionable recommendations:
      * Content approval/rejection action
      * User notification requirements
      * Content restrictions or warnings
      * Geographic or age-based restrictions
      * Appeals process guidance
    - Complete audit trail:
      * Analysis timestamp
      * AI models and tools used
      * Review duration
      * Decision maker identification
    - Risk assessment and priority level
    - Next steps and escalation path
    - Documentation for appeals or audits"""
)
