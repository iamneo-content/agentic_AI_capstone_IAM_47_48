"""
Content Analysis Task

This task defines the workflow for analyzing content for policy violations.
"""

from crewai import Task
from agents.content_analysis_agent import create_content_analysis_agent

agent = create_content_analysis_agent()

content_analysis_task = Task(
    description="""Analyze content for policy violations using AI-powered detection tools.

    Your responsibilities:
    1. Select appropriate analysis tools based on content type:
       - Image Analyzer Tool for images
       - Video Analyzer Tool for videos
       - Text Analyzer Tool for text content
       - Audio Analyzer Tool for audio content
    2. Analyze content for the following violation categories:
       - Violence and graphic content
       - Nudity and sexual content
       - Hate speech and symbols
       - Harassment and bullying
       - Self-harm content
       - Illegal activities
       - Spam and misleading content
       - Misinformation risks
    3. Generate confidence scores for each violation category
    4. Identify specific timestamps, regions, or segments with violations
    5. Calculate overall safety scores
    6. Provide initial recommendations (approve, reject, review)
    7. Document all findings with detailed evidence

    Use the appropriate analysis tools based on content type.
    Ensure comprehensive detection while minimizing false positives.""",
    agent=agent,
    expected_output="""A comprehensive content analysis report including:
    - Content ID and type analyzed
    - Detailed violation detection results for all categories
    - Confidence scores for each violation type (0.0 to 1.0)
    - Flagged regions, timestamps, or text segments
    - Overall safety score (0.0 to 1.0)
    - Severity assessment (critical, high, medium, low, none)
    - Visual/audio/text evidence of violations
    - Initial recommendation (approve, reject, review)
    - Analysis methodology and tools used
    - Quality metrics and reliability indicators"""
)
