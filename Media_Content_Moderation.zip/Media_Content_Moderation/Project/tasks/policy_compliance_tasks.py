"""
Policy Compliance Task

This task defines the workflow for checking content against policies and legal requirements.
"""

from crewai import Task
from agents.policy_compliance_agent import create_policy_compliance_agent

agent = create_policy_compliance_agent()

policy_compliance_task = Task(
    description="""Verify content compliance with platform policies and legal requirements.

    Your responsibilities:
    1. Check content against platform policies using the Policy Checker Tool
    2. Verify compliance with community guidelines
    3. Assess legal compliance including:
       - GDPR (data protection and privacy)
       - COPPA (children's online privacy)
       - DMCA (copyright protection)
       - Age restriction requirements
       - Regional content regulations
    4. Identify copyright infringement risks
    5. Assess required content labels or warnings
    6. Determine if content requires age restrictions
    7. Identify any required actions (removal, labeling, restriction)
    8. Calculate overall compliance score
    9. Document all policy violations and legal concerns

    Use the Policy Checker Tool to verify compliance.
    Ensure thorough policy and legal review.""",
    agent=agent,
    expected_output="""A comprehensive policy compliance report including:
    - Content ID and compliance check details
    - Platform policy compliance status and violations
    - Community guidelines compliance assessment
    - Legal compliance verification:
      * GDPR compliance status
      * COPPA compliance status
      * DMCA/copyright assessment
      * Age restriction requirements
    - Copyright infringement risk assessment
    - Required content labels or warnings
    - Geographic restrictions if applicable
    - Overall compliance score (0.0 to 1.0)
    - List of required actions (if any)
    - Risk level assessment (critical, high, medium, low, none)
    - Detailed violation documentation"""
)
