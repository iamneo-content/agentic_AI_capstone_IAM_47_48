"""Task definitions for Media Content Moderation agents."""
