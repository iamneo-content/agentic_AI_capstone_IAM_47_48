"""
Content Ingestion Task

This task defines the workflow for fetching and preparing content for moderation.
"""

from crewai import Task
from agents.content_ingestion_agent import create_content_ingestion_agent

agent = create_content_ingestion_agent()

content_ingestion_task = Task(
    description="""Fetch and prepare content for comprehensive moderation analysis.

    Your responsibilities:
    1. Fetch content from the specified source using the Content Fetcher Tool
    2. Extract comprehensive metadata including:
       - Content type (image, video, text, audio)
       - File format and technical specifications
       - Duration/length (for video/audio)
       - Resolution and quality metrics
       - Upload date and source information
       - Uploader/creator identification
    3. Categorize content type for appropriate analysis routing
    4. Verify content integrity and accessibility
    5. Prepare content for analysis pipeline
    6. Document any issues with content retrieval or quality

    Use the Content Fetcher Tool to retrieve content from various sources.
    Focus on completeness, accuracy, and proper content categorization.""",
    agent=agent,
    expected_output="""A comprehensive content ingestion report including:
    - Content ID and unique identifier
    - Content type and format details
    - Complete metadata (size, duration, resolution, format)
    - Source information and upload details
    - Uploader/creator identification
    - Content categorization for analysis routing
    - Technical quality assessment
    - Any retrieval issues or warnings
    - Content readiness status for moderation pipeline
    - Recommended analysis tools based on content type"""
)
