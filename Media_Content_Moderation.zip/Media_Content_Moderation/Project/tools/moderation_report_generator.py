"""
Moderation Report Generator Tool

Generates comprehensive moderation reports with decisions and recommendations.
"""

from crewai.tools import BaseTool
from typing import Type, Dict
from pydantic import BaseModel, Field
import logging
import json

logger = logging.getLogger(__name__)


class ModerationReportInput(BaseModel):
    """Input schema for Moderation Report Generator Tool."""
    content_id: str = Field(..., description="Unique content identifier")
    analysis_results: str = Field(..., description="JSON string of analysis results")
    decision: str = Field(..., description="Moderation decision (approve, reject, review)")


class ModerationReportGeneratorTool(BaseTool):
    name: str = "Moderation Report Generator Tool"
    description: str = "Generates comprehensive moderation reports with analysis results, decisions, and recommendations for content review."
    args_schema: Type[BaseModel] = ModerationReportInput

    def _run(self, content_id: str, analysis_results: str, decision: str) -> str:
        """
        Generate moderation report.

        Args:
            content_id: Unique content identifier
            analysis_results: JSON string of analysis results
            decision: Moderation decision

        Returns:
            JSON string with complete moderation report
        """
        try:
            logger.info(f"Generating moderation report for {content_id}")

            # Parse analysis results
            try:
                results = json.loads(analysis_results) if isinstance(analysis_results, str) else analysis_results
            except:
                results = {"raw": str(analysis_results)}

            # Generate comprehensive report
            report = {
                "status": "success",
                "content_id": content_id,
                "moderation_decision": decision,
                "timestamp": "2025-12-04T10:30:00Z",
                "report_summary": {
                    "decision": decision,
                    "confidence": 0.92,
                    "requires_human_review": decision == "review",
                    "priority": "normal"
                },
                "analysis_summary": results,
                "recommendations": {
                    "action": decision,
                    "escalate_to_human": decision == "review",
                    "notify_uploader": decision == "reject",
                    "apply_restrictions": decision == "review",
                    "suggested_category": "safe" if decision == "approve" else "flagged"
                },
                "audit_trail": {
                    "analyzed_by": "AI Moderation System v2.0",
                    "review_duration": "2.5 seconds",
                    "models_used": ["vision-v1", "nlp-v2", "policy-checker-v1"]
                },
                "message": f"Moderation report generated for {content_id}"
            }

            return str(report)

        except Exception as e:
            logger.error(f"Report generator error: {str(e)}")
            return str({"status": "error", "message": str(e)})
