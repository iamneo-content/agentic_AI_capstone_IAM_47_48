"""
Text Analysis Tool

Analyzes text content for hate speech, profanity, harassment, and other violations.
"""

from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import logging

logger = logging.getLogger(__name__)


class TextAnalyzerInput(BaseModel):
    """Input schema for Text Analyzer Tool."""
    content_id: str = Field(..., description="Unique content identifier")
    text_content: str = Field(..., description="Text content to analyze")
    language: str = Field(default="en", description="Language code (en, es, fr, etc.)")


class TextAnalyzerTool(BaseTool):
    name: str = "Text Analysis Tool"
    description: str = "Analyzes text content for hate speech, profanity, harassment, threats, and other policy violations using NLP."
    args_schema: Type[BaseModel] = TextAnalyzerInput

    def _run(self, content_id: str, text_content: str, language: str = "en") -> str:
        """
        Analyze text content for violations.

        Args:
            content_id: Unique content identifier
            text_content: Text to analyze
            language: Language code

        Returns:
            JSON string with analysis results
        """
        try:
            logger.info(f"Analyzing text {content_id} in language {language}")

            # Simulated text analysis with NLP
            result = {
                "status": "success",
                "content_id": content_id,
                "language": language,
                "text_length": len(text_content),
                "violations_detected": {
                    "hate_speech": {"detected": False, "confidence": 0.06, "phrases": []},
                    "profanity": {"detected": False, "confidence": 0.08, "words": []},
                    "harassment": {"detected": False, "confidence": 0.04},
                    "threats": {"detected": False, "confidence": 0.02},
                    "sexual_content": {"detected": False, "confidence": 0.05},
                    "spam": {"detected": False, "confidence": 0.10},
                    "misinformation_risk": {"detected": False, "confidence": 0.12}
                },
                "sentiment_score": 0.65,
                "toxicity_score": 0.08,
                "overall_safety_score": 0.93,
                "recommendation": "approve",
                "message": f"Text analysis completed for {content_id}"
            }

            return str(result)

        except Exception as e:
            logger.error(f"Text analyzer error: {str(e)}")
            return str({"status": "error", "message": str(e)})
