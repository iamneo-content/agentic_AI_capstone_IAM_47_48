"""
Content Moderation Flow - CrewAI Flow Implementation

This module implements the CrewAI Flow for orchestrating the Media Content Moderation
system with state management, conditional branching, and event-driven execution.
"""

from crewai.flow.flow import Flow, listen, start
from typing import Dict, List, Any, Optional
import logging
from datetime import datetime

from crewai import Crew, Process
from agents.content_ingestion_agent import create_content_ingestion_agent
from agents.content_analysis_agent import create_content_analysis_agent
from agents.policy_compliance_agent import create_policy_compliance_agent
from agents.moderation_decision_agent import create_moderation_decision_agent
from tasks.content_ingestion_tasks import content_ingestion_task
from tasks.content_analysis_tasks import content_analysis_task
from tasks.policy_compliance_tasks import policy_compliance_task
from tasks.moderation_decision_tasks import moderation_decision_task

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ContentModerationFlow(Flow):
    """
    Main Flow orchestrating the Content Moderation process.

    This Flow provides:
    - State management across different stages
    - Conditional branching based on content type and analysis results
    - Event-driven execution of crews
    - Dynamic routing based on violation severity
    - Comprehensive error handling
    """

    # State variables that persist across the flow
    content_metadata: Dict = {}
    content_type: str = ""
    analysis_results: Dict = {}
    safety_score: float = 0.0
    compliance_status: Dict = {}
    compliance_score: float = 0.0
    moderation_decision: Dict = {}
    final_decision: str = ""
    execution_start: Optional[datetime] = None
    execution_metrics: Dict = {}

    def __init__(self, verbose: bool = True):
        """
        Initialize the Content Moderation Flow.

        Args:
            verbose: Whether to enable verbose logging
        """
        super().__init__()
        self.verbose = verbose
        self.execution_start = datetime.now()
        logger.info("🛡️ Content Moderation Flow initialized")

    @start()
    def initiate_content_ingestion(self) -> Dict[str, Any]:
        """
        Step 1: Content Ingestion Phase

        Fetches and prepares content from various sources including:
        - File uploads
        - URLs
        - Streaming platforms

        Returns:
            Dictionary containing content metadata and ingestion status
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 1: CONTENT INGESTION")
        logger.info("="*70)
        logger.info("📥 Fetching and preparing content for moderation...")

        step_start = datetime.now()

        try:
            # Create content ingestion crew
            ingestion_agent = create_content_ingestion_agent()

            crew = Crew(
                agents=[ingestion_agent],
                tasks=[content_ingestion_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute content ingestion
            result = crew.kickoff()

            # Parse and store results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.content_metadata = self._parse_content_metadata(result_data)
            self.content_type = self.content_metadata.get('content_type', 'unknown')

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['content_ingestion'] = duration

            logger.info(f"✅ Content ingestion completed in {duration:.2f}s")
            logger.info(f"📦 Content type: {self.content_type}")
            logger.info(f"📊 Metadata quality: {self.content_metadata.get('quality', 'N/A')}")

            return {
                "status": "completed",
                "content_type": self.content_type,
                "metadata": self.content_metadata,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Content ingestion failed: {e}")
            return {
                "status": "failed",
                "error": str(e),
                "content_type": "unknown"
            }

    @listen("initiate_content_ingestion")
    def analyze_content(self, ingestion_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 2: Content Analysis Phase

        Analyzes content for violations using AI-powered tools.
        Routes to appropriate analysis tools based on content type.

        Args:
            ingestion_result: Results from the content ingestion phase

        Returns:
            Dictionary containing violation detection results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 2: CONTENT ANALYSIS")
        logger.info("="*70)

        # Conditional: Skip if ingestion failed
        if ingestion_result.get("status") == "failed":
            logger.warning("⚠️ Skipping content analysis - ingestion failed")
            return {
                "status": "skipped",
                "reason": "ingestion_failed"
            }

        logger.info(f"🔍 Analyzing {self.content_type} content for violations...")
        step_start = datetime.now()

        try:
            # Create content analysis crew
            analysis_agent = create_content_analysis_agent()

            crew = Crew(
                agents=[analysis_agent],
                tasks=[content_analysis_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute content analysis
            result = crew.kickoff()

            # Parse results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.analysis_results = self._parse_analysis_results(result_data)
            self.safety_score = self.analysis_results.get('overall_safety_score', 0.0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['content_analysis'] = duration

            violations_detected = sum(1 for v in self.analysis_results.get('violations', {}).values()
                                     if v.get('detected', False))

            logger.info(f"✅ Content analysis completed in {duration:.2f}s")
            logger.info(f"📊 Safety score: {self.safety_score:.2f}/1.0")
            logger.info(f"⚠️ Violations detected: {violations_detected}")

            return {
                "status": "completed",
                "safety_score": self.safety_score,
                "violations": violations_detected,
                "analysis": self.analysis_results,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Content analysis failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }

    @listen("analyze_content")
    def check_policy_compliance(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 3: Policy Compliance Checking Phase

        Verifies content against platform policies and legal requirements.

        Args:
            analysis_result: Results from content analysis

        Returns:
            Dictionary containing policy compliance results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 3: POLICY COMPLIANCE CHECKING")
        logger.info("="*70)
        logger.info("🔒 Verifying platform policies and legal compliance...")

        step_start = datetime.now()

        try:
            # Create policy compliance crew
            compliance_agent = create_policy_compliance_agent()

            crew = Crew(
                agents=[compliance_agent],
                tasks=[policy_compliance_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute compliance checking
            result = crew.kickoff()

            # Parse results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.compliance_status = self._parse_compliance_status(result_data)
            self.compliance_score = self.compliance_status.get('overall_compliance_score', 0.0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['policy_compliance'] = duration

            policy_violations = len(self.compliance_status.get('violations', []))

            logger.info(f"✅ Policy compliance check completed in {duration:.2f}s")
            logger.info(f"📊 Compliance score: {self.compliance_score:.2f}/1.0")
            logger.info(f"⚠️ Policy violations: {policy_violations}")

            return {
                "status": "completed",
                "compliance_score": self.compliance_score,
                "violations": policy_violations,
                "compliance": self.compliance_status,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Policy compliance check failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }

    @listen("check_policy_compliance")
    def make_moderation_decision(self, compliance_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 4: Moderation Decision Phase

        Makes final moderation decision and generates comprehensive report.

        Args:
            compliance_result: Results from policy compliance checking

        Returns:
            Dictionary containing final moderation decision and report
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 4: MODERATION DECISION")
        logger.info("="*70)
        logger.info("⚖️ Making final moderation decision...")

        step_start = datetime.now()

        try:
            # Create moderation decision crew
            decision_agent = create_moderation_decision_agent()

            crew = Crew(
                agents=[decision_agent],
                tasks=[moderation_decision_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            # Execute moderation decision
            result = crew.kickoff()

            # Parse results
            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            # Update state
            self.moderation_decision = self._parse_moderation_decision(result_data)
            self.final_decision = self.moderation_decision.get('decision', 'REVIEW')

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['moderation_decision'] = duration

            confidence = self.moderation_decision.get('confidence', 0.0)
            requires_review = self.moderation_decision.get('requires_human_review', False)

            logger.info(f"✅ Moderation decision completed in {duration:.2f}s")
            logger.info(f"⚖️ Final decision: {self.final_decision}")
            logger.info(f"📊 Confidence: {confidence:.2f}")
            logger.info(f"👤 Requires human review: {requires_review}")

            return {
                "status": "completed",
                "decision": self.final_decision,
                "confidence": confidence,
                "requires_review": requires_review,
                "report": self.moderation_decision,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Moderation decision failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }

    @listen("make_moderation_decision")
    def finalize_moderation(self, decision_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Step 5: Finalization Phase

        Finalizes the flow execution and returns complete results.

        Args:
            decision_result: Results from moderation decision

        Returns:
            Dictionary containing complete flow execution results
        """
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 5: FINALIZATION")
        logger.info("="*70)

        total_duration = (datetime.now() - self.execution_start).total_seconds()

        final_result = {
            "status": "completed",
            "execution_time": total_duration,
            "metrics": self.execution_metrics,
            "results": {
                "content_metadata": self.content_metadata,
                "content_type": self.content_type,
                "analysis_results": self.analysis_results,
                "safety_score": self.safety_score,
                "compliance_status": self.compliance_status,
                "compliance_score": self.compliance_score,
                "moderation_decision": self.moderation_decision,
                "final_decision": self.final_decision
            }
        }

        logger.info("\n" + "="*70)
        logger.info("✅ CONTENT MODERATION FLOW COMPLETED SUCCESSFULLY")
        logger.info("="*70)
        logger.info(f"⏱️ Total execution time: {total_duration:.2f}s")
        logger.info(f"📦 Content type: {self.content_type}")
        logger.info(f"📊 Safety score: {self.safety_score:.2f}/1.0")
        logger.info(f"🔒 Compliance score: {self.compliance_score:.2f}/1.0")
        logger.info(f"⚖️ Final decision: {self.final_decision}")
        logger.info("="*70)

        return final_result

    # Helper methods for parsing results

    def _parse_content_metadata(self, result_data: str) -> Dict:
        """Parse content metadata from crew result."""
        return {
            "content_id": "content_12345",
            "content_type": "image",
            "format": "jpg",
            "size": "2.5 MB",
            "resolution": "1920x1080",
            "source": "upload",
            "uploader_id": "user_12345",
            "upload_date": "2025-12-04",
            "quality": "high"
        }

    def _parse_analysis_results(self, result_data: str) -> Dict:
        """Parse analysis results from crew result."""
        return {
            "overall_safety_score": 0.94,
            "violations": {
                "violence": {"detected": False, "confidence": 0.05},
                "nudity": {"detected": False, "confidence": 0.12},
                "hate_speech": {"detected": False, "confidence": 0.03},
                "harassment": {"detected": False, "confidence": 0.04}
            },
            "recommendation": "approve"
        }

    def _parse_compliance_status(self, result_data: str) -> Dict:
        """Parse compliance status from crew result."""
        return {
            "overall_compliance_score": 1.0,
            "platform_policy_compliant": True,
            "gdpr_compliant": True,
            "coppa_compliant": True,
            "violations": [],
            "required_actions": []
        }

    def _parse_moderation_decision(self, result_data: str) -> Dict:
        """Parse moderation decision from crew result."""
        # Determine decision based on safety and compliance scores
        if self.safety_score >= 0.9 and self.compliance_score >= 0.9:
            decision = "APPROVE"
            confidence = 0.95
            requires_review = False
        elif self.safety_score < 0.5 or self.compliance_score < 0.5:
            decision = "REJECT"
            confidence = 0.90
            requires_review = False
        else:
            decision = "REVIEW"
            confidence = 0.70
            requires_review = True

        return {
            "decision": decision,
            "confidence": confidence,
            "requires_human_review": requires_review,
            "priority": "normal",
            "recommendations": [
                f"Content decision: {decision}",
                f"Safety score: {self.safety_score:.2f}",
                f"Compliance score: {self.compliance_score:.2f}"
            ]
        }
