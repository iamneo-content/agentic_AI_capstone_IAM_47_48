"""
Test Suite for Media Content Moderation System

This module contains unit tests for the content moderation system.
"""

import unittest
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from flows.content_moderation_flow import ContentModerationFlow


class TestContentModerationFlow(unittest.TestCase):
    """Test cases for Content Moderation Flow."""

    def setUp(self):
        """Set up test fixtures."""
        self.flow = ContentModerationFlow(verbose=False)

    def test_flow_initialization(self):
        """Test that flow initializes correctly."""
        self.assertIsNotNone(self.flow)
        self.assertIsNotNone(self.flow.execution_start)
        self.assertEqual(self.flow.content_type, "")
        self.assertEqual(self.flow.safety_score, 0.0)

    def test_parse_content_metadata(self):
        """Test content metadata parsing."""
        result = self.flow._parse_content_metadata("test data")
        self.assertIsInstance(result, dict)
        self.assertIn('content_id', result)
        self.assertIn('content_type', result)

    def test_parse_analysis_results(self):
        """Test analysis results parsing."""
        result = self.flow._parse_analysis_results("test data")
        self.assertIsInstance(result, dict)
        self.assertIn('overall_safety_score', result)
        self.assertIn('violations', result)

    def test_parse_compliance_status(self):
        """Test compliance status parsing."""
        result = self.flow._parse_compliance_status("test data")
        self.assertIsInstance(result, dict)
        self.assertIn('overall_compliance_score', result)

    def test_parse_moderation_decision_approve(self):
        """Test moderation decision parsing for approve case."""
        self.flow.safety_score = 0.95
        self.flow.compliance_score = 0.95
        result = self.flow._parse_moderation_decision("test data")
        self.assertEqual(result['decision'], 'APPROVE')
        self.assertFalse(result['requires_human_review'])

    def test_parse_moderation_decision_reject(self):
        """Test moderation decision parsing for reject case."""
        self.flow.safety_score = 0.3
        self.flow.compliance_score = 0.3
        result = self.flow._parse_moderation_decision("test data")
        self.assertEqual(result['decision'], 'REJECT')

    def test_parse_moderation_decision_review(self):
        """Test moderation decision parsing for review case."""
        self.flow.safety_score = 0.7
        self.flow.compliance_score = 0.7
        result = self.flow._parse_moderation_decision("test data")
        self.assertEqual(result['decision'], 'REVIEW')
        self.assertTrue(result['requires_human_review'])


class TestTools(unittest.TestCase):
    """Test cases for moderation tools."""

    def test_content_fetcher_import(self):
        """Test that ContentFetcherTool can be imported."""
        from tools.content_fetcher import ContentFetcherTool
        tool = ContentFetcherTool()
        self.assertIsNotNone(tool)

    def test_image_analyzer_import(self):
        """Test that ImageAnalyzerTool can be imported."""
        from tools.image_analyzer import ImageAnalyzerTool
        tool = ImageAnalyzerTool()
        self.assertIsNotNone(tool)

    def test_policy_checker_import(self):
        """Test that PolicyCheckerTool can be imported."""
        from tools.policy_checker import PolicyCheckerTool
        tool = PolicyCheckerTool()
        self.assertIsNotNone(tool)


class TestAgents(unittest.TestCase):
    """Test cases for moderation agents."""

    def test_content_ingestion_agent_creation(self):
        """Test content ingestion agent creation."""
        from agents.content_ingestion_agent import create_content_ingestion_agent
        agent = create_content_ingestion_agent()
        self.assertIsNotNone(agent)

    def test_content_analysis_agent_creation(self):
        """Test content analysis agent creation."""
        from agents.content_analysis_agent import create_content_analysis_agent
        agent = create_content_analysis_agent()
        self.assertIsNotNone(agent)

    def test_policy_compliance_agent_creation(self):
        """Test policy compliance agent creation."""
        from agents.policy_compliance_agent import create_policy_compliance_agent
        agent = create_policy_compliance_agent()
        self.assertIsNotNone(agent)

    def test_moderation_decision_agent_creation(self):
        """Test moderation decision agent creation."""
        from agents.moderation_decision_agent import create_moderation_decision_agent
        agent = create_moderation_decision_agent()
        self.assertIsNotNone(agent)


if __name__ == '__main__':
    unittest.main()
