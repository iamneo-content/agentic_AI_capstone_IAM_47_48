#!/usr/bin/env python3
"""
Comprehensive Test Suite for Learning Path Recommender

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import LearningPathState
    from graph import LearningPathGraph
    from workflows.learning_path_workflow import create_learning_path_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.skill_gap_agent import SkillGapAgent
    from agents.learning_style_agent import LearningStyleAgent
    from agents.resource_curator_agent import ResourceCuratorAgent
    from agents.difficulty_calibrator_agent import DifficultyCalibratorAgent
    from agents.progress_tracker_agent import ProgressTrackerAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.skill_gap_analyzer import SkillGapAnalyzer
    from analyzers.learning_style_detector import LearningStyleDetector
    from analyzers.resource_curator import ResourceCurator
    from analyzers.difficulty_calibrator import DifficultyCalibrator
    from analyzers.progress_tracker import ProgressTracker

    # Import nodes
    from nodes.analysis_nodes import (
        analyze_skill_gaps,
        detect_learning_style,
        calibrate_difficulty,
        curate_resources,
        plan_progress,
        create_learning_path,
        send_learning_plan
    )

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestLearningPathRecommenderArchitecture(unittest.TestCase):
    """Test suite for Learning Path Recommender Architecture"""

    SAMPLE_LEARNER = {
        "learner_id": "TEST-123",
        "name": "John Doe",
        "current_skills": ["Python basics", "Data structures"],
        "target_skills": ["Machine Learning", "Deep Learning", "TensorFlow"],
        "target_skill": "Machine Learning",
        "target_level": "intermediate",
        "learning_style": "visual",
        "time_commitment": 10,
        "duration_weeks": 12,
        "preferences": {
            "learning_pace": "moderate",
            "preferred_format": "video"
        }
    }

    def setUp(self):
        """Setup test environment"""
        self.sample_learner = self.SAMPLE_LEARNER.copy()

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test LearningPathState dataclass creation"""
        logger.info("Testing LearningPathState creation...")

        state = LearningPathState(
            learner_id="TEST-123",
            target_skill="Machine Learning"
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.learner_id, "TEST-123", "Learner ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test LearningPathState clone method"""
        logger.info("Testing LearningPathState clone...")

        state = LearningPathState(learner_id="TEST-123", target_skill="ML")
        state.skill_gaps = [{"test": "data"}]

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.learner_id, state.learner_id, "Learner ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_skill_gap_analyzer(self):
        """Test SkillGapAnalyzer (pure tool)"""
        logger.info("Testing SkillGapAnalyzer...")

        analyzer = SkillGapAnalyzer()
        results = analyzer.analyze(
            target_skill=self.sample_learner["target_skill"],
            current_skills={"Python": 7.0, "Data structures": 6.0},
            target_level=8.0
        )

        self.assertIsNotNone(results, "Skill gap analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("skill_breakdown", results, "Results should contain skill_breakdown")

        logger.info("✓ SkillGapAnalyzer tests passed")

    def test_learning_style_detector(self):
        """Test LearningStyleDetector (pure tool)"""
        logger.info("Testing LearningStyleDetector...")

        analyzer = LearningStyleDetector()
        results = analyzer.detect(
            preferences=self.sample_learner.get("preferences", {}),
            past_experiences=[]
        )

        self.assertIsNotNone(results, "Learning style detection results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("primary_style", results, "Results should contain primary_style")

        logger.info("✓ LearningStyleDetector tests passed")

    def test_resource_curator(self):
        """Test ResourceCurator (pure tool)"""
        logger.info("Testing ResourceCurator...")

        analyzer = ResourceCurator()
        skill_gaps = [{"skill_name": "Machine Learning"}]
        results = analyzer.curate(
            skill_gaps=skill_gaps,
            learning_style="visual",
            preferences=self.sample_learner.get("preferences", {})
        )

        self.assertIsNotNone(results, "Resource curation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("resources", results, "Results should contain resources")

        logger.info("✓ ResourceCurator tests passed")

    def test_difficulty_calibrator(self):
        """Test DifficultyCalibrator (pure tool)"""
        logger.info("Testing DifficultyCalibrator...")

        analyzer = DifficultyCalibrator()
        results = analyzer.calibrate(
            current_skills={"Python": 7.0, "Data structures": 6.0},
            target_skill=self.sample_learner["target_skill"],
            time_commitment=self.sample_learner["time_commitment"],
            learning_experience="intermediate"
        )

        self.assertIsNotNone(results, "Difficulty calibration results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("starting_difficulty", results, "Results should contain starting_difficulty")

        logger.info("✓ DifficultyCalibrator tests passed")

    def test_progress_tracker(self):
        """Test ProgressTracker (pure tool)"""
        logger.info("Testing ProgressTracker...")

        analyzer = ProgressTracker()
        skill_gaps = [{"skill_name": "ML", "estimated_hours": 20, "priority": "high"}]
        results = analyzer.plan_milestones(
            skill_gaps=skill_gaps,
            duration_weeks=self.sample_learner["duration_weeks"],
            time_per_week=self.sample_learner["time_commitment"]
        )

        self.assertIsNotNone(results, "Progress tracking results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIn("milestones", results, "Results should contain milestones")

        logger.info("✓ ProgressTracker tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_skill_gap_agent(self):
        """Test SkillGapAgent (coordinator)"""
        logger.info("Testing SkillGapAgent...")

        agent = SkillGapAgent()
        results = agent.analyze(self.sample_learner)

        self.assertIsNotNone(results, "Skill gap agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, SkillGapAnalyzer, "Should use SkillGapAnalyzer")

        logger.info("✓ SkillGapAgent tests passed")

    def test_learning_style_agent(self):
        """Test LearningStyleAgent (coordinator)"""
        logger.info("Testing LearningStyleAgent...")

        agent = LearningStyleAgent()
        results = agent.analyze(self.sample_learner)

        self.assertIsNotNone(results, "Learning style agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, LearningStyleDetector, "Should use LearningStyleDetector")

        logger.info("✓ LearningStyleAgent tests passed")

    def test_resource_curator_agent(self):
        """Test ResourceCuratorAgent (coordinator)"""
        logger.info("Testing ResourceCuratorAgent...")

        agent = ResourceCuratorAgent()
        results = agent.analyze([], "visual")

        self.assertIsNotNone(results, "Resource curator agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, ResourceCurator, "Should use ResourceCurator")

        logger.info("✓ ResourceCuratorAgent tests passed")

    def test_difficulty_calibrator_agent(self):
        """Test DifficultyCalibratorAgent (coordinator)"""
        logger.info("Testing DifficultyCalibratorAgent...")

        agent = DifficultyCalibratorAgent()
        results = agent.analyze(self.sample_learner, [])

        self.assertIsNotNone(results, "Difficulty calibrator agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, DifficultyCalibrator, "Should use DifficultyCalibrator")

        logger.info("✓ DifficultyCalibratorAgent tests passed")

    def test_progress_tracker_agent(self):
        """Test ProgressTrackerAgent (coordinator)"""
        logger.info("Testing ProgressTrackerAgent...")

        agent = ProgressTrackerAgent()
        results = agent.analyze([], [], "intermediate")

        self.assertIsNotNone(results, "Progress tracker agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")
        self.assertIsNotNone(agent.analyzer, "Agent should have analyzer")
        self.assertIsInstance(agent.analyzer, ProgressTracker, "Should use ProgressTracker")

        logger.info("✓ ProgressTrackerAgent tests passed")

    def test_coordinator_agent(self):
        """Test CoordinatorAgent"""
        logger.info("Testing CoordinatorAgent...")

        # Create mock results
        skill_gap_results = [{"skill_gaps": [{"skill_name": "ML"}]}]
        learning_style_results = [{"learning_style": "visual"}]
        difficulty_results = [{"starting_difficulty": "intermediate"}]
        resource_results = [{"resources": []}]
        progress_results = [{"milestones": []}]

        agent = CoordinatorAgent()
        result = agent.analyze(
            skill_gap_results,
            learning_style_results,
            difficulty_results,
            resource_results,
            progress_results
        )

        self.assertIsNotNone(result, "Coordinator result should not be None")
        self.assertIn("coordination_summary", result, "Result should contain coordination_summary")

        summary = result["coordination_summary"]
        self.assertIn("analyses_completed", summary, "Summary should contain analyses_completed")
        self.assertEqual(len(summary["analyses_completed"]), 5, "Should have 5 completed analyses")

        logger.info("✓ CoordinatorAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_analyze_skill_gaps_node(self):
        """Test analyze_skill_gaps node (thin wrapper)"""
        logger.info("Testing analyze_skill_gaps node...")

        state = LearningPathState(
            learner_id="TEST-LEARNER",
            target_skill="Machine Learning",
            current_skills=["Python"],
            target_level="intermediate"
        )

        result = analyze_skill_gaps(state)

        self.assertIsNotNone(result, "Skill gap node result should not be None")
        self.assertIsInstance(result, LearningPathState, "Result should be LearningPathState")
        self.assertTrue(result.metadata.get("skill_gap_complete"), "Should mark analysis as complete")

        logger.info("✓ analyze_skill_gaps node tests passed")

    def test_detect_learning_style_node(self):
        """Test detect_learning_style node (thin wrapper)"""
        logger.info("Testing detect_learning_style node...")

        state = LearningPathState(
            learner_id="TEST-LEARNER",
            target_skill="ML",
            preferences={"learning_pace": "moderate"}
        )

        result = detect_learning_style(state)

        self.assertIsNotNone(result, "Learning style node result should not be None")
        self.assertIsInstance(result, LearningPathState, "Result should be LearningPathState")
        self.assertTrue(result.metadata.get("learning_style_complete"), "Should mark analysis as complete")

        logger.info("✓ detect_learning_style node tests passed")

    def test_create_learning_path_node(self):
        """Test create_learning_path node (uses coordinator)"""
        logger.info("Testing create_learning_path node...")

        state = LearningPathState(
            learner_id="TEST-LEARNER",
            target_skill="ML"
        )
        state.skill_gap_analysis = {"skill_gaps": [{"skill_name": "ML"}]}
        state.learning_style_analysis = {"learning_style": "visual"}
        state.difficulty_calibration = {"starting_difficulty": "intermediate"}
        state.resource_analysis = {"resources": []}
        state.progress_tracking = {"milestones": []}

        result = create_learning_path(state)

        self.assertIsNotNone(result, "Learning path result should not be None")
        self.assertIsInstance(result, LearningPathState, "Result should be LearningPathState")
        self.assertIsNotNone(result.path_quality_score, "Should have path quality score")
        self.assertIsNotNone(result.path_ready, "Should have ready status")

        logger.info("✓ create_learning_path node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_learning_graph_creation(self):
        """Test LearningPathGraph class creation"""
        logger.info("Testing LearningPathGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = LearningPathGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ LearningPathGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = create_learning_path_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, LearningPathGraph, "Workflow should be LearningPathGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        skill_gap_agent = SkillGapAgent()
        self.assertIsNotNone(skill_gap_agent.analyzer, "SkillGapAgent should have an analyzer")
        self.assertIsInstance(skill_gap_agent.analyzer, SkillGapAnalyzer, "Should use SkillGapAnalyzer")

        learning_style_agent = LearningStyleAgent()
        self.assertIsNotNone(learning_style_agent.analyzer, "LearningStyleAgent should have an analyzer")
        self.assertIsInstance(learning_style_agent.analyzer, LearningStyleDetector, "Should use LearningStyleDetector")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = LearningPathState(
            learner_id="TEST-LEARNER",
            target_skill="ML",
            current_skills=["Python"],
            target_level="intermediate",
            preferences={}
        )

        # Test that nodes return LearningPathState
        result = analyze_skill_gaps(state)
        self.assertIsInstance(result, LearningPathState, "Node should return LearningPathState")

        result = detect_learning_style(state)
        self.assertIsInstance(result, LearningPathState, "Node should return LearningPathState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Learning Path Recommender - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
