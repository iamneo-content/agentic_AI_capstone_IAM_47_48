"""Configuration Management"""
import os
import logging
from typing import Dict, Any, Optional

DEFAULT_CONFIG = {
    "GEMINI_API_KEY": "AIzaSyConx5DqUzHDDVSNIGI03MmH1vgZXOraMI",
    "GEMINI_MODEL": "gemini-2.0-flash",
    "DEFAULT_DIFFICULTY": "intermediate",
    "DEFAULT_TIME_COMMITMENT": 10,
    "DEFAULT_LEARNING_DURATION": 12,
    "MIN_SKILL_LEVEL": 1,
    "MAX_SKILL_LEVEL": 10,
    "SKILL_GAP_THRESHOLD": 3.0,
    "PROGRESS_MILESTONE_INTERVAL": 2,
    "DIFFICULTY_ADJUSTMENT_THRESHOLD": 0.7,
    "MIN_RESOURCES_PER_TOPIC": 3,
    "MAX_RESOURCES_PER_TOPIC": 10,
    "PREFERRED_RESOURCE_TYPES": "video,article,course,book",
    "FREE_RESOURCES_ONLY": False,
    "INCLUDE_CERTIFICATIONS": True,
    "EMAIL_FROM": "pranavram106@gmail.com",
    "EMAIL_PASSWORD": "zmmd aqzh rlkf heac",
    "EMAIL_TO": "pranavram106@gmail.com",
    "SMTP_SERVER": "smtp.gmail.com",
    "SMTP_PORT": 587,
    "LOG_LEVEL": "INFO",
    "LOG_FILE": "logs/learning_path.log"
}

logger = logging.getLogger("config")

class ConfigManager:
    _instance = None
    _config = {}
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not self.__class__._initialized:
            self._load_config()
            self.__class__._initialized = True

    def _load_config(self):
        config = DEFAULT_CONFIG.copy()

        for key in config:
            env_value = os.environ.get(key)
            if env_value is not None:
                if isinstance(config[key], bool):
                    config[key] = env_value.lower() in ('true', '1', 'yes')
                elif isinstance(config[key], (int, float)):
                    try:
                        if isinstance(config[key], int):
                            config[key] = int(env_value)
                        else:
                            config[key] = float(env_value)
                    except ValueError:
                        logger.warning(f"Invalid numeric value for {key}: {env_value}")
                else:
                    config[key] = env_value

        self._load_env_file(config)
        self._config = config

    def _load_env_file(self, config: Dict[str, Any]) -> None:
        env_file = os.environ.get("ENV_FILE", ".env")
        if os.path.exists(env_file):
            try:
                with open(env_file, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if "=" in line:
                                key, value = line.split("=", 1)
                                key = key.strip()
                                value = value.strip()

                                if (value.startswith('"') and value.endswith('"')) or \
                                   (value.startswith("'") and value.endswith("'")):
                                    value = value[1:-1]

                                if key in config:
                                    if isinstance(config[key], bool):
                                        config[key] = value.lower() in ('true', '1', 'yes')
                                    elif isinstance(config[key], (int, float)):
                                        try:
                                            if isinstance(config[key], int):
                                                config[key] = int(value)
                                            else:
                                                config[key] = float(value)
                                        except ValueError:
                                            logger.warning(f"Invalid numeric value for {key}: {value}")
                                    else:
                                        config[key] = value
            except Exception as e:
                logger.warning(f"Error loading .env file: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def validate(self) -> None:
        required_keys = ["GEMINI_API_KEY"]
        missing = [key for key in required_keys if not self._config.get(key)]
        if missing:
            raise ValueError(f"Missing required configuration: {', '.join(missing)}")

    def get_all(self) -> Dict[str, Any]:
        return self._config.copy()

def get_config() -> ConfigManager:
    return ConfigManager()

def get_config_value(key: str, default: Any = None) -> Any:
    return get_config().get(key, default)

def validate_config() -> None:
    get_config().validate()
