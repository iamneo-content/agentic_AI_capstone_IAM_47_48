"""Learning Path State Management"""
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class LearningPathState:
    """
    Represents the state of a learner through the path recommendation workflow
    """
    # Input data
    learner_id: str
    target_skill: str
    current_skills: Dict[str, float] = field(default_factory=dict)  # skill: level (1-10)
    target_level: float = 8.0  # Desired proficiency (1-10)
    time_commitment: int = 10  # Hours per week
    duration_weeks: int = 12
    preferences: Dict[str, Any] = field(default_factory=dict)

    # Metadata
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Analysis results
    skill_gaps: List[Dict[str, Any]] = field(default_factory=list)
    skill_gap_analysis: Dict[str, Any] = field(default_factory=dict)

    learning_style: str = "balanced"  # visual, auditory, reading, kinesthetic, balanced
    learning_style_scores: Dict[str, float] = field(default_factory=dict)
    learning_style_analysis: Dict[str, Any] = field(default_factory=dict)

    recommended_resources: List[Dict[str, Any]] = field(default_factory=list)
    resource_analysis: Dict[str, Any] = field(default_factory=dict)

    milestones: List[Dict[str, Any]] = field(default_factory=list)
    progress_tracking: Dict[str, Any] = field(default_factory=dict)

    starting_difficulty: str = "intermediate"
    difficulty_calibration: Dict[str, Any] = field(default_factory=dict)

    # Overall path
    curriculum: List[Dict[str, Any]] = field(default_factory=list)
    learning_path_score: float = 0.0
    estimated_completion_time: int = 0  # In hours
    success_probability: float = 0.0

    # Recommendations
    recommendations: List[Dict[str, Any]] = field(default_factory=list)
    prerequisites: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    # Path quality
    path_quality_score: float = 0.0
    path_feasibility: str = "Unknown"
    path_ready: bool = False

    # Workflow status
    workflow_complete: bool = False
    report_sent: bool = False
    error: Optional[str] = None

    def clone(self) -> 'LearningPathState':
        """Create a deep copy of the state"""
        import copy
        return copy.deepcopy(self)

    def merge_from(self, other: 'LearningPathState') -> None:
        """Merge data from another state (for parallel node results)"""
        if other is None:
            return

        # Merge analysis results
        if other.skill_gaps:
            self.skill_gaps = other.skill_gaps
            self.skill_gap_analysis = other.skill_gap_analysis

        if other.learning_style != "balanced":
            self.learning_style = other.learning_style
            self.learning_style_scores = other.learning_style_scores
            self.learning_style_analysis = other.learning_style_analysis

        if other.recommended_resources:
            self.recommended_resources.extend(other.recommended_resources)
            self.resource_analysis = other.resource_analysis

        if other.milestones:
            self.milestones = other.milestones
            self.progress_tracking = other.progress_tracking

        if other.starting_difficulty != "intermediate":
            self.starting_difficulty = other.starting_difficulty
            self.difficulty_calibration = other.difficulty_calibration

        # Merge lists
        if other.recommendations:
            self.recommendations.extend(other.recommendations)

        if other.prerequisites:
            self.prerequisites.extend(other.prerequisites)

        if other.warnings:
            self.warnings.extend(other.warnings)

        # Merge metadata
        self.metadata.update(other.metadata)

        # Merge error if present
        if other.error:
            self.error = other.error

    def to_dict(self) -> Dict[str, Any]:
        """Convert state to dictionary"""
        return {
            "learner_id": self.learner_id,
            "target_skill": self.target_skill,
            "current_skills": self.current_skills,
            "target_level": self.target_level,
            "learning_style": self.learning_style,
            "skill_gaps": self.skill_gaps,
            "curriculum": self.curriculum,
            "recommended_resources": len(self.recommended_resources),
            "milestones": len(self.milestones),
            "starting_difficulty": self.starting_difficulty,
            "estimated_completion_time": self.estimated_completion_time,
            "success_probability": self.success_probability,
            "path_quality_score": self.path_quality_score,
            "path_feasibility": self.path_feasibility,
            "path_ready": self.path_ready,
            "timestamp": self.timestamp
        }

    def get_summary(self) -> str:
        """Get a human-readable summary"""
        summary = f"""
Learning Path Analysis Summary
{'=' * 60}
Learner ID: {self.learner_id}
Target Skill: {self.target_skill}
Target Level: {self.target_level}/10
Time Commitment: {self.time_commitment} hours/week for {self.duration_weeks} weeks

Path Quality Score: {self.path_quality_score:.1f}/10
Feasibility: {self.path_feasibility}
Ready: {'✅ Yes' if self.path_ready else '⚠️ Needs Review'}

Learning Style: {self.learning_style.capitalize()}
Starting Difficulty: {self.starting_difficulty.capitalize()}

Skill Gaps Identified: {len(self.skill_gaps)}
Curriculum Modules: {len(self.curriculum)}
Resources Recommended: {len(self.recommended_resources)}
Milestones: {len(self.milestones)}

Estimated Completion: {self.estimated_completion_time} hours
Success Probability: {self.success_probability * 100:.1f}%

{len(self.recommendations)} personalized recommendations
{len(self.warnings)} warnings found
{'=' * 60}
        """
        return summary.strip()

    def get_current_skill_level(self, skill: str) -> float:
        """Get current level for a specific skill"""
        return self.current_skills.get(skill, 0.0)

    def add_skill_gap(self, skill: str, current_level: float, target_level: float, priority: str = "medium"):
        """Add a skill gap to the list"""
        gap = {
            "skill": skill,
            "current_level": current_level,
            "target_level": target_level,
            "gap_size": target_level - current_level,
            "priority": priority
        }
        self.skill_gaps.append(gap)

    def add_milestone(self, week: int, title: str, description: str, skills: List[str], success_criteria: str):
        """Add a milestone to the learning path"""
        milestone = {
            "week": week,
            "title": title,
            "description": description,
            "skills": skills,
            "success_criteria": success_criteria,
            "status": "pending"
        }
        self.milestones.append(milestone)
