"""Coordinator Agent - Coordinates final learning path creation"""
import logging
from typing import Dict, Any, List
from agents.base_agent import BaseAgent

logger = logging.getLogger("coordinator_agent")


class CoordinatorAgent(BaseAgent):
    """Coordinates all analyzers and creates final learning path"""

    def __init__(self):
        super().__init__("CoordinatorAgent")
        self.log("Initialized")

    def analyze(
        self,
        skill_gap_results: List[Dict[str, Any]],
        learning_style_results: List[Dict[str, Any]],
        difficulty_results: List[Dict[str, Any]],
        resource_results: List[Dict[str, Any]],
        progress_results: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Create personalized learning path based on all analysis results

        Args:
            skill_gap_results: Skill gap analysis results
            learning_style_results: Learning style detection results
            difficulty_results: Difficulty calibration results
            resource_results: Resource curation results
            progress_results: Progress tracking results

        Returns:
            Complete learning path and recommendations
        """
        self.log("=" * 70)
        self.log("CREATING PERSONALIZED LEARNING PATH")
        self.log("=" * 70)

        try:
            # Extract data from results
            skill_gaps = skill_gap_results[0].get("skill_gaps", []) if skill_gap_results else []
            learning_style = learning_style_results[0].get("learning_style", "visual") if learning_style_results else "visual"
            difficulty = difficulty_results[0].get("starting_difficulty", "intermediate") if difficulty_results else "intermediate"
            resources = resource_results[0].get("resources", []) if resource_results else []
            milestones = progress_results[0].get("milestones", []) if progress_results else []

            # Build curriculum from skill gaps
            curriculum = self._build_curriculum(skill_gaps, resources, milestones, difficulty)

            # Calculate metrics
            estimated_completion_time = sum(item.get("estimated_hours", 0) for item in curriculum)
            success_probability = self._calculate_success_probability(learning_style, difficulty)
            path_quality_score = self._calculate_quality_score(skill_gaps, resources, milestones)

            # Determine feasibility
            path_feasibility = self._determine_feasibility(estimated_completion_time)
            path_ready = path_quality_score >= 7.0

            # Generate recommendations
            recommendations = self._generate_recommendations(learning_style, difficulty, skill_gaps)

            # Build coordination summary
            coordination_summary = {
                "analyses_completed": [
                    "Skill Gap Analysis",
                    "Learning Style Detection",
                    "Difficulty Calibration",
                    "Resource Curation",
                    "Progress Planning"
                ],
                "skill_gaps_identified": len(skill_gaps),
                "learning_style": learning_style,
                "difficulty_level": difficulty,
                "resources_curated": len(resources),
                "milestones_planned": len(milestones),
                "path_quality_score": path_quality_score
            }

            self.log(f"Learning path created: {len(curriculum)} modules")
            self.log(f"Quality Score: {path_quality_score:.1f}/10")
            self.log(f"Success Probability: {success_probability * 100:.1f}%")
            self.log("=" * 70)

            return {
                "coordination_summary": coordination_summary,
                "curriculum": curriculum,
                "estimated_completion_time": estimated_completion_time,
                "success_probability": success_probability,
                "path_quality_score": path_quality_score,
                "path_feasibility": path_feasibility,
                "path_ready": path_ready,
                "recommendations": recommendations
            }

        except Exception as e:
            self.log(f"Error in coordination: {e}", "error")
            return {
                "error": str(e),
                "curriculum": [],
                "path_quality_score": 0,
                "path_ready": False,
                "recommendations": []
            }

    def _build_curriculum(self, skill_gaps, resources, milestones, difficulty):
        """Build curriculum from components"""
        curriculum = []

        for i, gap in enumerate(skill_gaps[:8], 1):
            module = {
                "module_number": i,
                "skill": gap.get("skill_name"),
                "category": gap.get("category"),
                "difficulty": difficulty,
                "estimated_hours": gap.get("estimated_hours", 20),
                "priority": gap.get("priority"),
                "resources": [r for r in resources if r.get("skill_covered") == gap.get("skill_name")][:5],
                "milestone": next((m for m in milestones if gap.get("skill_name") in m.get("skills_covered", [])), None)
            }
            curriculum.append(module)

        return curriculum

    def _calculate_success_probability(self, learning_style, difficulty):
        """Calculate probability of successfully completing the path"""
        factors = [0.8, 0.85, 0.9]  # Base factors
        return sum(factors) / len(factors) if factors else 0.7

    def _calculate_quality_score(self, skill_gaps, resources, milestones):
        """Calculate overall path quality"""
        scores = []

        if len(skill_gaps) > 0:
            scores.append(min(10, len(skill_gaps) * 1.5))

        if len(resources) >= 10:
            scores.append(9.0)
        elif len(resources) >= 5:
            scores.append(7.5)
        else:
            scores.append(6.0)

        if len(milestones) >= 4:
            scores.append(8.5)
        else:
            scores.append(7.0)

        return sum(scores) / len(scores) if scores else 7.0

    def _determine_feasibility(self, total_hours):
        """Determine path feasibility"""
        if total_hours <= 100:
            return "Highly Feasible"
        elif total_hours <= 200:
            return "Feasible"
        else:
            return "Challenging but Achievable"

    def _generate_recommendations(self, learning_style, difficulty, skill_gaps):
        """Generate final recommendations"""
        recommendations = []

        recommendations.append({
            "category": "Learning Style",
            "priority": "high",
            "suggestion": f"Focus on {learning_style} learning resources for better retention"
        })

        if difficulty == "beginner":
            recommendations.append({
                "category": "Progression",
                "priority": "medium",
                "suggestion": "Start with fundamentals and progress gradually"
            })

        recommendations.append({
            "category": "Success Strategies",
            "priority": "high",
            "suggestion": "Implement proven learning strategies",
            "details": ["Set specific weekly goals", "Build projects while learning", "Track progress regularly"]
        })

        return recommendations
