"""Learning Path Orchestration Agent"""
import logging
from typing import Dict, Any, List
from state import LearningPathState

logger = logging.getLogger("learning_path_agent")

class LearningPathAgent:
    """Coordinates all analyzers and creates final learning path"""

    def __init__(self):
        logger.info("LearningPathAgent initialized")

    def create_learning_path(self, state: LearningPathState) -> LearningPathState:
        """Create comprehensive personalized learning path"""
        logger.info("=" * 70)
        logger.info("CREATING PERSONALIZED LEARNING PATH")
        logger.info("=" * 70)

        try:
            # Build curriculum from skill gaps
            curriculum = self._build_curriculum(state)
            state.curriculum = curriculum

            # Calculate path metrics
            state.estimated_completion_time = sum(
                item.get("estimated_hours", 0) for item in curriculum
            )
            
            # Calculate success probability
            state.success_probability = self._calculate_success_probability(state)
            
            # Calculate path quality score
            state.path_quality_score = self._calculate_quality_score(state)
            
            # Determine feasibility
            state.path_feasibility = self._determine_feasibility(state)
            state.path_ready = state.path_quality_score >= 7.0
            
            # Generate final recommendations
            state.recommendations = self._generate_recommendations(state)

            logger.info(f"Learning path created: {len(curriculum)} modules")
            logger.info(f"Quality Score: {state.path_quality_score:.1f}/10")
            logger.info(f"Success Probability: {state.success_probability * 100:.1f}%")
            logger.info("=" * 70)

            return state

        except Exception as e:
            logger.error(f"Error creating learning path: {e}")
            state.error = str(e)
            return state

    def _build_curriculum(self, state: LearningPathState) -> List[Dict[str, Any]]:
        """Build curriculum from components"""
        curriculum = []
        
        for i, gap in enumerate(state.skill_gaps[:8], 1):
            module = {
                "module_number": i,
                "skill": gap.get("skill_name"),
                "category": gap.get("category"),
                "difficulty": state.starting_difficulty,
                "estimated_hours": gap.get("estimated_hours", 20),
                "priority": gap.get("priority"),
                "resources": [r for r in state.recommended_resources 
                             if r.get("skill_covered") == gap.get("skill_name")][:5],
                "milestone": next((m for m in state.milestones 
                                 if gap.get("skill_name") in m.get("skills_covered", [])), None)
            }
            curriculum.append(module)
        
        return curriculum

    def _calculate_success_probability(self, state: LearningPathState) -> float:
        """Calculate probability of successfully completing the path"""
        factors = []
        
        # Time commitment factor
        if state.time_commitment >= 10:
            factors.append(0.9)
        elif state.time_commitment >= 5:
            factors.append(0.7)
        else:
            factors.append(0.5)
        
        # Difficulty match
        if state.difficulty_calibration.get("challenge_level") in ["comfortable", "moderate"]:
            factors.append(0.9)
        else:
            factors.append(0.7)
        
        # Learning style match
        if state.learning_style in ["balanced", "kinesthetic"]:
            factors.append(0.85)
        else:
            factors.append(0.8)
        
        return sum(factors) / len(factors) if factors else 0.7

    def _calculate_quality_score(self, state: LearningPathState) -> float:
        """Calculate overall path quality"""
        scores = []
        
        # Skill gap coverage
        if len(state.skill_gaps) > 0:
            scores.append(min(10, len(state.skill_gaps) * 1.5))
        
        # Resource quality
        if len(state.recommended_resources) >= 10:
            scores.append(9.0)
        elif len(state.recommended_resources) >= 5:
            scores.append(7.5)
        else:
            scores.append(6.0)
        
        # Milestone planning
        if len(state.milestones) >= 4:
            scores.append(8.5)
        else:
            scores.append(7.0)
        
        # Difficulty calibration
        if state.difficulty_calibration.get("confidence_score", 0.7) >= 0.75:
            scores.append(8.5)
        else:
            scores.append(7.0)
        
        return sum(scores) / len(scores) if scores else 7.0

    def _determine_feasibility(self, state: LearningPathState) -> str:
        """Determine path feasibility"""
        total_hours = state.estimated_completion_time
        available_hours = state.time_commitment * state.duration_weeks
        
        if total_hours <= available_hours * 0.8:
            return "Highly Feasible"
        elif total_hours <= available_hours:
            return "Feasible"
        elif total_hours <= available_hours * 1.2:
            return "Challenging but Achievable"
        else:
            return "May Need More Time"

    def _generate_recommendations(self, state: LearningPathState) -> List[Dict[str, Any]]:
        """Generate final recommendations"""
        recommendations = []
        
        # Time management
        if state.time_commitment < 10:
            recommendations.append({
                "category": "Time Management",
                "priority": "high",
                "suggestion": "Consider increasing weekly time commitment for better results",
                "details": ["Aim for 10-15 hours per week", "Break into daily 1-2 hour sessions"]
            })
        
        # Learning style optimization
        optimal_types = state.learning_style_analysis.get("optimal_resource_types", [])
        if optimal_types:
            recommendations.append({
                "category": "Resource Selection",
                "priority": "medium",
                "suggestion": f"Prioritize {', '.join(optimal_types[:3])} resources for your learning style",
                "details": state.learning_style_analysis.get("recommendations", [])
            })
        
        # Difficulty adjustments
        if state.starting_difficulty == "beginner":
            recommendations.append({
                "category": "Progression",
                "priority": "medium",
                "suggestion": "Start with fundamentals and progress gradually",
                "details": ["Master basics before advancing", "Don't rush through foundation"]
            })
        
        # Success strategies
        recommendations.append({
            "category": "Success Strategies",
            "priority": "high",
            "suggestion": "Implement proven learning strategies",
            "details": [
                "Set specific weekly goals",
                "Build projects while learning",
                "Join study communities",
                "Track progress regularly",
                "Review and adjust plan monthly"
            ]
        })
        
        return recommendations
