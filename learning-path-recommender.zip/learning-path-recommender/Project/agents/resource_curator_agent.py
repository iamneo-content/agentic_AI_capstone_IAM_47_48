"""Resource Curator Agent - Coordinates resource curation"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.resource_curator import ResourceCurator

logger = logging.getLogger("resource_curator_agent")


class ResourceCuratorAgent(BaseAgent):
    """Agent that coordinates resource curation using ResourceCurator"""

    def __init__(self):
        super().__init__("ResourceCuratorAgent")
        self.analyzer = ResourceCurator()
        self.log("Initialized with ResourceCurator")

    def analyze(self, skill_gaps: list, learning_style: str) -> Dict[str, Any]:
        """
        Curate learning resources

        Args:
            skill_gaps: List of skill gaps
            learning_style: Detected learning style

        Returns:
            Resource curation results
        """
        self.log("Starting resource curation")

        try:
            result = self.analyzer.curate(skill_gaps, learning_style)
            resources = result.get("resources", [])
            self.log(f"Curated {len(resources)} learning resources")
            return result

        except Exception as e:
            self.log(f"Error in resource curation: {e}", "error")
            return {
                "resources": [],
                "error": str(e)
            }
