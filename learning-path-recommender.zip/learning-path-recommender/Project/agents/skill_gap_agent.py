"""Skill Gap Agent - Coordinates skill gap analysis"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.skill_gap_analyzer import SkillGapAnalyzer

logger = logging.getLogger("skill_gap_agent")


class SkillGapAgent(BaseAgent):
    """Agent that coordinates skill gap analysis using SkillGapAnalyzer"""

    def __init__(self):
        super().__init__("SkillGapAgent")
        self.analyzer = SkillGapAnalyzer()
        self.log("Initialized with SkillGapAnalyzer")

    def analyze(self, learner_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze skill gaps

        Args:
            learner_profile: Learner profile data

        Returns:
            Skill gap analysis results
        """
        self.log("Starting skill gap analysis")

        try:
            result = self.analyzer.analyze(learner_profile)
            skill_gaps = result.get("skill_gaps", [])
            self.log(f"Identified {len(skill_gaps)} skill gaps")
            return result

        except Exception as e:
            self.log(f"Error in skill gap analysis: {e}", "error")
            return {
                "skill_gaps": [],
                "error": str(e)
            }
