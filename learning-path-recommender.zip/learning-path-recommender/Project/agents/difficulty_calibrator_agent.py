"""Difficulty Calibrator Agent - Coordinates difficulty calibration"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.difficulty_calibrator import DifficultyCalibrator

logger = logging.getLogger("difficulty_calibrator_agent")


class DifficultyCalibratorAgent(BaseAgent):
    """Agent that coordinates difficulty calibration using DifficultyCalibrator"""

    def __init__(self):
        super().__init__("DifficultyCalibratorAgent")
        self.analyzer = DifficultyCalibrator()
        self.log("Initialized with DifficultyCalibrator")

    def analyze(self, learner_profile: Dict[str, Any], skill_gaps: list) -> Dict[str, Any]:
        """
        Calibrate difficulty level

        Args:
            learner_profile: Learner profile data
            skill_gaps: List of skill gaps

        Returns:
            Difficulty calibration results
        """
        self.log("Starting difficulty calibration")

        try:
            result = self.analyzer.calibrate(learner_profile, skill_gaps)
            difficulty = result.get("starting_difficulty", "intermediate")
            self.log(f"Calibrated difficulty: {difficulty}")
            return result

        except Exception as e:
            self.log(f"Error in difficulty calibration: {e}", "error")
            return {
                "starting_difficulty": "intermediate",
                "error": str(e)
            }
