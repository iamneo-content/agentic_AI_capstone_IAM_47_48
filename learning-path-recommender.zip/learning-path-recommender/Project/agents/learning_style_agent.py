"""Learning Style Agent - Coordinates learning style detection"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.learning_style_detector import LearningStyleDetector

logger = logging.getLogger("learning_style_agent")


class LearningStyleAgent(BaseAgent):
    """Agent that coordinates learning style detection using LearningStyleDetector"""

    def __init__(self):
        super().__init__("LearningStyleAgent")
        self.analyzer = LearningStyleDetector()
        self.log("Initialized with LearningStyleDetector")

    def analyze(self, learner_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Detect learning style

        Args:
            learner_profile: Learner profile data

        Returns:
            Learning style analysis results
        """
        self.log("Starting learning style detection")

        try:
            result = self.analyzer.detect(learner_profile)
            learning_style = result.get("learning_style", "visual")
            self.log(f"Detected learning style: {learning_style}")
            return result

        except Exception as e:
            self.log(f"Error in learning style detection: {e}", "error")
            return {
                "learning_style": "visual",
                "error": str(e)
            }
