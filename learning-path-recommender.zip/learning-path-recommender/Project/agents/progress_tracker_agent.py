"""Progress Tracker Agent - Coordinates progress tracking"""
import logging
from typing import Dict, Any
from agents.base_agent import BaseAgent
from analyzers.progress_tracker import ProgressTracker

logger = logging.getLogger("progress_tracker_agent")


class ProgressTrackerAgent(BaseAgent):
    """Agent that coordinates progress tracking using ProgressTracker"""

    def __init__(self):
        super().__init__("ProgressTrackerAgent")
        self.analyzer = ProgressTracker()
        self.log("Initialized with ProgressTracker")

    def analyze(self, skill_gaps: list, resources: list, difficulty: str) -> Dict[str, Any]:
        """
        Plan progress milestones

        Args:
            skill_gaps: List of skill gaps
            resources: List of curated resources
            difficulty: Calibrated difficulty level

        Returns:
            Progress tracking results
        """
        self.log("Starting progress planning")

        try:
            result = self.analyzer.plan(skill_gaps, resources, difficulty)
            milestones = result.get("milestones", [])
            self.log(f"Planned {len(milestones)} progress milestones")
            return result

        except Exception as e:
            self.log(f"Error in progress planning: {e}", "error")
            return {
                "milestones": [],
                "error": str(e)
            }
