#!/usr/bin/env python3
"""
Learning Path Recommender
Main Entry Point
"""
import sys
import argparse
import logging
from datetime import datetime

from utils.logger import setup_logging
from config import get_config, validate_config
from state import LearningPathState
from workflows import create_learning_path_workflow
from services import create_sample_learner

logger = logging.getLogger("main")

def generate_learning_path(
    learner_id: str = None,
    target_skill: str = None,
    current_skills: dict = None,
    target_level: float = 8.0,
    time_commitment: int = 10,
    duration_weeks: int = 12,
    preferences: dict = None,
    skip_email: bool = False
) -> LearningPathState:
    """Generate personalized learning path"""
    logger.info(f"Generating learning path for: {learner_id or 'custom learner'}")

    # Load or create learner data
    if learner_id:
        learner_data = create_sample_learner(learner_id)
    else:
        learner_data = {
            "learner_id": f"CUSTOM_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "target_skill": target_skill or "General Skill",
            "current_skills": current_skills or {},
            "target_level": target_level,
            "time_commitment": time_commitment,
            "duration_weeks": duration_weeks,
            "preferences": preferences or {}
        }

    logger.info(f"Target: {learner_data['target_skill']}")
    logger.info(f"Duration: {learner_data['duration_weeks']} weeks")
    logger.info(f"Commitment: {learner_data['time_commitment']} hrs/week")

    # Create initial state
    initial_state = LearningPathState(
        learner_id=learner_data["learner_id"],
        target_skill=learner_data["target_skill"],
        current_skills=learner_data["current_skills"],
        target_level=learner_data["target_level"],
        time_commitment=learner_data["time_commitment"],
        duration_weeks=learner_data["duration_weeks"],
        preferences=learner_data.get("preferences", {}),
        timestamp=datetime.now().isoformat()
    )

    # Create and run workflow
    logger.info("Creating learning path workflow...")
    workflow = create_learning_path_workflow(max_workers=5)

    logger.info("Executing workflow...")
    final_state = workflow.run(initial_state)

    # Display results
    print_results(final_state)

    return final_state

def print_results(state: LearningPathState):
    """Print learning path results"""
    print("\n" + "=" * 70)
    print("PERSONALIZED LEARNING PATH")
    print("=" * 70)
    print(f"Learner ID: {state.learner_id}")
    print(f"Target Skill: {state.target_skill}")
    print(f"Target Level: {state.target_level}/10")
    print("-" * 70)
    print(f"\nPATH QUALITY SCORE: {state.path_quality_score:.1f}/10")
    print(f"Feasibility: {state.path_feasibility}")
    print(f"Status: {'[OK] Ready to Start' if state.path_ready else '[!] Needs Review'}")
    print(f"\nSuccess Probability: {state.success_probability * 100:.1f}%")
    print(f"Estimated Completion: {state.estimated_completion_time} hours")
    print("\n" + "-" * 70)
    print("PERSONALIZATION:")
    print(f"  Learning Style: {state.learning_style.capitalize()}")
    print(f"  Starting Difficulty: {state.starting_difficulty.capitalize()}")
    print(f"  Time Commitment: {state.time_commitment} hrs/week for {state.duration_weeks} weeks")

    if state.skill_gaps:
        print("\n" + "-" * 70)
        print(f"SKILL GAPS IDENTIFIED: {len(state.skill_gaps)}")
        for i, gap in enumerate(state.skill_gaps[:5], 1):
            print(f"  {i}. {gap.get('skill_name')} "
                  f"({gap.get('current_level', 0):.1f} → {gap.get('target_level'):.1f}) "
                  f"[{gap.get('priority')}]")
        if len(state.skill_gaps) > 5:
            print(f"  ... and {len(state.skill_gaps) - 5} more")

    if state.curriculum:
        print("\n" + "-" * 70)
        print(f"CURRICULUM: {len(state.curriculum)} Modules")
        for module in state.curriculum[:3]:
            print(f"  Module {module['module_number']}: {module['skill']}")
            print(f"    Difficulty: {module['difficulty']} | "
                  f"Hours: {module['estimated_hours']} | "
                  f"Resources: {len(module.get('resources', []))}")

    if state.recommended_resources:
        print("\n" + "-" * 70)
        print(f"RECOMMENDED RESOURCES: {len(state.recommended_resources)}")
        for i, resource in enumerate(state.recommended_resources[:5], 1):
            print(f"  {i}. [{resource.get('type')}] {resource.get('title')}")
            print(f"     Provider: {resource.get('provider')} | "
                  f"Difficulty: {resource.get('difficulty')} | "
                  f"Hours: {resource.get('estimated_hours')}")

    if state.milestones:
        print("\n" + "-" * 70)
        print(f"MILESTONES: {len(state.milestones)} Checkpoints")
        for milestone in state.milestones[:3]:
            print(f"  Week {milestone['week']}: {milestone['title']}")
            print(f"    {milestone['description']}")

    if state.recommendations:
        print("\n" + "-" * 70)
        print("RECOMMENDATIONS:")
        for i, rec in enumerate(state.recommendations[:5], 1):
            print(f"  {i}. [{rec.get('priority', 'medium').upper()}] {rec.get('category')}")
            print(f"     {rec.get('suggestion')}")

    print("\n" + "=" * 70)
    if state.report_sent:
        print("📧 Learning plan sent via email")
    print("=" * 70 + "\n")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Learning Path Recommender - AI-powered personalized skill development",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Use sample learner
  python main.py LEARNER001

  # Custom learning path
  python main.py --skill "Python Programming" --target-level 8 --weeks 12

  # With time commitment
  python main.py --skill "Data Science" --hours 15 --weeks 16

For more information, see README.md
        """
    )

    parser.add_argument("learner_id", nargs="?", help="Sample learner ID (LEARNER001, LEARNER002)")
    parser.add_argument("--skill", help="Target skill to learn")
    parser.add_argument("--target-level", type=float, default=8.0, help="Target proficiency (1-10)")
    parser.add_argument("--hours", type=int, default=10, help="Hours per week")
    parser.add_argument("--weeks", type=int, default=12, help="Duration in weeks")
    parser.add_argument("--skip-email", action="store_true", help="Skip email notification")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")

    args = parser.parse_args()

    # Setup logging
    setup_logging()
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Validate inputs
    if not args.learner_id and not args.skill:
        parser.print_help()
        print("\nError: Either learner_id or --skill must be provided")
        sys.exit(1)

    try:
        # Validate config
        logger.info("Validating configuration...")
        config = get_config()

        if not args.skip_email:
            try:
                validate_config()
            except ValueError as e:
                logger.warning(f"Email configuration incomplete: {e}")
                args.skip_email = True

        # Generate learning path
        generate_learning_path(
            learner_id=args.learner_id,
            target_skill=args.skill,
            target_level=args.target_level,
            time_commitment=args.hours,
            duration_weeks=args.weeks,
            skip_email=args.skip_email
        )

        logger.info("Learning path generation completed successfully")
        sys.exit(0)

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Failed: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
