"""Workflow Node Functions"""
import logging
from state import LearningPathState
from agents import (
    SkillGapAgent,
    LearningStyleAgent,
    ResourceCuratorAgent,
    DifficultyCalibratorAgent,
    ProgressTrackerAgent,
    CoordinatorAgent
)

logger = logging.getLogger("nodes")

def analyze_skill_gaps(state: LearningPathState) -> LearningPathState:
    """Node: Analyze skill gaps using agent"""
    logger.info("NODE: Analyzing skill gaps")
    try:
        agent = SkillGapAgent()
        learner_profile = {
            "target_skill": state.target_skill,
            "current_skills": state.current_skills,
            "target_level": state.target_level
        }
        result = agent.analyze(learner_profile)

        state.skill_gaps = result.get("skill_gaps", [])
        state.skill_gap_analysis = result
        state.prerequisites = result.get("prerequisites", [])
        state.metadata["skill_gap_complete"] = True

        logger.info(f"Identified {len(state.skill_gaps)} skill gaps")
        return state
    except Exception as e:
        logger.error(f"Error in analyze_skill_gaps: {e}")
        state.error = str(e)
        return state

def detect_learning_style(state: LearningPathState) -> LearningPathState:
    """Node: Detect learning style using agent"""
    logger.info("NODE: Detecting learning style")
    try:
        agent = LearningStyleAgent()
        learner_profile = {
            "preferences": state.preferences
        }
        result = agent.analyze(learner_profile)

        state.learning_style = result.get("learning_style", "visual")
        state.learning_style_scores = result.get("style_scores", {})
        state.learning_style_analysis = result
        state.metadata["learning_style_complete"] = True

        logger.info(f"Detected learning style: {state.learning_style}")
        return state
    except Exception as e:
        logger.error(f"Error in detect_learning_style: {e}")
        state.error = str(e)
        return state

def calibrate_difficulty(state: LearningPathState) -> LearningPathState:
    """Node: Calibrate difficulty using agent"""
    logger.info("NODE: Calibrating difficulty")
    try:
        agent = DifficultyCalibratorAgent()
        learner_profile = {
            "current_skills": state.current_skills,
            "target_skill": state.target_skill,
            "time_commitment": state.time_commitment
        }
        result = agent.analyze(learner_profile, state.skill_gaps)

        state.starting_difficulty = result.get("starting_difficulty", "intermediate")
        state.difficulty_calibration = result
        state.metadata["difficulty_complete"] = True

        logger.info(f"Calibrated difficulty: {state.starting_difficulty}")
        return state
    except Exception as e:
        logger.error(f"Error in calibrate_difficulty: {e}")
        state.error = str(e)
        return state

def curate_resources(state: LearningPathState) -> LearningPathState:
    """Node: Curate resources using agent"""
    logger.info("NODE: Curating resources")
    try:
        agent = ResourceCuratorAgent()
        result = agent.analyze(state.skill_gaps, state.learning_style)

        state.recommended_resources = result.get("resources", [])
        state.resource_analysis = result
        state.metadata["resources_complete"] = True

        logger.info(f"Curated {len(state.recommended_resources)} resources")
        return state
    except Exception as e:
        logger.error(f"Error in curate_resources: {e}")
        state.error = str(e)
        return state

def plan_progress(state: LearningPathState) -> LearningPathState:
    """Node: Plan progress milestones using agent"""
    logger.info("NODE: Planning progress milestones")
    try:
        agent = ProgressTrackerAgent()
        result = agent.analyze(
            state.skill_gaps,
            state.recommended_resources,
            state.starting_difficulty
        )

        state.milestones = result.get("milestones", [])
        state.progress_tracking = result
        state.metadata["progress_complete"] = True

        logger.info(f"Planned {len(state.milestones)} milestones")
        return state
    except Exception as e:
        logger.error(f"Error in plan_progress: {e}")
        state.error = str(e)
        return state

def create_learning_path(state: LearningPathState) -> LearningPathState:
    """Node: Create final learning path using coordinator agent"""
    logger.info("NODE: Creating final learning path")
    try:
        # Prepare results for coordinator
        skill_gap_results = [state.skill_gap_analysis] if hasattr(state, 'skill_gap_analysis') else []
        learning_style_results = [state.learning_style_analysis] if hasattr(state, 'learning_style_analysis') else []
        difficulty_results = [state.difficulty_calibration] if hasattr(state, 'difficulty_calibration') else []
        resource_results = [state.resource_analysis] if hasattr(state, 'resource_analysis') else []
        progress_results = [state.progress_tracking] if hasattr(state, 'progress_tracking') else []

        agent = CoordinatorAgent()
        result = agent.analyze(
            skill_gap_results,
            learning_style_results,
            difficulty_results,
            resource_results,
            progress_results
        )

        state.curriculum = result.get("curriculum", [])
        state.estimated_completion_time = result.get("estimated_completion_time", 0)
        state.success_probability = result.get("success_probability", 0.7)
        state.path_quality_score = result.get("path_quality_score", 0)
        state.path_feasibility = result.get("path_feasibility", "Unknown")
        state.path_ready = result.get("path_ready", False)
        state.recommendations = result.get("recommendations", [])
        state.coordination_summary = result.get("coordination_summary", {})
        state.metadata["path_creation_complete"] = True

        return state
    except Exception as e:
        logger.error(f"Error in create_learning_path: {e}")
        state.error = str(e)
        return state

def send_learning_plan(state: LearningPathState) -> LearningPathState:
    """Node: Send learning plan via email"""
    logger.info("NODE: Sending learning plan")
    try:
        from services.email_service import send_learning_plan_email
        success = send_learning_plan_email(state)

        if success:
            state.notification_sent = True
            logger.info("Learning plan sent successfully")
        else:
            logger.warning("Failed to send learning plan")

        state.metadata["notification_complete"] = True
        return state
    except Exception as e:
        logger.error(f"Error in send_learning_plan: {e}")
        # Don't fail the workflow if notification fails
        state.metadata["notification_error"] = str(e)
        return state
