"""Learning Path Recommendation Workflow"""
import logging
from graph import LearningPathGraph
from nodes import *

logger = logging.getLogger("workflow")

def create_learning_path_workflow(max_workers: int = 5) -> LearningPathGraph:
    """Create the learning path recommendation workflow"""
    logger.info("Creating learning path workflow")
    
    # Stage 1: Parallel analysis
    analysis_stage = [
        analyze_skill_gaps,
        detect_learning_style,
        calibrate_difficulty
    ]
    
    # Stage 2: Resource curation and progress planning (depends on stage 1)
    planning_stage = [
        curate_resources,
        plan_progress
    ]
    
    # Stage 3: Create final path
    path_creation_stage = [create_learning_path]
    
    # Stage 4: Send report
    reporting_stage = [send_learning_plan]
    
    stages = [analysis_stage, planning_stage, path_creation_stage, reporting_stage]
    
    logger.info(f"Workflow created with {len(stages)} stages")
    return LearningPathGraph(stages=stages, max_workers=max_workers)
