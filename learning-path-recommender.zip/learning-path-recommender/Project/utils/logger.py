"""Logging Configuration"""
import logging
import os
from config import get_config_value

def setup_logging():
    log_level = get_config_value("LOG_LEVEL", "INFO")
    log_file = get_config_value("LOG_FILE", "logs/learning_path.log")
    
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)-25s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("google").setLevel(logging.WARNING)
    
    logger = logging.getLogger(__name__)
    logger.info("=" * 70)
    logger.info(f"Logging initialized - Level: {log_level}")
    logger.info("=" * 70)
