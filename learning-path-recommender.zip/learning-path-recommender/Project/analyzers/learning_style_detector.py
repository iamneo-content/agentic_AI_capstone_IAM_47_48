"""Learning Style Detection"""
import logging
from typing import Dict, Any, List
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("learning_style_detector")

class LearningStyleDetector:
    """Detects optimal learning style for personalization"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"LearningStyleDetector initialized with model: {model_name}")

    def detect(self, preferences: Dict[str, Any], past_experiences: List[str] = None) -> Dict[str, Any]:
        """
        Detect learning style based on preferences and past experiences

        Args:
            preferences: Dictionary of learning preferences
            past_experiences: List of past learning experiences/outcomes

        Returns:
            Dictionary with learning style analysis
        """
        logger.info("Detecting learning style")

        try:
            pref_summary = "\n".join([f"- {k}: {v}" for k, v in preferences.items()]) if preferences else "No preferences specified"
            exp_summary = "\n".join([f"- {exp}" for exp in (past_experiences or [])]) or "No past experiences provided"

            prompt = f"""Analyze the learner's preferences and experiences to determine their optimal learning style.

LEARNER PREFERENCES:
{pref_summary}

PAST LEARNING EXPERIENCES:
{exp_summary}

Analyze learning style preferences across multiple dimensions:
1. VARK Model: Visual, Auditory, Reading/Writing, Kinesthetic
2. Pace: Self-paced vs Structured schedule
3. Interaction: Solo learning vs Collaborative
4. Depth: Broad overview vs Deep dive
5. Practice: Theory-first vs Hands-on first

Provide your analysis in the following JSON format:
{{
    "primary_style": "<visual|auditory|reading|kinesthetic|balanced>",
    "style_scores": {{
        "visual": <float 0-1>,
        "auditory": <float 0-1>,
        "reading": <float 0-1>,
        "kinesthetic": <float 0-1>
    }},
    "learning_preferences": {{
        "pace": "<self-paced|structured|mixed>",
        "interaction": "<solo|collaborative|mixed>",
        "depth": "<broad|deep|balanced>",
        "practice": "<theory-first|hands-on-first|balanced>"
    }},
    "optimal_resource_types": ["video", "article", "interactive", "book", "course"],
    "recommended_formats": ["tutorial", "project-based", "lecture", "workshop"],
    "study_session_length": "<short (30min)|medium (1hr)|long (2hr+)>",
    "retention_strategies": ["strategy1", "strategy2"],
    "motivation_factors": ["factor1", "factor2"],
    "potential_challenges": ["challenge1", "challenge2"],
    "recommendations": ["recommendation1", "recommendation2"],
    "analysis": "Overall learning style assessment"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Learning style detected: {result.get('primary_style')}")

            return result

        except Exception as e:
            logger.error(f"Error detecting learning style: {e}")
            return self._fallback_learning_style()

    def _fallback_learning_style(self) -> Dict[str, Any]:
        """Fallback default learning style"""
        logger.info("Using fallback learning style (balanced)")

        return {
            "primary_style": "balanced",
            "style_scores": {
                "visual": 0.7,
                "auditory": 0.6,
                "reading": 0.7,
                "kinesthetic": 0.8
            },
            "learning_preferences": {
                "pace": "self-paced",
                "interaction": "mixed",
                "depth": "balanced",
                "practice": "hands-on-first"
            },
            "optimal_resource_types": ["video", "article", "course", "interactive"],
            "recommended_formats": ["tutorial", "project-based", "lecture"],
            "study_session_length": "medium (1hr)",
            "retention_strategies": [
                "Spaced repetition",
                "Active recall",
                "Practice projects"
            ],
            "motivation_factors": [
                "Clear progress milestones",
                "Practical applications",
                "Community support"
            ],
            "potential_challenges": [
                "Staying consistent",
                "Avoiding tutorial hell"
            ],
            "recommendations": [
                "Mix different resource types",
                "Build projects while learning",
                "Set specific weekly goals"
            ],
            "analysis": "Balanced learning style with slight preference for hands-on practice"
        }
