"""Difficulty Calibration"""
import logging
from typing import Dict, Any
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("difficulty_calibrator")

class DifficultyCalibrator:
    """Calibrates starting difficulty and progression"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"DifficultyCalibrator initialized with model: {model_name}")

    def calibrate(
        self,
        current_skills: Dict[str, float],
        target_skill: str,
        time_commitment: int,
        learning_experience: str = "intermediate"
    ) -> Dict[str, Any]:
        """
        Calibrate difficulty level and progression

        Args:
            current_skills: Current skill levels
            target_skill: Target skill to learn
            time_commitment: Hours per week available
            learning_experience: Self-reported learning experience

        Returns:
            Dictionary with difficulty calibration
        """
        logger.info(f"Calibrating difficulty for {target_skill}")

        try:
            skills_summary = "\n".join([
                f"- {skill}: {level:.1f}/10"
                for skill, level in current_skills.items()
            ]) if current_skills else "No current skills"

            prompt = f"""Calibrate the optimal starting difficulty and progression pace for a learner.

TARGET SKILL: {target_skill}
TIME COMMITMENT: {time_commitment} hours/week
LEARNING EXPERIENCE: {learning_experience}

CURRENT SKILLS:
{skills_summary}

Analyze:
1. Appropriate starting difficulty level
2. Pace of difficulty progression
3. Challenge vs frustration balance
4. When to introduce advanced concepts
5. Safety nets for struggles
6. Acceleration opportunities

Provide calibration in the following JSON format:
{{
    "starting_difficulty": "<beginner|intermediate|advanced|expert>",
    "difficulty_score": <float 1-10>,
    "progression_pace": "<slow|moderate|fast|adaptive>",
    "difficulty_curve": [
        {{
            "week": <number>,
            "difficulty": "<beginner|intermediate|advanced>",
            "rationale": "Why this difficulty at this time"
        }}
    ],
    "challenge_level": "<comfortable|moderate|challenging|very-challenging>",
    "cognitive_load": "<low|medium|high>",
    "recommended_adjustments": [
        {{
            "trigger": "When this happens",
            "action": "Do this adjustment",
            "direction": "<increase|decrease|maintain>"
        }}
    ],
    "scaffolding_strategy": {{
        "initial_support": "<high|medium|low>",
        "fade_timeline": "When to reduce support",
        "independence_goal": "Target self-sufficiency level"
    }},
    "success_indicators": ["indicator1", "indicator2"],
    "struggle_indicators": ["indicator1", "indicator2"],
    "optimal_challenge_zone": {{
        "lower_bound": "Too easy indicators",
        "upper_bound": "Too hard indicators",
        "sweet_spot": "Just right indicators"
    }},
    "confidence_score": <float 0-1>,
    "recommendations": ["recommendation1", "recommendation2"],
    "analysis": "Overall difficulty calibration assessment"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Difficulty calibration complete: {result.get('starting_difficulty')}, "
                       f"pace={result.get('progression_pace')}")

            return result

        except Exception as e:
            logger.error(f"Error calibrating difficulty: {e}")
            return self._fallback_difficulty_calibration(current_skills, time_commitment)

    def _fallback_difficulty_calibration(
        self,
        current_skills: Dict[str, float],
        time_commitment: int
    ) -> Dict[str, Any]:
        """Fallback basic difficulty calibration"""
        logger.info("Using fallback difficulty calibration")

        # Estimate overall skill level
        avg_skill = sum(current_skills.values()) / len(current_skills) if current_skills else 0

        # Determine starting difficulty
        if avg_skill >= 7:
            starting_difficulty = "advanced"
            difficulty_score = 8.0
        elif avg_skill >= 4:
            starting_difficulty = "intermediate"
            difficulty_score = 5.0
        else:
            starting_difficulty = "beginner"
            difficulty_score = 3.0

        # Adjust based on time commitment
        if time_commitment >= 15:
            progression_pace = "fast"
        elif time_commitment >= 8:
            progression_pace = "moderate"
        else:
            progression_pace = "slow"

        return {
            "starting_difficulty": starting_difficulty,
            "difficulty_score": difficulty_score,
            "progression_pace": progression_pace,
            "difficulty_curve": [
                {
                    "week": 1,
                    "difficulty": "beginner",
                    "rationale": "Build confidence with fundamentals"
                },
                {
                    "week": 4,
                    "difficulty": "intermediate",
                    "rationale": "Progress to more complex concepts"
                },
                {
                    "week": 8,
                    "difficulty": "advanced",
                    "rationale": "Challenge with advanced applications"
                }
            ],
            "challenge_level": "moderate",
            "cognitive_load": "medium",
            "recommended_adjustments": [
                {
                    "trigger": "Completing lessons quickly and easily",
                    "action": "Skip ahead or increase difficulty",
                    "direction": "increase"
                },
                {
                    "trigger": "Struggling for more than 2 hours on basics",
                    "action": "Review prerequisites or get help",
                    "direction": "decrease"
                }
            ],
            "scaffolding_strategy": {
                "initial_support": "high",
                "fade_timeline": "Reduce support by 25% every 3 weeks",
                "independence_goal": "Self-sufficient problem-solving by week 10"
            },
            "success_indicators": [
                "Completing exercises without hints",
                "Explaining concepts to others",
                "Building projects independently"
            ],
            "struggle_indicators": [
                "Consistently stuck on basic concepts",
                "Avoiding practice exercises",
                "Losing motivation"
            ],
            "optimal_challenge_zone": {
                "lower_bound": "Too easy: finishing exercises in < 30% of expected time",
                "upper_bound": "Too hard: spending 3x expected time on basics",
                "sweet_spot": "Challenging but achievable with effort"
            },
            "confidence_score": 0.75,
            "recommendations": [
                "Start at comfortable difficulty to build momentum",
                "Increase difficulty gradually as confidence grows",
                "Don't hesitate to revisit easier material for reinforcement",
                "Challenge yourself with projects above your current level"
            ],
            "analysis": f"Calibrated to {starting_difficulty} difficulty with {progression_pace} progression based on current skill level"
        }
