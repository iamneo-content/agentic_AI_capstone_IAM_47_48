"""Skill Gap Analysis"""
import logging
from typing import Dict, Any, List
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("skill_gap_analyzer")

class SkillGapAnalyzer:
    """Analyzes skill gaps between current and target proficiency"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"SkillGapAnalyzer initialized with model: {model_name}")

    def analyze(
        self,
        target_skill: str,
        current_skills: Dict[str, float],
        target_level: float
    ) -> Dict[str, Any]:
        """
        Analyze skill gaps for learning path

        Args:
            target_skill: The skill the learner wants to acquire
            current_skills: Dictionary of current skills and their levels (1-10)
            target_level: Desired proficiency level (1-10)

        Returns:
            Dictionary with skill gap analysis
        """
        logger.info(f"Analyzing skill gaps for target: {target_skill}")

        try:
            # Prepare current skills summary
            skills_summary = "\n".join([
                f"- {skill}: {level:.1f}/10"
                for skill, level in current_skills.items()
            ]) if current_skills else "No current skills specified"

            prompt = f"""Analyze the skill gaps for a learner wanting to master a new skill.

TARGET SKILL: {target_skill}
TARGET PROFICIENCY LEVEL: {target_level}/10

CURRENT SKILLS:
{skills_summary}

Analyze:
1. Prerequisites and foundational skills needed
2. Core sub-skills required for the target skill
3. Advanced concepts and techniques
4. Practical application skills
5. Gap between current and target proficiency
6. Priority order for skill acquisition

Provide your analysis in the following JSON format:
{{
    "skill_breakdown": [
        {{
            "skill_name": "Foundational skill name",
            "category": "<foundational|core|advanced|practical>",
            "current_level": <float 0-10>,
            "target_level": <float 0-10>,
            "gap_size": <float 0-10>,
            "priority": "<critical|high|medium|low>",
            "estimated_hours": <number of hours to learn>,
            "description": "What this skill involves"
        }}
    ],
    "prerequisites": ["prerequisite1", "prerequisite2"],
    "learning_sequence": ["skill1", "skill2", "skill3"],
    "total_gap_score": <float 0-10>,
    "difficulty_level": "<beginner|intermediate|advanced|expert>",
    "estimated_total_hours": <total learning hours>,
    "key_challenges": ["challenge1", "challenge2"],
    "quick_wins": ["easy skill to build momentum"],
    "analysis": "Overall skill gap assessment"
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response to extract JSON
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Skill gap analysis complete: {len(result.get('skill_breakdown', []))} gaps identified, "
                       f"total gap score={result.get('total_gap_score'):.1f}")

            return result

        except Exception as e:
            logger.error(f"Error analyzing skill gaps: {e}")
            return self._fallback_skill_gap_analysis(target_skill, current_skills, target_level)

    def _fallback_skill_gap_analysis(
        self,
        target_skill: str,
        current_skills: Dict[str, float],
        target_level: float
    ) -> Dict[str, Any]:
        """Fallback basic skill gap analysis"""
        logger.info("Using fallback skill gap analysis")

        # Estimate current level for target skill
        current_level = current_skills.get(target_skill, 0.0)
        gap_size = target_level - current_level

        # Create basic breakdown
        skill_breakdown = [
            {
                "skill_name": f"{target_skill} - Fundamentals",
                "category": "foundational",
                "current_level": current_level,
                "target_level": min(target_level, 5.0),
                "gap_size": max(0, min(target_level, 5.0) - current_level),
                "priority": "critical",
                "estimated_hours": 20,
                "description": f"Core fundamentals of {target_skill}"
            },
            {
                "skill_name": f"{target_skill} - Intermediate Concepts",
                "category": "core",
                "current_level": max(0, current_level - 3),
                "target_level": min(target_level, 7.0),
                "gap_size": max(0, min(target_level, 7.0) - max(0, current_level - 3)),
                "priority": "high",
                "estimated_hours": 30,
                "description": f"Intermediate concepts and techniques"
            }
        ]

        if target_level >= 8.0:
            skill_breakdown.append({
                "skill_name": f"{target_skill} - Advanced Applications",
                "category": "advanced",
                "current_level": max(0, current_level - 5),
                "target_level": target_level,
                "gap_size": max(0, target_level - max(0, current_level - 5)),
                "priority": "medium",
                "estimated_hours": 40,
                "description": f"Advanced applications and mastery"
            })

        # Determine difficulty
        if gap_size >= 7:
            difficulty = "beginner"
        elif gap_size >= 5:
            difficulty = "intermediate"
        elif gap_size >= 3:
            difficulty = "advanced"
        else:
            difficulty = "expert"

        return {
            "skill_breakdown": skill_breakdown,
            "prerequisites": ["Basic computer literacy", "Time management"],
            "learning_sequence": [s["skill_name"] for s in skill_breakdown],
            "total_gap_score": gap_size,
            "difficulty_level": difficulty,
            "estimated_total_hours": sum(s["estimated_hours"] for s in skill_breakdown),
            "key_challenges": ["Maintaining consistency", "Applying concepts practically"],
            "quick_wins": ["Complete introductory tutorials", "Build simple projects"],
            "analysis": f"Basic skill gap analysis indicates a {gap_size:.1f} point gap from current to target level"
        }
