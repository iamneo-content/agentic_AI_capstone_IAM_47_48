"""Progress Tracking and Milestone Planning"""
import logging
from typing import Dict, Any, List
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("progress_tracker")

class ProgressTracker:
    """Plans milestones and tracking strategy"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"ProgressTracker initialized with model: {model_name}")

    def plan_milestones(
        self,
        skill_gaps: List[Dict[str, Any]],
        duration_weeks: int,
        time_per_week: int
    ) -> Dict[str, Any]:
        """
        Plan learning milestones and progress tracking

        Args:
            skill_gaps: List of skills to learn
            duration_weeks: Total learning duration in weeks
            time_per_week: Available hours per week

        Returns:
            Dictionary with milestone plan
        """
        logger.info(f"Planning milestones for {duration_weeks} weeks, {time_per_week} hrs/week")

        try:
            total_hours = duration_weeks * time_per_week
            gaps_summary = "\n".join([
                f"- {gap.get('skill_name')}: {gap.get('estimated_hours', 10)} hours (Priority: {gap.get('priority')})"
                for gap in skill_gaps
            ])

            prompt = f"""Create a detailed milestone-based learning plan.

SKILLS TO MASTER:
{gaps_summary}

TIME AVAILABLE:
- Duration: {duration_weeks} weeks
- Time commitment: {time_per_week} hours/week
- Total hours: {total_hours} hours

Create realistic, achievable milestones that:
1. Progress from foundational to advanced
2. Include regular check-points
3. Balance theory and practice
4. Allow for review and consolidation
5. Build momentum with early wins

Provide the plan in the following JSON format:
{{
    "milestones": [
        {{
            "week": <week number>,
            "title": "Milestone title",
            "description": "What to achieve",
            "skills_covered": ["skill1", "skill2"],
            "deliverables": ["deliverable1", "deliverable2"],
            "success_criteria": "How to measure success",
            "estimated_hours": <hours for this milestone>,
            "difficulty": "<easy|medium|hard>",
            "checkpoint_type": "<foundation|progress|mastery>"
        }}
    ],
    "weekly_schedule": [
        {{
            "week": <number>,
            "focus": "Week focus area",
            "hours_allocated": <hours>,
            "activities": ["activity1", "activity2"]
        }}
    ],
    "progress_metrics": [
        {{
            "metric": "Metric name",
            "measurement": "How to measure",
            "target": "Target value",
            "frequency": "<daily|weekly|bi-weekly>"
        }}
    ],
    "review_points": [
        {{
            "week": <number>,
            "type": "<self-assessment|project-review|skill-test>",
            "focus": "What to review",
            "questions": ["question1", "question2"]
        }}
    ],
    "motivation_strategies": [
        {{
            "strategy": "Strategy name",
            "timing": "When to apply",
            "description": "How it helps"
        }}
    ],
    "buffer_time": <percentage for unexpected delays>,
    "total_planned_hours": <hours>,
    "feasibility_score": <float 0-1>,
    "recommendations": ["recommendation1", "recommendation2"]
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Milestone planning complete: {len(result.get('milestones', []))} milestones created")

            return result

        except Exception as e:
            logger.error(f"Error planning milestones: {e}")
            return self._fallback_milestone_plan(skill_gaps, duration_weeks, time_per_week)

    def _fallback_milestone_plan(
        self,
        skill_gaps: List[Dict[str, Any]],
        duration_weeks: int,
        time_per_week: int
    ) -> Dict[str, Any]:
        """Fallback basic milestone plan"""
        logger.info("Using fallback milestone planning")

        total_hours = duration_weeks * time_per_week
        weeks_per_skill = max(2, duration_weeks // max(len(skill_gaps), 1))

        milestones = []
        week = 1

        for i, gap in enumerate(skill_gaps[:5]):  # Limit to 5 skills
            skill_name = gap.get("skill_name", f"Skill {i+1}")
            milestones.append({
                "week": week,
                "title": f"Master {skill_name}",
                "description": f"Complete learning and practice for {skill_name}",
                "skills_covered": [skill_name],
                "deliverables": [f"{skill_name} project", f"{skill_name} assessment"],
                "success_criteria": "Complete all resources and pass assessment",
                "estimated_hours": gap.get("estimated_hours", 20),
                "difficulty": gap.get("category", "medium"),
                "checkpoint_type": "progress"
            })
            week += weeks_per_skill

        # Add final milestone
        milestones.append({
            "week": duration_weeks,
            "title": "Capstone Project",
            "description": "Apply all learned skills in a comprehensive project",
            "skills_covered": [gap.get("skill_name") for gap in skill_gaps[:3]],
            "deliverables": ["Complete capstone project", "Portfolio piece"],
            "success_criteria": "Successfully implement all major concepts",
            "estimated_hours": time_per_week * 2,
            "difficulty": "hard",
            "checkpoint_type": "mastery"
        })

        # Generate weekly schedule
        weekly_schedule = [
            {
                "week": w,
                "focus": f"Week {w} Focus",
                "hours_allocated": time_per_week,
                "activities": ["Study", "Practice", "Review"]
            }
            for w in range(1, duration_weeks + 1)
        ]

        return {
            "milestones": milestones,
            "weekly_schedule": weekly_schedule,
            "progress_metrics": [
                {
                    "metric": "Completion Rate",
                    "measurement": "Resources completed / Total resources",
                    "target": "100%",
                    "frequency": "weekly"
                },
                {
                    "metric": "Practice Hours",
                    "measurement": "Hours spent on hands-on practice",
                    "target": f"{time_per_week * 0.5:.0f} hours/week",
                    "frequency": "weekly"
                }
            ],
            "review_points": [
                {
                    "week": duration_weeks // 2,
                    "type": "self-assessment",
                    "focus": "Mid-point review",
                    "questions": ["What have I learned?", "What needs more practice?"]
                }
            ],
            "motivation_strategies": [
                {
                    "strategy": "Weekly check-ins",
                    "timing": "End of each week",
                    "description": "Review progress and adjust as needed"
                },
                {
                    "strategy": "Celebrate small wins",
                    "timing": "After each milestone",
                    "description": "Acknowledge progress to maintain motivation"
                }
            ],
            "buffer_time": 20,  # 20% buffer
            "total_planned_hours": total_hours,
            "feasibility_score": 0.75,
            "recommendations": [
                "Set specific weekly goals",
                "Track time spent learning",
                "Review and adjust plan monthly",
                "Join accountability groups"
            ]
        }
