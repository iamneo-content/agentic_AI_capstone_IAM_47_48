"""Learning Resource Curation"""
import logging
from typing import Dict, Any, List
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("resource_curator")

class ResourceCurator:
    """Curates personalized learning resources"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not configured")

        genai.configure(api_key=api_key)
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")
        self.model = genai.GenerativeModel(model_name)
        logger.info(f"ResourceCurator initialized with model: {model_name}")

    def curate(
        self,
        skill_gaps: List[Dict[str, Any]],
        learning_style: str,
        preferences: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Curate learning resources based on gaps and learning style

        Args:
            skill_gaps: List of skill gaps to address
            learning_style: Primary learning style
            preferences: Resource preferences

        Returns:
            Dictionary with curated resources
        """
        logger.info(f"Curating resources for {len(skill_gaps)} skill gaps")

        try:
            gaps_summary = "\n".join([
                f"- {gap.get('skill_name')}: {gap.get('category')} (Priority: {gap.get('priority')})"
                for gap in skill_gaps[:10]  # Limit to top 10
            ])

            prompt = f"""Recommend high-quality learning resources for the specified skills.

SKILLS TO LEARN:
{gaps_summary}

LEARNING STYLE: {learning_style}
RESOURCE PREFERENCES: {preferences}

For each skill, recommend diverse, high-quality resources including:
- Online courses (Coursera, Udemy, edX, etc.)
- Video tutorials (YouTube, educational channels)
- Books and eBooks
- Interactive platforms (Codecademy, LeetCode, etc.)
- Articles and documentation
- Practice projects

Consider:
1. Resource quality and reputation
2. Learning style match
3. Difficulty progression
4. Time investment
5. Cost (free vs paid)
6. Hands-on practice opportunities

Provide recommendations in the following JSON format:
{{
    "resources": [
        {{
            "title": "Resource title",
            "type": "<course|video|book|article|interactive|project>",
            "provider": "Platform or author",
            "skill_covered": "Which skill this addresses",
            "difficulty": "<beginner|intermediate|advanced>",
            "estimated_hours": <number>,
            "cost": "<free|paid|freemium>",
            "url": "URL or platform name",
            "rating": <float 0-5>,
            "why_recommended": "Reason for recommendation",
            "learning_style_match": <float 0-1>
        }}
    ],
    "learning_paths": [
        {{
            "name": "Suggested path name",
            "resources": ["resource1", "resource2"],
            "total_hours": <number>,
            "description": "Path description"
        }}
    ],
    "practice_projects": [
        {{
            "title": "Project title",
            "description": "What to build",
            "skills_practiced": ["skill1", "skill2"],
            "difficulty": "<beginner|intermediate|advanced>",
            "estimated_hours": <number>
        }}
    ],
    "communities": [
        {{
            "name": "Community name",
            "platform": "Where to find it",
            "focus": "What they focus on",
            "value": "Why join"
        }}
    ],
    "total_resources": <number>,
    "free_resources": <number>,
    "paid_resources": <number>,
    "recommendations": ["tip1", "tip2"]
}}

Respond ONLY with valid JSON, no additional text."""

            response = self.model.generate_content(prompt)
            result_text = response.text.strip()

            # Clean response
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            import json
            result = json.loads(result_text)

            logger.info(f"Resource curation complete: {result.get('total_resources', 0)} resources recommended")

            return result

        except Exception as e:
            logger.error(f"Error curating resources: {e}")
            return self._fallback_resource_curation(skill_gaps)

    def _fallback_resource_curation(self, skill_gaps: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Fallback basic resource recommendations"""
        logger.info("Using fallback resource curation")

        # Generic resources based on common platforms
        resources = []
        for gap in skill_gaps[:5]:
            skill_name = gap.get("skill_name", "Unknown")
            resources.extend([
                {
                    "title": f"{skill_name} - Complete Course",
                    "type": "course",
                    "provider": "Coursera/Udemy",
                    "skill_covered": skill_name,
                    "difficulty": gap.get("category", "intermediate"),
                    "estimated_hours": gap.get("estimated_hours", 20),
                    "cost": "freemium",
                    "url": "Search on course platforms",
                    "rating": 4.5,
                    "why_recommended": "Comprehensive structured learning",
                    "learning_style_match": 0.8
                },
                {
                    "title": f"{skill_name} - Video Tutorial Series",
                    "type": "video",
                    "provider": "YouTube",
                    "skill_covered": skill_name,
                    "difficulty": "beginner",
                    "estimated_hours": 5,
                    "cost": "free",
                    "url": "YouTube",
                    "rating": 4.0,
                    "why_recommended": "Visual learning with examples",
                    "learning_style_match": 0.9
                }
            ])

        return {
            "resources": resources,
            "learning_paths": [
                {
                    "name": "Foundation to Advanced",
                    "resources": [r["title"] for r in resources[:4]],
                    "total_hours": sum(gap.get("estimated_hours", 20) for gap in skill_gaps[:3]),
                    "description": "Progressive learning from basics to advanced concepts"
                }
            ],
            "practice_projects": [
                {
                    "title": "Beginner Practice Project",
                    "description": "Apply fundamental concepts",
                    "skills_practiced": [gap.get("skill_name") for gap in skill_gaps[:2]],
                    "difficulty": "beginner",
                    "estimated_hours": 10
                }
            ],
            "communities": [
                {
                    "name": "Reddit Learning Community",
                    "platform": "Reddit",
                    "focus": "General skill learning",
                    "value": "Ask questions and share progress"
                }
            ],
            "total_resources": len(resources),
            "free_resources": len([r for r in resources if r["cost"] == "free"]),
            "paid_resources": len([r for r in resources if r["cost"] == "paid"]),
            "recommendations": [
                "Start with free resources to gauge interest",
                "Mix different resource types for better retention",
                "Join communities for support and motivation"
            ]
        }
