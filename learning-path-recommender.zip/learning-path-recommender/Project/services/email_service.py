"""Email Service"""
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from state import LearningPathState
from config import get_config_value

logger = logging.getLogger("email_service")

def send_learning_plan_email(state: LearningPathState) -> bool:
    try:
        email_from = get_config_value("EMAIL_FROM")
        email_password = get_config_value("EMAIL_PASSWORD")
        email_to = get_config_value("EMAIL_TO")
        
        if not all([email_from, email_password, email_to]):
            logger.warning("Email configuration incomplete")
            return False
        
        msg = MIMEMultipart()
        msg["Subject"] = f"Learning Path: {state.target_skill}"
        msg["From"] = email_from
        msg["To"] = email_to
        
        body = f"""
PERSONALIZED LEARNING PATH

Target Skill: {state.target_skill}
Target Level: {state.target_level}/10
Duration: {state.duration_weeks} weeks

PATH QUALITY SCORE: {state.path_quality_score:.1f}/10
Feasibility: {state.path_feasibility}
Success Probability: {state.success_probability * 100:.1f}%

CURRICULUM: {len(state.curriculum)} modules
RESOURCES: {len(state.recommended_resources)} curated resources
MILESTONES: {len(state.milestones)} checkpoints

Learning Style: {state.learning_style}
Starting Difficulty: {state.starting_difficulty}
Estimated Hours: {state.estimated_completion_time}

For full details, see the complete report.
        """
        
        msg.attach(MIMEText(body, "plain"))
        
        smtp_server = get_config_value("SMTP_SERVER", "smtp.gmail.com")
        smtp_port = get_config_value("SMTP_PORT", 587)
        
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(email_from, email_password)
            server.send_message(msg)
        
        logger.info("Email sent successfully")
        return True
    except Exception as e:
        logger.error(f"Error sending email: {e}")
        return False
