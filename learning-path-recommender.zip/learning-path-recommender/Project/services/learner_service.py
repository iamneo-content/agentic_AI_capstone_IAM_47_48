"""Learner Data Service"""
import logging

logger = logging.getLogger("learner_service")

def create_sample_learner(learner_id: str = "LEARNER001"):
    """Create sample learner data"""
    samples = {
        "LEARNER001": {
            "learner_id": "LEARNER001",
            "target_skill": "Machine Learning",
            "current_skills": {
                "Python": 7.0,
                "Statistics": 5.0,
                "Data Analysis": 6.0
            },
            "target_level": 8.0,
            "time_commitment": 12,
            "duration_weeks": 16,
            "preferences": {
                "resource_types": ["video", "course", "hands-on"],
                "pace": "self-paced",
                "budget": "moderate"
            }
        },
        "LEARNER002": {
            "learner_id": "LEARNER002",
            "target_skill": "Web Development",
            "current_skills": {
                "HTML": 6.0,
                "CSS": 5.0
            },
            "target_level": 8.0,
            "time_commitment": 10,
            "duration_weeks": 12,
            "preferences": {
                "resource_types": ["interactive", "project-based"],
                "pace": "structured"
            }
        }
    }
    
    return samples.get(learner_id, samples["LEARNER001"])
