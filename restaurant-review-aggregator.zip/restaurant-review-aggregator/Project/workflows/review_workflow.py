"""
Restaurant Review Workflow Builder

Defines the staged restaurant review pipeline with parallel and sequential nodes.
"""

from graph import RestaurantReviewGraph
from nodes import (
    data_collector_node,
    food_quality_node,
    hygiene_node,
    sentiment_node,
    pricing_node,
    location_ambiance_node,
    coordinator_node,
    decision_node,
    report_node
)


def build_review_workflow(max_workers: int = 5) -> RestaurantReviewGraph:
    """
    Build the restaurant review workflow with parallel execution

    Stages:
    1. Data collection (fetch restaurant data from multiple sources)
    2. Parallel analyses (food quality, hygiene, sentiment, pricing, location/ambiance)
    3. Coordinator (aggregate results)
    4. Decision (make automated decision)
    5. Report (generate final report and send notification)

    Args:
        max_workers: Maximum number of parallel workers (default: 5)

    Returns:
        Compiled RestaurantReviewGraph ready for execution
    """
    stages = [
        # Stage 1: Data collection
        [data_collector_node],

        # Stage 2: Parallel analyses (all 5 run simultaneously)
        [food_quality_node, hygiene_node, sentiment_node, pricing_node, location_ambiance_node],

        # Stage 3: Coordinator
        [coordinator_node],

        # Stage 4: Decision
        [decision_node],

        # Stage 5: Report
        [report_node]
    ]

    return RestaurantReviewGraph(stages=stages, max_workers=max_workers, raise_on_error=False)
