"""
Food Quality Analysis Node - Simplified Wrapper

Calls FoodQualityAgent to perform food quality analysis.
"""

from state import RestaurantReviewState
from agents.food_quality_agent import FoodQualityAgent

# Create agent instance
agent = FoodQualityAgent()


def food_quality_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Perform food quality analysis

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with food quality results
    """
    state.food_quality_results = agent.analyze(state.menu_data, state.customer_reviews)
    return state
