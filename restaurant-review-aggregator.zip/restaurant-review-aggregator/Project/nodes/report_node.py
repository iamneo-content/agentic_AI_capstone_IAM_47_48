"""
Report Node

Generates final report and sends email notification.
"""

from state import RestaurantReviewState
from services.email_service import EmailService
from datetime import datetime
import logging

logger = logging.getLogger("node.report")


def report_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Generate final report and send email notification

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with report
    """
    logger.info("Generating final report")

    # Generate improvement suggestions
    improvement_suggestions = []

    # Food quality suggestions
    if state.food_quality_results:
        food_recs = state.food_quality_results[0].get("recommendations", [])
        improvement_suggestions.extend(food_recs)

    # Hygiene suggestions
    if state.hygiene_results:
        hygiene_recs = state.hygiene_results[0].get("recommendations", [])
        improvement_suggestions.extend(hygiene_recs)

    # Sentiment suggestions
    if state.sentiment_results:
        sentiment_recs = state.sentiment_results[0].get("recommendations", [])
        improvement_suggestions.extend(sentiment_recs)

    # Key findings
    key_findings = [
        f"Overall Rating: {state.overall_rating:.2f}/10",
        f"Recommendation: {state.recommendation_level}",
        f"Decision: {state.decision}"
    ]

    if state.has_critical_issues:
        key_findings.append(f"Critical Issue: {state.critical_reason}")

    # Action items
    action_items = improvement_suggestions[:5]  # Top 5 suggestions

    # Determine priority
    if state.has_critical_issues:
        priority = "HIGH"
    elif state.overall_rating < 7.0:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    # Create report
    report = {
        "review_id": state.review_id,
        "restaurant_name": state.restaurant_name,
        "location": state.location,
        "timestamp": state.timestamp,
        "overall_rating": state.overall_rating,
        "recommendation": state.recommendation_level,
        "decision": state.decision,
        "priority": priority,
        "key_findings": key_findings,
        "action_items": action_items,
        "metrics": state.decision_metrics,
        "improvement_suggestions": improvement_suggestions
    }

    state.report = report
    state.improvement_suggestions = improvement_suggestions

    # Send email notification
    try:
        email_service = EmailService()

        # Send start notification
        email_service.send_review_start_email(
            state.review_id,
            state.restaurant_name,
            state.location
        )

        # Send final report
        email_service.send_final_report_email(state)

        state.notifications_sent.append({
            "type": "email",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "sent"
        })

        logger.info("Email notifications sent successfully")
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        state.notifications_sent.append({
            "type": "email",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "failed",
            "error": str(e)
        })

    logger.info("Report generation complete")
    return state
