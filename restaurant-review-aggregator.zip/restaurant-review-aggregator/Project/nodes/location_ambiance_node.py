"""
Location and Ambiance Analysis Node - Simplified Wrapper

Calls LocationAmbianceAgent to perform location and ambiance analysis.
"""

from state import RestaurantReviewState
from agents.location_ambiance_agent import LocationAmbianceAgent

# Create agent instance
agent = LocationAmbianceAgent()


def location_ambiance_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Perform location and ambiance analysis

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with location and ambiance results
    """
    state.location_ambiance_results = agent.analyze(state.restaurant_data, state.customer_reviews)
    return state
