"""
Pricing Analysis Node - Simplified Wrapper

Calls PricingAgent to perform pricing analysis.
"""

from state import RestaurantReviewState
from agents.pricing_agent import PricingAgent

# Create agent instance
agent = PricingAgent()


def pricing_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Perform pricing analysis

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with pricing results
    """
    state.pricing_results = agent.analyze(state.menu_data, state.restaurant_data, state.customer_reviews)
    return state
