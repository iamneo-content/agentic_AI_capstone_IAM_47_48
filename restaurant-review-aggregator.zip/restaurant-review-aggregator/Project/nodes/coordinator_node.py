"""
Coordinator Node - Simplified Wrapper

Calls CoordinatorAgent to coordinate and aggregate results.
"""

from state import RestaurantReviewState
from agents.coordinator_agent import CoordinatorAgent

# Create agent instance
agent = CoordinatorAgent()


def coordinator_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Coordinate and aggregate analysis results

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with coordination summary
    """
    state.coordination_summary = agent.analyze(
        state.food_quality_results,
        state.hygiene_results,
        state.sentiment_results,
        state.pricing_results,
        state.location_ambiance_results
    )
    return state
