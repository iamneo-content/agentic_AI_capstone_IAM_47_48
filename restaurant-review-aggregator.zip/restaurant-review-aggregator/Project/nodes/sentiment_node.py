"""
Sentiment Analysis Node - Simplified Wrapper

Calls SentimentAgent to perform sentiment analysis.
"""

from state import RestaurantReviewState
from agents.sentiment_agent import SentimentAgent

# Create agent instance
agent = SentimentAgent()


def sentiment_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Perform sentiment analysis

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with sentiment results
    """
    state.sentiment_results = agent.analyze(state.customer_reviews)
    return state
