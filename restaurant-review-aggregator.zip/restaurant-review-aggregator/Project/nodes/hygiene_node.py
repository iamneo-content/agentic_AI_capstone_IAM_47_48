"""
Hygiene Analysis Node - Simplified Wrapper

Calls HygieneAgent to perform hygiene analysis.
"""

from state import RestaurantReviewState
from agents.hygiene_agent import HygieneAgent

# Create agent instance
agent = HygieneAgent()


def hygiene_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Perform hygiene analysis

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with hygiene results
    """
    state.hygiene_results = agent.analyze(state.restaurant_data, state.customer_reviews)
    return state
