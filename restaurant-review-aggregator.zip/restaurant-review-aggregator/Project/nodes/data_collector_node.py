"""
Data Collector Node - Simplified Wrapper

Calls DataCollectorAgent to collect restaurant data.
"""

from state import RestaurantReviewState
from agents.data_collector_agent import DataCollectorAgent

# Create agent instance
agent = DataCollectorAgent()


def data_collector_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Collect restaurant data from multiple sources

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with collected data
    """
    result = agent.analyze(state.restaurant_name, state.location)

    state.restaurant_data = result.get("restaurant_data", {})
    state.menu_data = result.get("menu_data", [])
    state.customer_reviews = result.get("customer_reviews", [])

    return state
