"""
Decision Node

Makes automated decision based on coordinated analysis results.
"""

from state import RestaurantReviewState
from config import get_config_value
import logging

logger = logging.getLogger("node.decision")


def decision_node(state: RestaurantReviewState) -> RestaurantReviewState:
    """
    Make automated decision based on analysis results

    Args:
        state: Current restaurant review state

    Returns:
        Updated state with decision and metrics
    """
    logger.info("Making automated decision")

    summary = state.coordination_summary
    overall_score = summary.get("overall_score", 0)

    # Get thresholds from config
    food_threshold = get_config_value("FOOD_QUALITY_THRESHOLD", 7.0)
    hygiene_threshold = get_config_value("HYGIENE_THRESHOLD", 8.0)
    sentiment_threshold = get_config_value("SENTIMENT_THRESHOLD", 0.6)

    # Extract individual scores
    food_score = summary.get("food_quality_score", 0)
    hygiene_score = summary.get("hygiene_score", 0)
    sentiment_score = summary.get("sentiment_score", 0) / 10  # Convert to 0-1 scale

    # Determine recommendation level
    if overall_score >= 8.5:
        recommendation_level = "HIGHLY RECOMMENDED"
    elif overall_score >= 7.0:
        recommendation_level = "RECOMMENDED"
    elif overall_score >= 5.0:
        recommendation_level = "NEUTRAL"
    else:
        recommendation_level = "NOT RECOMMENDED"

    # Check for critical issues
    has_critical_issues = False
    critical_reason = ""

    if hygiene_score < hygiene_threshold:
        has_critical_issues = True
        critical_reason = f"Hygiene score ({hygiene_score:.1f}) below threshold ({hygiene_threshold})"
    elif food_score < food_threshold:
        has_critical_issues = True
        critical_reason = f"Food quality score ({food_score:.1f}) below threshold ({food_threshold})"
    elif sentiment_score < sentiment_threshold:
        has_critical_issues = True
        critical_reason = f"Customer sentiment ({sentiment_score:.2f}) below threshold ({sentiment_threshold})"

    # Determine final decision
    if has_critical_issues:
        decision = "NEEDS_IMPROVEMENT"
    elif overall_score >= 8.0:
        decision = "EXCELLENT"
    elif overall_score >= 7.0:
        decision = "GOOD"
    elif overall_score >= 6.0:
        decision = "ACCEPTABLE"
    else:
        decision = "NEEDS_IMPROVEMENT"

    # Store decision metrics
    decision_metrics = {
        "overall_score": overall_score,
        "food_quality_score": food_score,
        "hygiene_score": hygiene_score,
        "sentiment_score": sentiment_score,
        "pricing_score": summary.get("pricing_score", 0),
        "ambiance_score": summary.get("ambiance_score", 0)
    }

    state.decision = decision
    state.overall_rating = overall_score
    state.recommendation_level = recommendation_level
    state.has_critical_issues = has_critical_issues
    state.critical_reason = critical_reason
    state.decision_metrics = decision_metrics

    logger.info(f"Decision: {decision}, Rating: {overall_score:.2f}/10")
    return state
