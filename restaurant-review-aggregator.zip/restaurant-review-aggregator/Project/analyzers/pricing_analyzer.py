"""
Pricing Analyzer

Pure tool for analyzing pricing and value for money.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.pricing")


class PricingAnalyzer:
    """Analyzer for pricing and value assessment"""

    def analyze_pricing(self, menu_data: List[Dict[str, Any]], restaurant_data: Dict[str, Any], customer_reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze pricing and value for money

        Args:
            menu_data: List of menu items with prices
            restaurant_data: Restaurant information
            customer_reviews: List of customer reviews

        Returns:
            Dictionary containing pricing analysis
        """
        logger.info(f"Analyzing pricing for {len(menu_data)} menu items")

        # Calculate average price
        prices = [item.get("price", 0) for item in menu_data if item.get("price")]
        average_price = sum(prices) / len(prices) if prices else 0

        # Determine price range
        price_range = restaurant_data.get("price_range", "$$")

        # Categorize prices
        price_categories = {
            "budget": sum(1 for p in prices if p < 10),
            "moderate": sum(1 for p in prices if 10 <= p < 20),
            "premium": sum(1 for p in prices if p >= 20)
        }

        # Analyze value mentions in reviews
        value_keywords = ["worth", "value", "affordable", "reasonable", "expensive", "overpriced", "cheap"]
        value_mentions = []

        for review in customer_reviews:
            text = review.get("text", "").lower()
            for keyword in value_keywords:
                if keyword in text:
                    value_mentions.append(keyword)

        # Calculate value rating (based on sentiment and price)
        positive_value_words = ["worth", "value", "affordable", "reasonable"]
        negative_value_words = ["expensive", "overpriced"]

        positive_mentions = sum(1 for word in value_mentions if word in positive_value_words)
        negative_mentions = sum(1 for word in value_mentions if word in negative_value_words)

        if value_mentions:
            value_rating = (positive_mentions - negative_mentions) / len(value_mentions)
            value_rating = (value_rating + 1) / 2 * 10  # Normalize to 0-10
        else:
            value_rating = 7.0  # Default if no mentions

        # Calculate pricing score
        pricing_score = value_rating

        recommendations = []
        if average_price > 20:
            recommendations.append("Consider offering more budget-friendly options")
        if pricing_score < 7.0:
            recommendations.append("Review pricing to improve value perception")
        if negative_mentions > positive_mentions:
            recommendations.append("Address pricing concerns in customer feedback")

        result = {
            "pricing_score": round(pricing_score, 2),
            "average_price": round(average_price, 2),
            "price_range": price_range,
            "value_rating": round(value_rating, 2),
            "price_categories": price_categories,
            "recommendations": recommendations
        }

        logger.info(f"Pricing score: {result['pricing_score']}/10, Average: ${average_price:.2f}")
        return result
