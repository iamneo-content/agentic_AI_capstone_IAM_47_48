"""
Hygiene Analyzer

Pure tool for analyzing hygiene and safety standards.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.hygiene")


class HygieneAnalyzer:
    """Analyzer for hygiene and safety assessment"""

    def analyze_hygiene(self, restaurant_data: Dict[str, Any], customer_reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze hygiene and safety standards

        Args:
            restaurant_data: Restaurant information
            customer_reviews: List of customer reviews

        Returns:
            Dictionary containing hygiene analysis
        """
        logger.info(f"Analyzing hygiene for {restaurant_data.get('name', 'restaurant')}")

        # Check for hygiene-related keywords in reviews
        hygiene_positive = ["clean", "spotless", "sanitary", "hygienic", "well-maintained"]
        hygiene_negative = ["dirty", "unclean", "messy", "unsanitary", "stale"]

        cleanliness_indicators = []
        concerns = []

        for review in customer_reviews:
            text = review.get("text", "").lower()
            for keyword in hygiene_positive:
                if keyword in text:
                    cleanliness_indicators.append(f"Positive: {keyword}")
            for keyword in hygiene_negative:
                if keyword in text:
                    concerns.append(f"Concern: {keyword} mentioned in review")

        # Calculate hygiene score (base 8.0, deduct for concerns)
        hygiene_score = 8.0
        hygiene_score -= len(concerns) * 0.5
        hygiene_score = max(hygiene_score, 0)  # Don't go below 0

        # Safety compliance (mock data)
        safety_compliance = [
            "Food handler certification",
            "Regular health inspections",
            "Temperature control compliance"
        ]

        recommendations = []
        if hygiene_score < 8.0:
            recommendations.append("Address cleanliness concerns mentioned in reviews")
            recommendations.append("Implement stricter hygiene protocols")
        if not cleanliness_indicators:
            recommendations.append("Ensure visible cleanliness improvements")

        result = {
            "hygiene_score": round(hygiene_score, 2),
            "safety_compliance": safety_compliance,
            "cleanliness_indicators": cleanliness_indicators,
            "concerns": concerns,
            "recommendations": recommendations
        }

        logger.info(f"Hygiene score: {result['hygiene_score']}/10, {len(concerns)} concerns")
        return result
