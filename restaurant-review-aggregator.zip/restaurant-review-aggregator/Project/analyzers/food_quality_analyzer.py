"""
Food Quality Analyzer

Pure tool for analyzing food quality from menu and reviews.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.food_quality")


class FoodQualityAnalyzer:
    """Analyzer for food quality assessment"""

    def analyze_food_quality(self, menu_data: List[Dict[str, Any]], customer_reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze food quality from menu and reviews

        Args:
            menu_data: List of menu items
            customer_reviews: List of customer reviews

        Returns:
            Dictionary containing food quality analysis
        """
        logger.info(f"Analyzing food quality with {len(menu_data)} items and {len(customer_reviews)} reviews")

        # Analyze menu variety
        menu_variety = len(menu_data)
        categories = set(item.get("category", "Unknown") for item in menu_data)

        # Extract food-related keywords from reviews
        food_keywords = ["delicious", "tasty", "fresh", "flavorful", "amazing", "excellent", "perfect"]
        quality_indicators = []

        for review in customer_reviews:
            text = review.get("text", "").lower()
            for keyword in food_keywords:
                if keyword in text:
                    quality_indicators.append(keyword)

        # Calculate food quality score based on reviews and variety
        avg_rating = sum(review.get("rating", 0) for review in customer_reviews) / len(customer_reviews) if customer_reviews else 0
        variety_score = min(len(categories) / 5.0, 1.0) * 10  # Max 5 categories for full score

        food_quality_score = (avg_rating * 2) * 0.7 + variety_score * 0.3

        # Identify popular items (mock implementation)
        popular_items = [item.get("item", "") for item in menu_data[:3]]

        recommendations = []
        if food_quality_score < 7.0:
            recommendations.append("Consider improving ingredient quality")
            recommendations.append("Add more variety to the menu")
        if len(quality_indicators) < 5:
            recommendations.append("Focus on enhancing flavors and presentation")

        result = {
            "food_quality_score": round(food_quality_score, 2),
            "menu_variety": menu_variety,
            "popular_items": popular_items,
            "quality_indicators": list(set(quality_indicators)),
            "recommendations": recommendations
        }

        logger.info(f"Food quality score: {result['food_quality_score']}/10")
        return result
