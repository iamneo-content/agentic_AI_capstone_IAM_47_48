"""
Sentiment Analyzer

Pure tool for analyzing customer sentiment from reviews.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.sentiment")


class SentimentAnalyzer:
    """Analyzer for customer sentiment assessment"""

    def analyze_sentiment(self, customer_reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze customer sentiment from reviews

        Args:
            customer_reviews: List of customer reviews

        Returns:
            Dictionary containing sentiment analysis
        """
        logger.info(f"Analyzing sentiment from {len(customer_reviews)} reviews")

        if not customer_reviews:
            return {
                "overall_sentiment": 0.0,
                "positive_count": 0,
                "negative_count": 0,
                "neutral_count": 0,
                "key_themes": [],
                "sentiment_trend": "insufficient_data",
                "recommendations": ["Encourage more customer reviews"]
            }

        # Simple sentiment classification based on ratings
        positive_count = sum(1 for review in customer_reviews if review.get("rating", 0) >= 4.0)
        negative_count = sum(1 for review in customer_reviews if review.get("rating", 0) < 3.0)
        neutral_count = len(customer_reviews) - positive_count - negative_count

        # Calculate overall sentiment (0.0 to 1.0)
        overall_sentiment = positive_count / len(customer_reviews) if customer_reviews else 0

        # Extract key themes from reviews
        positive_keywords = ["excellent", "great", "amazing", "love", "best", "wonderful", "recommend"]
        negative_keywords = ["poor", "bad", "terrible", "worst", "disappointing", "awful"]

        key_themes = []
        for review in customer_reviews:
            text = review.get("text", "").lower()
            for keyword in positive_keywords:
                if keyword in text and f"Positive: {keyword}" not in key_themes:
                    key_themes.append(f"Positive: {keyword}")
            for keyword in negative_keywords:
                if keyword in text and f"Negative: {keyword}" not in key_themes:
                    key_themes.append(f"Negative: {keyword}")

        # Determine sentiment trend
        if overall_sentiment >= 0.7:
            sentiment_trend = "very_positive"
        elif overall_sentiment >= 0.5:
            sentiment_trend = "positive"
        elif overall_sentiment >= 0.3:
            sentiment_trend = "neutral"
        else:
            sentiment_trend = "negative"

        recommendations = []
        if overall_sentiment < 0.6:
            recommendations.append("Address negative feedback promptly")
            recommendations.append("Improve customer service training")
        if negative_count > positive_count:
            recommendations.append("Investigate recurring complaints")

        result = {
            "overall_sentiment": round(overall_sentiment, 2),
            "positive_count": positive_count,
            "negative_count": negative_count,
            "neutral_count": neutral_count,
            "key_themes": key_themes[:10],  # Top 10 themes
            "sentiment_trend": sentiment_trend,
            "recommendations": recommendations
        }

        logger.info(f"Overall sentiment: {result['overall_sentiment']:.2f} ({sentiment_trend})")
        return result
