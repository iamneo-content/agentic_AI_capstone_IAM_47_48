"""
Location and Ambiance Analyzer

Pure tool for analyzing location, ambiance, and atmosphere.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.location_ambiance")


class LocationAmbianceAnalyzer:
    """Analyzer for location and ambiance assessment"""

    def analyze_location_ambiance(self, restaurant_data: Dict[str, Any], customer_reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze location and ambiance

        Args:
            restaurant_data: Restaurant information
            customer_data: List of customer reviews

        Returns:
            Dictionary containing location and ambiance analysis
        """
        logger.info(f"Analyzing location and ambiance for {restaurant_data.get('name', 'restaurant')}")

        # Extract location information
        location = restaurant_data.get("location", "Unknown")

        # Analyze ambiance mentions in reviews
        ambiance_keywords = {
            "positive": ["cozy", "beautiful", "elegant", "romantic", "charming", "inviting", "comfortable"],
            "negative": ["noisy", "crowded", "cramped", "dark", "uncomfortable", "outdated"]
        }

        atmosphere_features = []
        positive_count = 0
        negative_count = 0

        for review in customer_reviews:
            text = review.get("text", "").lower()
            for keyword in ambiance_keywords["positive"]:
                if keyword in text:
                    atmosphere_features.append(f"Positive: {keyword}")
                    positive_count += 1
            for keyword in ambiance_keywords["negative"]:
                if keyword in text:
                    atmosphere_features.append(f"Concern: {keyword}")
                    negative_count += 1

        # Calculate ambiance score
        if positive_count + negative_count > 0:
            ambiance_score = (positive_count / (positive_count + negative_count)) * 10
        else:
            ambiance_score = 7.0  # Default

        # Location rating (mock based on mentions)
        location_keywords = ["convenient", "accessible", "central", "easy to find", "remote", "hard to find"]
        location_rating = 7.5  # Default

        for review in customer_reviews:
            text = review.get("text", "").lower()
            if any(keyword in text for keyword in ["convenient", "accessible", "central"]):
                location_rating = min(location_rating + 0.5, 10.0)
            if any(keyword in text for keyword in ["remote", "hard to find"]):
                location_rating = max(location_rating - 0.5, 0)

        # Accessibility features (mock data)
        accessibility = [
            "Wheelchair accessible",
            "Public transportation nearby",
            "Street parking available"
        ]

        # Parking availability (mock)
        parking_availability = "Street and valet parking available"

        recommendations = []
        if ambiance_score < 7.0:
            recommendations.append("Consider interior design improvements")
            recommendations.append("Address noise and comfort concerns")
        if location_rating < 7.0:
            recommendations.append("Improve signage and directions")

        result = {
            "ambiance_score": round(ambiance_score, 2),
            "location_rating": round(location_rating, 2),
            "accessibility": accessibility,
            "atmosphere_features": list(set(atmosphere_features)),
            "parking_availability": parking_availability,
            "recommendations": recommendations
        }

        logger.info(f"Ambiance score: {result['ambiance_score']}/10, Location rating: {location_rating:.2f}")
        return result
