"""
Coordinator Agent

Agent responsible for coordinating and aggregating results from all analysis agents.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent


class CoordinatorAgent(BaseAgent):
    """Agent for coordinating and aggregating analysis results"""

    def __init__(self):
        """Initialize coordinator agent"""
        super().__init__("coordinator")
        self.log("Coordinator agent initialized")

    def analyze(self, food_quality_results: List[Dict[str, Any]],
                hygiene_results: List[Dict[str, Any]],
                sentiment_results: List[Dict[str, Any]],
                pricing_results: List[Dict[str, Any]],
                location_ambiance_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Coordinate and aggregate results from all agents

        Args:
            food_quality_results: Results from food quality agent
            hygiene_results: Results from hygiene agent
            sentiment_results: Results from sentiment agent
            pricing_results: Results from pricing agent
            location_ambiance_results: Results from location ambiance agent

        Returns:
            Coordinated summary of all results
        """
        self.log("Coordinating results from all analysis agents")

        # Extract scores
        food_score = food_quality_results[0].get("food_quality_score", 0) if food_quality_results else 0
        hygiene_score = hygiene_results[0].get("hygiene_score", 0) if hygiene_results else 0
        sentiment_score = (sentiment_results[0].get("overall_sentiment", 0) * 10) if sentiment_results else 0
        pricing_score = pricing_results[0].get("pricing_score", 0) if pricing_results else 0
        ambiance_score = location_ambiance_results[0].get("ambiance_score", 0) if location_ambiance_results else 0

        # Calculate overall score (weighted average)
        overall_score = (
            food_score * 0.30 +
            hygiene_score * 0.25 +
            sentiment_score * 0.20 +
            pricing_score * 0.15 +
            ambiance_score * 0.10
        )

        coordination_summary = {
            "overall_score": round(overall_score, 2),
            "food_quality_score": round(food_score, 2),
            "hygiene_score": round(hygiene_score, 2),
            "sentiment_score": round(sentiment_score, 2),
            "pricing_score": round(pricing_score, 2),
            "ambiance_score": round(ambiance_score, 2),
            "total_agents": 5,
            "analysis_complete": True
        }

        self.log(f"Coordination complete: Overall score {overall_score:.2f}/10")
        return coordination_summary
