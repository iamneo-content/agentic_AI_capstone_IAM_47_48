"""
Hygiene Analysis Agent

Agent responsible for analyzing hygiene and safety standards.
Uses HygieneAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.hygiene_analyzer import HygieneAnalyzer


class HygieneAgent(BaseAgent):
    """Agent for hygiene and safety analysis"""

    def __init__(self):
        """Initialize hygiene agent with analyzer"""
        super().__init__("hygiene")
        self.analyzer = HygieneAnalyzer()
        self.log("Hygiene agent initialized")

    def analyze(self, restaurant_data: Dict[str, Any], customer_reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Perform hygiene and safety analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            restaurant_data: Restaurant information
            customer_reviews: List of customer reviews

        Returns:
            List of hygiene analysis results
        """
        self.log(f"Analyzing hygiene standards for {restaurant_data.get('name', 'restaurant')}")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_hygiene(restaurant_data, customer_reviews)

        results.append({
            "hygiene_score": analysis.get("hygiene_score", 8.0),
            "safety_compliance": analysis.get("safety_compliance", []),
            "cleanliness_indicators": analysis.get("cleanliness_indicators", []),
            "concerns": analysis.get("concerns", []),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("hygiene_score", 0)
        concerns = len(analysis.get("concerns", []))
        self.log(f"Hygiene analysis complete: Score {score}/10, {concerns} concerns found")
        return results
