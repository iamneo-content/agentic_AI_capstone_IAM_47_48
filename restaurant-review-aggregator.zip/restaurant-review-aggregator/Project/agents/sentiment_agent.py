"""
Customer Sentiment Analysis Agent

Agent responsible for analyzing customer sentiment from reviews.
Uses SentimentAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.sentiment_analyzer import SentimentAnalyzer


class SentimentAgent(BaseAgent):
    """Agent for customer sentiment analysis"""

    def __init__(self):
        """Initialize sentiment agent with analyzer"""
        super().__init__("sentiment")
        self.analyzer = SentimentAnalyzer()
        self.log("Sentiment agent initialized")

    def analyze(self, customer_reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Perform customer sentiment analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            customer_reviews: List of customer reviews

        Returns:
            List of sentiment analysis results
        """
        self.log(f"Analyzing customer sentiment from {len(customer_reviews)} reviews")
        results: List[Dict[str, Any]] = []

        if not customer_reviews:
            self.log("No reviews to analyze", "warning")
            return results

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_sentiment(customer_reviews)

        results.append({
            "overall_sentiment": analysis.get("overall_sentiment", 0.0),
            "positive_count": analysis.get("positive_count", 0),
            "negative_count": analysis.get("negative_count", 0),
            "neutral_count": analysis.get("neutral_count", 0),
            "key_themes": analysis.get("key_themes", []),
            "sentiment_trend": analysis.get("sentiment_trend", "stable"),
            "recommendations": analysis.get("recommendations", [])
        })

        sentiment = analysis.get("overall_sentiment", 0)
        self.log(f"Sentiment analysis complete: Overall sentiment {sentiment:.2f}")
        return results
