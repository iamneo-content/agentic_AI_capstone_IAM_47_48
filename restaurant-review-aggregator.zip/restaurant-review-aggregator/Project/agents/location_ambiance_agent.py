"""
Location and Ambiance Analysis Agent

Agent responsible for analyzing location, ambiance, and atmosphere.
Uses LocationAmbianceAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.location_ambiance_analyzer import LocationAmbianceAnalyzer


class LocationAmbianceAgent(BaseAgent):
    """Agent for location and ambiance analysis"""

    def __init__(self):
        """Initialize location ambiance agent with analyzer"""
        super().__init__("location_ambiance")
        self.analyzer = LocationAmbianceAnalyzer()
        self.log("Location and ambiance agent initialized")

    def analyze(self, restaurant_data: Dict[str, Any], customer_reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Perform location and ambiance analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            restaurant_data: Restaurant information
            customer_reviews: List of customer reviews

        Returns:
            List of location and ambiance analysis results
        """
        self.log(f"Analyzing location and ambiance for {restaurant_data.get('name', 'restaurant')}")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_location_ambiance(restaurant_data, customer_reviews)

        results.append({
            "ambiance_score": analysis.get("ambiance_score", 7.0),
            "location_rating": analysis.get("location_rating", 0.0),
            "accessibility": analysis.get("accessibility", []),
            "atmosphere_features": analysis.get("atmosphere_features", []),
            "parking_availability": analysis.get("parking_availability", "Unknown"),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("ambiance_score", 0)
        self.log(f"Location and ambiance analysis complete: Score {score}/10")
        return results
