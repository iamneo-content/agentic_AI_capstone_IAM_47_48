"""
Pricing Analysis Agent

Agent responsible for analyzing pricing and value for money.
Uses PricingAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.pricing_analyzer import PricingAnalyzer


class PricingAgent(BaseAgent):
    """Agent for pricing and value analysis"""

    def __init__(self):
        """Initialize pricing agent with analyzer"""
        super().__init__("pricing")
        self.analyzer = PricingAnalyzer()
        self.log("Pricing agent initialized")

    def analyze(self, menu_data: List[Dict[str, Any]], restaurant_data: Dict[str, Any], customer_reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Perform pricing and value analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            menu_data: List of menu items with prices
            restaurant_data: Restaurant information
            customer_reviews: List of customer reviews

        Returns:
            List of pricing analysis results
        """
        self.log(f"Analyzing pricing for {len(menu_data)} menu items")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_pricing(menu_data, restaurant_data, customer_reviews)

        results.append({
            "pricing_score": analysis.get("pricing_score", 7.0),
            "average_price": analysis.get("average_price", 0.0),
            "price_range": analysis.get("price_range", ""),
            "value_rating": analysis.get("value_rating", 0.0),
            "price_categories": analysis.get("price_categories", {}),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("pricing_score", 0)
        avg_price = analysis.get("average_price", 0)
        self.log(f"Pricing analysis complete: Score {score}/10, Average price ${avg_price:.2f}")
        return results
