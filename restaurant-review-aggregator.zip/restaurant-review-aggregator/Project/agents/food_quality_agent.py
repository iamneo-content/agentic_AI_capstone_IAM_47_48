"""
Food Quality Analysis Agent

Agent responsible for analyzing food quality from menu and reviews.
Uses FoodQualityAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.food_quality_analyzer import FoodQualityAnalyzer


class FoodQualityAgent(BaseAgent):
    """Agent for food quality analysis"""

    def __init__(self):
        """Initialize food quality agent with analyzer"""
        super().__init__("food_quality")
        self.analyzer = FoodQualityAnalyzer()
        self.log("Food quality agent initialized")

    def analyze(self, menu_data: List[Dict[str, Any]], customer_reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Perform food quality analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            menu_data: List of menu items with details
            customer_reviews: List of customer reviews

        Returns:
            List of food quality analysis results
        """
        self.log(f"Analyzing food quality with {len(menu_data)} menu items and {len(customer_reviews)} reviews")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_food_quality(menu_data, customer_reviews)

        results.append({
            "food_quality_score": analysis.get("food_quality_score", 7.0),
            "menu_variety": analysis.get("menu_variety", 0),
            "popular_items": analysis.get("popular_items", []),
            "quality_indicators": analysis.get("quality_indicators", []),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("food_quality_score", 0)
        self.log(f"Food quality analysis complete: Score {score}/10")
        return results
