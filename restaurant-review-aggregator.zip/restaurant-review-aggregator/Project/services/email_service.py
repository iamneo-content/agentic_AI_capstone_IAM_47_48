"""
Email Notification Service

Sends email notifications for restaurant review events.
"""

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
from config import get_config_value

logger = logging.getLogger("service.email")


class EmailService:
    """Service for sending email notifications"""

    def __init__(self):
        """Initialize email service"""
        self.smtp_server = get_config_value("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = get_config_value("SMTP_PORT", 587)
        self.email_from = get_config_value("EMAIL_FROM", "")
        self.email_password = get_config_value("EMAIL_PASSWORD", "")
        self.email_to = get_config_value("EMAIL_TO", "")

    def send_email(self, subject: str, body: str, html: bool = False) -> bool:
        """
        Send an email

        Args:
            subject: Email subject
            body: Email body
            html: Whether body is HTML (default: False)

        Returns:
            True if sent successfully, False otherwise
        """
        if not all([self.email_from, self.email_password, self.email_to]):
            logger.warning("Email configuration incomplete, skipping email")
            return False

        try:
            # Create message
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = self.email_from
            msg["To"] = self.email_to

            # Add body
            if html:
                msg.attach(MIMEText(body, "html"))
            else:
                msg.attach(MIMEText(body, "plain"))

            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.email_from, self.email_password)
                server.send_message(msg)

            logger.info(f"Email sent successfully: {subject}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False

    def send_review_start_email(self, review_id: str, restaurant_name: str, location: str) -> bool:
        """
        Send notification that review has started

        Args:
            review_id: Review ID
            restaurant_name: Restaurant name
            location: Restaurant location

        Returns:
            True if sent successfully
        """
        subject = f"Restaurant Review Started - {restaurant_name}"

        body = f"""
Restaurant Review Analysis Started

Review ID: {review_id}
Restaurant: {restaurant_name}
Location: {location}

Analysis is now in progress. You will receive a final report once complete.

This is an automated message from the Restaurant Review Aggregator system.
        """

        return self.send_email(subject, body.strip())

    def send_final_report_email(self, state) -> bool:
        """
        Send final review report

        Args:
            state: RestaurantReviewState with complete analysis

        Returns:
            True if sent successfully
        """
        subject = f"Restaurant Review Complete - {state.restaurant_name}"

        # Build email body
        body = f"""
RESTAURANT REVIEW ANALYSIS COMPLETE
{'='*60}

Review ID: {state.review_id}
Restaurant: {state.restaurant_name}
Location: {state.location}
Timestamp: {state.timestamp}

OVERALL RATING: {state.overall_rating:.2f}/10.0
RECOMMENDATION: {state.recommendation_level}
DECISION: {state.decision}

{'='*60}
QUALITY METRICS
{'='*60}

Food Quality Score:     {state.decision_metrics.get('food_quality_score', 0):.2f}/10.0
Hygiene Score:          {state.decision_metrics.get('hygiene_score', 0):.2f}/10.0
Customer Sentiment:     {state.decision_metrics.get('sentiment_score', 0):.2f}/10.0
Pricing Score:          {state.decision_metrics.get('pricing_score', 0):.2f}/10.0
Ambiance Score:         {state.decision_metrics.get('ambiance_score', 0):.2f}/10.0

{'='*60}
KEY FINDINGS
{'='*60}

"""
        if state.report and state.report.get('key_findings'):
            for finding in state.report['key_findings']:
                body += f"  - {finding}\n"

        if state.has_critical_issues:
            body += f"\n[!] CRITICAL ISSUE: {state.critical_reason}\n"

        body += f"\n{'='*60}\n"
        body += "IMPROVEMENT SUGGESTIONS\n"
        body += f"{'='*60}\n\n"

        if state.improvement_suggestions:
            for suggestion in state.improvement_suggestions[:5]:
                body += f"  - {suggestion}\n"

        body += "\n" + "="*60 + "\n"
        body += "This is an automated message from the Restaurant Review Aggregator system.\n"

        return self.send_email(subject, body.strip())
