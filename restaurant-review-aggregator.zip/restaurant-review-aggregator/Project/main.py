"""
Restaurant Review Aggregator - Client Format
Main application entry point
"""

import sys
import argparse
from datetime import datetime
import uuid

from config import validate_config, get_config_value
from state import RestaurantReviewState
from workflows.review_workflow import build_review_workflow
from utils.logging_utils import setup_logging


def main():
    """Main application entry point"""
    # Setup logging
    log_file = get_config_value("LOG_FILE", "logs/restaurant_review.log")
    log_level = get_config_value("LOG_LEVEL", "INFO")
    setup_logging(log_level, log_file)

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Restaurant Review Aggregator - Multi-Agent Analysis System"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Review restaurant command
    review_parser = subparsers.add_parser("review", help="Review a restaurant")
    review_parser.add_argument("restaurant_name", help="Restaurant name")
    review_parser.add_argument("location", help="Restaurant location")
    review_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run demo with sample restaurant")
    demo_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    args = parser.parse_args()

    try:
        # Validate configuration
        validate_config()

        # Handle commands
        if args.command == "review":
            review_restaurant(args.restaurant_name, args.location, args.max_workers)
        elif args.command == "demo":
            run_demo(args.max_workers)
        else:
            # Interactive mode
            interactive_mode()

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


def review_restaurant(restaurant_name: str, location: str, max_workers: int = 5):
    """
    Review a restaurant

    Args:
        restaurant_name: Name of the restaurant
        location: Location of the restaurant
        max_workers: Maximum parallel workers
    """
    print(f"\n{'='*70}")
    print(f"RESTAURANT REVIEW AGGREGATOR - CLIENT FORMAT")
    print(f"{'='*70}")
    print(f"Restaurant: {restaurant_name}")
    print(f"Location: {location}")
    print(f"Max Workers: {max_workers}")
    print(f"{'='*70}\n")

    # Create initial state
    review_id = f"REV-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
    restaurant_id = f"REST-{str(uuid.uuid4())[:8].upper()}"

    initial_state = RestaurantReviewState(
        review_id=review_id,
        restaurant_name=restaurant_name,
        restaurant_id=restaurant_id,
        location=location,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )

    print(f"Review ID: {review_id}")
    print(f"Starting workflow execution...\n")

    # Build and execute workflow
    workflow = build_review_workflow(max_workers=max_workers)
    final_state = workflow.run(initial_state)

    # Display results
    display_results(final_state)


def display_results(state: RestaurantReviewState):
    """Display workflow results"""
    print(f"\n{'='*70}")
    print("REVIEW COMPLETE")
    print(f"{'='*70}")
    print(f"Review ID: {state.review_id}")
    print(f"Restaurant: {state.restaurant_name}")
    print(f"Overall Rating: {state.overall_rating:.2f}/10.0")
    print(f"Recommendation: {state.recommendation_level}")
    print(f"Decision: {state.decision.upper()}")

    if state.has_critical_issues:
        print(f"\n[!] WARNING: {state.critical_reason}")
    else:
        print(f"\n[OK] SUCCESS: No critical issues found")

    # Display metrics
    if state.decision_metrics:
        print(f"\n{'='*70}")
        print("QUALITY METRICS")
        print(f"{'='*70}")
        metrics = state.decision_metrics
        print(f"Food Quality Score:       {metrics.get('food_quality_score', 0):.2f}/10.0")
        print(f"Hygiene Score:            {metrics.get('hygiene_score', 0):.2f}/10.0")
        print(f"Customer Sentiment:       {metrics.get('sentiment_score', 0):.2f}/10.0")
        print(f"Pricing Score:            {metrics.get('pricing_score', 0):.2f}/10.0")
        print(f"Ambiance Score:           {metrics.get('ambiance_score', 0):.2f}/10.0")

    # Display report summary
    if state.report:
        print(f"\n{'='*70}")
        print("REPORT SUMMARY")
        print(f"{'='*70}")
        report = state.report

        print(f"Priority: {report.get('priority', 'MEDIUM')}")

        key_findings = report.get('key_findings', [])
        if key_findings:
            print(f"\nKey Findings:")
            for finding in key_findings:
                print(f"  - {finding}")

        action_items = report.get('action_items', [])
        if action_items:
            print(f"\nAction Items:")
            for action in action_items:
                print(f"  - {action}")

        improvement_suggestions = state.improvement_suggestions
        if improvement_suggestions:
            print(f"\nImprovement Suggestions:")
            for suggestion in improvement_suggestions[:5]:  # Show top 5
                print(f"  - {suggestion}")

    print(f"\n{'='*70}")
    print("Email notification sent to configured recipient")
    print(f"{'='*70}\n")


def run_demo(max_workers: int = 5):
    """Run demo with sample restaurant"""
    print("\n" + "="*70)
    print("DEMO MODE - Restaurant Review Aggregator")
    print("="*70)
    print("This will analyze a sample restaurant with mock data.")
    print("\nExample: Bella Italia, New York, NY")

    # Demo restaurant
    restaurant_name = "Bella Italia"
    location = "New York, NY"

    print(f"\nAnalyzing: {restaurant_name} in {location}\n")

    review_restaurant(restaurant_name, location, max_workers)


def interactive_mode():
    """Interactive mode for restaurant review"""
    print("\n" + "="*70)
    print("Restaurant Review Aggregator - Multi-Agent Analysis System")
    print("="*70)
    print("\n1. Review Restaurant")
    print("2. Run Demo")
    print("0. Exit")

    choice = input("\nSelect option (0-2): ").strip()

    if choice == "0":
        print("Goodbye!")
        return

    elif choice == "1":
        restaurant_name = input("Enter restaurant name: ").strip()
        location = input("Enter location: ").strip()
        max_workers_str = input("Enter max workers (default 5): ").strip()

        try:
            max_workers = int(max_workers_str) if max_workers_str else 5
            review_restaurant(restaurant_name, location, max_workers)
        except ValueError:
            print("ERROR: Invalid input")

    elif choice == "2":
        max_workers_str = input("Enter max workers (default 5): ").strip()
        max_workers = int(max_workers_str) if max_workers_str else 5
        run_demo(max_workers)

    else:
        print("ERROR: Invalid choice")


if __name__ == "__main__":
    main()
