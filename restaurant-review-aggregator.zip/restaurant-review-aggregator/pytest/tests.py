#!/usr/bin/env python3
"""
Comprehensive Test Suite for Restaurant Review Aggregator

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import RestaurantReviewState
    from graph import RestaurantReviewGraph
    from workflows.review_workflow import build_review_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.data_collector_agent import DataCollectorAgent
    from agents.sentiment_agent import SentimentAgent
    from agents.food_quality_agent import FoodQualityAgent
    from agents.pricing_agent import PricingAgent
    from agents.hygiene_agent import HygieneAgent
    from agents.location_ambiance_agent import LocationAmbianceAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.sentiment_analyzer import SentimentAnalyzer
    from analyzers.food_quality_analyzer import FoodQualityAnalyzer
    from analyzers.pricing_analyzer import PricingAnalyzer
    from analyzers.hygiene_analyzer import HygieneAnalyzer
    from analyzers.location_ambiance_analyzer import LocationAmbianceAnalyzer

    # Import nodes
    from nodes.data_collector_node import data_collector_node
    from nodes.sentiment_node import sentiment_node
    from nodes.food_quality_node import food_quality_node
    from nodes.pricing_node import pricing_node
    from nodes.hygiene_node import hygiene_node
    from nodes.location_ambiance_node import location_ambiance_node
    from nodes.decision_node import decision_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestRestaurantReviewAggregatorArchitecture(unittest.TestCase):
    """Test suite for Restaurant Review Aggregator Architecture"""

    SAMPLE_RESTAURANT = {
        "restaurant_id": "TEST-123",
        "name": "The Great Bistro",
        "location": "San Francisco, CA",
        "cuisine": "French",
        "price_range": "$$",
        "reviews": [
            {
                "rating": 5,
                "text": "Excellent food and great service!",
                "date": "2024-01-15"
            },
            {
                "rating": 4,
                "text": "Good food but a bit pricey.",
                "date": "2024-01-10"
            },
            {
                "rating": 3,
                "text": "Average experience, nothing special.",
                "date": "2024-01-05"
            }
        ]
    }

    def setUp(self):
        """Setup test environment"""
        self.sample_restaurant = self.SAMPLE_RESTAURANT.copy()

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test RestaurantReviewState dataclass creation"""
        logger.info("Testing RestaurantReviewState creation...")

        state = RestaurantReviewState(
            restaurant_id="TEST-123",
            restaurant_data=self.sample_restaurant
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.restaurant_id, "TEST-123", "Restaurant ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test RestaurantReviewState clone method"""
        logger.info("Testing RestaurantReviewState clone...")

        state = RestaurantReviewState(restaurant_id="TEST-123", restaurant_data=self.sample_restaurant)
        state.sentiment_results = [{"test": "data"}]

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.restaurant_id, state.restaurant_id, "Restaurant ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_sentiment_analyzer(self):
        """Test SentimentAnalyzer (pure tool)"""
        logger.info("Testing SentimentAnalyzer...")

        analyzer = SentimentAnalyzer()
        results = analyzer.analyze_sentiment(self.sample_restaurant["reviews"])

        self.assertIsNotNone(results, "Sentiment analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ SentimentAnalyzer tests passed")

    def test_food_quality_analyzer(self):
        """Test FoodQualityAnalyzer (pure tool)"""
        logger.info("Testing FoodQualityAnalyzer...")

        analyzer = FoodQualityAnalyzer()
        menu_data = [
            {"item": "Pizza", "price": 15.99, "category": "Main"},
            {"item": "Salad", "price": 8.99, "category": "Appetizer"}
        ]
        results = analyzer.analyze_food_quality(menu_data, self.sample_restaurant["reviews"])

        self.assertIsNotNone(results, "Food quality analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ FoodQualityAnalyzer tests passed")

    def test_pricing_analyzer(self):
        """Test PricingAnalyzer (pure tool)"""
        logger.info("Testing PricingAnalyzer...")

        analyzer = PricingAnalyzer()
        menu_data = [
            {"item": "Pizza", "price": 15.99, "category": "Main"},
            {"item": "Salad", "price": 8.99, "category": "Appetizer"}
        ]
        results = analyzer.analyze_pricing(menu_data, self.sample_restaurant, self.sample_restaurant["reviews"])

        self.assertIsNotNone(results, "Pricing analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ PricingAnalyzer tests passed")

    def test_hygiene_analyzer(self):
        """Test HygieneAnalyzer (pure tool)"""
        logger.info("Testing HygieneAnalyzer...")

        analyzer = HygieneAnalyzer()
        results = analyzer.analyze_hygiene(self.sample_restaurant, self.sample_restaurant["reviews"])

        self.assertIsNotNone(results, "Hygiene analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ HygieneAnalyzer tests passed")

    def test_location_ambiance_analyzer(self):
        """Test LocationAmbianceAnalyzer (pure tool)"""
        logger.info("Testing LocationAmbianceAnalyzer...")

        analyzer = LocationAmbianceAnalyzer()
        results = analyzer.analyze_location_ambiance(self.sample_restaurant, self.sample_restaurant["reviews"])

        self.assertIsNotNone(results, "Location ambiance analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ LocationAmbianceAnalyzer tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_sentiment_agent(self):
        """Test SentimentAgent (coordinator)"""
        logger.info("Testing SentimentAgent...")

        agent = SentimentAgent()
        results = agent.analyze(self.sample_restaurant["reviews"])

        self.assertIsNotNone(results, "Sentiment agent results should not be None")
        self.assertIsInstance(results, list, "Results should be a list")

        logger.info("✓ SentimentAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_data_collector_node(self):
        """Test data_collector_node (thin wrapper)"""
        logger.info("Testing data_collector_node...")

        state = RestaurantReviewState(
            restaurant_id="TEST-RESTAURANT",
            restaurant_data=self.sample_restaurant
        )

        result = data_collector_node(state)

        self.assertIsNotNone(result, "Data collector node result should not be None")
        self.assertIsInstance(result, RestaurantReviewState, "Result should be RestaurantReviewState")

        logger.info("✓ data_collector_node tests passed")

    def test_sentiment_node(self):
        """Test sentiment_node (thin wrapper)"""
        logger.info("Testing sentiment_node...")

        state = RestaurantReviewState(
            restaurant_id="TEST-RESTAURANT",
            restaurant_data=self.sample_restaurant
        )

        result = sentiment_node(state)

        self.assertIsNotNone(result, "Sentiment node result should not be None")
        self.assertIsInstance(result, RestaurantReviewState, "Result should be RestaurantReviewState")

        logger.info("✓ sentiment_node tests passed")

    def test_decision_node(self):
        """Test decision_node logic"""
        logger.info("Testing decision_node...")

        state = RestaurantReviewState(
            restaurant_id="TEST-RESTAURANT",
            sentiment_results=[{"sentiment_score": 8.5}],
            food_quality_results=[{"food_score": 8.0}],
            pricing_results=[{"value_score": 7.5}],
            hygiene_results=[{"hygiene_score": 9.0}],
            location_ambiance_results=[{"ambiance_score": 8.0}]
        )

        result = decision_node(state)

        self.assertIsNotNone(result, "Decision result should not be None")
        self.assertIsInstance(result, RestaurantReviewState, "Result should be RestaurantReviewState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ decision_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_restaurant_graph_creation(self):
        """Test RestaurantReviewGraph class creation"""
        logger.info("Testing RestaurantReviewGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = RestaurantReviewGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ RestaurantReviewGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_review_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, RestaurantReviewGraph, "Workflow should be RestaurantReviewGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        sentiment_agent = SentimentAgent()
        self.assertIsNotNone(sentiment_agent.analyzer, "SentimentAgent should have an analyzer")
        self.assertIsInstance(sentiment_agent.analyzer, SentimentAnalyzer, "Should use SentimentAnalyzer")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = RestaurantReviewState(
            restaurant_id="TEST-RESTAURANT",
            restaurant_data=self.sample_restaurant
        )

        result = sentiment_node(state)
        self.assertIsInstance(result, RestaurantReviewState, "Node should return RestaurantReviewState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Restaurant Review Aggregator - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
