RESTAURANT REVIEW AGGREGATOR - MULTI-AGENT ANALYSIS SYSTEM

================================================================================
PROBLEM STATEMENT
================================================================================

The Restaurant Review Aggregator is an intelligent multi-agent system designed
to perform comprehensive analysis of restaurants using parallel processing and
automated decision-making. The system addresses the challenge of aggregating
and analyzing restaurant data from multiple sources to provide actionable
insights and recommendations.

The core problem this system solves is the need for automated, multi-dimensional
restaurant evaluation that considers:
- Food quality assessment based on menu variety and customer feedback
- Hygiene standards evaluation
- Customer sentiment analysis from reviews
- Pricing competitiveness analysis
- Location and ambiance quality assessment

The system employs a staged workflow architecture with parallel execution
capabilities, allowing multiple analysis agents to work simultaneously for
improved performance. It generates comprehensive reports with automated
decisions and sends email notifications to stakeholders.

================================================================================
FILE STRUCTURE
================================================================================

restaurant-review-aggregator/
    Project/
        agents/
            base_agent.py
            coordinator_agent.py
            data_collector_agent.py
            food_quality_agent.py
            hygiene_agent.py
            location_ambiance_agent.py
            pricing_agent.py
            sentiment_agent.py
            __init__.py

        analyzers/
            food_quality_analyzer.py
            gemini_client.py
            hygiene_analyzer.py
            location_ambiance_analyzer.py
            pricing_analyzer.py
            sentiment_analyzer.py
            __init__.py

        nodes/
            coordinator_node.py
            data_collector_node.py
            decision_node.py
            food_quality_node.py
            hygiene_node.py
            location_ambiance_node.py
            pricing_node.py
            report_node.py
            sentiment_node.py
            __init__.py

        services/
            email_service.py
            __init__.py

        utils/
            logging_utils.py
            __init__.py

        workflows/
            review_workflow.py
            __init__.py

        config.py
        graph.py
        main.py
        state.py
        requirements.txt
        .env.example

================================================================================
PURPOSE OF FILES AND IMPORTANT METHODS
================================================================================

--------------------------------------------------------------------------------
CORE ENTRY POINT
--------------------------------------------------------------------------------

main.py
    Purpose: Main application entry point that handles user interaction and
             workflow execution

    Important Methods:

    - main()
        Parameters: None
        Description: Entry point that sets up logging, parses arguments,
                    validates config and handles commands

    - review_restaurant(restaurant_name: str, location: str, max_workers: int)
        Parameters:
            restaurant_name: Name of the restaurant to review
            location: Location of the restaurant
            max_workers: Maximum parallel workers for execution
        Description: Reviews a specific restaurant by creating initial state,
                    building workflow and executing it

    - display_results(state: RestaurantReviewState)
        Parameters:
            state: Final state containing review results
        Description: Displays comprehensive review results including ratings,
                    metrics, and recommendations

    - run_demo(max_workers: int)
        Parameters:
            max_workers: Maximum parallel workers
        Description: Runs demo analysis with sample restaurant data

    - interactive_mode()
        Parameters: None
        Description: Provides interactive CLI for user input

--------------------------------------------------------------------------------
CONFIGURATION MANAGEMENT
--------------------------------------------------------------------------------

config.py
    Purpose: Manages configuration from environment variables and .env files

    Important Class: ConfigManager

    Methods:

    - __init__()
        Parameters: None
        Description: Initializes singleton config manager and loads config

    - _load_config()
        Parameters: None
        Description: Loads configuration from environment variables and defaults

    - get(key: str, default: Any)
        Parameters:
            key: Configuration key to retrieve
            default: Default value if key not found
        Description: Retrieves configuration value

    - validate()
        Parameters: None
        Description: Validates required configuration keys are present

    Helper Functions:

    - get_config_value(key: str, default: Any)
        Parameters:
            key: Configuration key
            default: Default value
        Description: Convenience function to get config value

--------------------------------------------------------------------------------
STATE MANAGEMENT
--------------------------------------------------------------------------------

state.py
    Purpose: Defines shared state dataclass for restaurant review pipeline

    Important Class: RestaurantReviewState

    Attributes:
        - review_id: Unique review identifier
        - restaurant_name: Name of restaurant
        - restaurant_id: Unique restaurant identifier
        - location: Restaurant location
        - restaurant_data: Collected restaurant information
        - menu_data: Menu items list
        - customer_reviews: Customer review list
        - food_quality_results: Food quality analysis results
        - hygiene_results: Hygiene analysis results
        - sentiment_results: Sentiment analysis results
        - pricing_results: Pricing analysis results
        - location_ambiance_results: Location and ambiance results
        - coordination_summary: Aggregated results from coordinator
        - decision: Final automated decision
        - overall_rating: Overall rating score
        - recommendation_level: Recommendation level
        - report: Final report dictionary
        - improvement_suggestions: List of improvement suggestions

    Methods:

    - clone()
        Parameters: None
        Description: Creates deep copy of state for parallel execution

    - to_dict()
        Parameters: None
        Description: Converts state to dictionary representation

    - merge_from(other: Any, overwrite_scalars: bool)
        Parameters:
            other: Another state or dict to merge from
            overwrite_scalars: Whether to overwrite scalar values
        Description: Merges another state into current state, extending lists
                    and updating dictionaries

--------------------------------------------------------------------------------
WORKFLOW ORCHESTRATION
--------------------------------------------------------------------------------

graph.py
    Purpose: Custom graph implementation for executing multi-stage workflows
             with parallel node support

    Important Class: RestaurantReviewGraph

    Methods:

    - __init__(stages: List[List[NodeFunc]], max_workers: int,
               raise_on_error: bool)
        Parameters:
            stages: List of stages, each containing list of node functions
            max_workers: Maximum parallel workers
            raise_on_error: Whether to raise exceptions on errors
        Description: Initializes graph with stages and execution parameters

    - run(initial_state: RestaurantReviewState)
        Parameters:
            initial_state: Initial state to start workflow
        Description: Executes workflow graph stage by stage, running parallel
                    nodes with ThreadPoolExecutor and merging results

    - _safe_run(node: NodeFunc, state_snapshot: RestaurantReviewState)
        Parameters:
            node: Node function to execute
            state_snapshot: Cloned state for this node
        Description: Executes node safely with error handling

workflows/review_workflow.py
    Purpose: Defines staged restaurant review pipeline structure

    Important Function:

    - build_review_workflow(max_workers: int)
        Parameters:
            max_workers: Maximum parallel workers
        Description: Builds 5-stage workflow:
                    Stage 1: Data collection
                    Stage 2: Parallel analyses (5 agents)
                    Stage 3: Coordinator
                    Stage 4: Decision
                    Stage 5: Report generation

--------------------------------------------------------------------------------
AGENT LAYER
--------------------------------------------------------------------------------

agents/base_agent.py
    Purpose: Abstract base class for all agents providing common functionality

    Important Class: BaseAgent

    Methods:

    - __init__(name: str)
        Parameters:
            name: Agent name for identification
        Description: Initializes agent with name and logger

    - log(message: str, level: str)
        Parameters:
            message: Log message
            level: Log level (info, warning, error, debug)
        Description: Logs message with agent name prefix

    - analyze(*args, **kwargs)
        Parameters: Varies by subclass
        Description: Abstract method to be implemented by subclasses

agents/data_collector_agent.py
    Purpose: Collects restaurant data from multiple sources

    Important Class: DataCollectorAgent

    Methods:

    - analyze(restaurant_name: str, location: str)
        Parameters:
            restaurant_name: Restaurant name
            location: Restaurant location
        Description: Collects restaurant data, menu items, and customer reviews

agents/coordinator_agent.py
    Purpose: Coordinates and aggregates results from all analysis agents

    Important Class: CoordinatorAgent

    Methods:

    - analyze(food_quality_results: List[Dict], hygiene_results: List[Dict],
              sentiment_results: List[Dict], pricing_results: List[Dict],
              location_ambiance_results: List[Dict])
        Parameters:
            food_quality_results: Food quality analysis results
            hygiene_results: Hygiene analysis results
            sentiment_results: Sentiment analysis results
            pricing_results: Pricing analysis results
            location_ambiance_results: Location ambiance results
        Description: Calculates weighted overall score from all agent results
                    (weights: food 30%, hygiene 25%, sentiment 20%,
                     pricing 15%, ambiance 10%)

--------------------------------------------------------------------------------
ANALYZER LAYER
--------------------------------------------------------------------------------

analyzers/food_quality_analyzer.py
    Purpose: Pure analysis tool for food quality assessment

    Important Class: FoodQualityAnalyzer

    Methods:

    - analyze_food_quality(menu_data: List[Dict], customer_reviews: List[Dict])
        Parameters:
            menu_data: List of menu items
            customer_reviews: List of customer reviews
        Description: Analyzes food quality based on menu variety and review
                    keywords, calculates quality score from average rating
                    and menu variety

analyzers/gemini_client.py
    Purpose: Client for Google Gemini AI API for advanced analysis

    Important Class: GeminiClient

    Methods:

    - __init__(api_key: Optional[str])
        Parameters:
            api_key: Gemini API key
        Description: Initializes Gemini AI client

    - analyze_with_ai(prompt: str, context: Dict)
        Parameters:
            prompt: Analysis prompt
            context: Context data for analysis
        Description: Performs AI analysis using Gemini API

    - generate_review_summary(reviews: list)
        Parameters:
            reviews: List of customer reviews
        Description: Generates AI-powered review summary

--------------------------------------------------------------------------------
NODE LAYER
--------------------------------------------------------------------------------

nodes/data_collector_node.py
    Purpose: Wrapper node for data collection agent

    Important Function:

    - data_collector_node(state: RestaurantReviewState)
        Parameters:
            state: Current state
        Description: Calls DataCollectorAgent and updates state with collected
                    restaurant data, menu, and reviews

nodes/decision_node.py
    Purpose: Makes automated decision based on analysis results

    Important Function:

    - decision_node(state: RestaurantReviewState)
        Parameters:
            state: Current state with coordination summary
        Description: Makes automated decision by comparing scores against
                    thresholds, determines recommendation level, checks for
                    critical issues, and stores decision metrics

nodes/report_node.py
    Purpose: Generates final report and sends notifications

    Important Function:

    - report_node(state: RestaurantReviewState)
        Parameters:
            state: Final state with all analysis results
        Description: Generates comprehensive report with priority level, key
                    findings, action items, and sends email notification

--------------------------------------------------------------------------------
SERVICES
--------------------------------------------------------------------------------

services/email_service.py
    Purpose: Handles email notification sending via SMTP

    Important Class: EmailService

    Methods:

    - __init__(smtp_server: str, smtp_port: int, email_from: str,
               email_password: str)
        Parameters:
            smtp_server: SMTP server address
            smtp_port: SMTP port number
            email_from: Sender email address
            email_password: Sender email password
        Description: Initializes email service with SMTP configuration

    - send_notification(email_to: str, subject: str, body: str,
                       html_body: Optional[str])
        Parameters:
            email_to: Recipient email address
            subject: Email subject
            body: Plain text email body
            html_body: HTML formatted email body
        Description: Sends email notification via SMTP

--------------------------------------------------------------------------------
UTILITIES
--------------------------------------------------------------------------------

utils/logging_utils.py
    Purpose: Provides logging configuration and setup

    Important Function:

    - setup_logging(log_level: str, log_file: str)
        Parameters:
            log_level: Logging level (INFO, DEBUG, WARNING, ERROR)
            log_file: Path to log file
        Description: Configures logging with file and console handlers

================================================================================
RUNNING COMMANDS
================================================================================

Installation:
-------------

Step 1: Install Python dependencies

    pip install -r Project/requirements.txt


Step 2: Configure environment variables

    Copy .env.example to .env and update with your credentials:
    - GEMINI_API_KEY: Your Google Gemini API key
    - EMAIL_FROM: Sender email address
    - EMAIL_PASSWORD: Sender email password
    - EMAIL_TO: Recipient email address


Execution Commands:
------------------

Command 1: Interactive Mode

    python3 main.py

    This launches interactive menu where you can select:
    1. Review Restaurant - Enter restaurant name and location
    2. Run Demo - Analyze sample restaurant
    0. Exit


Command 2: Review Specific Restaurant

    python3 main.py review "Restaurant Name" "Location"

    Example:
    python3 main.py review "Bella Italia" "New York, NY"

    Optional parameter:
    --max-workers N   Set maximum parallel workers (default: 5)

    Example with max workers:
    python3 main.py review "Bella Italia" "New York, NY" --max-workers 10


Command 3: Run Demo Mode

    python3 main.py demo

    This runs analysis on sample restaurant "Bella Italia" in "New York, NY"

    Optional parameter:
    --max-workers N   Set maximum parallel workers (default: 5)


Command 4: Run with Custom Configuration

    LOG_LEVEL=DEBUG python3 main.py demo

    Environment variables can be set inline to override configuration


Testing:
--------

Command 5: Run Tests (if pytest configured)

    python3 -m pytest tests.py -v

================================================================================
EXPECTED OUTPUT
================================================================================

When executing the restaurant review workflow, the system produces the
following output:

--------------------------------------------------------------------------------
Stage 1: Initialization and Data Collection
--------------------------------------------------------------------------------

Output Display:

======================================================================
RESTAURANT REVIEW AGGREGATOR - CLIENT FORMAT
======================================================================
Restaurant: Bella Italia
Location: New York, NY
Max Workers: 5
======================================================================

Review ID: REV-20251202-A1B2C3D4
Starting workflow execution...

======================================================================
STARTING RESTAURANT REVIEW WORKFLOW
======================================================================
Executing Stage 1 with 1 node(s)
  Executing single node: data_collector_node
  [Data Collector Agent] Collecting data for Bella Italia in New York, NY
  [Data Collector Agent] Collected 5 reviews and 3 menu items
  [OK] data_collector_node completed

--------------------------------------------------------------------------------
Stage 2: Parallel Analysis Execution
--------------------------------------------------------------------------------

Executing Stage 2 with 5 node(s)
  Executing 5 nodes in parallel...
  [Food Quality Agent] Analyzing food quality
  [Hygiene Agent] Analyzing hygiene standards
  [Sentiment Agent] Analyzing customer sentiment
  [Pricing Agent] Analyzing pricing competitiveness
  [Location Ambiance Agent] Analyzing location and ambiance
  [OK] food_quality_node completed
  [OK] hygiene_node completed
  [OK] sentiment_node completed
  [OK] pricing_node completed
  [OK] location_ambiance_node completed
  Merging 5 parallel results...
Stage 2 complete

--------------------------------------------------------------------------------
Stage 3: Coordination
--------------------------------------------------------------------------------

Executing Stage 3 with 1 node(s)
  Executing single node: coordinator_node
  [Coordinator Agent] Coordinating results from all analysis agents
  [Coordinator Agent] Coordination complete: Overall score 8.35/10
  [OK] coordinator_node completed

--------------------------------------------------------------------------------
Stage 4: Decision Making
--------------------------------------------------------------------------------

Executing Stage 4 with 1 node(s)
  Executing single node: decision_node
  [Decision Node] Making automated decision
  [Decision Node] Decision: EXCELLENT, Rating: 8.35/10
  [OK] decision_node completed

--------------------------------------------------------------------------------
Stage 5: Report Generation and Notification
--------------------------------------------------------------------------------

Executing Stage 5 with 1 node(s)
  Executing single node: report_node
  [Report Node] Generating final report
  [Email Service] Sending notification to pranavram246@gmail.com
  [Email Service] Email sent successfully
  [OK] report_node completed

======================================================================
RESTAURANT REVIEW WORKFLOW COMPLETE
======================================================================

--------------------------------------------------------------------------------
Final Results Display
--------------------------------------------------------------------------------

======================================================================
REVIEW COMPLETE
======================================================================
Review ID: REV-20251202-A1B2C3D4
Restaurant: Bella Italia
Overall Rating: 8.35/10.0
Recommendation: RECOMMENDED
Decision: EXCELLENT

[OK] SUCCESS: No critical issues found

======================================================================
QUALITY METRICS
======================================================================
Food Quality Score:       8.50/10.0
Hygiene Score:            8.20/10.0
Customer Sentiment:       8.60/10.0
Pricing Score:            7.80/10.0
Ambiance Score:           8.10/10.0

======================================================================
REPORT SUMMARY
======================================================================
Priority: MEDIUM

Key Findings:
  - Strong food quality with consistent positive reviews
  - Hygiene standards meet requirements
  - High customer satisfaction and positive sentiment
  - Competitive pricing for location and quality
  - Pleasant ambiance with good location

Action Items:
  - Maintain current food quality standards
  - Continue monitoring hygiene practices
  - Consider menu expansion for variety
  - Monitor pricing competitiveness in market

Improvement Suggestions:
  - Add seasonal menu items to increase variety
  - Enhance social media presence for better visibility
  - Consider loyalty program for repeat customers
  - Optimize table turnover during peak hours
  - Improve online reservation system

======================================================================
Email notification sent to configured recipient
======================================================================

--------------------------------------------------------------------------------
Error Handling Output Example
--------------------------------------------------------------------------------

If critical issues are detected, output would show:

Decision: NEEDS_IMPROVEMENT

[!] WARNING: Hygiene score (6.5) below threshold (8.0)

Action Items would include specific remediation steps
