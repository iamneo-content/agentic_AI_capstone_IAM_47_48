AGENT COMMUNICATION DIAGRAM
Restaurant Review Aggregator - Multi-Agent System

================================================================================

```mermaid
graph TB
    subgraph Stage1[Stage 1: Data Collection]
        START([User Input:<br/>Restaurant Name + Location])
        DC[Data Collector Agent<br/>Collects restaurant data,<br/>menu items, reviews]
    end

    subgraph Stage2[Stage 2: Parallel Analysis]
        FQ[Food Quality Agent<br/>Analyzes menu variety<br/>and food ratings]
        HY[Hygiene Agent<br/>Evaluates cleanliness<br/>standards]
        SE[Sentiment Agent<br/>Processes customer<br/>emotions]
        PR[Pricing Agent<br/>Assesses value and<br/>competitiveness]
        LA[Location Ambiance Agent<br/>Reviews location<br/>and atmosphere]
    end

    subgraph Stage3[Stage 3: Coordination]
        CO[Coordinator Agent<br/>Aggregates all results<br/>Calculates weighted score]
    end

    subgraph Stage4[Stage 4: Decision]
        DN[Decision Node<br/>Applies thresholds<br/>Makes recommendation]
    end

    subgraph Stage5[Stage 5: Reporting]
        RN[Report Node<br/>Generates report<br/>Sends email notification]
        END([Final Output:<br/>Rating + Report])
    end

    START --> DC
    DC -->|Menu Data<br/>Reviews| FQ
    DC -->|Restaurant Data<br/>Reviews| HY
    DC -->|Customer Reviews| SE
    DC -->|Menu Data<br/>Price Range| PR
    DC -->|Location Data<br/>Reviews| LA

    FQ -->|Food Quality Score<br/>8.5/10| CO
    HY -->|Hygiene Score<br/>8.2/10| CO
    SE -->|Sentiment Score<br/>0.86| CO
    PR -->|Pricing Score<br/>7.8/10| CO
    LA -->|Ambiance Score<br/>8.1/10| CO

    CO -->|Overall Score: 8.35<br/>All Metrics| DN
    DN -->|Decision: EXCELLENT<br/>Recommendation: RECOMMENDED| RN
    RN --> END

    style START fill:#f0f0f0,stroke:#333,stroke-width:2px
    style DC fill:#e1f5ff,stroke:#333,stroke-width:3px
    style FQ fill:#fff4e1,stroke:#333,stroke-width:2px
    style HY fill:#fff4e1,stroke:#333,stroke-width:2px
    style SE fill:#fff4e1,stroke:#333,stroke-width:2px
    style PR fill:#fff4e1,stroke:#333,stroke-width:2px
    style LA fill:#fff4e1,stroke:#333,stroke-width:2px
    style CO fill:#e1ffe1,stroke:#333,stroke-width:3px
    style DN fill:#ffe1f5,stroke:#333,stroke-width:2px
    style RN fill:#ffe1e1,stroke:#333,stroke-width:2px
    style END fill:#f0f0f0,stroke:#333,stroke-width:2px

    style Stage1 fill:#f9f9f9,stroke:#666,stroke-width:2px,stroke-dasharray: 5 5
    style Stage2 fill:#f9f9f9,stroke:#666,stroke-width:2px,stroke-dasharray: 5 5
    style Stage3 fill:#f9f9f9,stroke:#666,stroke-width:2px,stroke-dasharray: 5 5
    style Stage4 fill:#f9f9f9,stroke:#666,stroke-width:2px,stroke-dasharray: 5 5
    style Stage5 fill:#f9f9f9,stroke:#666,stroke-width:2px,stroke-dasharray: 5 5
```

================================================================================
AGENT COMMUNICATION FLOW
================================================================================

Stage 1: Data Collection
-------------------------
Input: User provides Restaurant Name and Location

Data Collector Agent
    - Collects restaurant data, menu items, and customer reviews
    - Distributes different data sets to each analysis agent:
        * Food Quality Agent: menu_data, customer_reviews
        * Hygiene Agent: restaurant_data, customer_reviews
        * Sentiment Agent: customer_reviews
        * Pricing Agent: menu_data, price_range
        * Location Ambiance Agent: location_data, customer_reviews


Stage 2: Parallel Analysis (5 agents execute simultaneously)
-------------------------------------------------------------
Food Quality Agent
    - Input: menu_data (3 items), customer_reviews (5 reviews)
    - Analyzes: menu variety, food quality keywords, rating patterns
    - Output: food_quality_score (8.5/10), popular items, recommendations
    - Sends to: Coordinator Agent

Hygiene Agent
    - Input: restaurant_data, customer_reviews
    - Analyzes: cleanliness indicators, hygiene keywords in reviews
    - Output: hygiene_score (8.2/10), cleanliness level
    - Sends to: Coordinator Agent

Sentiment Agent
    - Input: customer_reviews (5 reviews)
    - Analyzes: positive/negative keywords, emotional tone
    - Output: sentiment_score (0.86), sentiment breakdown
    - Sends to: Coordinator Agent

Pricing Agent
    - Input: menu_data, restaurant price_range
    - Analyzes: price competitiveness, value assessment
    - Output: pricing_score (7.8/10), value rating
    - Sends to: Coordinator Agent

Location Ambiance Agent
    - Input: location_data, customer_reviews
    - Analyzes: location quality, ambiance keywords
    - Output: ambiance_score (8.1/10), atmosphere rating
    - Sends to: Coordinator Agent


Stage 3: Coordination and Aggregation
--------------------------------------
Coordinator Agent
    - Input: Results from all 5 analysis agents
    - Aggregates: Calculates weighted overall score
        * Food Quality: 30% weight
        * Hygiene: 25% weight
        * Sentiment: 20% weight
        * Pricing: 15% weight
        * Ambiance: 10% weight
    - Output: overall_score (8.35/10), coordination_summary
    - Sends to: Decision Node


Stage 4: Automated Decision Making
-----------------------------------
Decision Node
    - Input: Overall score and all individual metrics
    - Applies: Threshold comparisons
        * Hygiene threshold: 8.0
        * Food quality threshold: 7.0
        * Sentiment threshold: 0.6
    - Determines: Recommendation level based on overall score
        * 8.5+: HIGHLY RECOMMENDED
        * 7.0-8.5: RECOMMENDED
        * 5.0-7.0: NEUTRAL
        * Below 5.0: NOT RECOMMENDED
    - Output: decision (EXCELLENT), recommendation (RECOMMENDED)
    - Sends to: Report Node


Stage 5: Report Generation and Notification
--------------------------------------------
Report Node
    - Input: All analysis results, decision, and metrics
    - Generates: Comprehensive report with:
        * Priority level (HIGH/MEDIUM/LOW)
        * Key findings (5-7 bullet points)
        * Action items for improvement
        * Improvement suggestions
    - Sends: Email notification via SMTP to configured recipient
    - Output: Final review report with rating and recommendations


Data Flow Summary
-----------------
User Input
    --> Data Collector Agent
    --> 5 Parallel Analysis Agents
    --> Coordinator Agent
    --> Decision Node
    --> Report Node
    --> Final Output + Email Notification

Execution Time: All 5 analysis agents run in parallel using ThreadPoolExecutor
with configurable max_workers (default: 5)

================================================================================
