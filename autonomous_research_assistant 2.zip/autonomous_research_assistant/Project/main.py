import sys
from graph import create_graph

def main():
    if len(sys.argv) > 1:
        query = " ".join(sys.argv[1:])
    else:
        query = "What is the latest in AI?"

    print(f"Starting research for: '{query}'")

    app = create_graph()

    initial_state = {"original_query": query}

    final_state = app.invoke(initial_state)

    print("\n" + "="*80)
    print("RESEARCH COMPLETE")
    print("="*80)
    print(f"\nOriginal Query: {final_state.get('original_query', 'N/A')}")
    print(f"\nGenerated Search Queries ({len(final_state.get('search_queries', []))}):")
    for i, query in enumerate(final_state.get('search_queries', []), 1):
        print(f"  {i}. {query}")
    print(f"\nSearch Results Collected: {len(final_state.get('search_results', []))} results")
    print("="*80)

if __name__ == "__main__":
    main()
