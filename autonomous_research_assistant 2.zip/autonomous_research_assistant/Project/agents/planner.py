from services.llm_service import LLMService

class PlannerAgent:
    def __init__(self):
        self.llm_service = LLMService()

    def plan(self, query: str) -> list[str]:
        print(f"PLANNER: Planning research for query: '{query}'")
        
        prompt = f"""
        You are a research planner. Your task is to generate a list of 3-5 search queries to research a given topic.
        The topic is: "{query}"
        
        Return a list of search queries, one per line. Do not include any other text or formatting.
        For example:
        what is the history of the internet
        who invented the http protocol
        latest trends in web development
        """
        
        response = self.llm_service.invoke(prompt)
        search_queries = [line.strip() for line in response.split('\n') if line.strip()]
        
        print(f"PLANNER: Generated queries: {search_queries}")
        return search_queries
