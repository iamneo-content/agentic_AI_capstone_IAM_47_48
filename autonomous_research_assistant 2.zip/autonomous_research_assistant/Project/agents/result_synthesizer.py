class ResultSynthesizerAgent:
    def synthesize(self, results: list) -> str:
        print("SYNTHESIZER: Synthesizing results...")
        return "Synthesized result."
