from services.web_search_service import WebSearchService

class ResearchAgent:
    def __init__(self):
        self.web_search_service = WebSearchService()

    def research(self, query: str) -> list:
        print(f"RESEARCH AGENT: Researching '{query}'...")
        results = self.web_search_service.search(query)
        return results
