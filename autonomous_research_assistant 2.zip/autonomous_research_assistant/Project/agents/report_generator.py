class ReportGeneratorAgent:
    def generate(self, analysis: str) -> str:
        print("REPORT GENERATOR: Generating report...")
        return f"Report: {analysis}"
