import os
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

load_dotenv()

class LLMService:
    def __init__(self):
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_API_KEY not found in .env file or is not set.")
        self.llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash-lite", google_api_key=api_key)

    def invoke(self, prompt: str) -> str:
        print(f"LLM SERVICE: Invoking with prompt: '{prompt[:50]}...'")
        response = self.llm.invoke(prompt)
        return response.content
