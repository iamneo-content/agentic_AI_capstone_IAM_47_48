class MemoryService:
    def __init__(self):
        self.memory = {}

    def remember(self, key: str, value: any):
        print(f"MEMORY SERVICE: Remembering '{key}'")
        self.memory[key] = value

    def recall(self, key: str) -> any:
        print(f"MEMORY SERVICE: Recalling '{key}'")
        return self.memory.get(key)
