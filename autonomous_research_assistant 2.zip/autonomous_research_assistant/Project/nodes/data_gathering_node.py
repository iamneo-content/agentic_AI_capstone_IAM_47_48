from state import ResearchState
from agents.research_agent import ResearchAgent

def data_gathering_node(state: ResearchState) -> dict:
    print("---DATA GATHERING NODE---")
    researcher = ResearchAgent()
    all_results = []
    for query in state["search_queries"]:
        results = researcher.research(query)
        all_results.extend(results)
    return {"search_results": all_results}
