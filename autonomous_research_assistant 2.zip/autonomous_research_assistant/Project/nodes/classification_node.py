from ..state import ResearchState

def classification_node(state: ResearchState) -> ResearchState:
    print("---CLASSIFICATION NODE---")
    # In a real implementation, this would call the query classifier agent
    print(f"Query '{state.original_query}' classified as general.")
    return state
