from ..state import ResearchState

def research_planning_node(state: ResearchState) -> ResearchState:
    print("---RESEARCH PLANNING NODE---")
    # In a real implementation, this would call the research planner agent
    print("Research plan created.")
    return state
