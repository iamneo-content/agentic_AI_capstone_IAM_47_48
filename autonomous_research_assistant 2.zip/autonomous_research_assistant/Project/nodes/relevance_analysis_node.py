from ..state import ResearchState

def relevance_analysis_node(state: ResearchState) -> ResearchState:
    print("---RELEVANCE ANALYSIS NODE---")
    # In a real implementation, this would call the relevance analyzer agent
    print("Relevance analysis complete.")
    return state
