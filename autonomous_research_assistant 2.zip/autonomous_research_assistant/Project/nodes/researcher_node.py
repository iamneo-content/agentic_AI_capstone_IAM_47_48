from ..state import ResearchState

def researcher_node(state: ResearchState) -> ResearchState:
    print("---RESEARCHER NODE---")
    # In a real implementation, this would call the research agent
    state.search_results = [{"url": "example.com", "content": "example content"}]
    return state
