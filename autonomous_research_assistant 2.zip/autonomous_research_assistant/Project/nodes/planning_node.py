from state import ResearchState
from agents.planner import PlannerAgent

def planning_node(state: ResearchState) -> dict:
    print("---PLANNING NODE---")
    planner = PlannerAgent()
    search_queries = planner.plan(state["original_query"])
    return {"search_queries": search_queries}
