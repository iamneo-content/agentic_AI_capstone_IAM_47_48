from typing import List, Dict, Optional, TypedDict

class ResearchState(TypedDict, total=False):
    original_query: Optional[str]
    search_queries: List[str]
    search_results: List[Dict]
    research_summary: Optional[str]
    error: Optional[str]
