import unittest
from ..Project.state import ResearchState

class PytestTests(unittest.TestCase):

    def test_state_initialization(self):
        state = ResearchState()
        self.assertIsNone(state.original_query)
        self.assertEqual(state.search_queries, [])
        self.assertEqual(state.search_results, [])
        self.assertIsNone(state.research_summary)
        self.assertIsNone(state.error)

if __name__ == '__main__':
    unittest.main()
