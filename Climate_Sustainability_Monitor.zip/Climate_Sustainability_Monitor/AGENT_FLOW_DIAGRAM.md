CLIMATE SUSTAINABILITY MONITOR - AGENT FLOW DIAGRAM
====================================================

MERMAID DIAGRAM
===============

graph TD
    Start([Flow Start]) --> EDCA[Environmental Data Collector Agent]

    EDCA -->|Data Quality Score >= 70| CAA[Climate Analysis Agent]
    EDCA -->|Data Collection Failed| SkipAnalysis[Skip Analysis]

    SkipAnalysis --> End([Flow Complete])

    CAA -->|Climate Severity Score >= 60| SAA[Sustainability Assessment Agent]
    CAA -->|Analysis Failed| SkipAssessment[Skip Assessment]

    SkipAssessment --> End

    SAA -->|Sustainability Score >= 50| ARA[Action Recommendation Agent]
    SAA -->|Assessment Failed| SkipRecommendations[Skip Recommendations]

    SkipRecommendations --> End

    ARA -->|High Priority Actions| CriticalActions[CRITICAL Priority]
    ARA -->|Medium Priority Actions| MediumActions[MEDIUM Priority]
    ARA -->|Low Priority Actions| LowActions[LOW Priority]

    CriticalActions --> SaveResults[Save All Results]
    MediumActions --> SaveResults
    LowActions --> SaveResults

    SaveResults --> GenerateReports[Generate Sustainability Reports]
    GenerateReports --> End

    style EDCA fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style CAA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style SAA fill:#fff3e0,stroke:#e65100,stroke-width:2px
    style ARA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style Start fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style End fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style SkipAnalysis fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipAssessment fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipRecommendations fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style CriticalActions fill:#ffcdd2,stroke:#c62828,stroke-width:2px
    style MediumActions fill:#fff9c4,stroke:#f57f17,stroke-width:2px
    style LowActions fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style SaveResults fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style GenerateReports fill:#b2dfdb,stroke:#00695c,stroke-width:2px


AGENT COMMUNICATION DETAILS
============================

1. ENVIRONMENTAL DATA COLLECTOR AGENT
--------------------------------------
Input: Region specification, data types, time period
Tools Used:
  - ClimateDataFetcherTool
Output: Environmental data with quality score
Next Agent: Climate Analysis Agent
Condition: Data Quality Score >= 70
Data Passed:
  - Temperature data
  - Carbon emissions data
  - Air quality data
  - Precipitation data
  - Sea level data


2. CLIMATE ANALYSIS AGENT
--------------------------
Input: Environmental data from previous agent
Tools Used:
  - CarbonEmissionsAnalyzerTool
  - TemperatureTrendAnalyzerTool
  - AirQualityAnalyzerTool
  - DeforestationMonitorTool
Output: Climate analysis with severity score
Next Agent: Sustainability Assessment Agent
Condition: Climate Severity Score >= 60
Data Passed:
  - Carbon emissions by sector
  - Temperature trends and anomalies
  - Air quality metrics
  - Deforestation rates
  - Climate projections


3. SUSTAINABILITY ASSESSMENT AGENT
-----------------------------------
Input: Climate analysis from previous agent
Tools Used:
  - RenewableEnergyTrackerTool
Output: Sustainability assessment with score
Next Agent: Action Recommendation Agent
Condition: Sustainability Score >= 50
Data Passed:
  - Sustainability score
  - Renewable energy metrics
  - SDG alignment scores
  - Progress toward climate goals
  - Gap analysis


4. ACTION RECOMMENDATION AGENT
-------------------------------
Input: Sustainability assessment from previous agent
Tools Used:
  - SustainabilityReportGeneratorTool
Output: Prioritized action recommendations
Next Step: Save Results and Generate Reports
Priority Levels:
  - CRITICAL (Score < 50): Immediate action required
  - MEDIUM (Score 50-75): Action needed within timeline
  - LOW (Score > 75): Monitor and maintain
Data Passed:
  - Recommended actions with priorities
  - Impact estimates
  - Cost estimates
  - Timeline projections
  - Implementation strategies


SCORE THRESHOLDS AND DECISION LOGIC
====================================

Data Quality Score Thresholds:
  >= 70: Proceed to Climate Analysis
  < 70: Skip analysis and end flow

Climate Severity Score Thresholds:
  >= 60: Proceed to Sustainability Assessment
  < 60: Skip assessment and end flow

Sustainability Score Thresholds:
  >= 50: Proceed to Action Recommendations
  < 50: Skip recommendations and end flow

Action Priority Classification:
  Score < 50: CRITICAL Priority (Red)
  Score 50-75: MEDIUM Priority (Yellow)
  Score > 75: LOW Priority (Green)


AGENT INTERACTION FLOW
=======================

Sequential Flow with Conditional Branching:

Step 1: Flow Initialization
  |
  v
Step 2: Environmental Data Collection
  |-- Success (Quality >= 70) --> Continue
  |-- Failure (Quality < 70) --> End Flow
  |
  v
Step 3: Climate Pattern Analysis
  |-- Success (Severity >= 60) --> Continue
  |-- Failure (Severity < 60) --> End Flow
  |
  v
Step 4: Sustainability Assessment
  |-- Success (Score >= 50) --> Continue
  |-- Failure (Score < 50) --> End Flow
  |
  v
Step 5: Action Recommendations
  |-- Critical Actions (Score < 50) --> High Priority
  |-- Medium Actions (Score 50-75) --> Medium Priority
  |-- Low Actions (Score > 75) --> Low Priority
  |
  v
Step 6: Save Results and Generate Reports
  |
  v
Step 7: Flow Complete


DATA FLOW BETWEEN AGENTS
=========================

Agent 1 --> Agent 2:
  Environmental Data Collector --> Climate Analysis Agent
  Data Transferred:
    - Temperature: 15.8°C (current), 14.5°C (average)
    - CO2 Levels: 425 ppm
    - Air Quality Index: 85
    - Data Quality Score: 85.5

Agent 2 --> Agent 3:
  Climate Analysis Agent --> Sustainability Assessment Agent
  Data Transferred:
    - Total Emissions: 125,000 Mt CO2
    - Temperature Anomaly: 1.3°C
    - Deforestation Rate: 2.7% annually
    - Climate Severity Score: 72.3

Agent 3 --> Agent 4:
  Sustainability Assessment Agent --> Action Recommendation Agent
  Data Transferred:
    - Sustainability Score: 68.0
    - Renewable Energy: 38% of total
    - SDG7 Score: 82 (on track)
    - SDG13 Score: 65 (needs improvement)
    - SDG15 Score: 58 (at risk)

Agent 4 --> Output:
  Action Recommendation Agent --> Results Storage
  Data Transferred:
    - 3 Critical Priority Actions
    - 2 Medium Priority Actions
    - 1 Low Priority Action
    - Complete Sustainability Report
    - SDG Alignment Details


CONDITIONAL PATHS
=================

Path 1: Successful Full Analysis
  Start --> Data Collection (Score 85) --> Climate Analysis (Score 72)
    --> Sustainability Assessment (Score 68) --> Action Recommendations
    --> Save Results --> End

Path 2: Failed Data Collection
  Start --> Data Collection (Score 45) --> Skip Analysis --> End

Path 3: Failed Climate Analysis
  Start --> Data Collection (Score 85) --> Climate Analysis (Score 40)
    --> Skip Assessment --> End

Path 4: Failed Sustainability Assessment
  Start --> Data Collection (Score 85) --> Climate Analysis (Score 72)
    --> Sustainability Assessment (Score 35) --> Skip Recommendations --> End


AGENT TOOLS MAPPING
====================

Environmental Data Collector Agent:
  - ClimateDataFetcherTool
    Purpose: Fetch environmental data from multiple sources
    Interaction: Retrieves data from NASA, NOAA, ESA

Climate Analysis Agent:
  - CarbonEmissionsAnalyzerTool
    Purpose: Analyze carbon footprint by sector
    Interaction: Processes emission data
  - TemperatureTrendAnalyzerTool
    Purpose: Analyze temperature patterns
    Interaction: Detects anomalies and trends
  - AirQualityAnalyzerTool
    Purpose: Evaluate air quality metrics
    Interaction: Monitors pollutant levels
  - DeforestationMonitorTool
    Purpose: Track forest coverage changes
    Interaction: Assesses biodiversity impact

Sustainability Assessment Agent:
  - RenewableEnergyTrackerTool
    Purpose: Monitor renewable energy adoption
    Interaction: Tracks capacity and growth

Action Recommendation Agent:
  - SustainabilityReportGeneratorTool
    Purpose: Generate comprehensive reports
    Interaction: Creates recommendations and reports


COLOR CODING LEGEND
===================

Agent Colors:
  Blue (#e1f5ff): Environmental Data Collector Agent
  Purple (#f3e5f5): Climate Analysis Agent
  Orange (#fff3e0): Sustainability Assessment Agent
  Green (#e8f5e9): Action Recommendation Agent

Status Colors:
  Pink (#fce4ec): Start/End nodes
  Red (#ffcdd2): Critical priority / Failed paths
  Yellow (#fff9c4): Medium priority
  Light Green (#c8e6c9): Low priority / Success
  Light Red (#ffebee): Skip/Error paths (dashed)
  Light Purple (#e1bee7): Processing nodes
  Teal (#b2dfdb): Report generation


EXECUTION TIMING
================

Typical execution times per agent:

Environmental Data Collector Agent: 5-10 seconds
Climate Analysis Agent: 15-20 seconds
Sustainability Assessment Agent: 8-12 seconds
Action Recommendation Agent: 10-15 seconds
Save Results and Generate Reports: 2-5 seconds

Total Average Execution Time: 45-50 seconds


ERROR HANDLING FLOW
====================

If any agent fails:
  1. Log error details
  2. Calculate partial scores
  3. Determine if continuation is possible
  4. If score below threshold: Skip remaining agents
  5. If continuation impossible: End flow gracefully
  6. Save partial results if available
  7. Generate error report

Recovery Options:
  - Retry with different parameters
  - Use cached data if available
  - Generate partial reports
  - Queue for manual review
