"""
Comprehensive Test Suite for Climate Sustainability Monitor
All 15 test cases in one file using pytest
"""

import pytest
import ast
import json
from datetime import datetime
from unittest.mock import Mock

# Import all tools to test
from tools.climate_data_fetcher import ClimateDataFetcherTool
from tools.carbon_emissions_analyzer import CarbonEmissionsAnalyzerTool
from tools.temperature_trend_analyzer import TemperatureTrendAnalyzerTool
from tools.air_quality_analyzer import AirQualityAnalyzerTool
from tools.deforestation_monitor import DeforestationMonitorTool
from tools.renewable_energy_tracker import RenewableEnergyTrackerTool
from tools.sustainability_report_generator import SustainabilityReportGeneratorTool


# ==================== FIXTURES ====================

@pytest.fixture
def sample_region():
    """Sample region for testing"""
    return "North America"


@pytest.fixture
def sample_environmental_data():
    """Sample environmental data for testing"""
    return {
        "status": "success",
        "region": "North America",
        "temperature": 15.2,
        "co2_levels": 420,
        "air_quality_index": 85,
        "forest_coverage": 33.2,
        "renewable_energy_percentage": 28.5,
        "data_collection_timestamp": datetime.now().isoformat(),
        "message": "Environmental data collected successfully"
    }


@pytest.fixture
def sample_climate_analysis():
    """Sample climate analysis data for testing"""
    return {
        "status": "success",
        "region": "North America",
        "carbon_emissions": {
            "total_emissions": 5000,
            "emissions_trend": "increasing",
            "major_sectors": ["transportation", "energy", "industry"]
        },
        "temperature_trends": {
            "average_change": 1.8,
            "anomaly_detected": False
        },
        "air_quality": {
            "aqi": 85,
            "status": "moderate"
        },
        "deforestation": {
            "rate": 2.3,
            "status": "concerning"
        }
    }


@pytest.fixture
def sample_sustainability_assessment():
    """Sample sustainability assessment data for testing"""
    return {
        "status": "success",
        "region": "North America",
        "sustainability_score": 72.5,
        "renewable_energy": {
            "current_capacity": 500,
            "growth_rate": 5.2,
            "targets_met": True
        },
        "sdg_alignment": {
            "SDG7": 75,
            "SDG13": 68,
            "SDG15": 70
        }
    }


# ==================== TEST CASES ====================

class TestClimateDataFetcherTool:
    """Test cases for ClimateDataFetcherTool"""

    def test_climate_data_fetcher_returns_valid_structure(self, sample_region):
        """Test Case 1: Verify ClimateDataFetcherTool returns valid structure"""
        tool = ClimateDataFetcherTool()
        result = tool._run(
            region=sample_region,
            data_types="temperature,emissions,air_quality",
            time_period_days=30
        )

        # Parse result and verify structure
        data = ast.literal_eval(result)

        assert "status" in data
        assert "region" in data
        assert data["region"] == sample_region
        assert "message" in data

    def test_climate_data_fetcher_with_different_time_periods(self):
        """Test Case 2: Verify ClimateDataFetcherTool handles different time periods"""
        tool = ClimateDataFetcherTool()

        # Test with 7 days
        result_7 = tool._run(region="Asia", data_types="temperature", time_period_days=7)
        data_7 = ast.literal_eval(result_7)

        # Test with 90 days
        result_90 = tool._run(region="Asia", data_types="temperature", time_period_days=90)
        data_90 = ast.literal_eval(result_90)

        assert data_7["status"] == "success"
        assert data_90["status"] == "success"
        assert "time_period_days" in data_7
        assert data_7["time_period_days"] == 7
        assert data_90["time_period_days"] == 90


class TestCarbonEmissionsAnalyzerTool:
    """Test cases for CarbonEmissionsAnalyzerTool"""

    def test_carbon_emissions_analyzer_returns_emissions_by_sector(self, sample_region):
        """Test Case 3: Verify CarbonEmissionsAnalyzerTool returns emissions by sector"""
        tool = CarbonEmissionsAnalyzerTool()
        result = tool._run(region=sample_region, analysis_scope="comprehensive")

        data = ast.literal_eval(result)

        assert "status" in data
        assert "emissions_by_sector" in data
        assert isinstance(data["emissions_by_sector"], dict)

        # Check for common sectors
        sectors = data["emissions_by_sector"]
        assert "transportation" in sectors
        assert "energy" in sectors
        assert "industry" in sectors

    def test_carbon_emissions_analyzer_includes_trends(self):
        """Test Case 4: Verify CarbonEmissionsAnalyzerTool includes emission trends"""
        tool = CarbonEmissionsAnalyzerTool()
        result = tool._run(region="Europe", analysis_scope="trends")

        data = ast.literal_eval(result)

        assert "trends" in data
        assert "total_emissions_mt_co2" in data
        assert isinstance(data["total_emissions_mt_co2"], (int, float))
        assert "trend_direction" in data["trends"]
        assert data["trends"]["trend_direction"] in ["increasing", "decreasing", "stable"]


class TestTemperatureTrendAnalyzerTool:
    """Test cases for TemperatureTrendAnalyzerTool"""

    def test_temperature_trend_analyzer_detects_anomalies(self, sample_region):
        """Test Case 5: Verify TemperatureTrendAnalyzerTool detects temperature anomalies"""
        tool = TemperatureTrendAnalyzerTool()
        result = tool._run(region=sample_region, years_of_data=10)

        data = ast.literal_eval(result)

        assert "status" in data
        assert "temperature_anomaly_c" in data
        assert "trends" in data
        assert isinstance(data["temperature_anomaly_c"], (int, float))
        assert "overall_trend" in data["trends"]

    def test_temperature_trend_analyzer_includes_projections(self):
        """Test Case 6: Verify TemperatureTrendAnalyzerTool includes future projections"""
        tool = TemperatureTrendAnalyzerTool()
        result = tool._run(region="South America", years_of_data=20)

        data = ast.literal_eval(result)

        assert "projections" in data
        assert "impacts_observed" in data
        assert isinstance(data["impacts_observed"], list)
        assert len(data["impacts_observed"]) > 0
        assert "2050_projected_c" in data["projections"]


class TestAirQualityAnalyzerTool:
    """Test cases for AirQualityAnalyzerTool"""

    def test_air_quality_analyzer_returns_aqi(self, sample_region):
        """Test Case 7: Verify AirQualityAnalyzerTool returns AQI values"""
        tool = AirQualityAnalyzerTool()
        result = tool._run(region=sample_region, include_forecasts=False)

        data = ast.literal_eval(result)

        assert "status" in data
        assert "current_aqi" in data
        assert isinstance(data["current_aqi"], (int, float))
        assert 0 <= data["current_aqi"] <= 500

    def test_air_quality_analyzer_includes_pollutant_levels(self):
        """Test Case 8: Verify AirQualityAnalyzerTool includes pollutant breakdown"""
        tool = AirQualityAnalyzerTool()
        result = tool._run(region="Asia", include_forecasts=True)

        data = ast.literal_eval(result)

        assert "pollutants" in data
        pollutants = data["pollutants"]

        # Check for common pollutants
        assert "pm25" in pollutants or "pm10" in pollutants
        assert "health_recommendations" in data


class TestDeforestationMonitorTool:
    """Test cases for DeforestationMonitorTool"""

    def test_deforestation_monitor_tracks_forest_coverage(self, sample_region):
        """Test Case 9: Verify DeforestationMonitorTool tracks forest coverage"""
        tool = DeforestationMonitorTool()
        result = tool._run(region=sample_region, time_period_years=5)

        data = ast.literal_eval(result)

        assert "status" in data
        assert "forest_coverage" in data
        assert "deforestation_rate" in data
        assert "current_km2" in data["forest_coverage"]
        assert isinstance(data["forest_coverage"]["current_km2"], (int, float))

    def test_deforestation_monitor_assesses_biodiversity_impact(self):
        """Test Case 10: Verify DeforestationMonitorTool assesses biodiversity impact"""
        tool = DeforestationMonitorTool()
        result = tool._run(region="Africa", time_period_years=10)

        data = ast.literal_eval(result)

        assert "biodiversity_impact" in data
        assert "carbon_impact" in data
        assert "carbon_released_mt" in data["carbon_impact"]


class TestRenewableEnergyTrackerTool:
    """Test cases for RenewableEnergyTrackerTool"""

    def test_renewable_energy_tracker_measures_capacity(self, sample_region):
        """Test Case 11: Verify RenewableEnergyTrackerTool measures renewable capacity"""
        tool = RenewableEnergyTrackerTool()
        result = tool._run(region=sample_region, energy_types="solar,wind,hydro")

        data = ast.literal_eval(result)

        assert "status" in data
        assert "total_capacity_gw" in data
        assert "capacity_by_type" in data
        assert isinstance(data["capacity_by_type"], dict)

    def test_renewable_energy_tracker_shows_growth_trends(self):
        """Test Case 12: Verify RenewableEnergyTrackerTool shows growth trends"""
        tool = RenewableEnergyTrackerTool()
        result = tool._run(region="Europe", energy_types="all")

        data = ast.literal_eval(result)

        assert "growth_trends" in data
        assert "renewable_percentage" in data
        assert isinstance(data["renewable_percentage"], (int, float))
        assert 0 <= data["renewable_percentage"] <= 100


class TestSustainabilityReportGeneratorTool:
    """Test cases for SustainabilityReportGeneratorTool"""

    def test_sustainability_report_generator_creates_comprehensive_report(
        self, sample_region, sample_climate_analysis
    ):
        """Test Case 13: Verify SustainabilityReportGeneratorTool creates comprehensive report"""
        tool = SustainabilityReportGeneratorTool()
        result = tool._run(
            region=sample_region,
            analysis_results=json.dumps(sample_climate_analysis),
            report_type="comprehensive"
        )

        data = ast.literal_eval(result)

        assert "status" in data
        assert "report_type" in data
        assert "executive_summary" in data
        assert "overall_sustainability_score" in data["executive_summary"]
        assert isinstance(data["executive_summary"]["overall_sustainability_score"], (int, float))
        assert 0 <= data["executive_summary"]["overall_sustainability_score"] <= 100

    def test_sustainability_report_generator_includes_sdg_alignment(self):
        """Test Case 14: Verify SustainabilityReportGeneratorTool includes SDG alignment"""
        tool = SustainabilityReportGeneratorTool()
        result = tool._run(
            region="Global",
            analysis_results=json.dumps({"test": "data"}),
            report_type="sdg_focused"
        )

        data = ast.literal_eval(result)

        assert "sdg_alignment" in data
        assert isinstance(data["sdg_alignment"], dict)

        # Check for specific SDGs
        sdgs = data["sdg_alignment"]
        assert any(sdg.startswith("SDG") for sdg in sdgs.keys())

    def test_sustainability_report_generator_provides_recommendations(self):
        """Test Case 15: Verify SustainabilityReportGeneratorTool provides recommendations"""
        tool = SustainabilityReportGeneratorTool()
        result = tool._run(
            region="Asia",
            analysis_results=json.dumps({"emissions": "high"}),
            report_type="actionable"
        )

        data = ast.literal_eval(result)

        assert "action_recommendations" in data
        assert isinstance(data["action_recommendations"], list)
        assert len(data["action_recommendations"]) > 0

        # Verify recommendations have required structure
        for rec in data["action_recommendations"]:
            assert "priority" in rec
            assert "action" in rec


# ==================== MAIN ====================

if __name__ == "__main__":
    # Run tests with pytest when executed directly
    pytest.main([__file__, "-v", "--tb=short"])
