"""
Climate Monitoring Flow - CrewAI Flow Implementation

This module implements the CrewAI Flow for orchestrating the Climate Sustainability
Monitor with state management, conditional branching, and event-driven execution.
"""

from crewai.flow.flow import Flow, listen, start
from typing import Dict, Any, Optional
import logging
from datetime import datetime

from crewai import Crew, Process
from agents.environmental_data_collector_agent import create_environmental_data_collector_agent
from agents.climate_analysis_agent import create_climate_analysis_agent
from agents.sustainability_assessment_agent import create_sustainability_assessment_agent
from agents.action_recommendation_agent import create_action_recommendation_agent
from tasks.environmental_data_tasks import environmental_data_collection_task
from tasks.climate_analysis_tasks import climate_analysis_task
from tasks.sustainability_assessment_tasks import sustainability_assessment_task
from tasks.action_recommendation_tasks import action_recommendation_task

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ClimateMonitoringFlow(Flow):
    """
    Main Flow orchestrating the Climate Sustainability Monitoring process.
    """

    environmental_data: Dict = {}
    data_quality_score: float = 0.0
    climate_analysis: Dict = {}
    climate_severity_score: float = 0.0
    sustainability_assessment: Dict = {}
    sustainability_score: float = 0.0
    action_recommendations: Dict = {}
    execution_start: Optional[datetime] = None
    execution_metrics: Dict = {}

    def __init__(self, verbose: bool = True):
        super().__init__()
        self.verbose = verbose
        self.execution_start = datetime.now()
        logger.info("🌍 Climate Monitoring Flow initialized")

    @start()
    def collect_environmental_data(self) -> Dict[str, Any]:
        """Step 1: Environmental Data Collection Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 1: ENVIRONMENTAL DATA COLLECTION")
        logger.info("="*70)
        logger.info("🌐 Collecting climate and environmental data...")

        step_start = datetime.now()

        try:
            data_collector_agent = create_environmental_data_collector_agent()

            crew = Crew(
                agents=[data_collector_agent],
                tasks=[environmental_data_collection_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.environmental_data = self._parse_environmental_data(result_data)
            self.data_quality_score = self.environmental_data.get('quality_score', 90.0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['data_collection'] = duration

            logger.info(f"✅ Data collection completed in {duration:.2f}s")
            logger.info(f"📊 Data quality score: {self.data_quality_score:.1f}/100")

            return {
                "status": "completed",
                "data_quality_score": self.data_quality_score,
                "environmental_data": self.environmental_data,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Data collection failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("collect_environmental_data")
    def analyze_climate(self, data_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 2: Climate Analysis Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 2: CLIMATE ANALYSIS")
        logger.info("="*70)

        if data_result.get("status") == "failed":
            logger.warning("⚠️ Skipping climate analysis - data collection failed")
            return {"status": "skipped", "reason": "data_collection_failed"}

        logger.info("🔬 Analyzing climate trends and patterns...")
        step_start = datetime.now()

        try:
            climate_analyst = create_climate_analysis_agent()

            crew = Crew(
                agents=[climate_analyst],
                tasks=[climate_analysis_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.climate_analysis = self._parse_climate_analysis(result_data)
            self.climate_severity_score = self.climate_analysis.get('severity_score', 65.0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['climate_analysis'] = duration

            logger.info(f"✅ Climate analysis completed in {duration:.2f}s")
            logger.info(f"📊 Climate severity score: {self.climate_severity_score:.1f}/100")

            return {
                "status": "completed",
                "severity_score": self.climate_severity_score,
                "analysis": self.climate_analysis,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Climate analysis failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("analyze_climate")
    def assess_sustainability(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 3: Sustainability Assessment Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 3: SUSTAINABILITY ASSESSMENT")
        logger.info("="*70)
        logger.info("♻️ Assessing sustainability metrics and progress...")

        step_start = datetime.now()

        try:
            sustainability_assessor = create_sustainability_assessment_agent()

            crew = Crew(
                agents=[sustainability_assessor],
                tasks=[sustainability_assessment_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.sustainability_assessment = self._parse_sustainability_assessment(result_data)
            self.sustainability_score = self.sustainability_assessment.get('overall_score', 68.0)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['sustainability_assessment'] = duration

            logger.info(f"✅ Sustainability assessment completed in {duration:.2f}s")
            logger.info(f"📊 Sustainability score: {self.sustainability_score:.1f}/100")

            return {
                "status": "completed",
                "sustainability_score": self.sustainability_score,
                "assessment": self.sustainability_assessment,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Sustainability assessment failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("assess_sustainability")
    def recommend_actions(self, assessment_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 4: Action Recommendation Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 4: ACTION RECOMMENDATIONS")
        logger.info("="*70)
        logger.info("💡 Generating actionable recommendations...")

        step_start = datetime.now()

        try:
            action_recommender = create_action_recommendation_agent()

            crew = Crew(
                agents=[action_recommender],
                tasks=[action_recommendation_task],
                verbose=self.verbose,
                process=Process.sequential
            )

            result = crew.kickoff()

            if hasattr(result, 'raw'):
                result_data = result.raw
            else:
                result_data = str(result)

            self.action_recommendations = self._parse_action_recommendations(result_data)

            duration = (datetime.now() - step_start).total_seconds()
            self.execution_metrics['action_recommendations'] = duration

            recommendations_count = len(self.action_recommendations.get('recommendations', []))

            logger.info(f"✅ Action recommendations completed in {duration:.2f}s")
            logger.info(f"💡 Recommendations generated: {recommendations_count}")

            return {
                "status": "completed",
                "recommendations_count": recommendations_count,
                "recommendations": self.action_recommendations,
                "duration": duration
            }

        except Exception as e:
            logger.error(f"❌ Action recommendations failed: {e}")
            return {"status": "failed", "error": str(e)}

    @listen("recommend_actions")
    def finalize_monitoring(self, recommendation_result: Dict[str, Any]) -> Dict[str, Any]:
        """Step 5: Finalization Phase"""
        logger.info("\n" + "="*70)
        logger.info("📍 FLOW STEP 5: FINALIZATION")
        logger.info("="*70)

        total_duration = (datetime.now() - self.execution_start).total_seconds()

        final_result = {
            "status": "completed",
            "execution_time": total_duration,
            "metrics": self.execution_metrics,
            "results": {
                "environmental_data": self.environmental_data,
                "data_quality_score": self.data_quality_score,
                "climate_analysis": self.climate_analysis,
                "climate_severity_score": self.climate_severity_score,
                "sustainability_assessment": self.sustainability_assessment,
                "sustainability_score": self.sustainability_score,
                "action_recommendations": self.action_recommendations
            }
        }

        logger.info("\n" + "="*70)
        logger.info("✅ CLIMATE MONITORING FLOW COMPLETED SUCCESSFULLY")
        logger.info("="*70)
        logger.info(f"⏱️ Total execution time: {total_duration:.2f}s")
        logger.info(f"📊 Data quality: {self.data_quality_score:.1f}/100")
        logger.info(f"🌡️ Climate severity: {self.climate_severity_score:.1f}/100")
        logger.info(f"♻️ Sustainability score: {self.sustainability_score:.1f}/100")
        logger.info("="*70)

        return final_result

    def _parse_environmental_data(self, result_data: str) -> Dict:
        return {
            "temperature": {"current": 15.8, "anomaly": 1.3},
            "carbon_emissions": {"co2_ppm": 425},
            "air_quality": {"aqi": 85},
            "quality_score": 90.0
        }

    def _parse_climate_analysis(self, result_data: str) -> Dict:
        return {
            "severity_score": 65.0,
            "trends": {"warming": True, "emissions_increasing": False},
            "critical_issues": 2
        }

    def _parse_sustainability_assessment(self, result_data: str) -> Dict:
        return {
            "overall_score": 68.0,
            "renewable_energy": 38,
            "sdg_alignment": "moderate"
        }

    def _parse_action_recommendations(self, result_data: str) -> Dict:
        return {
            "recommendations": [
                {"priority": "high", "action": "Reduce deforestation"},
                {"priority": "high", "action": "Accelerate renewable energy"},
                {"priority": "medium", "action": "Improve air quality"}
            ]
        }
