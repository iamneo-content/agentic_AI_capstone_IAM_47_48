"""AI Agent definitions for Climate Sustainability Monitoring."""
