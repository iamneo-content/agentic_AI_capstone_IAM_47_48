"""
Environmental Data Collector Agent

This agent collects environmental and climate data from various sources including
satellites, weather stations, and monitoring networks.
"""

from crewai import Agent
from tools.climate_data_fetcher import ClimateDataFetcherTool
from utils.llm_config import get_llm_config


def create_environmental_data_collector_agent():
    """
    Create the Environmental Data Collector Agent.

    This agent collects comprehensive climate and environmental data from multiple
    sources to provide a complete picture of current environmental conditions.

    Returns:
        Configured Agent for environmental data collection
    """
    llm = get_llm_config()

    climate_data_fetcher = ClimateDataFetcherTool()

    agent = Agent(
        role="Environmental Data Collector Specialist",
        goal="Collect comprehensive environmental and climate data from all available sources to provide accurate baseline assessments",
        backstory="""You are an expert environmental data scientist with deep knowledge of
        climate monitoring systems, satellite imagery analysis, and environmental sensor networks.
        You excel at collecting data from diverse sources including NASA, NOAA, ESA satellites,
        ground-based weather stations, ocean buoys, and air quality monitoring networks. Your
        attention to detail ensures complete and accurate environmental datasets for analysis.""",
        llm=llm,
        tools=[climate_data_fetcher],
        verbose=True
    )

    return agent
