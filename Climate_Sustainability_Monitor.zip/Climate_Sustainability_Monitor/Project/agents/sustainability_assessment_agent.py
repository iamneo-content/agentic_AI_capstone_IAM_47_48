"""
Sustainability Assessment Agent

This agent assesses sustainability metrics and progress toward environmental goals.
"""

from crewai import Agent
from tools.renewable_energy_tracker import RenewableEnergyTrackerTool
from utils.llm_config import get_llm_config


def create_sustainability_assessment_agent():
    """
    Create the Sustainability Assessment Agent.

    This agent evaluates sustainability metrics, tracks progress toward environmental
    goals, and assesses alignment with UN Sustainable Development Goals (SDGs).

    Returns:
        Configured Agent for sustainability assessment
    """
    llm = get_llm_config()

    renewable_energy_tracker = RenewableEnergyTrackerTool()

    agent = Agent(
        role="Sustainability Assessment Specialist",
        goal="Evaluate sustainability performance and progress toward environmental targets and UN SDG goals",
        backstory="""You are a sustainability expert with extensive experience in environmental
        policy, renewable energy systems, and sustainable development. You specialize in assessing
        sustainability metrics, tracking progress toward environmental goals, evaluating SDG
        alignment, and identifying opportunities for improvement. Your expertise helps organizations
        understand their environmental impact and chart paths toward sustainability.""",
        llm=llm,
        tools=[renewable_energy_tracker],
        verbose=True
    )

    return agent
