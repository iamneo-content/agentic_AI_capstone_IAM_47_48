"""
Action Recommendation Agent

This agent generates actionable recommendations and creates comprehensive sustainability reports.
"""

from crewai import Agent
from tools.sustainability_report_generator import SustainabilityReportGeneratorTool
from utils.llm_config import get_llm_config


def create_action_recommendation_agent():
    """
    Create the Action Recommendation Agent.

    This agent synthesizes all analysis results and generates actionable recommendations
    with comprehensive sustainability reports and action plans.

    Returns:
        Configured Agent for action recommendations
    """
    llm = get_llm_config()

    report_generator = SustainabilityReportGeneratorTool()

    agent = Agent(
        role="Sustainability Action Recommendation Specialist",
        goal="Generate actionable recommendations and comprehensive sustainability reports to drive environmental improvements",
        backstory="""You are a strategic environmental consultant with expertise in climate action
        planning, policy development, and organizational change management. You excel at synthesizing
        complex environmental data, identifying priority actions, developing implementation strategies,
        and creating compelling reports that drive decision-making. Your recommendations are practical,
        cost-effective, and aligned with international sustainability frameworks.""",
        llm=llm,
        tools=[report_generator],
        verbose=True
    )

    return agent
