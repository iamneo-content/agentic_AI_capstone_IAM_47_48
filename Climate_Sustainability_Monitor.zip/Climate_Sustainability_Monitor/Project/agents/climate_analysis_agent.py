"""
Climate Analysis Agent

This agent analyzes climate data to identify trends, patterns, and anomalies using
specialized analytical tools.
"""

from crewai import Agent
from tools.carbon_emissions_analyzer import CarbonEmissionsAnalyzerTool
from tools.temperature_trend_analyzer import TemperatureTrendAnalyzerTool
from tools.air_quality_analyzer import AirQualityAnalyzerTool
from tools.deforestation_monitor import DeforestationMonitorTool
from utils.llm_config import get_llm_config


def create_climate_analysis_agent():
    """
    Create the Climate Analysis Agent.

    This agent analyzes environmental data to identify climate trends, patterns,
    anomalies, and assess the severity of environmental issues.

    Returns:
        Configured Agent for climate analysis
    """
    llm = get_llm_config()

    carbon_analyzer = CarbonEmissionsAnalyzerTool()
    temperature_analyzer = TemperatureTrendAnalyzerTool()
    air_quality_analyzer = AirQualityAnalyzerTool()
    deforestation_monitor = DeforestationMonitorTool()

    agent = Agent(
        role="Climate Analysis Specialist",
        goal="Analyze environmental data to identify climate trends, patterns, and critical issues requiring attention",
        backstory="""You are a senior climate scientist with expertise in atmospheric science,
        environmental modeling, and data analysis. You specialize in identifying climate trends,
        analyzing carbon emissions, assessing air quality impacts, monitoring deforestation, and
        evaluating temperature anomalies. Your analytical skills help translate complex environmental
        data into actionable insights for decision-makers.""",
        llm=llm,
        tools=[carbon_analyzer, temperature_analyzer, air_quality_analyzer, deforestation_monitor],
        verbose=True
    )

    return agent
