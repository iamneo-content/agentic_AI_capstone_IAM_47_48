"""
Action Recommendation Task

This task defines the workflow for generating actionable recommendations and reports.
"""

from crewai import Task
from agents.action_recommendation_agent import create_action_recommendation_agent

agent = create_action_recommendation_agent()

action_recommendation_task = Task(
    description="""Generate actionable recommendations and comprehensive sustainability reports.

    Your responsibilities:
    1. Synthesize all analysis and assessment results
    2. Identify priority actions based on severity and impact
    3. Develop implementation strategies with timelines and costs
    4. Create comprehensive sustainability report
    5. Generate executive summary with key findings
    6. Provide specific, actionable recommendations
    7. Include risk assessment and mitigation strategies
    8. Align recommendations with SDG goals

    Use the Sustainability Report Generator Tool to create comprehensive reports.
    Focus on practical, achievable actions with measurable outcomes.""",
    agent=agent,
    expected_output="""A comprehensive sustainability report including:
    - Executive summary with key findings
    - Overall sustainability scores and ratings
    - Prioritized action recommendations with:
      * Priority level (high, medium, low)
      * Category and specific action
      * Expected impact and timeline
      * Cost estimates
    - Implementation strategies
    - Risk assessment and mitigation plans
    - SDG alignment analysis
    - Trends analysis (improving, stable, declining)
    - Complete audit trail and data sources"""
)
