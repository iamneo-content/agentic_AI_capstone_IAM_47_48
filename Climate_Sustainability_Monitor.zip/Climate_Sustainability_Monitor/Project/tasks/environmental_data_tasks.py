"""
Environmental Data Collection Task

This task defines the workflow for collecting climate and environmental data.
"""

from crewai import Task
from agents.environmental_data_collector_agent import create_environmental_data_collector_agent

agent = create_environmental_data_collector_agent()

environmental_data_collection_task = Task(
    description="""Collect comprehensive climate and environmental data from all available sources.

    Your responsibilities:
    1. Fetch climate data from satellites, weather stations, and monitoring networks
    2. Collect temperature, carbon emissions, air quality, and precipitation data
    3. Gather sea level, forest coverage, and biodiversity metrics
    4. Extract renewable energy and sustainability indicators
    5. Verify data quality and completeness
    6. Create unified environmental dataset

    Use the Climate Data Fetcher Tool to gather comprehensive information.
    Focus on accuracy, completeness, and data quality.""",
    agent=agent,
    expected_output="""A comprehensive environmental data report including:
    - Temperature data with trends and anomalies
    - Carbon emissions metrics and changes
    - Air quality indices and pollutant levels
    - Precipitation and weather patterns
    - Sea level measurements and trends
    - Forest coverage and deforestation rates
    - Biodiversity indicators
    - Renewable energy statistics
    - Data quality assessment
    - Source attribution and timestamps"""
)
