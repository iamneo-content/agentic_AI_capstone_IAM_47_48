"""Task definitions for Climate Sustainability Monitor agents."""
