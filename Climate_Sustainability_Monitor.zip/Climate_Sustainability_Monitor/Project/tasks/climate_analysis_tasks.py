"""
Climate Analysis Task

This task defines the workflow for analyzing climate trends and patterns.
"""

from crewai import Task
from agents.climate_analysis_agent import create_climate_analysis_agent

agent = create_climate_analysis_agent()

climate_analysis_task = Task(
    description="""Analyze environmental data to identify trends, patterns, and critical issues.

    Your responsibilities:
    1. Analyze carbon emissions trends and identify major sources
    2. Assess temperature trends and climate anomalies
    3. Evaluate air quality and pollution patterns
    4. Monitor deforestation rates and biodiversity impacts
    5. Identify extreme weather events and climate risks
    6. Calculate environmental impact metrics
    7. Assess severity of identified issues

    Use Carbon Emissions Analyzer, Temperature Trend Analyzer, Air Quality Analyzer,
    and Deforestation Monitor tools for comprehensive analysis.
    Focus on identifying actionable insights and critical concerns.""",
    agent=agent,
    expected_output="""A comprehensive climate analysis report including:
    - Carbon emissions analysis with trends and major sources
    - Temperature trend analysis with projections
    - Air quality assessment with pollution sources
    - Deforestation monitoring with biodiversity impacts
    - Climate risk identification
    - Severity assessment for all identified issues
    - Key findings and critical concerns
    - Data-driven insights for decision-making"""
)
