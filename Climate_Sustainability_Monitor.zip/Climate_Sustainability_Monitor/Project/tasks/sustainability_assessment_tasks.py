"""
Sustainability Assessment Task

This task defines the workflow for assessing sustainability metrics and progress.
"""

from crewai import Task
from agents.sustainability_assessment_agent import create_sustainability_assessment_agent

agent = create_sustainability_assessment_agent()

sustainability_assessment_task = Task(
    description="""Evaluate sustainability performance and progress toward environmental goals.

    Your responsibilities:
    1. Track renewable energy adoption and capacity growth
    2. Assess progress toward 2030 sustainability targets
    3. Evaluate UN SDG alignment and scores
    4. Calculate overall sustainability scores
    5. Identify sustainability strengths and weaknesses
    6. Assess carbon offset achievements
    7. Evaluate green transition progress

    Use the Renewable Energy Tracker Tool to monitor progress.
    Focus on measurable metrics and target alignment.""",
    agent=agent,
    expected_output="""A comprehensive sustainability assessment including:
    - Renewable energy adoption metrics and trends
    - Progress toward 2030 emission reduction targets
    - UN SDG alignment scores for relevant goals
    - Overall sustainability score and rating
    - Identified strengths in sustainability efforts
    - Areas requiring improvement
    - Carbon offset achievements
    - Investment trends in green technologies
    - Sustainability trajectory analysis"""
)
