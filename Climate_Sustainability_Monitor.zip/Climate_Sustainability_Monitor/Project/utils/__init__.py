"""Utility modules for Climate Sustainability Monitor."""
