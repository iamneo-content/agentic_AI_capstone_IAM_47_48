"""
Output Processing and Saving Utility

Handles processing and saving of flow execution results to files.
"""

import json
import os
from pathlib import Path
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


def save_complete_output(output: str, filename: str = "complete_output.txt") -> bool:
    """
    Save complete output to a file in the outputs directory.

    Args:
        output: The output string to save
        filename: Name of the output file

    Returns:
        True if successful, False otherwise
    """
    try:
        output_dir = Path(__file__).parent.parent / 'outputs'
        output_dir.mkdir(parents=True, exist_ok=True)

        output_file = output_dir / filename

        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(output)

        logger.info(f"Complete output saved to: {output_file}")
        return True

    except Exception as e:
        logger.error(f"Error saving complete output: {e}")
        return False


def extract_and_save_components(result: dict) -> bool:
    """
    Extract and save individual components from execution results.

    Args:
        result: The result dictionary from flow execution

    Returns:
        True if successful, False otherwise
    """
    try:
        output_dir = Path(__file__).parent.parent / 'outputs'

        if 'results' in result and 'action_recommendations' in result['results']:
            reports_dir = output_dir / 'reports'
            reports_dir.mkdir(parents=True, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = reports_dir / f"climate_report_{timestamp}.json"

            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(result['results']['action_recommendations'], f, indent=2)

            logger.info(f"Climate report saved to: {report_file}")

        if 'metrics' in result:
            analytics_dir = output_dir / 'analytics'
            analytics_dir.mkdir(parents=True, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            analytics_file = analytics_dir / f"analytics_{timestamp}.json"

            with open(analytics_file, 'w', encoding='utf-8') as f:
                json.dump(result['metrics'], f, indent=2)

            logger.info(f"Analytics saved to: {analytics_file}")

        return True

    except Exception as e:
        logger.error(f"Error extracting and saving components: {e}")
        return False


def process_and_save_results(result) -> bool:
    """
    Main function that processes and saves all results from flow execution.

    Args:
        result: The result object from flow execution

    Returns:
        True if successful, False otherwise
    """
    try:
        if hasattr(result, '__dict__'):
            result_dict = result.__dict__
        elif isinstance(result, dict):
            result_dict = result
        else:
            result_dict = {"raw_result": str(result)}

        output_json = json.dumps(result_dict, indent=2, default=str)
        save_complete_output(output_json, "complete_output.json")

        save_complete_output(str(result), "complete_output.txt")

        if isinstance(result_dict, dict):
            extract_and_save_components(result_dict)

        return True

    except Exception as e:
        logger.error(f"Error processing and saving results: {e}")
        return False
