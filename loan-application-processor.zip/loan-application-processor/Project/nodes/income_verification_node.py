"""
Income Verification Node

Wrapper for Income Verification Agent.
"""

import logging
from state import LoanApplicationState
from agents import IncomeVerificationAgent

logger = logging.getLogger("node.income_verification")


def income_verification_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Verify income and employment stability

    Args:
        state: Current loan application state

    Returns:
        Updated state with income verification results
    """
    logger.info("Income Verification Node: Verifying income")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = IncomeVerificationAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.income_verification_results = [result]

        logger.info(
            f"Income verification complete - Status: {result.get('verification_status', 'N/A')}"
        )

    except Exception as e:
        logger.error(f"Error in income verification: {str(e)}")
        new_state.income_verification_results = [{
            "agent": "IncomeVerification",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
