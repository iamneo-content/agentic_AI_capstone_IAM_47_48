"""
Collateral Evaluation Node

Wrapper for Collateral Evaluator Agent.
"""

import logging
from state import LoanApplicationState
from agents import CollateralEvaluatorAgent

logger = logging.getLogger("node.collateral_evaluation")


def collateral_evaluation_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Evaluate collateral and calculate LTV ratio

    Args:
        state: Current loan application state

    Returns:
        Updated state with collateral evaluation results
    """
    logger.info("Collateral Evaluation Node: Evaluating collateral")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = CollateralEvaluatorAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.collateral_evaluation_results = [result]

        logger.info(
            f"Collateral evaluation complete - Adequacy: {result.get('collateral_adequacy', 'N/A')}"
        )

    except Exception as e:
        logger.error(f"Error in collateral evaluation: {str(e)}")
        new_state.collateral_evaluation_results = [{
            "agent": "CollateralEvaluator",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
