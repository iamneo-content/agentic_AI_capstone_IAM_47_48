"""
Input Validation Node

Validates and enriches loan application input data.
"""

import logging
from datetime import datetime
from state import LoanApplicationState

logger = logging.getLogger("node.input_validation")


def input_validation_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Validate and enrich input data

    Args:
        state: Current loan application state

    Returns:
        Updated state with validation results
    """
    logger.info("Stage 1: Input Validation")

    # Create a working copy
    new_state = state.clone()

    try:
        # Validate required fields
        errors = []

        if not new_state.applicant_name:
            errors.append("Applicant name is required")

        if not new_state.loan_amount or new_state.loan_amount <= 0:
            errors.append("Valid loan amount is required")

        if not new_state.credit_score or new_state.credit_score < 300:
            errors.append("Valid credit score is required")

        if not new_state.annual_income or new_state.annual_income <= 0:
            errors.append("Annual income is required")

        # Set validation errors if any
        if errors:
            new_state.error = "; ".join(errors)
            logger.error(f"Validation failed: {new_state.error}")
            return new_state

        # Enrich state with calculated values
        if not new_state.monthly_income:
            new_state.monthly_income = new_state.annual_income / 12

        # Calculate total monthly debt from existing debts if not provided
        if not new_state.monthly_debt_payments and new_state.existing_debts:
            new_state.monthly_debt_payments = sum(
                debt.get("monthly_payment", 0) for debt in new_state.existing_debts
            )

        # Set timestamp
        new_state.updated_at = datetime.now().isoformat()

        logger.info(
            f"Input validation successful - Application: {new_state.application_id}, "
            f"Loan Amount: ${new_state.loan_amount:,.2f}, "
            f"Credit Score: {new_state.credit_score}"
        )

    except Exception as e:
        logger.error(f"Error in input validation: {str(e)}")
        new_state.error = f"Validation error: {str(e)}"

    return new_state
