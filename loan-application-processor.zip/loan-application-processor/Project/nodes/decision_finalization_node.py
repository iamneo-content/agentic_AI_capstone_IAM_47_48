"""
Decision Finalization Node

Finalizes loan decision and prepares approval/denial documentation.
"""

import logging
from datetime import datetime
from state import LoanApplicationState

logger = logging.getLogger("node.decision_finalization")


def decision_finalization_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Finalize loan decision with all details

    Args:
        state: Current loan application state

    Returns:
        Updated state with finalized decision
    """
    logger.info("Stage 4: Decision Finalization")

    # Create a working copy
    new_state = state.clone()

    try:
        decision = new_state.decision

        # Generate improvement suggestions for denials
        if decision == "DENIED":
            new_state.improvement_suggestions = _generate_improvement_suggestions(new_state)

        # Add additional conditions for conditional approvals
        if decision == "CONDITIONAL_APPROVAL":
            # Ensure all conditions are documented
            if not new_state.conditions:
                new_state.conditions = ["Complete additional verification as requested"]

        # Update timestamp
        new_state.updated_at = datetime.now().isoformat()

        logger.info(
            f"Decision finalization complete - "
            f"Decision: {decision}, "
            f"Approved Amount: ${new_state.approved_amount:,.2f}" if decision != "DENIED" else f"Decision: {decision}"
        )

    except Exception as e:
        logger.error(f"Error finalizing decision: {str(e)}")
        new_state.error = f"Decision finalization error: {str(e)}"

    return new_state


def _generate_improvement_suggestions(state: LoanApplicationState) -> list:
    """Generate suggestions for improving loan application"""
    suggestions = []

    # Credit score improvements
    if state.credit_score < 670:
        suggestions.append("Improve credit score by paying bills on time and reducing credit utilization")

    # Income improvements
    income_results = state.income_verification_results
    if income_results:
        income_status = income_results[0].get("verification_status", "")
        if income_status in ["INSUFFICIENT_INCOME", "EMPLOYMENT_CONCERN"]:
            suggestions.append("Increase income or wait for longer employment history")

    # DTI improvements
    dti_results = state.debt_to_income_results
    if dti_results:
        dti_level = dti_results[0].get("dti_level", "")
        if dti_level in ["HIGH", "CRITICAL"]:
            suggestions.append("Pay down existing debts to improve debt-to-income ratio")

    # Collateral improvements
    collateral_results = state.collateral_evaluation_results
    if collateral_results:
        collateral_adequacy = collateral_results[0].get("collateral_adequacy", "")
        if collateral_adequacy in ["INSUFFICIENT", "MISSING_REQUIRED"]:
            suggestions.append("Provide adequate collateral or increase down payment")

    # General suggestions
    if not suggestions:
        suggestions.append("Reapply after 6-12 months of improved financial management")
        suggestions.append("Consider a co-signer with stronger financial profile")

    return suggestions
