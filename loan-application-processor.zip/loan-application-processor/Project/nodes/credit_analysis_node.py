"""
Credit Analysis Node

Wrapper for Credit Score Agent.
"""

import logging
from state import LoanApplicationState
from agents import CreditScoreAgent

logger = logging.getLogger("node.credit_analysis")


def credit_analysis_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Analyze credit score and creditworthiness

    Args:
        state: Current loan application state

    Returns:
        Updated state with credit analysis results
    """
    logger.info("Credit Analysis Node: Analyzing credit score")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = CreditScoreAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.credit_analysis_results = [result]

        logger.info(
            f"Credit analysis complete - Rating: {result.get('credit_rating', 'N/A')}"
        )

    except Exception as e:
        logger.error(f"Error in credit analysis: {str(e)}")
        new_state.credit_analysis_results = [{
            "agent": "CreditScoreAnalyzer",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
