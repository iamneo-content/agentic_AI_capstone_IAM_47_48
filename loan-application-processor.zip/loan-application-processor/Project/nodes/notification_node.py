"""
Notification Node

Sends email notifications with loan decision results.
"""

import logging
from datetime import datetime
from state import LoanApplicationState
from services.email_service import EmailService

logger = logging.getLogger("node.notification")


def notification_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Send email notification with loan decision

    Args:
        state: Current loan application state

    Returns:
        Updated state with notification status
    """
    logger.info("Stage 5: Notification")

    # Create a working copy
    new_state = state.clone()

    try:
        # Check if email is provided
        if not new_state.applicant_email:
            logger.warning("No email address provided - skipping notification")
            new_state.workflow_complete = True
            new_state.updated_at = datetime.now().isoformat()
            return new_state

        # Initialize email service
        email_service = EmailService()

        # Format decision summary
        summary = _format_decision_summary(new_state)

        # Send email
        success = email_service.send_loan_decision(
            to_email=new_state.applicant_email,
            applicant_name=new_state.applicant_name,
            application_id=new_state.application_id,
            decision=new_state.decision,
            loan_amount=new_state.loan_amount,
            decision_summary=summary
        )

        # Record notification
        notification = {
            "type": "email",
            "recipient": new_state.applicant_email,
            "status": "sent" if success else "failed",
            "timestamp": datetime.now().isoformat()
        }
        new_state.notifications_sent.append(notification)

        if success:
            logger.info(f"Notification sent to {new_state.applicant_email}")
        else:
            logger.warning(f"Failed to send notification to {new_state.applicant_email}")

        # Mark workflow as complete
        new_state.workflow_complete = True
        new_state.updated_at = datetime.now().isoformat()

    except Exception as e:
        logger.error(f"Error sending notification: {str(e)}")
        new_state.notifications_sent.append({
            "type": "email",
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        })
        new_state.workflow_complete = True  # Complete even on error

    return new_state


def _format_decision_summary(state: LoanApplicationState) -> str:
    """Format decision summary for email"""
    lines = []

    # Decision and application details
    lines.append(f"Application ID: {state.application_id}")
    lines.append(f"Decision: {state.decision}")
    lines.append(f"Risk Score: {state.overall_risk_score:.1f}/10")
    lines.append(f"Confidence: {state.confidence_level}")
    lines.append("")

    # Loan details
    lines.append(f"Requested Amount: ${state.loan_amount:,.2f}")
    lines.append(f"Purpose: {state.loan_purpose}")
    lines.append("")

    # Approval details
    if state.decision in ["APPROVED", "CONDITIONAL_APPROVAL"]:
        lines.append("Approved Terms:")
        lines.append(f"  Amount: ${state.approved_amount:,.2f}")
        lines.append(f"  Interest Rate: {state.approved_interest_rate:.2f}%")
        lines.append(f"  Term: {state.approved_term_months} months")
        lines.append(f"  Monthly Payment: ${state.monthly_payment:,.2f}")
        lines.append("")

        if state.conditions:
            lines.append("Conditions:")
            for condition in state.conditions:
                lines.append(f"  - {condition}")
            lines.append("")

    # Denial details
    if state.decision == "DENIED":
        if state.denial_reasons:
            lines.append("Denial Reasons:")
            for reason in state.denial_reasons:
                lines.append(f"  - {reason}")
            lines.append("")

        if state.improvement_suggestions:
            lines.append("Improvement Suggestions:")
            for suggestion in state.improvement_suggestions[:5]:
                lines.append(f"  - {suggestion}")
            lines.append("")

    # Rationale
    if state.coordination_summary:
        rationale = state.coordination_summary.get("decision_rationale", "")
        if rationale:
            lines.append(f"Rationale: {rationale}")

    return "\n".join(lines)
