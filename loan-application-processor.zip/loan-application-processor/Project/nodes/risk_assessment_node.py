"""
Risk Assessment Node

Wrapper for Risk Assessment Agent.
"""

import logging
from state import LoanApplicationState
from agents import RiskAssessmentAgent

logger = logging.getLogger("node.risk_assessment")


def risk_assessment_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Perform comprehensive risk assessment

    Args:
        state: Current loan application state

    Returns:
        Updated state with risk assessment results
    """
    logger.info("Risk Assessment Node: Performing risk assessment")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = RiskAssessmentAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.risk_assessment_results = [result]

        logger.info(
            f"Risk assessment complete - Risk Level: {result.get('risk_level', 'N/A')}, "
            f"Score: {result.get('risk_score', 0):.2f}"
        )

    except Exception as e:
        logger.error(f"Error in risk assessment: {str(e)}")
        new_state.risk_assessment_results = [{
            "agent": "RiskAssessment",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
