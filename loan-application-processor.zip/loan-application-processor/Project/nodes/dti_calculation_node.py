"""
Debt-to-Income Calculation Node

Wrapper for Debt-to-Income Agent.
"""

import logging
from state import LoanApplicationState
from agents import DebtToIncomeAgent

logger = logging.getLogger("node.dti_calculation")


def dti_calculation_node(state: LoanApplicationState) -> LoanApplicationState:
    """
    Calculate debt-to-income ratio

    Args:
        state: Current loan application state

    Returns:
        Updated state with DTI calculation results
    """
    logger.info("DTI Calculation Node: Calculating debt-to-income ratio")

    # Create a working copy
    new_state = state.clone()

    try:
        # Initialize and run agent
        agent = DebtToIncomeAgent()
        result = agent.analyze(new_state)

        # Update state
        new_state.debt_to_income_results = [result]

        logger.info(
            f"DTI calculation complete - New DTI: {result.get('new_dti_ratio', 0):.2%}"
        )

    except Exception as e:
        logger.error(f"Error in DTI calculation: {str(e)}")
        new_state.debt_to_income_results = [{
            "agent": "DebtToIncome",
            "status": "error",
            "error_message": str(e)
        }]

    return new_state
