"""
Email Service

Sends email notifications with loan decision results.
"""

import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional

from config import ConfigManager


class EmailService:
    """Service for sending email notifications"""

    def __init__(self):
        self.logger = logging.getLogger("service.email")
        self.config = ConfigManager()

        # Email configuration
        self.smtp_server = self.config.get("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = self.config.get("SMTP_PORT", 587)
        self.smtp_username = self.config.get("SMTP_USERNAME", "")
        self.smtp_password = self.config.get("SMTP_PASSWORD", "")
        self.from_email = self.config.get("FROM_EMAIL", "noreply@loanprocessor.com")

        # Check if email is configured
        self.is_configured = bool(self.smtp_username and self.smtp_password)
        if not self.is_configured:
            self.logger.warning("Email service not configured - notifications will not be sent")

    def send_loan_decision(
        self,
        to_email: str,
        applicant_name: str,
        application_id: str,
        decision: str,
        loan_amount: float,
        decision_summary: str
    ) -> bool:
        """
        Send loan decision email to applicant

        Args:
            to_email: Recipient email address
            applicant_name: Applicant's name
            application_id: Application ID
            decision: Loan decision (APPROVED, DENIED, CONDITIONAL_APPROVAL)
            loan_amount: Requested loan amount
            decision_summary: Formatted decision summary

        Returns:
            True if sent successfully, False otherwise
        """
        if not self.is_configured:
            self.logger.warning("Email service not configured - skipping send")
            return False

        try:
            # Create message
            msg = MIMEMultipart("alternative")
            msg["Subject"] = f"Loan Application Decision - {application_id}"
            msg["From"] = self.from_email
            msg["To"] = to_email

            # Create email body
            text_body = self._create_text_body(
                applicant_name, application_id, decision, loan_amount, decision_summary
            )
            html_body = self._create_html_body(
                applicant_name, application_id, decision, loan_amount, decision_summary
            )

            # Attach both plain text and HTML versions
            part1 = MIMEText(text_body, "plain")
            part2 = MIMEText(html_body, "html")
            msg.attach(part1)
            msg.attach(part2)

            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(msg)

            self.logger.info(f"Loan decision email sent to {to_email}")
            return True

        except Exception as e:
            self.logger.error(f"Failed to send email: {str(e)}")
            return False

    def _create_text_body(
        self,
        applicant_name: str,
        application_id: str,
        decision: str,
        loan_amount: float,
        decision_summary: str
    ) -> str:
        """Create plain text email body"""
        return f"""
Dear {applicant_name},

Thank you for applying for a loan with us.

We have completed the review of your loan application (ID: {application_id}).

DECISION: {decision}

Loan Amount Requested: ${loan_amount:,.2f}

{decision_summary}

---
This decision was made by our AI-powered multi-agent loan processing system based on comprehensive analysis of your credit, income, debt obligations, collateral, and overall risk profile.

If you have any questions about this decision, please contact our loan services department.

Sincerely,
Loan Processing Team
        """.strip()

    def _create_html_body(
        self,
        applicant_name: str,
        application_id: str,
        decision: str,
        loan_amount: float,
        decision_summary: str
    ) -> str:
        """Create HTML email body"""
        # Determine decision color
        decision_colors = {
            "APPROVED": "#28a745",
            "CONDITIONAL_APPROVAL": "#ffc107",
            "DENIED": "#dc3545",
            "ERROR": "#6c757d"
        }
        decision_color = decision_colors.get(decision, "#6c757d")

        # Determine decision icon
        decision_icons = {
            "APPROVED": "✓",
            "CONDITIONAL_APPROVAL": "⚠",
            "DENIED": "✗",
            "ERROR": "!"
        }
        decision_icon = decision_icons.get(decision, "•")

        # Format summary with HTML line breaks
        formatted_summary = decision_summary.replace("\n", "<br>")

        return f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
        }}
        .container {{
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }}
        .header {{
            background-color: #004085;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 5px 5px 0 0;
        }}
        .content {{
            background-color: #f8f9fa;
            padding: 20px;
            border: 1px solid #dee2e6;
        }}
        .decision-box {{
            background-color: {decision_color};
            color: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }}
        .summary {{
            background-color: white;
            padding: 15px;
            margin: 15px 0;
            border-left: 4px solid #004085;
        }}
        .footer {{
            text-align: center;
            padding: 20px;
            color: #6c757d;
            font-size: 0.9em;
        }}
        .amount {{
            font-size: 20px;
            font-weight: bold;
            color: #004085;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>💰 Loan Application Decision</h1>
            <p>Application ID: {application_id}</p>
        </div>

        <div class="content">
            <p>Dear <strong>{applicant_name}</strong>,</p>

            <p>Thank you for applying for a loan with us. We have completed the review of your application.</p>

            <div class="decision-box">
                {decision_icon} {decision}
            </div>

            <p class="amount">Requested Amount: ${loan_amount:,.2f}</p>

            <div class="summary">
                <p>{formatted_summary}</p>
            </div>

            <p>If you have any questions about this decision, please don't hesitate to contact our loan services department.</p>

            <p><strong>Sincerely,<br>Loan Processing Team</strong></p>
        </div>

        <div class="footer">
            <p>This decision was made by our AI-powered multi-agent loan processing system based on comprehensive analysis of your credit, income, debt obligations, collateral, and overall risk profile.</p>
            <p>&copy; 2024 Loan Application Processor. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
        """.strip()
