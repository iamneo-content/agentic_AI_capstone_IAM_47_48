"""Services for loan application processor"""

from .email_service import EmailService

__all__ = ["EmailService"]
