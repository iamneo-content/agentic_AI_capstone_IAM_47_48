"""
Income Verifier

Verifies applicant income, employment stability, and
calculates income-to-loan ratios.
"""

from typing import Dict, Any
import logging
from config import ConfigManager


class IncomeVerifier:
    """Analyzer for income verification"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.income")
        self.config = ConfigManager()

    def verify_income(
        self,
        annual_income: float = None,
        monthly_income: float = None,
        employment_status: str = None,
        employment_duration_months: int = None,
        loan_amount: float = None,
        documents_provided: bool = None
    ) -> Dict[str, Any]:
        """
        Verify income and assess ability to repay

        Can be called with individual parameters or with a single dict parameter.

        Args:
            annual_income: Annual income amount OR full application dict
            monthly_income: Monthly income amount
            employment_status: Employment status
            employment_duration_months: Duration of current employment
            loan_amount: Requested loan amount
            documents_provided: Whether income documents are provided

        Returns:
            Income verification results with stability assessment
        """
        # Support dict input for backwards compatibility
        if isinstance(annual_income, dict):
            app_data = annual_income
            annual_income = app_data.get("annual_income", 0.0)
            monthly_income = app_data.get("monthly_income", annual_income / 12)
            employment_status = app_data.get("applicant", {}).get("employment_status", "employed")
            employment_duration_months = app_data.get("employment_duration_months", 12)
            loan_amount = app_data.get("loan_amount", 0.0)
            documents_provided = app_data.get("income_documents_provided", False)

        # Set defaults if None
        if annual_income is None:
            annual_income = 0.0
        if monthly_income is None:
            monthly_income = annual_income / 12
        if employment_status is None:
            employment_status = "employed"
        if employment_duration_months is None:
            employment_duration_months = 0
        if loan_amount is None:
            loan_amount = 0.0
        if documents_provided is None:
            documents_provided = False

        self.logger.info(f"Verifying income: ${annual_income:,.2f} annually")

        # Verify income consistency
        calculated_monthly = annual_income / 12
        income_consistent = abs(monthly_income - calculated_monthly) / calculated_monthly < 0.1

        # Calculate income-to-loan ratio
        income_to_loan_ratio = annual_income / loan_amount if loan_amount > 0 else 0

        # Check minimum income requirement
        min_multiplier = self.config.get("MIN_INCOME_MULTIPLIER", 0.25)
        meets_minimum = income_to_loan_ratio >= min_multiplier

        # Assess employment stability
        employment_stability = self._assess_employment_stability(
            employment_status, employment_duration_months
        )

        # Calculate income score (0-10)
        income_score = self._calculate_income_score(
            income_to_loan_ratio,
            employment_stability,
            documents_provided,
            income_consistent
        )

        # Determine verification status
        verification_status = self._determine_verification_status(
            meets_minimum,
            employment_stability,
            documents_provided,
            income_consistent
        )

        return {
            "agent": "IncomeVerification",
            "status": "success",
            "verification_status": verification_status,
            "income_score": income_score,
            "annual_income": annual_income,
            "monthly_income": monthly_income,
            "income_to_loan_ratio": income_to_loan_ratio,
            "meets_minimum_income": meets_minimum,
            "income_consistent": income_consistent,
            "employment_status": employment_status,
            "employment_stability": employment_stability,
            "employment_duration_months": employment_duration_months,
            "documents_provided": documents_provided,
            "income_insights": self._generate_income_insights(
                income_to_loan_ratio, employment_stability, documents_provided
            ),
            "required_documents": self._get_required_documents(employment_status, documents_provided)
        }

    def _assess_employment_stability(
        self,
        employment_status: str,
        employment_duration_months: int
    ) -> str:
        """Assess employment stability"""
        stable_months = self.config.get("STABLE_EMPLOYMENT_MONTHS", 12)

        if employment_status.lower() == "unemployed":
            return "UNSTABLE"
        elif employment_status.lower() == "retired":
            return "STABLE"
        elif employment_status.lower() == "self-employed":
            if employment_duration_months >= stable_months * 2:  # Higher threshold for self-employed
                return "STABLE"
            elif employment_duration_months >= stable_months:
                return "MODERATE"
            else:
                return "UNSTABLE"
        else:  # employed
            if employment_duration_months >= stable_months * 2:
                return "VERY_STABLE"
            elif employment_duration_months >= stable_months:
                return "STABLE"
            elif employment_duration_months >= 6:
                return "MODERATE"
            else:
                return "UNSTABLE"

    def _calculate_income_score(
        self,
        income_to_loan_ratio: float,
        employment_stability: str,
        documents_provided: bool,
        income_consistent: bool
    ) -> float:
        """Calculate income score (0-10)"""
        score = 5.0  # Base score

        # Income to loan ratio contribution
        if income_to_loan_ratio >= 1.0:
            score += 2.5
        elif income_to_loan_ratio >= 0.5:
            score += 2.0
        elif income_to_loan_ratio >= 0.25:
            score += 1.0
        else:
            score -= 1.0

        # Employment stability contribution
        stability_scores = {
            "VERY_STABLE": 2.5,
            "STABLE": 2.0,
            "MODERATE": 1.0,
            "UNSTABLE": -1.5
        }
        score += stability_scores.get(employment_stability, 0)

        # Documentation contribution
        if documents_provided:
            score += 0.5
        else:
            score -= 0.5

        # Consistency contribution
        if income_consistent:
            score += 0.5
        else:
            score -= 0.5

        return max(0.0, min(10.0, score))

    def _determine_verification_status(
        self,
        meets_minimum: bool,
        employment_stability: str,
        documents_provided: bool,
        income_consistent: bool
    ) -> str:
        """Determine overall verification status"""
        if not meets_minimum:
            return "INSUFFICIENT_INCOME"

        if employment_stability == "UNSTABLE":
            return "EMPLOYMENT_CONCERN"

        if not documents_provided:
            return "DOCUMENTATION_REQUIRED"

        if not income_consistent:
            return "VERIFICATION_NEEDED"

        if employment_stability in ["VERY_STABLE", "STABLE"] and documents_provided:
            return "VERIFIED"
        else:
            return "PARTIALLY_VERIFIED"

    def _generate_income_insights(
        self,
        income_to_loan_ratio: float,
        employment_stability: str,
        documents_provided: bool
    ) -> list:
        """Generate insights about income verification"""
        insights = []

        if income_to_loan_ratio >= 1.0:
            insights.append("Strong income-to-loan ratio indicates good repayment capacity")
        elif income_to_loan_ratio >= 0.5:
            insights.append("Adequate income relative to loan amount")
        elif income_to_loan_ratio >= 0.25:
            insights.append("Income meets minimum requirements but limited cushion")
        else:
            insights.append("Income may be insufficient for requested loan amount")

        if employment_stability in ["VERY_STABLE", "STABLE"]:
            insights.append("Stable employment history supports loan approval")
        elif employment_stability == "MODERATE":
            insights.append("Moderately stable employment may require additional review")
        else:
            insights.append("Employment stability concerns may affect approval")

        if not documents_provided:
            insights.append("Income documentation required for verification")

        return insights

    def _get_required_documents(self, employment_status: str, documents_provided: bool) -> list:
        """Get list of required documents"""
        if documents_provided:
            return []

        documents = []

        if employment_status.lower() == "employed":
            documents.extend([
                "Recent pay stubs (last 2-3 months)",
                "W-2 forms or tax returns (last 2 years)",
                "Employment verification letter"
            ])
        elif employment_status.lower() == "self-employed":
            documents.extend([
                "Tax returns (last 2 years)",
                "Profit and loss statements",
                "Business bank statements (last 6 months)",
                "CPA letter or business license"
            ])
        elif employment_status.lower() == "retired":
            documents.extend([
                "Social Security or pension statements",
                "Retirement account statements",
                "Tax returns (last year)"
            ])

        return documents
