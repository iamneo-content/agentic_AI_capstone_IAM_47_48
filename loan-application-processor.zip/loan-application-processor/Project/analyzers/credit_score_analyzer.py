"""
Credit Score Analyzer

Analyzes credit scores and determines creditworthiness,
risk levels, and recommended interest rates.
"""

from typing import Dict, Any, List
import logging
from config import ConfigManager


class CreditScoreAnalyzer:
    """Analyzer for credit score assessment"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.credit_score")
        self.config = ConfigManager()

    def analyze_credit(
        self,
        credit_score: int = None,
        loan_amount: float = None,
        loan_purpose: str = None,
        existing_debts: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyze credit score and determine creditworthiness

        Can be called with individual parameters or with a single dict parameter.

        Args:
            credit_score: Applicant's credit score (300-850) OR full application dict
            loan_amount: Requested loan amount
            loan_purpose: Purpose of the loan
            existing_debts: List of existing debts

        Returns:
            Credit analysis with rating and recommendations
        """
        # Support dict input for backwards compatibility
        if isinstance(credit_score, dict):
            app_data = credit_score
            credit_score = app_data.get("credit_score", 0)
            loan_amount = app_data.get("loan_amount", 0.0)
            loan_purpose = app_data.get("loan_purpose", "")
            existing_debts = app_data.get("existing_debts", [])

        # Set defaults if None
        if existing_debts is None:
            existing_debts = []
        if loan_purpose is None:
            loan_purpose = ""
        if loan_amount is None:
            loan_amount = 0.0
        if credit_score is None:
            credit_score = 0
        self.logger.info(f"Analyzing credit score: {credit_score}")

        # Determine credit rating
        credit_rating = self._determine_credit_rating(credit_score)

        # Calculate credit score value (normalized 0-10)
        credit_score_value = self._normalize_credit_score(credit_score)

        # Determine risk level
        risk_level = self._determine_risk_level(credit_score)

        # Get recommended interest rate
        recommended_rate = self._get_recommended_rate(credit_score, loan_purpose)

        # Analyze credit utilization (if debt info available)
        total_existing_debt = sum(debt.get("balance", 0) for debt in existing_debts)

        # Generate credit insights
        insights = self._generate_credit_insights(
            credit_score, credit_rating, existing_debts
        )

        return {
            "agent": "CreditScoreAnalyzer",
            "status": "success",
            "credit_score": credit_score,
            "credit_rating": credit_rating,
            "credit_score_value": credit_score_value,
            "risk_level": risk_level,
            "recommended_interest_rate": recommended_rate,
            "total_existing_debt": total_existing_debt,
            "number_of_existing_debts": len(existing_debts),
            "credit_insights": insights,
            "approval_likelihood": self._get_approval_likelihood(credit_rating),
            "improvement_tips": self._get_improvement_tips(credit_rating)
        }

    def _determine_credit_rating(self, credit_score: int) -> str:
        """Determine credit rating category"""
        excellent_threshold = self.config.get("EXCELLENT_CREDIT_THRESHOLD", 750)
        good_threshold = self.config.get("GOOD_CREDIT_THRESHOLD", 670)
        fair_threshold = self.config.get("FAIR_CREDIT_THRESHOLD", 580)

        if credit_score >= excellent_threshold:
            return "EXCELLENT"
        elif credit_score >= good_threshold:
            return "GOOD"
        elif credit_score >= fair_threshold:
            return "FAIR"
        elif credit_score >= 500:
            return "POOR"
        else:
            return "VERY_POOR"

    def _normalize_credit_score(self, credit_score: int) -> float:
        """Normalize credit score to 0-10 scale"""
        # Map 300-850 range to 0-10
        min_score = 300
        max_score = 850

        normalized = ((credit_score - min_score) / (max_score - min_score)) * 10
        return max(0.0, min(10.0, normalized))

    def _determine_risk_level(self, credit_score: int) -> str:
        """Determine risk level based on credit score"""
        excellent_threshold = self.config.get("EXCELLENT_CREDIT_THRESHOLD", 750)
        good_threshold = self.config.get("GOOD_CREDIT_THRESHOLD", 670)
        fair_threshold = self.config.get("FAIR_CREDIT_THRESHOLD", 580)

        if credit_score >= excellent_threshold:
            return "LOW"
        elif credit_score >= good_threshold:
            return "MODERATE"
        elif credit_score >= fair_threshold:
            return "MODERATE_HIGH"
        else:
            return "HIGH"

    def _get_recommended_rate(self, credit_score: int, loan_purpose: str) -> float:
        """Get recommended interest rate based on credit score"""
        excellent_threshold = self.config.get("EXCELLENT_CREDIT_THRESHOLD", 750)
        good_threshold = self.config.get("GOOD_CREDIT_THRESHOLD", 670)
        fair_threshold = self.config.get("FAIR_CREDIT_THRESHOLD", 580)

        # Base rates from config
        if credit_score >= excellent_threshold:
            base_rate = self.config.get("EXCELLENT_CREDIT_RATE", 4.5)
        elif credit_score >= good_threshold:
            base_rate = self.config.get("GOOD_CREDIT_RATE", 6.0)
        elif credit_score >= fair_threshold:
            base_rate = self.config.get("FAIR_CREDIT_RATE", 8.5)
        else:
            base_rate = self.config.get("POOR_CREDIT_RATE", 12.0)

        # Adjust for loan purpose
        if loan_purpose.lower() == "home":
            return base_rate * 0.9  # Lower rate for mortgages
        elif loan_purpose.lower() == "auto":
            return base_rate * 0.95  # Slightly lower for auto loans
        elif loan_purpose.lower() == "business":
            return base_rate * 1.1  # Higher for business loans
        else:
            return base_rate

    def _generate_credit_insights(
        self,
        credit_score: int,
        credit_rating: str,
        existing_debts: List[Dict[str, Any]]
    ) -> List[str]:
        """Generate insights about credit profile"""
        insights = []

        if credit_rating == "EXCELLENT":
            insights.append("Excellent credit history demonstrates strong financial responsibility")
        elif credit_rating == "GOOD":
            insights.append("Good credit score qualifies for competitive interest rates")
        elif credit_rating == "FAIR":
            insights.append("Fair credit score may result in higher interest rates")
        else:
            insights.append("Credit score below optimal range may limit loan options")

        # Debt analysis
        if len(existing_debts) == 0:
            insights.append("No existing debts reported shows good debt management")
        elif len(existing_debts) > 5:
            insights.append(f"Multiple existing debts ({len(existing_debts)}) may impact approval")

        return insights

    def _get_approval_likelihood(self, credit_rating: str) -> str:
        """Get approval likelihood based on credit rating"""
        likelihood_map = {
            "EXCELLENT": "VERY_HIGH",
            "GOOD": "HIGH",
            "FAIR": "MODERATE",
            "POOR": "LOW",
            "VERY_POOR": "VERY_LOW"
        }
        return likelihood_map.get(credit_rating, "UNKNOWN")

    def _get_improvement_tips(self, credit_rating: str) -> List[str]:
        """Get tips for credit improvement"""
        if credit_rating in ["EXCELLENT", "GOOD"]:
            return ["Maintain current good credit practices"]

        tips = [
            "Pay all bills on time to improve payment history",
            "Keep credit card balances below 30% of credit limits",
            "Avoid opening multiple new credit accounts"
        ]

        if credit_rating in ["POOR", "VERY_POOR"]:
            tips.append("Consider credit counseling services")
            tips.append("Review credit report for errors and dispute inaccuracies")

        return tips
