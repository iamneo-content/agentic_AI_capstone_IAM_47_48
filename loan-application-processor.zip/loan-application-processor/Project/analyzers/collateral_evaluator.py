"""
Collateral Evaluator

Evaluates collateral value and calculates loan-to-value (LTV) ratios
for secured loans.
"""

from typing import Dict, Any
import logging
from config import ConfigManager


class CollateralEvaluator:
    """Analyzer for collateral evaluation"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.collateral")
        self.config = ConfigManager()

    def evaluate_collateral(
        self,
        collateral_type: str = None,
        collateral_value: float = None,
        collateral_details: Dict[str, Any] = None,
        loan_amount: float = None,
        loan_purpose: str = None
    ) -> Dict[str, Any]:
        """
        Evaluate collateral and calculate LTV ratio

        Can be called with individual parameters or with a single dict parameter.

        Args:
            collateral_type: Type of collateral (property, vehicle, securities, none) OR full application dict
            collateral_value: Estimated value of collateral
            collateral_details: Additional collateral details
            loan_amount: Requested loan amount
            loan_purpose: Purpose of the loan

        Returns:
            Collateral evaluation with LTV assessment
        """
        # Support dict input for backwards compatibility
        if isinstance(collateral_type, dict):
            app_data = collateral_type
            collateral_info = app_data.get("collateral", {})
            collateral_type = collateral_info.get("type", "none")
            collateral_value = collateral_info.get("value", 0.0)
            collateral_details = collateral_info
            loan_amount = app_data.get("loan_amount", 0.0)
            loan_purpose = app_data.get("loan_purpose", "")

        # Set defaults if None
        if collateral_type is None:
            collateral_type = "none"
        if collateral_value is None:
            collateral_value = 0.0
        if collateral_details is None:
            collateral_details = {}
        if loan_amount is None:
            loan_amount = 0.0
        if loan_purpose is None:
            loan_purpose = ""

        self.logger.info(f"Evaluating collateral: {collateral_type or 'None'}")

        # Check if collateral is provided
        has_collateral = bool(collateral_type and collateral_type.lower() != "none")

        # Calculate LTV ratio
        ltv_ratio = loan_amount / collateral_value if collateral_value > 0 else 999

        # Determine collateral adequacy
        collateral_adequacy = self._determine_adequacy(
            has_collateral, ltv_ratio, collateral_type, loan_purpose
        )

        # Calculate collateral score (0-10)
        collateral_score = self._calculate_collateral_score(
            has_collateral, ltv_ratio, collateral_type, loan_purpose
        )

        # Assess collateral quality
        collateral_quality = self._assess_collateral_quality(
            collateral_type, collateral_details
        )

        # Calculate maximum loan based on collateral
        max_loan_on_collateral = self._calculate_max_loan(
            collateral_value, collateral_type
        )

        # Determine if collateral is required
        collateral_required = self._is_collateral_required(loan_purpose, loan_amount)

        return {
            "agent": "CollateralEvaluator",
            "status": "success",
            "has_collateral": has_collateral,
            "collateral_type": collateral_type,
            "collateral_value": collateral_value,
            "ltv_ratio": ltv_ratio if has_collateral else 0.0,
            "collateral_adequacy": collateral_adequacy,
            "collateral_score": collateral_score,
            "collateral_quality": collateral_quality,
            "max_loan_on_collateral": max_loan_on_collateral,
            "collateral_required": collateral_required,
            "collateral_insights": self._generate_collateral_insights(
                has_collateral, ltv_ratio, collateral_type, loan_purpose, collateral_required
            ),
            "recommendations": self._generate_recommendations(
                has_collateral, ltv_ratio, collateral_required, loan_purpose
            )
        }

    def _determine_adequacy(
        self,
        has_collateral: bool,
        ltv_ratio: float,
        collateral_type: str,
        loan_purpose: str
    ) -> str:
        """Determine collateral adequacy"""
        # If collateral not required and not provided
        if not self._is_collateral_required(loan_purpose, 0) and not has_collateral:
            return "NOT_REQUIRED"

        if not has_collateral:
            if self._is_collateral_required(loan_purpose, 0):
                return "MISSING_REQUIRED"
            else:
                return "NONE_PROVIDED"

        # Check LTV ratio
        ideal_ltv = self.config.get("IDEAL_LTV_RATIO", 0.80)
        max_ltv = self.config.get("MAX_LTV_RATIO", 0.90)

        if ltv_ratio <= ideal_ltv:
            return "EXCELLENT"
        elif ltv_ratio <= max_ltv:
            return "ADEQUATE"
        else:
            return "INSUFFICIENT"

    def _calculate_collateral_score(
        self,
        has_collateral: bool,
        ltv_ratio: float,
        collateral_type: str,
        loan_purpose: str
    ) -> float:
        """Calculate collateral score (0-10)"""
        if not has_collateral:
            # If collateral not required, give neutral score
            if not self._is_collateral_required(loan_purpose, 0):
                return 7.0
            else:
                return 0.0  # Required but not provided

        # Base score
        score = 5.0

        # LTV contribution
        ideal_ltv = self.config.get("IDEAL_LTV_RATIO", 0.80)
        max_ltv = self.config.get("MAX_LTV_RATIO", 0.90)

        if ltv_ratio <= ideal_ltv:
            score += 3.0
        elif ltv_ratio <= max_ltv:
            score += 2.0
        elif ltv_ratio <= 1.0:
            score += 0.5
        else:
            score -= 2.0

        # Collateral type contribution
        type_scores = {
            "property": 2.0,
            "vehicle": 1.5,
            "securities": 1.0,
            "other": 0.5
        }
        score += type_scores.get(collateral_type.lower(), 0)

        return max(0.0, min(10.0, score))

    def _assess_collateral_quality(
        self,
        collateral_type: str,
        collateral_details: Dict[str, Any]
    ) -> str:
        """Assess quality of collateral"""
        if not collateral_type or collateral_type.lower() == "none":
            return "N/A"

        if collateral_type.lower() == "property":
            # Property is generally high quality
            return "HIGH"
        elif collateral_type.lower() == "vehicle":
            # Check vehicle age if available
            vehicle_age = collateral_details.get("age_years", 0)
            if vehicle_age <= 3:
                return "HIGH"
            elif vehicle_age <= 7:
                return "MEDIUM"
            else:
                return "LOW"
        elif collateral_type.lower() == "securities":
            # Securities are generally good
            return "MEDIUM"
        else:
            return "UNKNOWN"

    def _calculate_max_loan(self, collateral_value: float, collateral_type: str) -> float:
        """Calculate maximum loan amount based on collateral"""
        if collateral_value == 0:
            return 0.0

        max_ltv = self.config.get("MAX_LTV_RATIO", 0.90)

        # Different LTV limits for different collateral types
        if collateral_type.lower() == "property":
            max_ltv_for_type = max_ltv
        elif collateral_type.lower() == "vehicle":
            max_ltv_for_type = max_ltv * 0.9  # Slightly lower for vehicles
        elif collateral_type.lower() == "securities":
            max_ltv_for_type = max_ltv * 0.7  # More conservative for securities
        else:
            max_ltv_for_type = max_ltv * 0.8

        return collateral_value * max_ltv_for_type

    def _is_collateral_required(self, loan_purpose: str, loan_amount: float) -> bool:
        """Determine if collateral is required for loan type"""
        # Typically required for:
        required_purposes = ["home", "auto", "business"]
        return loan_purpose.lower() in required_purposes

    def _generate_collateral_insights(
        self,
        has_collateral: bool,
        ltv_ratio: float,
        collateral_type: str,
        loan_purpose: str,
        collateral_required: bool
    ) -> list:
        """Generate insights about collateral"""
        insights = []

        if not has_collateral:
            if collateral_required:
                insights.append(f"Collateral typically required for {loan_purpose} loans")
                insights.append("Providing collateral will improve approval chances")
            else:
                insights.append("Unsecured loan - approval based on creditworthiness")
            return insights

        if ltv_ratio <= 0.80:
            insights.append("Excellent collateral coverage with low LTV ratio")
        elif ltv_ratio <= 0.90:
            insights.append("Adequate collateral coverage within acceptable range")
        else:
            insights.append("Limited collateral coverage may require additional security")

        if collateral_type.lower() == "property":
            insights.append("Real estate collateral provides strong security")
        elif collateral_type.lower() == "vehicle":
            insights.append("Vehicle collateral subject to depreciation considerations")

        return insights

    def _generate_recommendations(
        self,
        has_collateral: bool,
        ltv_ratio: float,
        collateral_required: bool,
        loan_purpose: str
    ) -> list:
        """Generate recommendations for collateral"""
        recommendations = []

        if not has_collateral and collateral_required:
            recommendations.append("Provide collateral to improve loan terms")
            recommendations.append("Consider secured loan for better interest rates")
            return recommendations

        if has_collateral:
            if ltv_ratio > 0.90:
                recommendations.append("Increase down payment to lower LTV ratio")
                recommendations.append("Consider reducing loan amount")

            if ltv_ratio <= 0.80:
                recommendations.append("Strong collateral position may qualify for premium rates")

        return recommendations
