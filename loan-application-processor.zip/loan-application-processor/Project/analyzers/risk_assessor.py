"""
Risk Assessor

Performs comprehensive risk assessment by analyzing all factors:
credit, income, debt, collateral, and employment stability.
"""

from typing import Dict, Any, List
import logging
from config import ConfigManager


class RiskAssessor:
    """Analyzer for comprehensive risk assessment"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.risk")
        self.config = ConfigManager()

    def assess_risk(
        self,
        credit_score: int = None,
        annual_income: float = None,
        monthly_debt_payments: float = None,
        loan_amount: float = None,
        loan_purpose: str = None,
        employment_status: str = None,
        employment_duration_months: int = None,
        collateral_type: str = None,
        collateral_value: float = None,
        existing_debts: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Perform comprehensive risk assessment

        Can be called with individual parameters or with a single dict parameter.

        Args:
            credit_score: Applicant's credit score OR full application dict
            annual_income: Annual income
            monthly_debt_payments: Monthly debt obligations
            loan_amount: Requested loan amount
            loan_purpose: Purpose of the loan
            employment_status: Employment status
            employment_duration_months: Employment duration
            collateral_type: Type of collateral
            collateral_value: Value of collateral
            existing_debts: List of existing debts

        Returns:
            Comprehensive risk assessment with scores and probability
        """
        # Support dict input for backwards compatibility
        if isinstance(credit_score, dict):
            app_data = credit_score
            credit_score = app_data.get("credit_score", 0)
            annual_income = app_data.get("annual_income", 0.0)
            monthly_debt_payments = app_data.get("monthly_debt_payments", 0.0)
            loan_amount = app_data.get("loan_amount", 0.0)
            loan_purpose = app_data.get("loan_purpose", "")
            employment_status = app_data.get("applicant", {}).get("employment_status", "employed")
            employment_duration_months = app_data.get("employment_duration_months", 12)
            collateral_info = app_data.get("collateral", {})
            collateral_type = collateral_info.get("type", "none")
            collateral_value = collateral_info.get("value", 0.0)
            existing_debts = app_data.get("existing_debts", [])

        # Set defaults if None
        if credit_score is None:
            credit_score = 0
        if annual_income is None:
            annual_income = 0.0
        if monthly_debt_payments is None:
            monthly_debt_payments = 0.0
        if loan_amount is None:
            loan_amount = 0.0
        if loan_purpose is None:
            loan_purpose = ""
        if employment_status is None:
            employment_status = "employed"
        if employment_duration_months is None:
            employment_duration_months = 0
        if collateral_type is None:
            collateral_type = "none"
        if collateral_value is None:
            collateral_value = 0.0
        if existing_debts is None:
            existing_debts = []

        self.logger.info(f"Performing comprehensive risk assessment")

        # Calculate individual risk factors
        credit_risk = self._assess_credit_risk(credit_score)
        income_risk = self._assess_income_risk(annual_income, loan_amount)
        debt_risk = self._assess_debt_risk(monthly_debt_payments, annual_income / 12)
        employment_risk = self._assess_employment_risk(employment_status, employment_duration_months)
        collateral_risk = self._assess_collateral_risk(
            collateral_type, collateral_value, loan_amount, loan_purpose
        )

        # Calculate overall risk score (weighted average)
        risk_score = (
            credit_risk * 0.30 +
            income_risk * 0.20 +
            debt_risk * 0.25 +
            employment_risk * 0.15 +
            collateral_risk * 0.10
        )

        # Determine risk level
        risk_level = self._determine_risk_level(risk_score)

        # Calculate default probability
        default_probability = self._estimate_default_probability(
            credit_score, risk_score, debt_risk
        )

        # Generate risk factors
        risk_factors = self._identify_risk_factors(
            credit_score, annual_income, monthly_debt_payments,
            employment_status, employment_duration_months, existing_debts
        )

        # Generate mitigation strategies
        mitigations = self._generate_mitigations(risk_factors, risk_level)

        return {
            "agent": "RiskAssessment",
            "status": "success",
            "risk_score": risk_score,
            "risk_level": risk_level,
            "default_probability": default_probability,
            "risk_components": {
                "credit_risk": credit_risk,
                "income_risk": income_risk,
                "debt_risk": debt_risk,
                "employment_risk": employment_risk,
                "collateral_risk": collateral_risk
            },
            "risk_factors": risk_factors,
            "mitigation_strategies": mitigations,
            "risk_insights": self._generate_risk_insights(
                risk_score, risk_level, default_probability
            ),
            "approval_recommendation": self._get_approval_recommendation(risk_score, risk_level)
        }

    def _assess_credit_risk(self, credit_score: int) -> float:
        """Assess risk based on credit score (0-10, where 10 is lowest risk)"""
        # Map credit score (300-850) to risk score (0-10)
        if credit_score >= 750:
            return 9.5
        elif credit_score >= 700:
            return 8.5
        elif credit_score >= 670:
            return 7.5
        elif credit_score >= 620:
            return 6.0
        elif credit_score >= 580:
            return 4.5
        elif credit_score >= 500:
            return 3.0
        else:
            return 1.0

    def _assess_income_risk(self, annual_income: float, loan_amount: float) -> float:
        """Assess risk based on income relative to loan"""
        income_to_loan = annual_income / loan_amount if loan_amount > 0 else 0

        if income_to_loan >= 2.0:
            return 10.0
        elif income_to_loan >= 1.0:
            return 8.5
        elif income_to_loan >= 0.5:
            return 7.0
        elif income_to_loan >= 0.25:
            return 5.0
        else:
            return 2.0

    def _assess_debt_risk(self, monthly_debt: float, monthly_income: float) -> float:
        """Assess risk based on debt-to-income ratio"""
        dti = monthly_debt / monthly_income if monthly_income > 0 else 999

        if dti <= 0.20:
            return 10.0
        elif dti <= 0.36:
            return 8.5
        elif dti <= 0.43:
            return 6.5
        elif dti <= 0.50:
            return 4.0
        else:
            return 1.5

    def _assess_employment_risk(self, employment_status: str, duration_months: int) -> float:
        """Assess risk based on employment stability"""
        if employment_status.lower() == "unemployed":
            return 1.0
        elif employment_status.lower() == "retired":
            return 8.0
        elif employment_status.lower() == "self-employed":
            if duration_months >= 24:
                return 8.0
            elif duration_months >= 12:
                return 6.5
            else:
                return 4.0
        else:  # employed
            if duration_months >= 24:
                return 9.5
            elif duration_months >= 12:
                return 8.5
            elif duration_months >= 6:
                return 6.5
            else:
                return 4.5

    def _assess_collateral_risk(
        self,
        collateral_type: str,
        collateral_value: float,
        loan_amount: float,
        loan_purpose: str
    ) -> float:
        """Assess risk based on collateral"""
        if not collateral_type or collateral_type.lower() == "none":
            # If collateral not typically required, neutral score
            if loan_purpose.lower() not in ["home", "auto", "business"]:
                return 7.0
            else:
                return 5.0  # Lower score if collateral expected but not provided

        # Calculate LTV
        ltv = loan_amount / collateral_value if collateral_value > 0 else 999

        if ltv <= 0.70:
            return 10.0
        elif ltv <= 0.80:
            return 9.0
        elif ltv <= 0.90:
            return 7.5
        elif ltv <= 1.0:
            return 5.5
        else:
            return 3.0

    def _determine_risk_level(self, risk_score: float) -> str:
        """Determine overall risk level"""
        low_threshold = self.config.get("LOW_RISK_THRESHOLD", 7.5)
        moderate_threshold = self.config.get("MODERATE_RISK_THRESHOLD", 5.5)
        high_threshold = self.config.get("HIGH_RISK_THRESHOLD", 3.5)

        if risk_score >= low_threshold:
            return "LOW"
        elif risk_score >= moderate_threshold:
            return "MODERATE"
        elif risk_score >= high_threshold:
            return "MODERATE_HIGH"
        else:
            return "HIGH"

    def _estimate_default_probability(
        self,
        credit_score: int,
        risk_score: float,
        debt_risk: float
    ) -> float:
        """Estimate probability of default"""
        # Simplified model based on credit score and risk factors
        base_prob = 0.50  # 50% baseline

        # Credit score adjustment
        if credit_score >= 750:
            base_prob *= 0.05  # 2.5%
        elif credit_score >= 700:
            base_prob *= 0.10  # 5%
        elif credit_score >= 670:
            base_prob *= 0.15  # 7.5%
        elif credit_score >= 620:
            base_prob *= 0.30  # 15%
        elif credit_score >= 580:
            base_prob *= 0.50  # 25%
        else:
            base_prob *= 0.80  # 40%

        # Risk score adjustment
        risk_adjustment = (10 - risk_score) / 10 * 0.2  # Up to 20% additional
        base_prob += risk_adjustment

        # Debt risk adjustment
        debt_adjustment = (10 - debt_risk) / 10 * 0.15  # Up to 15% additional
        base_prob += debt_adjustment

        return min(0.95, max(0.01, base_prob))

    def _identify_risk_factors(
        self,
        credit_score: int,
        annual_income: float,
        monthly_debt_payments: float,
        employment_status: str,
        employment_duration_months: int,
        existing_debts: List[Dict[str, Any]]
    ) -> List[str]:
        """Identify specific risk factors"""
        factors = []

        if credit_score < 620:
            factors.append("Below-average credit score increases default risk")

        if employment_status.lower() == "unemployed":
            factors.append("Unemployment creates income instability")
        elif employment_duration_months < 12:
            factors.append("Short employment duration indicates instability")

        monthly_income = annual_income / 12
        dti = monthly_debt_payments / monthly_income if monthly_income > 0 else 999
        if dti > 0.43:
            factors.append("High debt-to-income ratio limits repayment capacity")

        if len(existing_debts) > 5:
            factors.append("Multiple existing debts may indicate financial stress")

        if annual_income < 25000:
            factors.append("Low income may limit ability to absorb financial shocks")

        return factors

    def _generate_mitigations(self, risk_factors: List[str], risk_level: str) -> List[str]:
        """Generate risk mitigation strategies"""
        mitigations = []

        if risk_level in ["MODERATE_HIGH", "HIGH"]:
            mitigations.append("Require additional collateral or guarantor")
            mitigations.append("Implement stricter monitoring and reporting requirements")
            mitigations.append("Consider loan amount reduction")

        if any("credit score" in factor.lower() for factor in risk_factors):
            mitigations.append("Require credit improvement before approval")

        if any("employment" in factor.lower() for factor in risk_factors):
            mitigations.append("Request additional income verification")
            mitigations.append("Consider co-signer with stable employment")

        if any("debt" in factor.lower() for factor in risk_factors):
            mitigations.append("Require debt consolidation or reduction")
            mitigations.append("Extend loan term to reduce monthly payment")

        if not mitigations:
            mitigations.append("Standard loan monitoring procedures apply")

        return mitigations

    def _generate_risk_insights(
        self,
        risk_score: float,
        risk_level: str,
        default_probability: float
    ) -> List[str]:
        """Generate insights about risk assessment"""
        insights = []

        if risk_level == "LOW":
            insights.append("Low risk profile with high probability of successful repayment")
        elif risk_level == "MODERATE":
            insights.append("Moderate risk profile suitable for standard loan terms")
        elif risk_level == "MODERATE_HIGH":
            insights.append("Elevated risk requires enhanced due diligence")
        else:
            insights.append("High risk profile may not meet approval criteria")

        insights.append(f"Estimated default probability: {default_probability:.1%}")

        if risk_score >= 8.0:
            insights.append("Strong overall financial profile")
        elif risk_score < 5.0:
            insights.append("Multiple risk factors present requiring mitigation")

        return insights

    def _get_approval_recommendation(self, risk_score: float, risk_level: str) -> str:
        """Get approval recommendation based on risk"""
        if risk_level == "HIGH":
            return "RECOMMEND_DENIAL"
        elif risk_level == "MODERATE_HIGH":
            return "CONDITIONAL_APPROVAL_WITH_MITIGATIONS"
        elif risk_level == "MODERATE":
            return "STANDARD_APPROVAL"
        else:
            return "FAST_TRACK_APPROVAL"
