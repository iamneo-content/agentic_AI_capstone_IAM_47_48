"""
Debt-to-Income (DTI) Calculator

Calculates and analyzes debt-to-income ratios to assess
the applicant's ability to manage additional debt.
"""

from typing import Dict, Any, List
import logging
from config import ConfigManager


class DTICalculator:
    """Analyzer for debt-to-income ratio calculation"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.dti")
        self.config = ConfigManager()

    def calculate_dti(
        self,
        monthly_income: float = None,
        monthly_debt_payments: float = None,
        loan_amount: float = None,
        loan_term_months: int = None,
        interest_rate: float = None,
        existing_debts: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Calculate debt-to-income ratio

        Can be called with individual parameters or with a single dict parameter.

        Args:
            monthly_income: Monthly income OR full application dict
            monthly_debt_payments: Current monthly debt payments
            loan_amount: Requested loan amount
            loan_term_months: Loan term in months
            interest_rate: Annual interest rate
            existing_debts: List of existing debts

        Returns:
            DTI analysis with affordability assessment
        """
        # Support dict input for backwards compatibility
        if isinstance(monthly_income, dict):
            app_data = monthly_income
            annual_income = app_data.get("annual_income", 0.0)
            monthly_income = annual_income / 12 if annual_income > 0 else 0.0
            monthly_debt_payments = app_data.get("monthly_debt_payments", 0.0)
            loan_amount = app_data.get("loan_amount", 0.0)
            loan_term_months = app_data.get("loan_term_months", 360)  # Default 30 years
            interest_rate = app_data.get("requested_interest_rate", 5.0)
            existing_debts = app_data.get("existing_debts", [])

        # Set defaults if None
        if monthly_income is None:
            monthly_income = 0.0
        if monthly_debt_payments is None:
            monthly_debt_payments = 0.0
        if loan_amount is None:
            loan_amount = 0.0
        if loan_term_months is None:
            loan_term_months = 360
        if interest_rate is None:
            interest_rate = 5.0
        if existing_debts is None:
            existing_debts = []

        self.logger.info(f"Calculating DTI ratio - Income: ${monthly_income:,.2f}/month")

        # Calculate current DTI ratio
        current_dti_ratio = monthly_debt_payments / monthly_income if monthly_income > 0 else 999

        # Calculate new monthly loan payment
        new_loan_payment = self._calculate_monthly_payment(
            loan_amount, interest_rate, loan_term_months
        )

        # Calculate new DTI ratio with the loan
        new_total_debt = monthly_debt_payments + new_loan_payment
        new_dti_ratio = new_total_debt / monthly_income if monthly_income > 0 else 999

        # Determine DTI level
        dti_level = self._determine_dti_level(new_dti_ratio)

        # Calculate DTI score (0-10)
        dti_score = self._calculate_dti_score(new_dti_ratio)

        # Calculate max affordable loan
        max_affordable_loan = self._calculate_max_affordable_loan(
            monthly_income, monthly_debt_payments, interest_rate, loan_term_months
        )

        # Assess affordability
        is_affordable = new_dti_ratio <= self.config.get("MAX_DTI_RATIO", 0.43)

        return {
            "agent": "DebtToIncome",
            "status": "success",
            "current_dti_ratio": current_dti_ratio,
            "new_dti_ratio": new_dti_ratio,
            "dti_level": dti_level,
            "dti_score": dti_score,
            "current_monthly_debt": monthly_debt_payments,
            "new_loan_payment": new_loan_payment,
            "new_total_monthly_debt": new_total_debt,
            "monthly_income": monthly_income,
            "is_affordable": is_affordable,
            "max_affordable_loan": max_affordable_loan,
            "remaining_monthly_income": monthly_income - new_total_debt,
            "dti_insights": self._generate_dti_insights(
                current_dti_ratio, new_dti_ratio, is_affordable
            ),
            "recommendations": self._generate_recommendations(
                new_dti_ratio, is_affordable, max_affordable_loan, loan_amount
            )
        }

    def _calculate_monthly_payment(
        self,
        principal: float,
        annual_rate: float,
        term_months: int
    ) -> float:
        """Calculate monthly loan payment"""
        if term_months == 0 or principal == 0:
            return 0.0

        monthly_rate = (annual_rate / 100) / 12
        if monthly_rate == 0:
            return principal / term_months

        # Standard loan payment formula
        payment = principal * (monthly_rate * (1 + monthly_rate) ** term_months) / \
                  ((1 + monthly_rate) ** term_months - 1)

        return payment

    def _determine_dti_level(self, dti_ratio: float) -> str:
        """Determine DTI level category"""
        ideal_threshold = self.config.get("IDEAL_DTI_RATIO", 0.36)
        max_threshold = self.config.get("MAX_DTI_RATIO", 0.43)
        critical_threshold = self.config.get("CRITICAL_DTI_RATIO", 0.50)

        if dti_ratio <= ideal_threshold:
            return "IDEAL"
        elif dti_ratio <= max_threshold:
            return "ACCEPTABLE"
        elif dti_ratio <= critical_threshold:
            return "HIGH"
        else:
            return "CRITICAL"

    def _calculate_dti_score(self, dti_ratio: float) -> float:
        """Calculate DTI score (0-10, where 10 is best)"""
        ideal_threshold = self.config.get("IDEAL_DTI_RATIO", 0.36)
        max_threshold = self.config.get("MAX_DTI_RATIO", 0.43)

        if dti_ratio <= ideal_threshold:
            # Linear scale from 8-10 for DTI 0%-36%
            score = 10 - (dti_ratio / ideal_threshold) * 2
        elif dti_ratio <= max_threshold:
            # Linear scale from 5-8 for DTI 36%-43%
            ratio_in_range = (dti_ratio - ideal_threshold) / (max_threshold - ideal_threshold)
            score = 8 - (ratio_in_range * 3)
        else:
            # Linear scale from 0-5 for DTI > 43%
            score = max(0, 5 - (dti_ratio - max_threshold) * 10)

        return max(0.0, min(10.0, score))

    def _calculate_max_affordable_loan(
        self,
        monthly_income: float,
        monthly_debt_payments: float,
        interest_rate: float,
        term_months: int
    ) -> float:
        """Calculate maximum affordable loan amount"""
        max_dti = self.config.get("MAX_DTI_RATIO", 0.43)

        # Maximum total debt payment allowed
        max_total_debt = monthly_income * max_dti

        # Maximum new loan payment
        max_loan_payment = max_total_debt - monthly_debt_payments

        if max_loan_payment <= 0:
            return 0.0

        # Calculate loan amount from payment
        monthly_rate = (interest_rate / 100) / 12
        if monthly_rate == 0:
            return max_loan_payment * term_months

        # Reverse loan payment formula
        max_loan = max_loan_payment * ((1 + monthly_rate) ** term_months - 1) / \
                   (monthly_rate * (1 + monthly_rate) ** term_months)

        return max(0.0, max_loan)

    def _generate_dti_insights(
        self,
        current_dti: float,
        new_dti: float,
        is_affordable: bool
    ) -> List[str]:
        """Generate insights about DTI ratio"""
        insights = []

        if new_dti <= 0.36:
            insights.append("Excellent DTI ratio - strong financial position")
        elif new_dti <= 0.43:
            insights.append("Acceptable DTI ratio - meets lending standards")
        elif new_dti <= 0.50:
            insights.append("High DTI ratio - limited financial flexibility")
        else:
            insights.append("Critical DTI ratio - high risk of financial strain")

        dti_increase = new_dti - current_dti
        if dti_increase > 0.15:
            insights.append(f"Loan would significantly increase debt burden (+{dti_increase:.1%})")
        elif dti_increase > 0.05:
            insights.append(f"Moderate increase in debt burden (+{dti_increase:.1%})")

        if not is_affordable:
            insights.append("Requested loan amount exceeds recommended DTI threshold")

        return insights

    def _generate_recommendations(
        self,
        new_dti: float,
        is_affordable: bool,
        max_affordable: float,
        requested: float
    ) -> List[str]:
        """Generate recommendations for DTI management"""
        recommendations = []

        if not is_affordable:
            if max_affordable > 0:
                recommendations.append(
                    f"Consider reducing loan amount to ${max_affordable:,.2f} for better DTI"
                )
            recommendations.append("Pay down existing debts before applying")
            recommendations.append("Increase income sources if possible")

        if new_dti > 0.40:
            recommendations.append("Consider longer loan term to reduce monthly payment")
            recommendations.append("Build emergency fund before taking new debt")

        if new_dti <= 0.36:
            recommendations.append("DTI ratio is in excellent range for approval")

        return recommendations
