"""
Gemini AI Client

Enhanced AI-powered analysis for loan applications using Google's Gemini model.
Provides intelligent insights for risk assessment and decision support.
"""

import logging
from typing import Dict, Any, List, Optional

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

from config import ConfigManager


class GeminiClient:
    """Client for Google Gemini AI integration"""

    def __init__(self):
        self.logger = logging.getLogger("analyzer.gemini")
        self.config = ConfigManager()
        self.model = None

        if GEMINI_AVAILABLE:
            self._initialize_client()
        else:
            self.logger.warning("Google Generative AI not available - install with: pip install google-generativeai")

    def _initialize_client(self):
        """Initialize Gemini AI client"""
        try:
            api_key = self.config.get("GEMINI_API_KEY")
            if not api_key:
                self.logger.warning("GEMINI_API_KEY not configured - AI features disabled")
                return

            genai.configure(api_key=api_key)
            model_name = self.config.get("GEMINI_MODEL", "gemini-pro")
            self.model = genai.GenerativeModel(model_name)
            self.logger.info(f"Gemini AI initialized with model: {model_name}")

        except Exception as e:
            self.logger.error(f"Failed to initialize Gemini AI: {str(e)}")
            self.model = None

    def analyze_loan_application(
        self,
        credit_score: int,
        annual_income: float,
        loan_amount: float,
        loan_purpose: str,
        employment_status: str,
        dti_ratio: float
    ) -> Optional[str]:
        """
        Generate AI-powered loan application analysis

        Args:
            credit_score: Applicant's credit score
            annual_income: Annual income
            loan_amount: Requested loan amount
            loan_purpose: Purpose of the loan
            employment_status: Employment status
            dti_ratio: Debt-to-income ratio

        Returns:
            AI-generated analysis or None if unavailable
        """
        if not self.model:
            return None

        try:
            prompt = f"""
            As a financial analyst, provide a concise analysis of this loan application:

            Credit Score: {credit_score}
            Annual Income: ${annual_income:,.2f}
            Loan Amount Requested: ${loan_amount:,.2f}
            Loan Purpose: {loan_purpose}
            Employment Status: {employment_status}
            Debt-to-Income Ratio: {dti_ratio:.1%}

            Provide:
            1. Overall assessment (2-3 sentences)
            2. Key strengths (2-3 points)
            3. Areas of concern (2-3 points)
            4. Recommendation summary

            Keep the response professional and under 400 words.
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error analyzing loan application: {str(e)}")
            return None

    def generate_risk_insights(
        self,
        risk_factors: List[str],
        risk_level: str,
        default_probability: float
    ) -> Optional[str]:
        """
        Generate AI-powered risk insights

        Args:
            risk_factors: List of identified risk factors
            risk_level: Overall risk level
            default_probability: Estimated default probability

        Returns:
            Risk insights or None
        """
        if not self.model:
            return None

        try:
            factors_text = "\n".join([f"- {factor}" for factor in risk_factors])

            prompt = f"""
            As a risk analyst, provide insights on this loan risk profile:

            Risk Level: {risk_level}
            Default Probability: {default_probability:.1%}

            Risk Factors:
            {factors_text}

            Provide:
            1. Risk interpretation (what does this mean?)
            2. Specific mitigation strategies (3-4 actionable items)
            3. Monitoring recommendations

            Be specific and actionable. Keep under 350 words.
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error generating risk insights: {str(e)}")
            return None

    def recommend_loan_terms(
        self,
        loan_amount: float,
        credit_rating: str,
        dti_ratio: float,
        has_collateral: bool,
        loan_purpose: str
    ) -> Optional[str]:
        """
        Generate AI-powered loan terms recommendations

        Args:
            loan_amount: Requested loan amount
            credit_rating: Credit rating category
            dti_ratio: Debt-to-income ratio
            has_collateral: Whether collateral is provided
            loan_purpose: Purpose of the loan

        Returns:
            Loan terms recommendations or None
        """
        if not self.model:
            return None

        try:
            prompt = f"""
            As a loan officer, recommend optimal loan terms:

            Loan Amount: ${loan_amount:,.2f}
            Credit Rating: {credit_rating}
            DTI Ratio: {dti_ratio:.1%}
            Collateral: {"Yes" if has_collateral else "No"}
            Purpose: {loan_purpose}

            Recommend:
            1. Appropriate interest rate range
            2. Optimal loan term (months/years)
            3. Required down payment (if applicable)
            4. Monthly payment estimate
            5. Any special conditions

            Provide practical, market-competitive recommendations. Keep under 300 words.
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error recommending loan terms: {str(e)}")
            return None

    def explain_denial(
        self,
        denial_reasons: List[str],
        credit_score: int,
        dti_ratio: float
    ) -> Optional[str]:
        """
        Generate AI-powered denial explanation

        Args:
            denial_reasons: List of denial reasons
            credit_score: Applicant's credit score
            dti_ratio: Debt-to-income ratio

        Returns:
            Denial explanation or None
        """
        if not self.model:
            return None

        try:
            reasons_text = "\n".join([f"- {reason}" for reason in denial_reasons])

            prompt = f"""
            As a loan officer, explain this loan denial empathetically but clearly:

            Credit Score: {credit_score}
            DTI Ratio: {dti_ratio:.1%}

            Denial Reasons:
            {reasons_text}

            Provide:
            1. Clear explanation of why the application was denied
            2. Specific steps the applicant can take to improve
            3. Timeline for when they might reapply
            4. Alternative options to consider

            Be empathetic but professional. Keep under 350 words.
            """

            response = self.model.generate_content(prompt)
            return response.text

        except Exception as e:
            self.logger.error(f"Error explaining denial: {str(e)}")
            return None

    def is_available(self) -> bool:
        """Check if Gemini AI is available"""
        return self.model is not None
