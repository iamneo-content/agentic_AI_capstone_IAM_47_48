"""
Loan Processing Workflow Builder

Constructs the multi-stage loan application processing workflow with parallel execution.
"""

import logging
from typing import List
from graph import LoanProcessingGraph, NodeFunc
from nodes import (
    input_validation_node,
    credit_analysis_node,
    income_verification_node,
    dti_calculation_node,
    collateral_evaluation_node,
    risk_assessment_node,
    coordination_node,
    decision_finalization_node,
    notification_node
)

logger = logging.getLogger("workflow.loan")


def build_loan_processing_workflow(max_workers: int = 5) -> LoanProcessingGraph:
    """
    Build the loan processing workflow graph

    Workflow Stages:
    1. Input Validation - Validate and enrich application data
    2. Parallel Analysis - Run 5 specialized agents in parallel:
       - Credit Score Analyzer
       - Income Verification Agent
       - Debt-to-Income Agent
       - Collateral Evaluator
       - Risk Assessment Agent
    3. Coordination - Aggregate results and make decision
    4. Decision Finalization - Prepare approval/denial details
    5. Notification - Send email notification

    Args:
        max_workers: Maximum parallel workers (default: 5)

    Returns:
        LoanProcessingGraph ready to execute
    """
    logger.info("Building loan processing workflow")

    # Define workflow stages
    stages: List[List[NodeFunc]] = [
        # Stage 1: Input Validation (sequential)
        [input_validation_node],

        # Stage 2: Parallel Analysis (5 agents run in parallel)
        [
            credit_analysis_node,
            income_verification_node,
            dti_calculation_node,
            collateral_evaluation_node,
            risk_assessment_node
        ],

        # Stage 3: Coordination (sequential)
        [coordination_node],

        # Stage 4: Decision Finalization (sequential)
        [decision_finalization_node],

        # Stage 5: Notification (sequential)
        [notification_node]
    ]

    # Create and return graph
    workflow = LoanProcessingGraph(
        stages=stages,
        max_workers=max_workers,
        raise_on_error=False  # Continue workflow even if individual nodes fail
    )

    logger.info(
        f"Workflow built with {len(stages)} stages, "
        f"{len(stages[1])} parallel agents in stage 2"
    )

    return workflow


# Alias for backward compatibility
build_loan_workflow = build_loan_processing_workflow
