"""
Loan Application Processor - Main Entry Point

Multi-agent system for intelligent loan application processing.
Uses 5 specialized agents to analyze credit, income, debt, collateral, and risk.
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from typing import Dict, Any

from state import LoanApplicationState
from workflows import build_loan_processing_workflow
from utils.logging_utils import setup_logging
from config import ConfigManager


def create_excellent_applicant() -> LoanApplicationState:
    """Create a loan application with excellent creditworthiness"""
    return LoanApplicationState(
        application_id="LOAN-2024-001",
        applicant_name="Sarah Johnson",
        applicant_email="sarah.johnson@example.com",
        timestamp=datetime.now().isoformat(),

        # Loan details
        loan_amount=250000.0,
        loan_purpose="home",
        loan_term_months=360,  # 30 years
        requested_interest_rate=6.5,

        # Applicant information
        applicant_age=35,
        employment_status="employed",
        employment_duration_months=72,  # 6 years
        employer_name="Tech Corp Inc.",

        # Financial information
        annual_income=120000.0,
        monthly_income=10000.0,
        credit_score=780,
        existing_debts=[
            {"type": "auto", "balance": 15000, "monthly_payment": 400},
            {"type": "credit_card", "balance": 2000, "monthly_payment": 100}
        ],
        monthly_debt_payments=500.0,
        assets=[
            {"type": "savings", "value": 50000},
            {"type": "retirement", "value": 150000}
        ],
        total_assets_value=200000.0,

        # Collateral
        collateral_type="property",
        collateral_value=300000.0,
        collateral_details={"property_type": "single_family", "location": "suburban"},

        # Verification
        identity_verified=True,
        income_documents_provided=True,
        address_verified=True
    )


def create_moderate_risk_applicant() -> LoanApplicationState:
    """Create a loan application with moderate risk"""
    return LoanApplicationState(
        application_id="LOAN-2024-002",
        applicant_name="Michael Chen",
        applicant_email="michael.chen@example.com",
        timestamp=datetime.now().isoformat(),

        # Loan details
        loan_amount=25000.0,
        loan_purpose="auto",
        loan_term_months=60,  # 5 years
        requested_interest_rate=7.5,

        # Applicant information
        applicant_age=28,
        employment_status="employed",
        employment_duration_months=18,  # 1.5 years
        employer_name="Retail Solutions LLC",

        # Financial information
        annual_income=50000.0,
        monthly_income=4167.0,
        credit_score=650,
        existing_debts=[
            {"type": "student_loan", "balance": 30000, "monthly_payment": 300},
            {"type": "credit_card", "balance": 5000, "monthly_payment": 150},
            {"type": "personal_loan", "balance": 8000, "monthly_payment": 200}
        ],
        monthly_debt_payments=650.0,
        assets=[
            {"type": "savings", "value": 5000}
        ],
        total_assets_value=5000.0,

        # Collateral
        collateral_type="vehicle",
        collateral_value=30000.0,
        collateral_details={"vehicle_year": 2023, "make": "Honda", "model": "Accord"},

        # Verification
        identity_verified=True,
        income_documents_provided=True,
        address_verified=True
    )


def create_high_risk_applicant() -> LoanApplicationState:
    """Create a loan application with high risk (likely denial)"""
    return LoanApplicationState(
        application_id="LOAN-2024-003",
        applicant_name="James Rodriguez",
        applicant_email="james.rodriguez@example.com",
        timestamp=datetime.now().isoformat(),

        # Loan details
        loan_amount=50000.0,
        loan_purpose="personal",
        loan_term_months=60,
        requested_interest_rate=12.0,

        # Applicant information
        applicant_age=45,
        employment_status="self-employed",
        employment_duration_months=8,  # Less than 1 year
        employer_name="Self-Employed Consultant",

        # Financial information
        annual_income=35000.0,
        monthly_income=2917.0,
        credit_score=550,
        existing_debts=[
            {"type": "credit_card", "balance": 8000, "monthly_payment": 200},
            {"type": "credit_card", "balance": 6000, "monthly_payment": 150},
            {"type": "personal_loan", "balance": 12000, "monthly_payment": 350},
            {"type": "medical", "balance": 5000, "monthly_payment": 100}
        ],
        monthly_debt_payments=800.0,
        assets=[
            {"type": "savings", "value": 1000}
        ],
        total_assets_value=1000.0,

        # Collateral
        collateral_type="none",
        collateral_value=0.0,
        collateral_details={},

        # Verification
        identity_verified=True,
        income_documents_provided=False,  # Missing documentation
        address_verified=True
    )


def print_loan_decision_summary(state: LoanApplicationState) -> None:
    """Print a summary of the loan processing results"""
    print("\n" + "="*80)
    print("LOAN APPLICATION PROCESSING RESULTS")
    print("="*80)

    # Basic information
    print(f"\nApplication ID: {state.application_id}")
    print(f"Applicant: {state.applicant_name}")
    print(f"Loan Amount: ${state.loan_amount:,.2f}")
    print(f"Purpose: {state.loan_purpose}")
    print(f"Credit Score: {state.credit_score}")
    print(f"Annual Income: ${state.annual_income:,.2f}")

    # Decision
    print(f"\n{'='*80}")
    print(f"DECISION: {state.decision}")
    print(f"Overall Risk Score: {state.overall_risk_score:.2f}/10")
    print(f"Confidence Level: {state.confidence_level}")
    print(f"{'='*80}")

    # Component scores
    if state.decision_metrics:
        print("\nComponent Scores:")
        for component, score in state.decision_metrics.items():
            print(f"  - {component.replace('_', ' ').title()}: {score:.2f}/10")

    # Decision rationale
    if state.coordination_summary:
        rationale = state.coordination_summary.get("decision_rationale", "")
        if rationale:
            print(f"\nRationale: {rationale}")

    # Approval details
    if state.decision in ["APPROVED", "CONDITIONAL_APPROVAL"]:
        print("\nApproved Terms:")
        print(f"  Amount: ${state.approved_amount:,.2f}")
        print(f"  Interest Rate: {state.approved_interest_rate:.2f}%")
        print(f"  Term: {state.approved_term_months} months ({state.approved_term_months // 12} years)")
        print(f"  Monthly Payment: ${state.monthly_payment:,.2f}")

        if state.conditions:
            print("\n  Conditions:")
            for condition in state.conditions:
                print(f"    - {condition}")

    # Denial details
    if state.decision == "DENIED":
        if state.denial_reasons:
            print("\nDenial Reasons:")
            for reason in state.denial_reasons:
                print(f"  - {reason}")

        if state.improvement_suggestions:
            print("\nImprovement Suggestions:")
            for suggestion in state.improvement_suggestions:
                print(f"  - {suggestion}")

    # Analysis details
    print("\nDetailed Analysis:")

    # Credit analysis
    if state.credit_analysis_results:
        credit_result = state.credit_analysis_results[0]
        print(f"\n  Credit Analysis:")
        print(f"    Rating: {credit_result.get('credit_rating', 'N/A')}")
        print(f"    Score: {credit_result.get('credit_score_value', 0):.2f}/10")
        print(f"    Risk Level: {credit_result.get('risk_level', 'N/A')}")
        print(f"    Recommended Rate: {credit_result.get('recommended_interest_rate', 0):.2f}%")

    # Income verification
    if state.income_verification_results:
        income_result = state.income_verification_results[0]
        print(f"\n  Income Verification:")
        print(f"    Status: {income_result.get('verification_status', 'N/A')}")
        print(f"    Score: {income_result.get('income_score', 0):.2f}/10")
        print(f"    Income-to-Loan Ratio: {income_result.get('income_to_loan_ratio', 0):.2f}")
        print(f"    Employment Stability: {income_result.get('employment_stability', 'N/A')}")

    # DTI analysis
    if state.debt_to_income_results:
        dti_result = state.debt_to_income_results[0]
        print(f"\n  Debt-to-Income Ratio:")
        print(f"    Current DTI: {dti_result.get('current_dti_ratio', 0):.2%}")
        print(f"    New DTI (with loan): {dti_result.get('new_dti_ratio', 0):.2%}")
        print(f"    DTI Level: {dti_result.get('dti_level', 'N/A')}")
        print(f"    DTI Score: {dti_result.get('dti_score', 0):.2f}/10")
        print(f"    Is Affordable: {dti_result.get('is_affordable', False)}")

    # Collateral evaluation
    if state.collateral_evaluation_results:
        collateral_result = state.collateral_evaluation_results[0]
        print(f"\n  Collateral Evaluation:")
        print(f"    Type: {collateral_result.get('collateral_type', 'None')}")
        if collateral_result.get('has_collateral', False):
            print(f"    Value: ${collateral_result.get('collateral_value', 0):,.2f}")
            print(f"    LTV Ratio: {collateral_result.get('ltv_ratio', 0):.2%}")
            print(f"    Adequacy: {collateral_result.get('collateral_adequacy', 'N/A')}")
        print(f"    Score: {collateral_result.get('collateral_score', 0):.2f}/10")

    # Risk assessment
    if state.risk_assessment_results:
        risk_result = state.risk_assessment_results[0]
        print(f"\n  Risk Assessment:")
        print(f"    Risk Level: {risk_result.get('risk_level', 'N/A')}")
        print(f"    Risk Score: {risk_result.get('risk_score', 0):.2f}/10")
        print(f"    Default Probability: {risk_result.get('default_probability', 0):.2%}")

        risk_factors = risk_result.get('risk_factors', [])
        if risk_factors:
            print(f"    Risk Factors:")
            for factor in risk_factors:
                print(f"      - {factor}")

    # Errors
    if state.error:
        print(f"\nErrors: {state.error}")

    print("\n" + "="*80)


def main():
    """Main entry point for loan application processor"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="Loan Application Processor - Multi-agent loan processing system"
    )
    parser.add_argument(
        "--scenario",
        type=str,
        choices=["excellent", "moderate", "high-risk"],
        default="excellent",
        help="Loan application scenario to process (default: excellent)"
    )
    parser.add_argument(
        "--log-level",
        type=str,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level (default: INFO)"
    )
    parser.add_argument(
        "--log-file",
        type=str,
        help="Optional log file path"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=5,
        help="Maximum parallel workers (default: 5)"
    )

    args = parser.parse_args()

    # Setup logging
    log_file = args.log_file or "logs/loan_processor.log"
    setup_logging(log_level=args.log_level, log_file=log_file)

    logger = logging.getLogger(__name__)
    logger.info("Starting Loan Application Processor")
    logger.info(f"Scenario: {args.scenario}")

    try:
        # Load configuration
        config = ConfigManager()
        logger.info(f"Configuration loaded from: {config.config_file}")

        # Create loan application based on scenario
        scenarios = {
            "excellent": create_excellent_applicant,
            "moderate": create_moderate_risk_applicant,
            "high-risk": create_high_risk_applicant
        }

        initial_state = scenarios[args.scenario]()
        logger.info(f"Created loan application: {initial_state.application_id}")

        # Build workflow
        workflow = build_loan_processing_workflow(max_workers=args.workers)
        logger.info("Workflow built successfully")

        # Execute workflow
        print(f"\nProcessing loan application for {initial_state.applicant_name}...")
        print(f"Running {args.scenario} risk scenario with {args.workers} parallel workers\n")

        final_state = workflow.run(initial_state)

        # Print results
        print_loan_decision_summary(final_state)

        # Log completion
        logger.info(
            f"Workflow completed - Decision: {final_state.decision}, "
            f"Risk Score: {final_state.overall_risk_score:.2f}"
        )

        # Print notification status
        if final_state.notifications_sent:
            last_notification = final_state.notifications_sent[-1]
            if last_notification.get("status") == "sent":
                print(f"\n✓ Decision notification sent to {final_state.applicant_email}")
            else:
                print(f"\n✗ Failed to send notification (email service may not be configured)")

        return 0

    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        print("\n\nProcess interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Fatal error: {str(e)}", exc_info=True)
        print(f"\n\nError: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
