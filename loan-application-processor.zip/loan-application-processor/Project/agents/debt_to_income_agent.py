"""
Debt-to-Income Ratio Agent

Calculates and analyzes the applicant's debt-to-income (DTI) ratio to assess
ability to manage additional debt obligations.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.dti_calculator import DTICalculator
from state import LoanApplicationState


class DebtToIncomeAgent(BaseAgent):
    """Agent responsible for debt-to-income ratio analysis"""

    def __init__(self):
        super().__init__("DebtToIncome")
        self.calculator = DTICalculator()

    def analyze(self, state: LoanApplicationState) -> Dict[str, Any]:
        """
        Calculate and analyze debt-to-income ratio

        Args:
            state: Current loan application state

        Returns:
            DTI analysis results with affordability assessment
        """
        self.log(f"Calculating DTI ratio for application {state.application_id}")

        try:
            # Extract DTI parameters
            monthly_income = state.monthly_income
            monthly_debt_payments = state.monthly_debt_payments
            loan_amount = state.loan_amount
            loan_term_months = state.loan_term_months
            requested_interest_rate = state.requested_interest_rate
            existing_debts = state.existing_debts

            # Calculate DTI ratio
            dti_result = self.calculator.calculate_dti(
                monthly_income=monthly_income,
                monthly_debt_payments=monthly_debt_payments,
                loan_amount=loan_amount,
                loan_term_months=loan_term_months,
                interest_rate=requested_interest_rate,
                existing_debts=existing_debts
            )

            self.log(
                f"DTI analysis complete - Current DTI: {dti_result.get('current_dti_ratio', 0):.2%}, "
                f"New DTI: {dti_result.get('new_dti_ratio', 0):.2%}, "
                f"DTI Level: {dti_result.get('dti_level', 'N/A')}"
            )

            return dti_result

        except Exception as e:
            self.log(f"Error during DTI calculation: {str(e)}", level="error")
            return {
                "agent": "DebtToIncome",
                "status": "error",
                "error_message": str(e),
                "dti_level": "UNKNOWN",
                "dti_score": 0.0
            }
