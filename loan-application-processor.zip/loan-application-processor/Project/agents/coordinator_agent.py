"""
Coordinator Agent

Aggregates results from all specialized agents and makes final decisions
on loan approval, denial, or conditional approval.
"""

from typing import Dict, Any, List
from .base_agent import BaseAgent
from state import LoanApplicationState
from config import ConfigManager


class CoordinatorAgent(BaseAgent):
    """Agent responsible for coordinating all analysis results and making final decisions"""

    def __init__(self):
        super().__init__("Coordinator")
        self.config = ConfigManager()

    def analyze(self, state: LoanApplicationState) -> Dict[str, Any]:
        """
        Coordinate all agent results and make final decision

        Args:
            state: Current loan application state with all analysis results

        Returns:
            Coordination summary with final decision and terms
        """
        self.log("Coordinating analysis results from all agents")

        try:
            # Extract analysis results
            credit_results = state.credit_analysis_results
            income_results = state.income_verification_results
            dti_results = state.debt_to_income_results
            collateral_results = state.collateral_evaluation_results
            risk_results = state.risk_assessment_results

            # Calculate component scores
            credit_score = self._extract_score(credit_results, "credit_score_value", 0.0)
            income_score = self._extract_score(income_results, "income_score", 0.0)
            dti_score = self._extract_score(dti_results, "dti_score", 0.0)
            collateral_score = self._extract_score(collateral_results, "collateral_score", 0.0)
            risk_score = self._extract_score(risk_results, "risk_score", 0.0)

            # Weighted average for overall risk score
            # Risk assessment has highest weight as it's comprehensive
            overall_risk_score = (
                credit_score * 0.25 +
                income_score * 0.20 +
                dti_score * 0.20 +
                collateral_score * 0.15 +
                risk_score * 0.20
            )

            # Extract key metrics
            credit_rating = self._extract_value(credit_results, "credit_rating", "UNKNOWN")
            dti_level = self._extract_value(dti_results, "dti_level", "UNKNOWN")
            risk_level = self._extract_value(risk_results, "risk_level", "UNKNOWN")

            # Check for critical issues
            has_critical_issues = self._check_critical_issues(state, credit_results, income_results, dti_results)

            # Make decision
            decision = self._make_decision(
                overall_risk_score=overall_risk_score,
                credit_rating=credit_rating,
                dti_level=dti_level,
                risk_level=risk_level,
                has_critical_issues=has_critical_issues
            )

            # Calculate approved terms
            approved_terms = self._calculate_approved_terms(
                decision=decision,
                state=state,
                overall_risk_score=overall_risk_score,
                credit_results=credit_results,
                dti_results=dti_results
            )

            # Generate conditions if conditional approval
            conditions = self._generate_conditions(
                decision=decision,
                state=state,
                credit_results=credit_results,
                income_results=income_results,
                dti_results=dti_results,
                collateral_results=collateral_results
            )

            # Generate denial reasons if denied
            denial_reasons = self._generate_denial_reasons(
                decision=decision,
                has_critical_issues=has_critical_issues,
                credit_rating=credit_rating,
                dti_level=dti_level,
                risk_level=risk_level
            )

            # Calculate confidence level
            confidence_level = self._calculate_confidence(overall_risk_score, [
                credit_score, income_score, dti_score, collateral_score, risk_score
            ])

            coordination_summary = {
                "agent": "Coordinator",
                "status": "success",
                "overall_risk_score": overall_risk_score,
                "component_scores": {
                    "credit": credit_score,
                    "income": income_score,
                    "debt_to_income": dti_score,
                    "collateral": collateral_score,
                    "risk_assessment": risk_score
                },
                "decision": decision,
                "confidence_level": confidence_level,
                "has_critical_issues": has_critical_issues,
                "approved_amount": approved_terms.get("approved_amount", 0.0),
                "approved_interest_rate": approved_terms.get("approved_interest_rate", 0.0),
                "approved_term_months": approved_terms.get("approved_term_months", 0),
                "monthly_payment": approved_terms.get("monthly_payment", 0.0),
                "conditions": conditions,
                "denial_reasons": denial_reasons,
                "decision_rationale": self._generate_rationale(
                    decision, overall_risk_score, credit_rating, dti_level, risk_level
                )
            }

            self.log(
                f"Coordination complete - Decision: {decision}, "
                f"Risk Score: {overall_risk_score:.2f}, Confidence: {confidence_level}"
            )

            return coordination_summary

        except Exception as e:
            self.log(f"Error during coordination: {str(e)}", level="error")
            return {
                "agent": "Coordinator",
                "status": "error",
                "error_message": str(e),
                "decision": "ERROR",
                "overall_risk_score": 0.0,
                "confidence_level": "NONE"
            }

    def _extract_score(self, results: list, key: str, default: float) -> float:
        """Extract score from results list"""
        if results and len(results) > 0:
            return results[0].get(key, default)
        return default

    def _extract_value(self, results: list, key: str, default: Any) -> Any:
        """Extract value from results list"""
        if results and len(results) > 0:
            return results[0].get(key, default)
        return default

    def _check_critical_issues(
        self,
        state: LoanApplicationState,
        credit_results: list,
        income_results: list,
        dti_results: list
    ) -> bool:
        """Check for critical issues that would prevent approval"""
        # Very low credit score
        credit_score = state.credit_score
        if credit_score < self.config.get("MIN_CREDIT_SCORE", 300):
            return True

        # Failed income verification
        income_status = self._extract_value(income_results, "verification_status", "")
        if income_status == "FAILED":
            return True

        # Critical DTI ratio
        dti_level = self._extract_value(dti_results, "dti_level", "")
        if dti_level == "CRITICAL":
            return True

        return False

    def _make_decision(
        self,
        overall_risk_score: float,
        credit_rating: str,
        dti_level: str,
        risk_level: str,
        has_critical_issues: bool
    ) -> str:
        """Make final approval decision"""
        # Critical issues = automatic denial
        if has_critical_issues:
            return "DENIED"

        # High risk level = denial
        if risk_level == "HIGH":
            return "DENIED"

        # Excellent score = automatic approval
        auto_approve_threshold = self.config.get("AUTO_APPROVE_RISK_SCORE", 8.0)
        if overall_risk_score >= auto_approve_threshold and credit_rating in ["EXCELLENT", "GOOD"]:
            return "APPROVED"

        # Good score with manageable DTI = approval
        conditional_threshold = self.config.get("CONDITIONAL_APPROVE_RISK_SCORE", 6.0)
        if overall_risk_score >= conditional_threshold:
            if dti_level in ["IDEAL", "ACCEPTABLE"]:
                return "APPROVED"
            else:
                return "CONDITIONAL_APPROVAL"

        # Moderate score = conditional approval
        min_approval_threshold = self.config.get("MIN_APPROVAL_RISK_SCORE", 5.0)
        if overall_risk_score >= min_approval_threshold:
            return "CONDITIONAL_APPROVAL"

        # Low score = denial
        return "DENIED"

    def _calculate_approved_terms(
        self,
        decision: str,
        state: LoanApplicationState,
        overall_risk_score: float,
        credit_results: list,
        dti_results: list
    ) -> Dict[str, Any]:
        """Calculate approved loan terms"""
        if decision == "DENIED":
            return {
                "approved_amount": 0.0,
                "approved_interest_rate": 0.0,
                "approved_term_months": 0,
                "monthly_payment": 0.0
            }

        # Get recommended interest rate from credit analysis
        recommended_rate = self._extract_value(credit_results, "recommended_interest_rate", 0.0)

        # Adjust rate based on overall risk
        if overall_risk_score >= 8.0:
            interest_rate = recommended_rate
        elif overall_risk_score >= 6.5:
            interest_rate = recommended_rate * 1.1  # 10% higher
        else:
            interest_rate = recommended_rate * 1.2  # 20% higher

        # Determine approved amount
        if decision == "CONDITIONAL_APPROVAL":
            # Reduce amount if conditional
            max_loan_amount = self._extract_value(dti_results, "max_affordable_loan", state.loan_amount)
            approved_amount = min(state.loan_amount, max_loan_amount * 0.9)
        else:
            approved_amount = state.loan_amount

        # Use requested term or default
        approved_term = state.loan_term_months if state.loan_term_months > 0 else 60

        # Calculate monthly payment
        monthly_payment = self._calculate_monthly_payment(
            approved_amount, interest_rate, approved_term
        )

        return {
            "approved_amount": approved_amount,
            "approved_interest_rate": interest_rate,
            "approved_term_months": approved_term,
            "monthly_payment": monthly_payment
        }

    def _calculate_monthly_payment(
        self,
        principal: float,
        annual_rate: float,
        term_months: int
    ) -> float:
        """Calculate monthly loan payment"""
        if term_months == 0 or principal == 0:
            return 0.0

        monthly_rate = (annual_rate / 100) / 12
        if monthly_rate == 0:
            return principal / term_months

        # Standard loan payment formula
        payment = principal * (monthly_rate * (1 + monthly_rate) ** term_months) / \
                  ((1 + monthly_rate) ** term_months - 1)

        return payment

    def _generate_conditions(
        self,
        decision: str,
        state: LoanApplicationState,
        credit_results: list,
        income_results: list,
        dti_results: list,
        collateral_results: list
    ) -> List[str]:
        """Generate approval conditions"""
        if decision != "CONDITIONAL_APPROVAL":
            return []

        conditions = []

        # Income verification conditions
        if not state.income_documents_provided:
            conditions.append("Provide proof of income (pay stubs, tax returns)")

        # DTI conditions
        dti_level = self._extract_value(dti_results, "dti_level", "")
        if dti_level == "HIGH":
            conditions.append("Pay down existing debts to improve debt-to-income ratio")

        # Collateral conditions
        collateral_adequacy = self._extract_value(collateral_results, "collateral_adequacy", "")
        if collateral_adequacy == "INSUFFICIENT":
            conditions.append("Provide additional collateral or larger down payment")

        # Identity verification
        if not state.identity_verified:
            conditions.append("Complete identity verification process")

        if not state.address_verified:
            conditions.append("Provide proof of residence")

        return conditions

    def _generate_denial_reasons(
        self,
        decision: str,
        has_critical_issues: bool,
        credit_rating: str,
        dti_level: str,
        risk_level: str
    ) -> List[str]:
        """Generate reasons for denial"""
        if decision != "DENIED":
            return []

        reasons = []

        if has_critical_issues:
            reasons.append("Application failed critical eligibility requirements")

        if credit_rating in ["POOR", "VERY_POOR"]:
            reasons.append("Credit score below minimum threshold")

        if dti_level == "CRITICAL":
            reasons.append("Debt-to-income ratio exceeds acceptable limits")

        if risk_level == "HIGH":
            reasons.append("Overall risk assessment indicates high default probability")

        if not reasons:
            reasons.append("Application does not meet approval criteria")

        return reasons

    def _calculate_confidence(self, overall_score: float, component_scores: list) -> str:
        """Calculate confidence level based on score consistency"""
        avg_score = sum(component_scores) / len(component_scores)
        variance = sum((s - avg_score) ** 2 for s in component_scores) / len(component_scores)

        if variance < 0.5 and overall_score >= 7.5:
            return "HIGH"
        elif variance < 1.0 and overall_score >= 6.0:
            return "MEDIUM"
        else:
            return "LOW"

    def _generate_rationale(
        self,
        decision: str,
        overall_risk_score: float,
        credit_rating: str,
        dti_level: str,
        risk_level: str
    ) -> str:
        """Generate human-readable decision rationale"""
        if decision == "APPROVED":
            return (
                f"Loan approved with risk score of {overall_risk_score:.1f}/10. "
                f"Credit rating: {credit_rating}, DTI level: {dti_level}, "
                f"Risk level: {risk_level}. All criteria met for approval."
            )
        elif decision == "CONDITIONAL_APPROVAL":
            return (
                f"Conditional approval with risk score of {overall_risk_score:.1f}/10. "
                f"Application meets basic requirements but requires additional conditions. "
                f"Credit rating: {credit_rating}, DTI level: {dti_level}."
            )
        elif decision == "DENIED":
            return (
                f"Loan denied with risk score of {overall_risk_score:.1f}/10. "
                f"Credit rating: {credit_rating}, DTI level: {dti_level}, "
                f"Risk level: {risk_level}. Application does not meet approval criteria."
            )
        else:
            return "Unable to process application due to system error."
