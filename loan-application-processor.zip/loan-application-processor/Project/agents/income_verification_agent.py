"""
Income Verification Agent

Verifies applicant's income, employment stability, and ability to repay the loan
based on income-to-loan ratios.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.income_verifier import IncomeVerifier
from state import LoanApplicationState


class IncomeVerificationAgent(BaseAgent):
    """Agent responsible for income verification and employment stability"""

    def __init__(self):
        super().__init__("IncomeVerification")
        self.verifier = IncomeVerifier()

    def analyze(self, state: LoanApplicationState) -> Dict[str, Any]:
        """
        Verify income and employment stability

        Args:
            state: Current loan application state

        Returns:
            Income verification results with stability assessment
        """
        self.log(f"Verifying income for application {state.application_id}")

        try:
            # Extract income parameters
            annual_income = state.annual_income
            monthly_income = state.monthly_income
            employment_status = state.employment_status
            employment_duration_months = state.employment_duration_months
            loan_amount = state.loan_amount
            income_documents_provided = state.income_documents_provided

            # Perform income verification
            verification_result = self.verifier.verify_income(
                annual_income=annual_income,
                monthly_income=monthly_income,
                employment_status=employment_status,
                employment_duration_months=employment_duration_months,
                loan_amount=loan_amount,
                documents_provided=income_documents_provided
            )

            self.log(
                f"Income verification complete - Status: {verification_result.get('verification_status', 'N/A')}, "
                f"Income-to-Loan: {verification_result.get('income_to_loan_ratio', 0):.2f}, "
                f"Employment Stability: {verification_result.get('employment_stability', 'N/A')}"
            )

            return verification_result

        except Exception as e:
            self.log(f"Error during income verification: {str(e)}", level="error")
            return {
                "agent": "IncomeVerification",
                "status": "error",
                "error_message": str(e),
                "verification_status": "FAILED",
                "income_score": 0.0
            }
