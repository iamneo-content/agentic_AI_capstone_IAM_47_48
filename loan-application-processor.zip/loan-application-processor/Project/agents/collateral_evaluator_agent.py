"""
Collateral Evaluator Agent

Evaluates collateral value and calculates loan-to-value (LTV) ratios
for secured loans.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.collateral_evaluator import CollateralEvaluator
from state import LoanApplicationState


class CollateralEvaluatorAgent(BaseAgent):
    """Agent responsible for collateral evaluation and LTV calculation"""

    def __init__(self):
        super().__init__("CollateralEvaluator")
        self.evaluator = CollateralEvaluator()

    def analyze(self, state: LoanApplicationState) -> Dict[str, Any]:
        """
        Evaluate collateral and calculate LTV ratio

        Args:
            state: Current loan application state

        Returns:
            Collateral evaluation results with LTV assessment
        """
        self.log(f"Evaluating collateral for application {state.application_id}")

        try:
            # Extract collateral parameters
            collateral_type = state.collateral_type
            collateral_value = state.collateral_value
            collateral_details = state.collateral_details
            loan_amount = state.loan_amount
            loan_purpose = state.loan_purpose

            # Evaluate collateral
            evaluation_result = self.evaluator.evaluate_collateral(
                collateral_type=collateral_type,
                collateral_value=collateral_value,
                collateral_details=collateral_details,
                loan_amount=loan_amount,
                loan_purpose=loan_purpose
            )

            self.log(
                f"Collateral evaluation complete - Type: {collateral_type or 'None'}, "
                f"LTV Ratio: {evaluation_result.get('ltv_ratio', 0):.2%}, "
                f"Adequacy: {evaluation_result.get('collateral_adequacy', 'N/A')}"
            )

            return evaluation_result

        except Exception as e:
            self.log(f"Error during collateral evaluation: {str(e)}", level="error")
            return {
                "agent": "CollateralEvaluator",
                "status": "error",
                "error_message": str(e),
                "collateral_adequacy": "UNKNOWN",
                "collateral_score": 0.0
            }
