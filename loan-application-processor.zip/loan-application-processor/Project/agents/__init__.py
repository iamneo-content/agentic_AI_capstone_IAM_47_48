"""Agent classes for loan application processing"""

from .base_agent import BaseAgent
from .credit_score_agent import CreditScoreAgent
from .income_verification_agent import IncomeVerificationAgent
from .debt_to_income_agent import DebtToIncomeAgent
from .collateral_evaluator_agent import CollateralEvaluatorAgent
from .risk_assessment_agent import RiskAssessmentAgent
from .coordinator_agent import CoordinatorAgent

__all__ = [
    "BaseAgent",
    "CreditScoreAgent",
    "IncomeVerificationAgent",
    "DebtToIncomeAgent",
    "CollateralEvaluatorAgent",
    "RiskAssessmentAgent",
    "CoordinatorAgent"
]
