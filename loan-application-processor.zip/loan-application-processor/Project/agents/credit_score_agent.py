"""
Credit Score Analyzer Agent

Analyzes applicant's credit score and credit history to determine
creditworthiness and appropriate interest rates.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.credit_score_analyzer import CreditScoreAnalyzer
from state import LoanApplicationState


class CreditScoreAgent(BaseAgent):
    """Agent responsible for credit score analysis"""

    def __init__(self):
        super().__init__("CreditScoreAnalyzer")
        self.analyzer = CreditScoreAnalyzer()

    def analyze(self, state: LoanApplicationState = None) -> Dict[str, Any]:
        """
        Analyze credit score and determine creditworthiness

        Can accept either a LoanApplicationState object or a dict.

        Args:
            state: Current loan application state OR application dict

        Returns:
            Credit analysis results with score assessment and recommended rates
        """
        # Support dict input for backwards compatibility
        if isinstance(state, dict):
            app_data = state
            app_id = app_data.get("application_id", "UNKNOWN")
            self.log(f"Analyzing credit score for application {app_id}")
            # Pass the dict directly to analyzer which supports dict input
            return self.analyzer.analyze_credit(app_data)

        self.log(f"Analyzing credit score for application {state.application_id}")

        try:
            # Extract credit parameters
            credit_score = state.credit_score
            loan_amount = state.loan_amount
            loan_purpose = state.loan_purpose
            existing_debts = state.existing_debts

            # Perform credit analysis
            analysis_result = self.analyzer.analyze_credit(
                credit_score=credit_score,
                loan_amount=loan_amount,
                loan_purpose=loan_purpose,
                existing_debts=existing_debts
            )

            self.log(
                f"Credit analysis complete - Score: {credit_score}, "
                f"Rating: {analysis_result.get('credit_rating', 'N/A')}, "
                f"Risk Level: {analysis_result.get('risk_level', 'N/A')}"
            )

            return analysis_result

        except Exception as e:
            self.log(f"Error during credit analysis: {str(e)}", level="error")
            return {
                "agent": "CreditScoreAnalyzer",
                "status": "error",
                "error_message": str(e),
                "credit_rating": "UNKNOWN",
                "credit_score_value": 0
            }
