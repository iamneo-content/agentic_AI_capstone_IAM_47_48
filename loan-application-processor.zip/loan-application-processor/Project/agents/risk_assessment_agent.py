"""
Risk Assessment Agent

Performs comprehensive risk assessment by analyzing credit, income, debt,
and collateral factors to determine overall loan risk level.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.risk_assessor import RiskAssessor
from state import LoanApplicationState


class RiskAssessmentAgent(BaseAgent):
    """Agent responsible for comprehensive risk assessment"""

    def __init__(self):
        super().__init__("RiskAssessment")
        self.assessor = RiskAssessor()

    def analyze(self, state: LoanApplicationState) -> Dict[str, Any]:
        """
        Perform comprehensive risk assessment

        Args:
            state: Current loan application state

        Returns:
            Risk assessment results with overall risk score
        """
        self.log(f"Performing risk assessment for application {state.application_id}")

        try:
            # Extract all relevant parameters
            credit_score = state.credit_score
            annual_income = state.annual_income
            monthly_debt_payments = state.monthly_debt_payments
            loan_amount = state.loan_amount
            loan_purpose = state.loan_purpose
            employment_status = state.employment_status
            employment_duration_months = state.employment_duration_months
            collateral_type = state.collateral_type
            collateral_value = state.collateral_value
            existing_debts = state.existing_debts

            # Perform risk assessment
            risk_result = self.assessor.assess_risk(
                credit_score=credit_score,
                annual_income=annual_income,
                monthly_debt_payments=monthly_debt_payments,
                loan_amount=loan_amount,
                loan_purpose=loan_purpose,
                employment_status=employment_status,
                employment_duration_months=employment_duration_months,
                collateral_type=collateral_type,
                collateral_value=collateral_value,
                existing_debts=existing_debts
            )

            self.log(
                f"Risk assessment complete - Risk Score: {risk_result.get('risk_score', 0):.2f}/10, "
                f"Risk Level: {risk_result.get('risk_level', 'N/A')}, "
                f"Default Probability: {risk_result.get('default_probability', 0):.2%}"
            )

            return risk_result

        except Exception as e:
            self.log(f"Error during risk assessment: {str(e)}", level="error")
            return {
                "agent": "RiskAssessment",
                "status": "error",
                "error_message": str(e),
                "risk_level": "UNKNOWN",
                "risk_score": 0.0
            }
