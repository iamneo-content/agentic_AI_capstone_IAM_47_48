"""
Configuration Management

Centralized configuration for loan application processing system.
Loads from environment variables with sensible defaults.
"""

import os
from typing import Any, Dict
from pathlib import Path
from dotenv import load_dotenv


# Default configuration values
DEFAULT_CONFIG = {
    # Credit score thresholds
    "EXCELLENT_CREDIT_THRESHOLD": 750,
    "GOOD_CREDIT_THRESHOLD": 670,
    "FAIR_CREDIT_THRESHOLD": 580,
    "MIN_CREDIT_SCORE": 300,

    # Income verification thresholds
    "MIN_INCOME_MULTIPLIER": 0.25,  # Loan amount should not exceed 4x annual income
    "STABLE_EMPLOYMENT_MONTHS": 12,

    # Debt-to-Income ratio thresholds
    "MAX_DTI_RATIO": 0.43,  # 43% is typical max for approval
    "IDEAL_DTI_RATIO": 0.36,  # 36% or below is ideal
    "CRITICAL_DTI_RATIO": 0.50,  # Above 50% is critical

    # Collateral thresholds (Loan-to-Value ratio)
    "MAX_LTV_RATIO": 0.90,  # 90% max loan-to-value
    "IDEAL_LTV_RATIO": 0.80,  # 80% or below is ideal

    # Risk assessment thresholds
    "LOW_RISK_THRESHOLD": 7.5,
    "MODERATE_RISK_THRESHOLD": 5.5,
    "HIGH_RISK_THRESHOLD": 3.5,

    # Interest rate ranges (%)
    "BASE_INTEREST_RATE": 5.0,
    "EXCELLENT_CREDIT_RATE": 4.5,
    "GOOD_CREDIT_RATE": 6.0,
    "FAIR_CREDIT_RATE": 8.5,
    "POOR_CREDIT_RATE": 12.0,

    # Approval criteria
    "AUTO_APPROVE_RISK_SCORE": 8.0,
    "CONDITIONAL_APPROVE_RISK_SCORE": 6.0,
    "MIN_APPROVAL_RISK_SCORE": 5.0,

    # Email configuration
    "SMTP_SERVER": "smtp.gmail.com",
    "SMTP_PORT": 587,
    "SMTP_USERNAME": "",
    "SMTP_PASSWORD": "",
    "FROM_EMAIL": "noreply@loanprocessor.com",

    # Gemini AI configuration (optional)
    "GEMINI_API_KEY": "",
    "GEMINI_MODEL": "gemini-pro",

    # Application settings
    "LOG_LEVEL": "INFO",
    "MAX_WORKERS": 5,
}


class ConfigManager:
    """Singleton configuration manager"""

    _instance = None
    _config: Dict[str, Any] = {}
    _loaded = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._loaded:
            self._load_config()
            self._loaded = True

    def _load_config(self):
        """Load configuration from .env file and environment variables"""
        # Try to load .env file from current directory and parent directories
        current_dir = Path.cwd()
        env_file = current_dir / ".env"

        if env_file.exists():
            load_dotenv(env_file)
            self.config_file = str(env_file)
        else:
            # Try parent directory
            parent_env = current_dir.parent / ".env"
            if parent_env.exists():
                load_dotenv(parent_env)
                self.config_file = str(parent_env)
            else:
                self.config_file = "No .env file found (using defaults)"

        # Load configuration with environment variable overrides
        for key, default_value in DEFAULT_CONFIG.items():
            env_value = os.getenv(key)

            if env_value is not None:
                # Type conversion based on default value type
                if isinstance(default_value, bool):
                    self._config[key] = env_value.lower() in ("true", "1", "yes")
                elif isinstance(default_value, int):
                    try:
                        self._config[key] = int(env_value)
                    except ValueError:
                        self._config[key] = default_value
                elif isinstance(default_value, float):
                    try:
                        self._config[key] = float(env_value)
                    except ValueError:
                        self._config[key] = default_value
                else:
                    self._config[key] = env_value
            else:
                self._config[key] = default_value

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value

        Args:
            key: Configuration key
            default: Default value if key not found

        Returns:
            Configuration value
        """
        return self._config.get(key, default)

    def set(self, key: str, value: Any):
        """
        Set configuration value (runtime override)

        Args:
            key: Configuration key
            value: Configuration value
        """
        self._config[key] = value

    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values"""
        return self._config.copy()


# Global singleton instance
_config_manager = ConfigManager()


def get_config() -> ConfigManager:
    """
    Get the global configuration manager instance

    Returns:
        ConfigManager: The singleton configuration manager
    """
    return _config_manager


def get_config_value(key: str, default: Any = None) -> Any:
    """
    Get a configuration value by key

    Args:
        key: Configuration key
        default: Default value if key not found

    Returns:
        Configuration value or default
    """
    return _config_manager.get(key, default)
