#!/usr/bin/env python3
"""
Comprehensive Test Suite for Loan Application Processor

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import LoanState
    from graph import LoanGraph
    from workflows.loan_workflow import build_loan_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.credit_score_agent import CreditScoreAgent
    from agents.income_verification_agent import IncomeVerificationAgent
    from agents.debt_to_income_agent import DebtToIncomeAgent
    from agents.collateral_evaluator_agent import CollateralEvaluatorAgent
    from agents.risk_assessment_agent import RiskAssessmentAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.credit_score_analyzer import CreditScoreAnalyzer
    from analyzers.income_verifier import IncomeVerifier
    from analyzers.dti_calculator import DTICalculator
    from analyzers.collateral_evaluator import CollateralEvaluator
    from analyzers.risk_assessor import RiskAssessor

    # Import nodes
    from nodes.input_validation_node import input_validation_node
    from nodes.credit_analysis_node import credit_analysis_node
    from nodes.income_verification_node import income_verification_node
    from nodes.dti_calculation_node import dti_calculation_node
    from nodes.collateral_evaluation_node import collateral_evaluation_node
    from nodes.risk_assessment_node import risk_assessment_node
    from nodes.decision_finalization_node import decision_finalization_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestLoanApplicationProcessorArchitecture(unittest.TestCase):
    """Test suite for Loan Application Processor Architecture"""

    SAMPLE_APPLICATION = {
        "application_id": "TEST-123",
        "applicant": {
            "name": "John Doe",
            "age": 35,
            "employment_status": "employed"
        },
        "credit_score": 720,
        "annual_income": 75000,
        "monthly_debt_payments": 2000,
        "loan_amount": 200000,
        "loan_purpose": "home purchase",
        "collateral": {
            "type": "property",
            "value": 250000
        }
    }

    def setUp(self):
        """Setup test environment"""
        self.sample_application = self.SAMPLE_APPLICATION.copy()

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test LoanState dataclass creation"""
        logger.info("Testing LoanState creation...")

        state = LoanState(
            application_id="TEST-123",
            application_data=self.sample_application
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.application_id, "TEST-123", "Application ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test LoanState clone method"""
        logger.info("Testing LoanState clone...")

        state = LoanState(application_id="TEST-123", application_data=self.sample_application)
        state.credit_results = [{"test": "data"}]

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.application_id, state.application_id, "Application ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_credit_score_analyzer(self):
        """Test CreditScoreAnalyzer (pure tool)"""
        logger.info("Testing CreditScoreAnalyzer...")

        analyzer = CreditScoreAnalyzer()
        results = analyzer.analyze_credit(self.sample_application)

        self.assertIsNotNone(results, "Credit score analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ CreditScoreAnalyzer tests passed")

    def test_income_verifier(self):
        """Test IncomeVerifier (pure tool)"""
        logger.info("Testing IncomeVerifier...")

        analyzer = IncomeVerifier()
        results = analyzer.verify_income(self.sample_application)

        self.assertIsNotNone(results, "Income verification results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ IncomeVerifier tests passed")

    def test_dti_calculator(self):
        """Test DTICalculator (pure tool)"""
        logger.info("Testing DTICalculator...")

        analyzer = DTICalculator()
        results = analyzer.calculate_dti(self.sample_application)

        self.assertIsNotNone(results, "DTI calculation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ DTICalculator tests passed")

    def test_collateral_evaluator(self):
        """Test CollateralEvaluator (pure tool)"""
        logger.info("Testing CollateralEvaluator...")

        analyzer = CollateralEvaluator()
        results = analyzer.evaluate_collateral(self.sample_application)

        self.assertIsNotNone(results, "Collateral evaluation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ CollateralEvaluator tests passed")

    def test_risk_assessor(self):
        """Test RiskAssessor (pure tool)"""
        logger.info("Testing RiskAssessor...")

        analyzer = RiskAssessor()
        results = analyzer.assess_risk(self.sample_application)

        self.assertIsNotNone(results, "Risk assessment results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ RiskAssessor tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_credit_score_agent(self):
        """Test CreditScoreAgent (coordinator)"""
        logger.info("Testing CreditScoreAgent...")

        agent = CreditScoreAgent()
        results = agent.analyze(self.sample_application)

        self.assertIsNotNone(results, "Credit score agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ CreditScoreAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_input_validation_node(self):
        """Test input_validation_node (thin wrapper)"""
        logger.info("Testing input_validation_node...")

        state = LoanState(
            application_id="TEST-APP",
            application_data=self.sample_application
        )

        result = input_validation_node(state)

        self.assertIsNotNone(result, "Input validation node result should not be None")
        self.assertIsInstance(result, LoanState, "Result should be LoanState")

        logger.info("✓ input_validation_node tests passed")

    def test_credit_analysis_node(self):
        """Test credit_analysis_node (thin wrapper)"""
        logger.info("Testing credit_analysis_node...")

        state = LoanState(
            application_id="TEST-APP",
            application_data=self.sample_application
        )

        result = credit_analysis_node(state)

        self.assertIsNotNone(result, "Credit analysis node result should not be None")
        self.assertIsInstance(result, LoanState, "Result should be LoanState")

        logger.info("✓ credit_analysis_node tests passed")

    def test_decision_finalization_node(self):
        """Test decision_finalization_node logic"""
        logger.info("Testing decision_finalization_node...")

        state = LoanState(
            application_id="TEST-APP",
            credit_results=[{"credit_score": 720}],
            income_results=[{"income_verified": True}],
            dti_results=[{"dti_ratio": 0.32}],
            collateral_results=[{"collateral_value": 250000}],
            risk_results=[{"risk_level": "low"}]
        )

        result = decision_finalization_node(state)

        self.assertIsNotNone(result, "Decision result should not be None")
        self.assertIsInstance(result, LoanState, "Result should be LoanState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ decision_finalization_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_loan_graph_creation(self):
        """Test LoanGraph class creation"""
        logger.info("Testing LoanGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = LoanGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ LoanGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_loan_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, LoanGraph, "Workflow should be LoanGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        credit_agent = CreditScoreAgent()
        self.assertIsNotNone(credit_agent.analyzer, "CreditScoreAgent should have an analyzer")
        self.assertIsInstance(credit_agent.analyzer, CreditScoreAnalyzer, "Should use CreditScoreAnalyzer")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = LoanState(
            application_id="TEST-APP",
            application_data=self.sample_application
        )

        result = credit_analysis_node(state)
        self.assertIsInstance(result, LoanState, "Node should return LoanState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Loan Application Processor - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
