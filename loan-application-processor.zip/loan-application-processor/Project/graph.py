"""
Loan Processing Graph

Custom graph execution engine for parallel multi-agent loan processing.
Supports multi-stage workflows with parallel execution within stages.
"""

import logging
from typing import List, Callable, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

from state import LoanApplicationState

# Type alias for node functions
NodeFunc = Callable[[LoanApplicationState], LoanApplicationState]

logger = logging.getLogger("graph.loan_processing")


class LoanProcessingGraph:
    """
    Custom graph for loan application processing with parallel execution support

    Executes nodes in stages, where nodes within a stage can run in parallel.
    Results from parallel nodes are merged back into the state.
    """

    def __init__(
        self,
        stages: List[List[NodeFunc]],
        max_workers: int = 5,
        raise_on_error: bool = False
    ):
        """
        Initialize the loan processing graph

        Args:
            stages: List of stages, each stage is a list of node functions
            max_workers: Maximum number of parallel workers
            raise_on_error: Whether to raise exceptions or continue on error
        """
        self.stages = stages
        self.max_workers = max_workers
        self.raise_on_error = raise_on_error
        logger.info(f"Initialized LoanProcessingGraph with {len(stages)} stages")

    def run(self, initial_state: LoanApplicationState) -> LoanApplicationState:
        """
        Execute the entire workflow

        Args:
            initial_state: Starting state for the workflow

        Returns:
            Final state after all stages complete
        """
        logger.info("Starting loan processing workflow")
        current_state = initial_state.clone()

        for stage_idx, stage_nodes in enumerate(self.stages, 1):
            logger.info(f"Executing Stage {stage_idx} with {len(stage_nodes)} node(s)")

            try:
                if len(stage_nodes) == 1:
                    # Sequential execution for single node
                    current_state = self._execute_sequential(stage_nodes, current_state)
                else:
                    # Parallel execution for multiple nodes
                    current_state = self._execute_parallel(stage_nodes, current_state)

                # Check for critical errors
                if current_state.error and self.raise_on_error:
                    raise RuntimeError(f"Stage {stage_idx} failed: {current_state.error}")

                logger.info(f"Stage {stage_idx} completed successfully")

            except Exception as e:
                logger.error(f"Error in Stage {stage_idx}: {str(e)}")
                if self.raise_on_error:
                    raise
                current_state.error = f"Stage {stage_idx} error: {str(e)}"

        logger.info("Loan processing workflow completed")
        return current_state

    def _execute_sequential(
        self,
        nodes: List[NodeFunc],
        state: LoanApplicationState
    ) -> LoanApplicationState:
        """Execute nodes sequentially"""
        current_state = state
        for node in nodes:
            node_name = node.__name__
            logger.debug(f"Executing node: {node_name}")
            try:
                current_state = node(current_state)
            except Exception as e:
                logger.error(f"Error in node {node_name}: {str(e)}")
                if self.raise_on_error:
                    raise
                current_state.error = f"Node {node_name} error: {str(e)}"
        return current_state

    def _execute_parallel(
        self,
        nodes: List[NodeFunc],
        state: LoanApplicationState
    ) -> LoanApplicationState:
        """Execute nodes in parallel and merge results"""
        results = []
        base_state = state.clone()

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all nodes
            future_to_node = {
                executor.submit(node, base_state.clone()): node
                for node in nodes
            }

            # Collect results as they complete
            for future in as_completed(future_to_node):
                node = future_to_node[future]
                node_name = node.__name__

                try:
                    result = future.result()
                    results.append(result)
                    logger.debug(f"Node {node_name} completed successfully")
                except Exception as e:
                    logger.error(f"Error in parallel node {node_name}: {str(e)}")
                    if self.raise_on_error:
                        raise
                    # Create error result
                    error_state = base_state.clone()
                    error_state.error = f"Node {node_name} error: {str(e)}"
                    results.append(error_state)

        # Merge all results back into base state
        merged_state = base_state.clone()
        for result in results:
            merged_state.merge_from(result, overwrite_scalars=False)

        return merged_state


# Alias for backward compatibility
LoanGraph = LoanProcessingGraph
