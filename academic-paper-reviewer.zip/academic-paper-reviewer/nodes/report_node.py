"""
Report Node

Generates final review report and sends email notification.
"""

from state import PaperReviewState
from services.email_service import EmailService
from datetime import datetime
import logging

logger = logging.getLogger("node.report")


def report_node(state: PaperReviewState) -> PaperReviewState:
    """
    Generate final review report and send email notification

    Args:
        state: Current paper review state

    Returns:
        Updated state with report
    """
    logger.info("Generating final review report")

    # Determine priority based on decision
    if state.decision == "ACCEPT":
        priority = "HIGH"
    elif state.decision in ["MINOR_REVISION", "MAJOR_REVISION"]:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    # Key findings
    key_findings = [
        f"Overall Score: {state.overall_score:.2f}/10",
        f"Decision: {state.decision}",
        f"Confidence: {state.confidence_level}"
    ]

    if state.has_critical_issues:
        key_findings.append(f"Critical Issues: {state.critical_reason}")

    # Action items based on decision
    action_items = []
    if state.decision == "ACCEPT":
        action_items.extend([
            "Proceed with publication",
            "Send acceptance notification to authors",
            "Request final camera-ready version"
        ])
    elif state.decision == "MINOR_REVISION":
        action_items.extend([
            "Request minor revisions from authors",
            "Schedule re-review after revisions",
            "Provide detailed feedback"
        ])
    elif state.decision == "MAJOR_REVISION":
        action_items.extend([
            "Request major revisions from authors",
            "Schedule full re-review",
            "Provide comprehensive revision guidelines"
        ])
    else:  # REJECT
        action_items.extend([
            "Send rejection notification",
            "Provide constructive feedback",
            "Suggest alternative venues if applicable"
        ])

    # Compile all recommendations
    all_recommendations = []
    if state.methodology_results:
        all_recommendations.extend(state.methodology_results[0].get("recommendations", []))
    if state.novelty_results:
        all_recommendations.extend(state.novelty_results[0].get("recommendations", []))
    if state.citation_results:
        all_recommendations.extend(state.citation_results[0].get("recommendations", []))
    if state.writing_quality_results:
        all_recommendations.extend(state.writing_quality_results[0].get("recommendations", []))
    if state.reproducibility_results:
        all_recommendations.extend(state.reproducibility_results[0].get("recommendations", []))

    # Create report
    report = {
        "review_id": state.review_id,
        "paper_title": state.paper_title,
        "authors": state.authors,
        "conference_journal": state.conference_journal,
        "timestamp": state.timestamp,
        "overall_score": state.overall_score,
        "decision": state.decision,
        "confidence_level": state.confidence_level,
        "priority": priority,
        "key_findings": key_findings,
        "action_items": action_items,
        "strengths": state.strengths[:5],  # Top 5 strengths
        "weaknesses": state.weaknesses[:5],  # Top 5 weaknesses
        "reviewer_comments": state.reviewer_comments,
        "revision_suggestions": state.revision_suggestions,
        "all_recommendations": all_recommendations[:10],  # Top 10
        "metrics": state.decision_metrics
    }

    state.report = report

    # Send email notification
    try:
        email_service = EmailService()

        # Send review start notification
        email_service.send_review_start_email(
            state.review_id,
            state.paper_title,
            state.conference_journal
        )

        # Send final report
        email_service.send_final_report_email(state)

        state.notifications_sent.append({
            "type": "email",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "sent"
        })

        logger.info("Email notifications sent successfully")
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        state.notifications_sent.append({
            "type": "email",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "failed",
            "error": str(e)
        })

    logger.info("Report generation complete")
    return state
