"""
Methodology Reviewer Node - Simplified Wrapper

Calls MethodologyReviewerAgent to review methodology.
"""

from state import PaperReviewState
from agents.methodology_reviewer_agent import MethodologyReviewerAgent

# Create agent instance
agent = MethodologyReviewerAgent()


def methodology_reviewer_node(state: PaperReviewState) -> PaperReviewState:
    """
    Review research methodology

    Args:
        state: Current paper review state

    Returns:
        Updated state with methodology review results
    """
    state.methodology_results = agent.analyze(state.paper_content, state.paper_metadata)
    return state
