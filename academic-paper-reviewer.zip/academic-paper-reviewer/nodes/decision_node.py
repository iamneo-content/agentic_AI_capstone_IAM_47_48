"""
Decision Node

Makes automated peer review decision based on coordinated results.
"""

from state import PaperReviewState
from config import get_config_value
import logging

logger = logging.getLogger("node.decision")


def decision_node(state: PaperReviewState) -> PaperReviewState:
    """
    Make automated peer review decision

    Args:
        state: Current paper review state

    Returns:
        Updated state with decision and metrics
    """
    logger.info("Making automated peer review decision")

    summary = state.coordination_summary
    overall_score = summary.get("overall_score", 0)

    # Get thresholds from config
    methodology_threshold = get_config_value("METHODOLOGY_THRESHOLD", 7.0)
    novelty_threshold = get_config_value("NOVELTY_THRESHOLD", 6.0)
    overall_accept_threshold = get_config_value("OVERALL_ACCEPT_THRESHOLD", 7.5)

    # Extract individual scores
    methodology_score = summary.get("methodology_score", 0)
    novelty_score = summary.get("novelty_score", 0)
    citation_score = summary.get("citation_score", 0)
    writing_score = summary.get("writing_quality_score", 0)
    reproducibility_score = summary.get("reproducibility_score", 0)

    # Check for critical issues
    has_critical_issues = summary.get("has_critical_issues", False)
    critical_issues = summary.get("critical_issues", [])
    critical_reason = "; ".join(critical_issues) if critical_issues else ""

    # Determine confidence level
    if overall_score >= 8.5:
        confidence_level = "HIGH"
    elif overall_score >= 7.0:
        confidence_level = "MEDIUM"
    else:
        confidence_level = "LOW"

    # Make decision: ACCEPT, MINOR_REVISION, MAJOR_REVISION, or REJECT
    decision = ""

    if has_critical_issues or methodology_score < 5.0:
        decision = "REJECT"
    elif overall_score >= 8.5 and methodology_score >= methodology_threshold and novelty_score >= novelty_threshold:
        decision = "ACCEPT"
    elif overall_score >= overall_accept_threshold and methodology_score >= methodology_threshold - 0.5:
        decision = "MINOR_REVISION"
    elif overall_score >= 6.0 and methodology_score >= 6.0:
        decision = "MAJOR_REVISION"
    else:
        decision = "REJECT"

    # Generate reviewer comments
    reviewer_comments = []

    # Methodology comments
    if methodology_score >= 8.0:
        reviewer_comments.append("The methodology is rigorous and well-designed")
    elif methodology_score < 6.0:
        reviewer_comments.append("The methodology needs significant improvement")

    # Novelty comments
    if novelty_score >= 7.0:
        reviewer_comments.append("The work presents significant novel contributions")
    elif novelty_score < 5.0:
        reviewer_comments.append("The novelty of the work is questionable")

    # Reproducibility comments
    if reproducibility_score >= 8.0:
        reviewer_comments.append("Excellent reproducibility with code and data available")
    elif reproducibility_score < 6.0:
        reviewer_comments.append("Reproducibility could be improved with more details")

    # Generate revision suggestions based on decision
    revision_suggestions = []

    if decision in ["MAJOR_REVISION", "MINOR_REVISION"]:
        if methodology_score < methodology_threshold:
            revision_suggestions.append("Strengthen methodology section with more details")
        if novelty_score < novelty_threshold:
            revision_suggestions.append("Better articulate novelty and contributions")
        if citation_score < 7.0:
            revision_suggestions.append("Expand literature review with more citations")
        if writing_score < 7.0:
            revision_suggestions.append("Improve writing clarity and organization")
        if reproducibility_score < 7.0:
            revision_suggestions.append("Provide code/data or more implementation details")

    # Store decision metrics
    decision_metrics = {
        "overall_score": overall_score,
        "methodology_score": methodology_score,
        "novelty_score": novelty_score,
        "citation_score": citation_score,
        "writing_quality_score": writing_score,
        "reproducibility_score": reproducibility_score
    }

    state.decision = decision
    state.overall_score = overall_score
    state.confidence_level = confidence_level
    state.has_critical_issues = has_critical_issues
    state.critical_reason = critical_reason
    state.decision_metrics = decision_metrics
    state.reviewer_comments = reviewer_comments
    state.revision_suggestions = revision_suggestions

    logger.info(f"Decision: {decision}, Overall Score: {overall_score:.2f}/10")
    return state
