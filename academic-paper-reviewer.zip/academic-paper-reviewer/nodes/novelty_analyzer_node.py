"""
Novelty Analyzer Node - Simplified Wrapper

Calls NoveltyAnalyzerAgent to analyze novelty.
"""

from state import PaperReviewState
from agents.novelty_analyzer_agent import NoveltyAnalyzerAgent

# Create agent instance
agent = NoveltyAnalyzerAgent()


def novelty_analyzer_node(state: PaperReviewState) -> PaperReviewState:
    """
    Analyze research novelty

    Args:
        state: Current paper review state

    Returns:
        Updated state with novelty analysis results
    """
    state.novelty_results = agent.analyze(
        state.paper_content,
        state.paper_abstract,
        state.paper_metadata
    )
    return state
