"""
Citation Checker Agent

Agent responsible for checking citations and references quality.
Uses CitationChecker as a tool for actual checking.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.citation_checker import CitationChecker


class CitationCheckerAgent(BaseAgent):
    """Agent for citation and reference checking"""

    def __init__(self):
        """Initialize citation checker agent with checker"""
        super().__init__("citation_checker")
        self.checker = CitationChecker()
        self.log("Citation checker agent initialized")

    def analyze(self, paper_content: str, paper_metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Check citations and references quality

        Pure reasoning logic only - coordinates checking using checker tool

        Args:
            paper_content: Full paper content
            paper_metadata: Paper metadata

        Returns:
            List of citation checking results
        """
        self.log("Checking citations and references")
        results: List[Dict[str, Any]] = []

        # Use checker tool for actual checking
        check = self.checker.check_citations(paper_content, paper_metadata)

        results.append({
            "citation_score": check.get("citation_score", 0),
            "total_citations": check.get("total_citations", 0),
            "recent_citations_percentage": check.get("recent_citations_percentage", 0),
            "citation_quality": check.get("citation_quality", ""),
            "key_works_cited": check.get("key_works_cited", []),
            "missing_citations": check.get("missing_citations", []),
            "citation_issues": check.get("citation_issues", []),
            "recommendations": check.get("recommendations", [])
        })

        score = check.get("citation_score", 0)
        total = check.get("total_citations", 0)
        self.log(f"Citation check complete: Score {score}/10, {total} citations found")
        return results
