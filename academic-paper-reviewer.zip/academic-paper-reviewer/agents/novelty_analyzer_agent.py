"""
Novelty Analyzer Agent

Agent responsible for analyzing research novelty and contributions.
Uses NoveltyAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.novelty_analyzer import NoveltyAnalyzer


class NoveltyAnalyzerAgent(BaseAgent):
    """Agent for novelty and contribution analysis"""

    def __init__(self):
        """Initialize novelty analyzer agent with analyzer"""
        super().__init__("novelty_analyzer")
        self.analyzer = NoveltyAnalyzer()
        self.log("Novelty analyzer agent initialized")

    def analyze(self, paper_content: str, paper_abstract: str, paper_metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze research novelty and contributions

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            paper_content: Full paper content
            paper_abstract: Paper abstract
            paper_metadata: Paper metadata

        Returns:
            List of novelty analysis results
        """
        self.log("Analyzing research novelty and contributions")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_novelty(paper_content, paper_abstract, paper_metadata)

        results.append({
            "novelty_score": analysis.get("novelty_score", 0),
            "contribution_level": analysis.get("contribution_level", ""),
            "key_contributions": analysis.get("key_contributions", []),
            "existing_work_comparison": analysis.get("existing_work_comparison", ""),
            "innovation_assessment": analysis.get("innovation_assessment", ""),
            "novelty_concerns": analysis.get("novelty_concerns", []),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("novelty_score", 0)
        self.log(f"Novelty analysis complete: Score {score}/10")
        return results
