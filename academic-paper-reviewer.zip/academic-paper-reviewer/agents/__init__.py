"""Agent classes for academic paper review"""

from .base_agent import BaseAgent
from .methodology_reviewer_agent import MethodologyReviewerAgent
from .novelty_analyzer_agent import NoveltyAnalyzerAgent
from .citation_checker_agent import CitationCheckerAgent
from .writing_quality_agent import WritingQualityAgent
from .reproducibility_agent import ReproducibilityAgent
from .coordinator_agent import CoordinatorAgent

__all__ = [
    "BaseAgent",
    "MethodologyReviewerAgent",
    "NoveltyAnalyzerAgent",
    "CitationCheckerAgent",
    "WritingQualityAgent",
    "ReproducibilityAgent",
    "CoordinatorAgent"
]
