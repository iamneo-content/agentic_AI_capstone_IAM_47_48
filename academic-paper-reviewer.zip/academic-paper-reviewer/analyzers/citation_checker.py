"""
Citation Checker

Pure tool for checking citations and references quality.
No state management - just checking logic.
"""

from typing import Dict, Any, List
import re
import logging

logger = logging.getLogger("analyzer.citation_checker")


class CitationChecker:
    """Analyzer for citation and reference checking"""

    def check_citations(self, paper_content: str, paper_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Check citations and references quality

        Args:
            paper_content: Full paper content
            paper_metadata: Paper metadata

        Returns:
            Dictionary containing citation check results
        """
        logger.info("Checking citations and references")

        # Count citations (simple pattern matching)
        # Looking for patterns like [1], (Author, Year), etc.
        citation_patterns = [
            r'\[\d+\]',  # [1], [2], etc.
            r'\(\w+,?\s+\d{4}\)',  # (Author, 2020)
            r'\(\w+\s+et\s+al\.,?\s+\d{4}\)',  # (Author et al., 2020)
        ]

        total_citations = 0
        for pattern in citation_patterns:
            matches = re.findall(pattern, paper_content)
            total_citations += len(matches)

        # Estimate recent citations (citations from last 5 years)
        # Mock: assume 60% are recent
        recent_citations_percentage = 60.0 if total_citations > 0 else 0

        # Check for references section
        content_lower = paper_content.lower()
        has_references = "references" in content_lower or "bibliography" in content_lower

        # Calculate citation score
        citation_score = 0.0

        if has_references:
            citation_score += 3.0

        # Points based on citation count
        if total_citations >= 30:
            citation_score += 4.0
        elif total_citations >= 20:
            citation_score += 3.0
        elif total_citations >= 10:
            citation_score += 2.0
        elif total_citations >= 5:
            citation_score += 1.0

        # Points for recent citations
        if recent_citations_percentage >= 50:
            citation_score += 2.0
        elif recent_citations_percentage >= 30:
            citation_score += 1.0

        # Points for foundational works
        foundational_keywords = ["seminal", "foundational", "pioneering", "landmark"]
        has_foundational = any(kw in content_lower for kw in foundational_keywords)
        if has_foundational:
            citation_score += 1.0

        citation_score = min(citation_score, 10.0)

        # Determine citation quality
        if citation_score >= 8.0:
            citation_quality = "Excellent"
        elif citation_score >= 6.0:
            citation_quality = "Good"
        elif citation_score >= 4.0:
            citation_quality = "Adequate"
        else:
            citation_quality = "Insufficient"

        # Key works cited (mock)
        key_works_cited = []
        if total_citations >= 10:
            key_works_cited.append("Adequate coverage of prior work")
        if has_foundational:
            key_works_cited.append("Cites foundational works in the field")

        # Missing citations (mock)
        missing_citations = []
        if total_citations < 10:
            missing_citations.append("Limited citation of prior work")
        if recent_citations_percentage < 30:
            missing_citations.append("Few recent citations (last 5 years)")

        # Citation issues
        citation_issues = []
        if not has_references:
            citation_issues.append("No references section found")
        if total_citations < 5:
            citation_issues.append("Very few citations - insufficient literature review")
        if recent_citations_percentage < 20:
            citation_issues.append("Citations are predominantly old")

        # Recommendations
        recommendations = []
        if total_citations < 10:
            recommendations.append("Expand literature review with more citations")
        if recent_citations_percentage < 40:
            recommendations.append("Include more recent publications (last 3-5 years)")
        if not has_references:
            recommendations.append("Add proper references section")
        if citation_score >= 8.0:
            recommendations.append("Citation quality is strong")

        result = {
            "citation_score": round(citation_score, 2),
            "total_citations": total_citations,
            "recent_citations_percentage": round(recent_citations_percentage, 2),
            "citation_quality": citation_quality,
            "key_works_cited": key_works_cited,
            "missing_citations": missing_citations,
            "citation_issues": citation_issues,
            "recommendations": recommendations
        }

        logger.info(f"Citation check complete: Score {citation_score:.1f}/10, {total_citations} citations")
        return result
