"""
Paper Review Workflow Builder

Defines the staged academic paper review pipeline with parallel and sequential nodes.
"""

from graph import PaperReviewGraph
from nodes import (
    methodology_reviewer_node,
    novelty_analyzer_node,
    citation_checker_node,
    writing_quality_node,
    reproducibility_node,
    coordinator_node,
    decision_node,
    report_node
)


def build_review_workflow(max_workers: int = 5) -> PaperReviewGraph:
    """
    Build the academic paper review workflow with parallel execution

    Stages:
    1. Parallel reviews (methodology, novelty, citations, writing, reproducibility)
    2. Coordinator (aggregate results)
    3. Decision (make review decision)
    4. Report (generate final report and send notification)

    Args:
        max_workers: Maximum number of parallel workers (default: 5)

    Returns:
        Compiled PaperReviewGraph ready for execution
    """
    stages = [
        # Stage 1: Parallel reviews (all 5 run simultaneously)
        [
            methodology_reviewer_node,
            novelty_analyzer_node,
            citation_checker_node,
            writing_quality_node,
            reproducibility_node
        ],

        # Stage 2: Coordinator
        [coordinator_node],

        # Stage 3: Decision
        [decision_node],

        # Stage 4: Report
        [report_node]
    ]

    return PaperReviewGraph(stages=stages, max_workers=max_workers, raise_on_error=False)
