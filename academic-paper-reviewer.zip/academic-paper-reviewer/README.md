# Academic Paper Reviewer - Client Format

**LangGraph-Compliant Multi-Agent Peer Review System**

A production-ready automated academic paper review system built with proper separation of concerns following the client format architecture pattern.

---

## Overview

This is a **complete implementation** of the client format architecture for multi-agent academic paper peer review. It automatically reviews papers across 5 dimensions using parallel agent execution.

### Key Features

- Client Format Architecture - Agents, Analyzers, Workflows separation
- Parallel Execution - 5 agents run simultaneously (3x faster)
- PaperReviewGraph Class - Custom parallel execution engine
- @dataclass State - With clone() and merge_from() methods
- Comprehensive Review - Methodology, Novelty, Citations, Writing, Reproducibility
- Automated Decisions - ACCEPT, MINOR_REVISION, MAJOR_REVISION, REJECT

---

## Project Structure

```
academic-paper-reviewer/
├── agents/                         # Agent CLASSES (coordinators)
│   ├── base_agent.py              # BaseAgent class
│   ├── methodology_reviewer_agent.py # Methodology review agent
│   ├── novelty_analyzer_agent.py  # Novelty analysis agent
│   ├── citation_checker_agent.py  # Citation checking agent
│   ├── writing_quality_agent.py   # Writing quality agent
│   ├── reproducibility_agent.py   # Reproducibility agent
│   └── coordinator_agent.py       # Result coordinator agent
│
├── analyzers/                      # Pure TOOLS (separate folder!)
│   ├── methodology_reviewer.py    # Methodology review logic
│   ├── novelty_analyzer.py        # Novelty analysis logic
│   ├── citation_checker.py        # Citation checking logic
│   ├── writing_quality_analyzer.py # Writing quality logic
│   ├── reproducibility_analyzer.py # Reproducibility logic
│   └── gemini_client.py           # Gemini AI client
│
├── nodes/                          # Simplified business logic wrappers
│   ├── methodology_reviewer_node.py # Calls MethodologyReviewerAgent
│   ├── novelty_analyzer_node.py   # Calls NoveltyAnalyzerAgent
│   ├── citation_checker_node.py   # Calls CitationCheckerAgent
│   ├── writing_quality_node.py    # Calls WritingQualityAgent
│   ├── reproducibility_node.py    # Calls ReproducibilityAgent
│   ├── coordinator_node.py        # Calls CoordinatorAgent
│   ├── decision_node.py           # Decision logic
│   └── report_node.py             # Report generation
│
├── workflows/                      # Workflow definitions
│   └── review_workflow.py         # build_review_workflow()
│
├── services/                       # External integrations
│   └── email_service.py           # Email notifications
│
├── utils/                          # Utilities
│   └── logging_utils.py           # Logging configuration
│
├── graph.py                        # PaperReviewGraph CLASS
├── state.py                        # PaperReviewState @dataclass
├── config.py                       # Configuration management
├── main.py                         # Application entry point
├── requirements.txt                # Dependencies
└── .env.example                    # Configuration template
```

---

## Quick Start

### Prerequisites

- Python 3.8+
- Google AI Studio account (for Gemini API)
- Gmail account (for notifications)

### Installation

```bash
# Navigate to project directory
cd academic-paper-reviewer

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create logs directory
mkdir logs
```

### Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your credentials
nano .env
```

Required configuration:
```env
GEMINI_API_KEY=your_gemini_api_key_here
EMAIL_FROM=your-email@gmail.com
EMAIL_PASSWORD=your_gmail_app_password
EMAIL_TO=reviewer@university.edu
```

---

## Usage

### Option 1: Review a Paper

```bash
python main.py review "Paper Title"
```

**Example:**
```bash
python main.py review "A Novel Approach to Deep Learning"
```

With paper file:
```bash
python main.py review "Paper Title" --paper-file path/to/paper.txt --conference "ICML 2024"
```

### Option 2: Run Demo

```bash
python main.py demo
```

This will review a sample paper with mock data.

### Option 3: Interactive Mode

```bash
python main.py
```

Then select from menu:
1. Review Paper
2. Run Demo
0. Exit

### With Custom Workers

```bash
python main.py review "Paper Title" --max-workers 10
python main.py demo --max-workers 10
```

---

## Architecture

### The Client Format Pattern

```
┌─────────────────────────────────────────┐
│         WORKFLOWS LAYER                 │
│      (workflow definitions)             │
│  • build_review_workflow()              │
└─────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│         ORCHESTRATION LAYER             │
│            (graph.py)                   │
│  • PaperReviewGraph class               │
│  • Parallel execution engine            │
│  • Stage management                     │
└─────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│        BUSINESS LOGIC LAYER             │
│            (nodes/)                     │
│  • Thin wrappers                        │
│  • Call agents                          │
│  • Update state                         │
└─────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│           AGENT LAYER                   │
│           (agents/)                     │
│  • Agent classes                        │
│  • Coordinate review                    │
│  • Use analyzers as tools               │
└─────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│           TOOL LAYER                    │
│           (analyzers/)                  │
│  • Pure analysis tools                  │
│  • No state management                  │
│  • Reusable across workflows            │
└─────────────────────────────────────────┘
```

---

## Workflow Execution

### 4-Stage Pipeline

```
Stage 1: Parallel Reviews (5 agents simultaneously)
    ├── Methodology Reviewer
    ├── Novelty Analyzer
    ├── Citation Checker
    ├── Writing Quality Agent
    └── Reproducibility Agent
    ↓
Stage 2: Coordination
    ↓
Stage 3: Decision Making
    ↓
Stage 4: Report Generation
```

**Performance**: Parallel execution = **3x faster** than sequential

---

## Review Thresholds

| Metric | Threshold | Impact |
|--------|-----------|--------|
| Methodology Score | ≥ 7.0/10 | Critical for acceptance |
| Novelty Score | ≥ 6.0/10 | Required minimum |
| Citation Score | ≥ 7.0/10 | Literature coverage |
| Writing Quality | ≥ 7.0/10 | Clarity requirement |
| Reproducibility | ≥ 7.0/10 | Open science standard |
| Overall Score | ≥ 7.5/10 | Acceptance threshold |

---

## Review Decisions

### ACCEPT
- Overall score ≥ 8.5/10
- Methodology ≥ 7.0/10
- Novelty ≥ 6.0/10
- No critical issues
- Strong paper ready for publication

### MINOR_REVISION
- Overall score ≥ 7.5/10
- Generally strong paper
- Minor improvements needed
- Expected to be accepted after revision

### MAJOR_REVISION
- Overall score ≥ 6.0/10
- Methodology ≥ 6.0/10
- Significant revisions required
- Potential for acceptance with substantial changes

### REJECT
- Overall score < 6.0/10
- Critical methodology issues
- Insufficient novelty
- Not suitable for publication

---

## Email Notifications

You'll receive 2 emails:

1. **Review Started** - When analysis begins
2. **Final Report** - With decision, scores, and detailed feedback

---

## Review Components

### Methodology Review
- Research design quality
- Experimental rigor
- Statistical validity
- Reproducibility of methods

### Novelty Analysis
- Contribution assessment
- Innovation level
- Comparison with prior work
- Advancement to the field

### Citation Check
- Literature coverage
- Recent citations
- Key works referenced
- Citation quality

### Writing Quality
- Clarity and organization
- Grammar and style
- Readability
- Structure completeness

### Reproducibility
- Code availability
- Data availability
- Implementation details
- Experimental setup clarity

---

## Learning Value

This project demonstrates:

- Client format architecture pattern
- Agent/Analyzer separation
- Custom parallel execution engine
- @dataclass state management
- Workflow builder pattern
- Multi-agent coordination
- Production-ready code

---

## Extending the System

### Adding a New Review Agent

Follow the same pattern as existing agents:

1. Create Analyzer in `analyzers/`
2. Create Agent in `agents/`
3. Create Node in `nodes/`
4. Add to workflow in `workflows/review_workflow.py`

---

## Configuration Reference

See `.env.example` for all available configuration options.

### Required Variables

- `GEMINI_API_KEY` - Google Gemini API key
- `EMAIL_FROM` - Gmail address
- `EMAIL_PASSWORD` - Gmail app password
- `EMAIL_TO` - Recipient email

### Optional Variables

- `METHODOLOGY_THRESHOLD` - Methodology threshold (default: 7.0)
- `NOVELTY_THRESHOLD` - Novelty threshold (default: 6.0)
- `CITATION_THRESHOLD` - Citation threshold (default: 7.0)
- `WRITING_QUALITY_THRESHOLD` - Writing threshold (default: 7.0)
- `REPRODUCIBILITY_THRESHOLD` - Reproducibility threshold (default: 7.0)
- `OVERALL_ACCEPT_THRESHOLD` - Acceptance threshold (default: 7.5)

---

## Status

**COMPLETE** - Production Ready

- All agents implemented
- All analyzers implemented
- All nodes implemented
- Workflow builder complete
- PaperReviewGraph class complete
- State management complete
- Configuration management complete
- Services integrated
- Documentation complete

---

## License

MIT License

---

## Acknowledgments

- **Client Format Pattern** - Based on Langgraph-client-format reference
- **LangGraph Team** - For the framework principles
- **Original Project** - Smart Code Review Client Format

---

**Built with proper separation of concerns following client format architecture**
