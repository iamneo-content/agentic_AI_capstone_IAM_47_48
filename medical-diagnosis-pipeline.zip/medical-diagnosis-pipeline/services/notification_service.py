"""
Notification Service
Sends email notifications for diagnosis events
"""

import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Any
from config import get_config_value

logger = logging.getLogger("notification_service")


class NotificationService:
    """Email notification service for diagnosis reports"""

    def __init__(self):
        self.email_from = get_config_value("EMAIL_FROM", "")
        self.email_password = get_config_value("EMAIL_PASSWORD", "")
        self.email_to = get_config_value("EMAIL_TO", "")
        self.smtp_server = get_config_value("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(get_config_value("SMTP_PORT", 587))

        if not all([self.email_from, self.email_password, self.email_to]):
            logger.warning("Email configuration incomplete - notifications disabled")

    def send_email(self, subject: str, content: str) -> bool:
        """Send email notification"""
        if not all([self.email_from, self.email_password, self.email_to]):
            logger.warning("Email not configured - skipping notification")
            return False

        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_from
            msg['To'] = self.email_to
            msg['Subject'] = subject

            msg.attach(MIMEText(content, 'plain'))

            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.email_from, self.email_password)
                server.send_message(msg)

            logger.info(f"Email sent: {subject}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False

    def send_diagnosis_started(self, patient_details: Dict[str, Any]) -> bool:
        """Send diagnosis started notification"""
        patient_name = patient_details.get('patient_name', 'Unknown')
        patient_id = patient_details.get('patient_id', 'unknown')

        subject = f"Medical Diagnosis Started: Patient {patient_id}"

        content = f"""
MEDICAL DIAGNOSIS STARTED
========================

Patient: {patient_name}
Patient ID: {patient_id}
Age: {patient_details.get('patient_age', 'Unknown')}
Gender: {patient_details.get('patient_gender', 'Unknown')}

The Medical Diagnosis Pipeline has started analyzing this patient.
You will receive the final diagnosis report shortly.

CONFIDENTIAL - This is an automated notification for healthcare providers only.
"""

        return self.send_email(subject, content)

    def send_diagnosis_report(self, patient_details: Dict[str, Any], report: Dict[str, Any], is_critical: bool) -> bool:
        """Send final diagnosis report notification"""
        patient_name = patient_details.get('patient_name', 'Unknown')
        patient_id = report.get('patient_id', 'unknown')

        status_prefix = "URGENT - CRITICAL FINDINGS" if is_critical else "DIAGNOSIS REPORT"
        decision = report.get('decision', 'NEEDS_REVIEW').upper()

        subject = f"{status_prefix}: Patient {patient_id}"

        content = f"""
{status_prefix}
========================

Patient: {patient_name}
Patient ID: {patient_id}
Diagnosis ID: {report.get('diagnosis_id', 'unknown')}
Timestamp: {report.get('timestamp', 'unknown')}

CLINICAL DECISION: {report.get('recommendation', decision)}
PRIORITY: {report.get('priority', 'ROUTINE')}

{self._format_report(report)}

CONFIDENTIAL - This is an automated clinical decision support notification.
All findings must be reviewed and validated by qualified healthcare professionals.
This system provides diagnostic assistance only and does not replace clinical judgment.
"""

        return self.send_email(subject, content)

    def _format_report(self, report: Dict[str, Any]) -> str:
        """Format report for email"""
        sections = []

        # Overall Assessment
        sections.append("OVERALL ASSESSMENT:")
        sections.append(f"  Severity Score: {report.get('overall_severity', 0):.2f}/10.0")
        sections.append(f"  Severity Level: {report.get('severity_level', 'UNKNOWN')}")

        # Metrics
        metrics = report.get('metrics', {})
        if metrics:
            sections.append("\nCLINICAL METRICS:")
            sections.append(f"  Symptom Severity: {metrics.get('symptom_severity', 0):.2f}/10.0")
            sections.append(f"  Lab Abnormality: {metrics.get('lab_abnormality', 0):.2f}/10.0")
            sections.append(f"  Medical History Risk: {metrics.get('medical_history_risk', 0):.2f}/10.0")
            sections.append(f"  Drug Interaction Score: {metrics.get('drug_interaction_score', 0):.2f}/10.0")
            sections.append(f"  AI Assessment: {metrics.get('ai_assessment_score', 0):.2f}/1.0")
            sections.append(f"  AI Confidence: {metrics.get('ai_confidence', 0):.2f}")

        # Key findings
        findings = report.get('key_findings', [])
        if findings:
            sections.append("\nKEY CLINICAL FINDINGS:")
            for finding in findings[:10]:  # Limit to top 10
                sections.append(f"  - {finding}")

        # Suspected conditions
        conditions = report.get('suspected_conditions', [])
        if conditions:
            sections.append("\nSUSPECTED CONDITIONS:")
            for condition in conditions[:5]:  # Top 5
                cond_name = condition.get('condition', 'Unknown')
                source = condition.get('source', 'Analysis')
                confidence = condition.get('confidence', 0) * 100
                sections.append(f"  - {cond_name} ({source}, {confidence:.0f}% confidence)")

        # Specialist recommendations
        specialists = report.get('specialist_recommendations', [])
        if specialists:
            sections.append("\nSPECIALIST RECOMMENDATIONS:")
            for spec in specialists[:3]:  # Top 3
                spec_name = spec.get('specialist', 'Unknown')
                urgency = spec.get('urgency', 'MODERATE')
                sections.append(f"  - {spec_name} ({urgency} priority)")

        # AI Insights
        ai_insights = report.get('ai_insights', {})
        if ai_insights.get('likely_diagnoses'):
            sections.append("\nAI DIAGNOSTIC INSIGHTS:")
            for diagnosis in ai_insights.get('likely_diagnoses', [])[:3]:
                sections.append(f"  - {diagnosis}")

        # Action items
        actions = report.get('action_items', [])
        if actions:
            sections.append("\nRECOMMENDED ACTIONS:")
            for action in actions[:8]:  # Top 8 actions
                sections.append(f"  - {action}")

        sections.append("\n" + "=" * 70)
        sections.append("IMPORTANT DISCLAIMER:")
        sections.append("This report is generated by an AI-assisted diagnostic support system.")
        sections.append("All findings and recommendations must be reviewed and validated by")
        sections.append("qualified healthcare professionals. This system does not replace")
        sections.append("clinical judgment and is intended for decision support only.")

        return "\n".join(sections)
