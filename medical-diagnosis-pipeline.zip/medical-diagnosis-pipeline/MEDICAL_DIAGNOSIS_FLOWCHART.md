```mermaid
graph TD
    %% Entry Point
    START([🏥 Patient Medical Data Received]) --> INPUT_VALIDATION[🔍 Patient Intake Node]

    %% Stage 1: Patient Intake & Validation
    INPUT_VALIDATION --> |"Validate Patient Data<br/>Process Medical History<br/>Verify Lab Results<br/>Check Vital Signs"| VALIDATION_CHECK{"✅ Patient Data<br/>Valid?"}

    VALIDATION_CHECK --> |"No - Missing/Invalid Data"| VALIDATION_ERROR[❌ Data Validation Error]
    VALIDATION_ERROR --> ERROR_NOTIFICATION[📧 Error Notification to Provider]
    ERROR_NOTIFICATION --> END_ERROR([🔴 DIAGNOSIS FAILED<br/>Invalid Patient Data])

    VALIDATION_CHECK --> |"Yes - All Data Valid"| PARALLEL_LAUNCH{"🎯 Launch Parallel<br/>Clinical Analysis Stage"}

    %% Stage 2: Parallel Agent Execution (5 agents run simultaneously)
    PARALLEL_LAUNCH --> |"Simultaneously"| SYMPTOM_AGENT[🤒 Symptom Analysis Agent]
    PARALLEL_LAUNCH --> |"Simultaneously"| LAB_AGENT[🧪 Laboratory Results Agent]
    PARALLEL_LAUNCH --> |"Simultaneously"| HISTORY_AGENT[📋 Medical History Agent]
    PARALLEL_LAUNCH --> |"Simultaneously"| DRUG_AGENT[💊 Drug Interaction Agent]
    PARALLEL_LAUNCH --> |"Simultaneously"| SPECIALIST_AGENT[👨‍⚕️ Specialist & AI Agent]

    %% Symptom Analysis Agent
    SYMPTOM_AGENT --> |"Analyze Symptom Severity<br/>Match Condition Patterns<br/>Calculate Risk Score<br/>Generate Recommendations"| SYMPTOM_RESULT[🤒 Symptom Analysis Results<br/>━━━━━━━━━━━━━━<br/>Severity Score: 8.67/10<br/>Severity Level: HIGH<br/>Max Individual Severity: 10<br/>Duration: 3 days<br/>Suspected Conditions:<br/>  • Heart Attack 60% match<br/>  • COVID-19 40% match<br/>Requires Immediate Attention: YES<br/>Recommendations:<br/>  • URGENT: Seek emergency care<br/>  • Call 911 or go to ER<br/>  • Chew aspirin if available]

    %% Lab Results Agent
    LAB_AGENT --> |"Evaluate Lab Tests<br/>Check Reference Ranges<br/>Identify Abnormalities<br/>Flag Critical Findings"| LAB_RESULT[🧪 Laboratory Analysis Results<br/>━━━━━━━━━━━━━━<br/>Abnormality Score: 10.0/10<br/>Severity Level: CRITICAL<br/>Tests Analyzed: 7<br/>Abnormal Results: 6/7<br/>Critical Findings:<br/>  • Glucose: 145 mg/dL HIGH<br/>  • Cholesterol: 220 mg/dL HIGH<br/>  • LDL: 140 mg/dL HIGH<br/>  • HDL: 35 mg/dL LOW<br/>  • Creatinine: 1.4 mg/dL HIGH<br/>Recommendations:<br/>  • Immediate diabetes evaluation<br/>  • Cardiac enzyme tests needed<br/>  • Renal function monitoring]

    %% Medical History Agent
    HISTORY_AGENT --> |"Assess Medical History<br/>Calculate Risk Factors<br/>Check Medications<br/>Review Allergies"| HISTORY_RESULT[📋 Medical History Results<br/>━━━━━━━━━━━━━━<br/>Risk Score: 5.85/10<br/>Risk Level: MODERATE<br/>Medical Conditions: 4<br/>  • Diabetes<br/>  • Hypertension<br/>Current Medications: 3<br/>  • Metformin<br/>  • Lisinopril<br/>  • Atorvastatin<br/>High-Risk Conditions: 2<br/>Critical Allergies: Penicillin<br/>Family History:<br/>  • Diabetes<br/>  • Heart disease<br/>Concerns:<br/>  • Multiple chronic conditions<br/>  • Cardiovascular risk factors]

    %% Drug Interaction Agent
    DRUG_AGENT --> |"Check Drug Interactions<br/>Analyze Medication Safety<br/>Identify Contraindications<br/>Calculate Interaction Score"| DRUG_RESULT[💊 Drug Interaction Results<br/>━━━━━━━━━━━━━━<br/>Interaction Score: 0.0/10<br/>Severity Level: NONE<br/>Current Medications: 3<br/>Proposed Medications: 0<br/>Interactions Found: 0<br/>Warnings: None<br/>Status: No significant interactions<br/>Note: Safe medication profile]

    %% Specialist & AI Agent
    SPECIALIST_AGENT --> |"Recommend Specialists<br/>Match Symptoms to Specialties<br/>Call Gemini AI API<br/>Generate AI Diagnostic Insights"| SPECIALIST_RESULT[👨‍⚕️ Specialist & AI Results<br/>━━━━━━━━━━━━━━<br/>Specialist Recommendations: 5<br/>  1. Cardiologist HIGH priority<br/>  2. Pulmonologist HIGH priority<br/>  3. Endocrinologist MODERATE<br/>  4. Nephrologist MODERATE<br/>  5. Primary Care ROUTINE<br/>AI Diagnostic Analysis:<br/>  • Assessment Score: 0.50/1.0<br/>  • Confidence: 0.00<br/>  • Status: API key expired<br/>  • Likely Diagnoses: N/A<br/>  • Clinical Observations: Limited<br/>  • Urgency: MODERATE<br/>Note: AI analysis unavailable]

    %% Agent Results Flow to Coordinator
    SYMPTOM_RESULT --> WAIT_AGENTS[⏳ Wait for All<br/>5 Agents to Complete]
    LAB_RESULT --> WAIT_AGENTS
    HISTORY_RESULT --> WAIT_AGENTS
    DRUG_RESULT --> WAIT_AGENTS
    SPECIALIST_RESULT --> WAIT_AGENTS

    %% Stage 3: Coordination
    WAIT_AGENTS --> |"All 5 Agents Complete"| COORDINATOR[🎯 Coordinator Agent]

    COORDINATOR --> |"Aggregate All Analysis Results<br/>Calculate Overall Severity<br/>Compile Critical Flags<br/>Merge Suspected Conditions<br/>Build Comprehensive Summary"| COORD_ANALYSIS[🎯 Coordination Summary<br/>━━━━━━━━━━━━━━<br/>Overall Severity Score: 8.50/10<br/>Severity Level: HIGH<br/>Component Scores:<br/>  • Symptom Severity: 8.67/10<br/>  • Lab Abnormality: 10.0/10<br/>  • Medical History Risk: 5.85/10<br/>  • Drug Interaction: 0.0/10<br/>  • AI Assessment: 0.50/1.0<br/>  • AI Confidence: 0.00<br/>Critical Flags: 2<br/>  • Critical lab findings detected<br/>  • High symptom severity<br/>Suspected Conditions: 3<br/>  • Cardiac event<br/>  • Diabetes complication<br/>  • Respiratory distress<br/>Specialists Needed: 5]

    %% Decision Making Logic
    COORD_ANALYSIS --> DECISION_LOGIC{"⚖️ Clinical Decision<br/>Multi-Factor Analysis"}

    %% Critical Issues Check
    DECISION_LOGIC --> |"Check Critical Flags"| CRITICAL_CHECK{"🚨 Critical<br/>Flags Present?"}

    CRITICAL_CHECK --> |"Yes:<br/>• Critical lab findings<br/>• Severe bleeding<br/>• Loss of consciousness<br/>• Stroke symptoms<br/>• Critical vital signs"| IMMEDIATE_INTERVENTION[🔴 IMMEDIATE INTERVENTION]

    CRITICAL_CHECK --> |"No Critical Flags"| SEVERITY_CHECK{"⚠️ Overall Severity<br/>Assessment"}

    SEVERITY_CHECK --> |"Overall Severity ≥ 8.0"| URGENT_SPECIALIST[🟠 URGENT SPECIALIST REFERRAL]

    SEVERITY_CHECK --> |"Overall Severity < 8.0"| SYMPTOM_LAB_CHECK{"📊 Symptom/Lab<br/>Threshold Check"}

    %% Score-Based Decision Paths
    SYMPTOM_LAB_CHECK --> |"Symptom Severity ≥ 7.0 OR<br/>Lab Abnormality ≥ 2.0 SD"| SPECIALIST_CONSULT[🟡 SPECIALIST CONSULTATION]

    SYMPTOM_LAB_CHECK --> |"Thresholds Not Met"| DRUG_CHECK{"💊 Drug Interaction<br/>Check"}

    DRUG_CHECK --> |"Drug Interaction Score ≥ 5.0"| PHARMACIST_REVIEW[🟢 PHARMACIST REVIEW]

    DRUG_CHECK --> |"Drug Score < 5.0"| MODERATE_CHECK{"📈 Moderate<br/>Severity Check"}

    MODERATE_CHECK --> |"Overall Severity ≥ 4.0"| FOLLOW_UP[🟢 FOLLOW-UP CARE]

    MODERATE_CHECK --> |"Overall Severity < 4.0"| ROUTINE_CARE[🟢 ROUTINE CARE]

    %% Stage 4: Decision Finalization & Report Generation
    IMMEDIATE_INTERVENTION --> FINALIZATION[📋 Report Generation Node]
    URGENT_SPECIALIST --> FINALIZATION
    SPECIALIST_CONSULT --> FINALIZATION
    PHARMACIST_REVIEW --> FINALIZATION
    FOLLOW_UP --> FINALIZATION
    ROUTINE_CARE --> FINALIZATION

    FINALIZATION --> |"Generate Comprehensive Report<br/>Compile Key Findings<br/>List Suspected Conditions<br/>Create Action Items<br/>Format Recommendations"| FINAL_REPORT{"📋 Final Diagnosis<br/>Report Preparation"}

    %% Immediate Intervention Path Details
    FINAL_REPORT --> |"IMMEDIATE INTERVENTION"| CRITICAL_DETAILS[🔴 Critical Findings Report<br/>━━━━━━━━━━━━━━<br/>Decision: IMMEDIATE INTERVENTION<br/>Priority: CRITICAL<br/>Requires Immediate Attention: YES<br/>Critical Reason:<br/>  Critical lab findings detected<br/>  Multiple high-risk conditions<br/>Key Findings:<br/>  • Critical symptom severity 8.67/10<br/>  • Critical lab abnormalities 10/10<br/>  • Cardiac symptoms with respiratory distress<br/>  • Elevated glucose diabetes concern<br/>  • Multiple cardiovascular risk factors<br/>Suspected Conditions:<br/>  • Acute Coronary Syndrome<br/>  • Heart Attack<br/>  • Diabetes Crisis<br/>Specialist Recommendations:<br/>  • Cardiologist IMMEDIATE<br/>  • Pulmonologist IMMEDIATE<br/>  • Endocrinologist URGENT<br/>Action Items:<br/>  • URGENT: Call 911 immediately<br/>  • Seek emergency medical attention<br/>  • Chew aspirin if no allergies<br/>  • Cardiac evaluation within 1 hour<br/>  • Emergency department admission]

    %% Urgent Specialist Referral Path Details
    FINAL_REPORT --> |"URGENT SPECIALIST REFERRAL"| URGENT_DETAILS[🟠 Urgent Referral Report<br/>━━━━━━━━━━━━━━<br/>Decision: URGENT SPECIALIST REFERRAL<br/>Priority: HIGH<br/>Requires Immediate Attention: YES<br/>Reason: Overall clinical severity 8.0+<br/>Key Findings:<br/>  • High severity across multiple systems<br/>  • Concerning symptom patterns<br/>  • Abnormal lab trends<br/>Specialist Recommendations:<br/>  • Specialist consultation within 24 hours<br/>  • Comprehensive diagnostic workup<br/>Action Items:<br/>  • Schedule urgent specialist appointment<br/>  • Additional testing required<br/>  • Close monitoring needed]

    %% Specialist Consultation Path Details
    FINAL_REPORT --> |"SPECIALIST CONSULTATION"| SPECIALIST_DETAILS[🟡 Specialist Consultation Report<br/>━━━━━━━━━━━━━━<br/>Decision: SPECIALIST CONSULTATION<br/>Priority: MODERATE<br/>Requires Immediate Attention: NO<br/>Reason:<br/>  High symptom severity 7.0+ OR<br/>  Significant lab abnormalities<br/>Key Findings:<br/>  • Symptoms require specialist evaluation<br/>  • Lab results outside normal range<br/>  • Chronic condition management needed<br/>Specialist Recommendations:<br/>  • Schedule appointment within 1 week<br/>  • Continue current medications<br/>Action Items:<br/>  • Book specialist consultation<br/>  • Monitor symptoms daily<br/>  • Follow medication regimen]

    %% Pharmacist Review Path Details
    FINAL_REPORT --> |"PHARMACIST REVIEW"| PHARMACIST_DETAILS[🟢 Pharmacist Review Report<br/>━━━━━━━━━━━━━━<br/>Decision: PHARMACIST REVIEW<br/>Priority: MODERATE<br/>Requires Immediate Attention: NO<br/>Reason:<br/>  Significant drug interactions detected<br/>Key Findings:<br/>  • Drug interaction score 5.0+<br/>  • Potential medication conflicts<br/>  • Dosage adjustments may be needed<br/>Action Items:<br/>  • Consult with pharmacist<br/>  • Review medication regimen<br/>  • Potential medication changes<br/>  • Monitor for side effects]

    %% Follow-Up Care Path Details
    FINAL_REPORT --> |"FOLLOW-UP CARE"| FOLLOWUP_DETAILS[🟢 Follow-Up Care Report<br/>━━━━━━━━━━━━━━<br/>Decision: FOLLOW-UP CARE<br/>Priority: ROUTINE<br/>Requires Immediate Attention: NO<br/>Reason:<br/>  Moderate clinical findings require follow-up<br/>Key Findings:<br/>  • Overall severity 4.0-7.0<br/>  • Some abnormal findings present<br/>  • Continued monitoring recommended<br/>Action Items:<br/>  • Schedule follow-up within 2 weeks<br/>  • Continue monitoring symptoms<br/>  • Maintain current treatment plan<br/>  • Report any worsening]

    %% Routine Care Path Details
    FINAL_REPORT --> |"ROUTINE CARE"| ROUTINE_DETAILS[🟢 Routine Care Report<br/>━━━━━━━━━━━━━━<br/>Decision: ROUTINE CARE<br/>Priority: LOW<br/>Requires Immediate Attention: NO<br/>Reason:<br/>  No critical findings<br/>  Routine care appropriate<br/>Key Findings:<br/>  • Overall severity < 4.0<br/>  • No significant abnormalities<br/>  • Stable condition<br/>Action Items:<br/>  • Continue routine care<br/>  • Schedule regular checkup<br/>  • Maintain healthy lifestyle<br/>  • Monitor any changes]

    %% Stage 5: Notification
    CRITICAL_DETAILS --> NOTIFICATION[📧 Notification Service Node]
    URGENT_DETAILS --> NOTIFICATION
    SPECIALIST_DETAILS --> NOTIFICATION
    PHARMACIST_DETAILS --> NOTIFICATION
    FOLLOWUP_DETAILS --> NOTIFICATION
    ROUTINE_DETAILS --> NOTIFICATION

    NOTIFICATION --> |"Generate Email Content<br/>Format Diagnosis Report<br/>Include Clinical Metrics<br/>Add Suspected Conditions<br/>List Action Items<br/>Send via SMTP Service"| EMAIL_SEND{"📧 Email<br/>Service"}

    EMAIL_SEND --> |"Email Sent Successfully"| EMAIL_SUCCESS[✅ Email Delivered<br/>━━━━━━━━━━━━━━<br/>To: Healthcare Provider<br/>Subject: Medical Diagnosis Report<br/>Status: Sent Successfully<br/>Timestamp: 2025-12-02 12:29:37<br/>Contains:<br/>  • Patient demographics<br/>  • Clinical decision<br/>  • Severity metrics<br/>  • Key findings<br/>  • Suspected conditions<br/>  • Specialist recommendations<br/>  • AI insights if available<br/>  • Recommended actions<br/>  • Priority level<br/>  • Disclaimer notice]

    EMAIL_SEND --> |"Email Service Error<br/>SMTP Not Configured<br/>Authentication Failed"| EMAIL_FAIL[⚠️ Email Delivery Failed<br/>━━━━━━━━━━━━━━<br/>Status: Failed to Send<br/>Error: SMTP service unavailable<br/>Note: Diagnosis report generated<br/>Report saved in system logs<br/>Manual notification required<br/>Provider should check system<br/>directly for diagnosis results]

    %% Final States
    EMAIL_SUCCESS --> END_CRITICAL([🔴 IMMEDIATE INTERVENTION REQUIRED<br/>Provider Notified - CRITICAL])
    EMAIL_SUCCESS --> END_URGENT([🟠 URGENT SPECIALIST REFERRAL<br/>Provider Notified - HIGH PRIORITY])
    EMAIL_SUCCESS --> END_SPECIALIST([🟡 SPECIALIST CONSULTATION<br/>Provider Notified - MODERATE])
    EMAIL_SUCCESS --> END_PHARMACIST([🟢 PHARMACIST REVIEW NEEDED<br/>Provider Notified - ROUTINE])
    EMAIL_SUCCESS --> END_FOLLOWUP([🟢 FOLLOW-UP CARE SCHEDULED<br/>Provider Notified - ROUTINE])
    EMAIL_SUCCESS --> END_ROUTINE([🟢 ROUTINE CARE APPROPRIATE<br/>Provider Notified - LOW PRIORITY])

    EMAIL_FAIL --> END_CRITICAL_NOEMAIL([🔴 IMMEDIATE INTERVENTION<br/>Email Failed - Check System])
    EMAIL_FAIL --> END_URGENT_NOEMAIL([🟠 URGENT REFERRAL<br/>Email Failed - Check System])
    EMAIL_FAIL --> END_SPECIALIST_NOEMAIL([🟡 SPECIALIST CONSULTATION<br/>Email Failed - Check System])
    EMAIL_FAIL --> END_PHARMACIST_NOEMAIL([🟢 PHARMACIST REVIEW<br/>Email Failed - Check System])
    EMAIL_FAIL --> END_FOLLOWUP_NOEMAIL([🟢 FOLLOW-UP CARE<br/>Email Failed - Check System])
    EMAIL_FAIL --> END_ROUTINE_NOEMAIL([🟢 ROUTINE CARE<br/>Email Failed - Check System])

    %% Error Handling Throughout
    INPUT_VALIDATION --> |"Processing Error"| ERROR_HANDLER[❌ Error Handler]
    SYMPTOM_AGENT --> |"Analysis Error"| ERROR_HANDLER
    LAB_AGENT --> |"Analysis Error"| ERROR_HANDLER
    HISTORY_AGENT --> |"Analysis Error"| ERROR_HANDLER
    DRUG_AGENT --> |"Analysis Error"| ERROR_HANDLER
    SPECIALIST_AGENT --> |"API Error/Analysis Error"| ERROR_HANDLER
    COORDINATOR --> |"Coordination Error"| ERROR_HANDLER
    FINALIZATION --> |"Report Generation Error"| ERROR_HANDLER

    ERROR_HANDLER --> |"Log Error Details<br/>Use Default Values<br/>Continue Workflow<br/>with Partial Results<br/>Flag Error in Report"| PARTIAL_DECISION[⚠️ Partial Diagnosis<br/>with Error Handling<br/>━━━━━━━━━━━━━━<br/>Status: Completed with Errors<br/>Available Results: Partial<br/>Missing Data: Noted in Report<br/>Errors Logged: Yes<br/>Recommendation:<br/>  Manual review recommended<br/>  Some analyses unavailable<br/>  Decision based on available data]

    PARTIAL_DECISION --> NOTIFICATION

    %% Parallel Execution Details
    PARALLEL_LAUNCH -.->|"ThreadPoolExecutor"| PARALLEL_NOTE[🔄 Parallel Execution Details<br/>━━━━━━━━━━━━━━<br/>Execution Mode: PARALLEL<br/>Max Workers: 5<br/>State Management: Clone per Agent<br/>Each agent receives:<br/>  • Deep copy of current state<br/>  • Independent execution context<br/>  • Isolated analysis environment<br/>Results merged after completion:<br/>  • Lists: Extended<br/>  • Dicts: Updated<br/>  • Scalars: Overwritten<br/>Execution time: 1-2 seconds<br/>vs Sequential: 5-10 seconds]

    %% Clinical Thresholds Reference
    DECISION_LOGIC -.->|"Reference"| THRESHOLD_NOTE[📊 Clinical Thresholds<br/>━━━━━━━━━━━━━━<br/>SYMPTOM_SEVERITY_THRESHOLD: 7.0/10<br/>LAB_ABNORMALITY_THRESHOLD: 2.0 SD<br/>SPECIALIST_REFERRAL_THRESHOLD: 8.0/10<br/>DRUG_INTERACTION_THRESHOLD: 5.0/10<br/>MODERATE_SEVERITY_THRESHOLD: 4.0/10<br/><br/>Decision Categories:<br/>1. IMMEDIATE_INTERVENTION<br/>2. URGENT_SPECIALIST_REFERRAL<br/>3. SPECIALIST_CONSULTATION<br/>4. PHARMACIST_REVIEW<br/>5. FOLLOW_UP_CARE<br/>6. ROUTINE_CARE]

    %% Styling with Black Text
    classDef agentNode fill:#e3f2fd,stroke:#1565c0,stroke-width:2px,color:#000000
    classDef resultNode fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px,color:#000000
    classDef decisionNode fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#000000
    classDef criticalNode fill:#ffebee,stroke:#c62828,stroke-width:3px,color:#000000
    classDef urgentNode fill:#ffe0b2,stroke:#e65100,stroke-width:3px,color:#000000
    classDef moderateNode fill:#fff9c4,stroke:#f57f17,stroke-width:3px,color:#000000
    classDef routineNode fill:#e8f5e9,stroke:#2e7d32,stroke-width:3px,color:#000000
    classDef coordinatorNode fill:#e0f2f1,stroke:#00695c,stroke-width:3px,color:#000000
    classDef validationNode fill:#fce4ec,stroke:#880e4f,stroke-width:2px,color:#000000
    classDef notificationNode fill:#e1f5fe,stroke:#01579b,stroke-width:2px,color:#000000
    classDef errorNode fill:#ffccbc,stroke:#bf360c,stroke-width:2px,color:#000000
    classDef waitNode fill:#f5f5f5,stroke:#616161,stroke-width:2px,color:#000000
    classDef endNode fill:#c8e6c9,stroke:#1b5e20,stroke-width:3px,color:#000000
    classDef noteNode fill:#e8eaf6,stroke:#3949ab,stroke-width:1px,color:#000000,stroke-dasharray: 5 5

    class SYMPTOM_AGENT,LAB_AGENT,HISTORY_AGENT,DRUG_AGENT,SPECIALIST_AGENT agentNode
    class SYMPTOM_RESULT,LAB_RESULT,HISTORY_RESULT,DRUG_RESULT,SPECIALIST_RESULT resultNode
    class DECISION_LOGIC,CRITICAL_CHECK,SEVERITY_CHECK,SYMPTOM_LAB_CHECK,DRUG_CHECK,MODERATE_CHECK,FINAL_REPORT decisionNode
    class IMMEDIATE_INTERVENTION,CRITICAL_DETAILS,END_CRITICAL,END_CRITICAL_NOEMAIL criticalNode
    class URGENT_SPECIALIST,URGENT_DETAILS,END_URGENT,END_URGENT_NOEMAIL urgentNode
    class SPECIALIST_CONSULT,SPECIALIST_DETAILS,END_SPECIALIST,END_SPECIALIST_NOEMAIL,PHARMACIST_REVIEW,PHARMACIST_DETAILS,END_PHARMACIST,END_PHARMACIST_NOEMAIL moderateNode
    class FOLLOW_UP,FOLLOWUP_DETAILS,END_FOLLOWUP,END_FOLLOWUP_NOEMAIL,ROUTINE_CARE,ROUTINE_DETAILS,END_ROUTINE,END_ROUTINE_NOEMAIL routineNode
    class COORDINATOR,COORD_ANALYSIS coordinatorNode
    class INPUT_VALIDATION,VALIDATION_CHECK,FINALIZATION validationNode
    class NOTIFICATION,EMAIL_SEND,EMAIL_SUCCESS,EMAIL_FAIL notificationNode
    class ERROR_HANDLER,ERROR_NOTIFICATION,VALIDATION_ERROR,PARTIAL_DECISION,END_ERROR errorNode
    class WAIT_AGENTS,PARALLEL_LAUNCH waitNode
    class START endNode
    class PARALLEL_NOTE,THRESHOLD_NOTE noteNode
```
