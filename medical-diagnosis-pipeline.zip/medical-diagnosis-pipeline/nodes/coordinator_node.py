"""
Coordinator Node - Simplified Wrapper

Calls CoordinatorAgent to aggregate all analysis results.
"""

from state import DiagnosisState
from agents.coordinator_agent import CoordinatorAgent

# Create agent instance
agent = CoordinatorAgent()


def coordinator_node(state: DiagnosisState) -> DiagnosisState:
    """
    Coordinate and aggregate all analysis results

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with coordination summary
    """
    result = agent.analyze(
        state.symptom_analysis,
        state.lab_analysis,
        state.medical_history_analysis,
        state.drug_interaction_analysis,
        state.specialist_recommendations
    )

    state.coordination_summary = result.get("coordination_summary", {})
    return state
