"""
Specialist Recommendation Node - Simplified Wrapper

Calls SpecialistAgent to perform specialist recommendations and AI analysis.
"""

from state import DiagnosisState
from agents.specialist_agent import SpecialistAgent

# Create agent instance
agent = SpecialistAgent()


def specialist_node(state: DiagnosisState) -> DiagnosisState:
    """
    Perform specialist recommendations and AI diagnostic analysis

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with specialist recommendations and AI insights
    """
    symptom_severity = state.symptom_analysis.get("severity_score", 0.0)
    lab_abnormality = state.lab_analysis.get("abnormality_score", 0.0)

    # Build context for AI
    context = {
        "symptom_severity": symptom_severity,
        "lab_abnormality": lab_abnormality,
        "risk_score": state.medical_history_analysis.get("risk_score", 0.0),
        "suspected_conditions": [c.get("condition") for c in state.symptom_analysis.get("suspected_conditions", [])]
    }

    state.specialist_recommendations = agent.analyze(
        state.current_symptoms,
        state.medical_history,
        state.lab_results,
        symptom_severity,
        lab_abnormality,
        state.patient_age,
        state.patient_gender,
        state.vital_signs,
        context
    )
    return state
