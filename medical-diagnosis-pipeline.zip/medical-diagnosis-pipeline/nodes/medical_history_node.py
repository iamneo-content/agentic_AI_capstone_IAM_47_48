"""
Medical History Analysis Node - Simplified Wrapper

Calls MedicalHistoryAgent to perform medical history analysis.
"""

from state import DiagnosisState
from agents.medical_history_agent import MedicalHistoryAgent

# Create agent instance
agent = MedicalHistoryAgent()


def medical_history_node(state: DiagnosisState) -> DiagnosisState:
    """
    Perform medical history analysis

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with medical history analysis results
    """
    current_medications = state.patient_details.get("current_medications", [])
    allergies = state.patient_details.get("allergies", [])
    family_history = state.patient_details.get("family_history", [])

    state.medical_history_analysis = agent.analyze(
        state.medical_history,
        current_medications,
        allergies,
        family_history,
        state.patient_age
    )
    return state
