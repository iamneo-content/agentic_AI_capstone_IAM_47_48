"""
Drug Interaction Analysis Node - Simplified Wrapper

Calls DrugInteractionAgent to perform drug interaction analysis.
"""

from state import DiagnosisState
from agents.drug_interaction_agent import DrugInteractionAgent

# Create agent instance
agent = DrugInteractionAgent()


def drug_interaction_node(state: DiagnosisState) -> DiagnosisState:
    """
    Perform drug interaction analysis

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with drug interaction analysis results
    """
    current_medications = state.patient_details.get("current_medications", [])
    proposed_medications = state.patient_details.get("proposed_medications", [])
    allergies = state.patient_details.get("allergies", [])

    state.drug_interaction_analysis = agent.analyze(
        current_medications,
        proposed_medications,
        allergies
    )
    return state
