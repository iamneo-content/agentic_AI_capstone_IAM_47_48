"""
Report Node - Business Logic

Generates final diagnosis report and sends notification.
"""

import logging
from typing import List
from datetime import datetime
from state import DiagnosisState
from services.notification_service import NotificationService

logger = logging.getLogger("report_node")


def report_node(state: DiagnosisState) -> DiagnosisState:
    """
    Generate final diagnosis report and send notification

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with diagnosis report
    """
    logger.info("Generating final diagnosis report")

    # Build report
    report = {
        "diagnosis_id": state.diagnosis_id,
        "patient_id": state.patient_id,
        "patient_name": state.patient_name,
        "timestamp": state.timestamp,
        "decision": state.decision,
        "recommendation": state.decision.replace("_", " ").title(),
        "priority": "CRITICAL" if state.requires_immediate_attention else "ROUTINE",
        "overall_severity": state.decision_metrics.get("overall_severity_score", 0.0),
        "severity_level": state.decision_metrics.get("severity_level", "UNKNOWN"),
        "metrics": state.decision_metrics,
        "key_findings": _generate_key_findings(state),
        "action_items": _generate_action_items(state),
        "suspected_conditions": state.coordination_summary.get("suspected_conditions", []),
        "specialist_recommendations": state.coordination_summary.get("high_priority_specialists", []),
        "ai_insights": {
            "likely_diagnoses": state.specialist_recommendations.get("ai_likely_diagnoses", []),
            "clinical_observations": state.specialist_recommendations.get("ai_clinical_observations", []),
            "recommended_actions": state.specialist_recommendations.get("ai_recommended_actions", [])
        }
    }

    # Send notification
    try:
        notification_service = NotificationService()
        notification_service.send_diagnosis_report(
            state.patient_details,
            report,
            state.requires_immediate_attention
        )
        logger.info("Diagnosis report notification sent")

        state.notifications_sent.append({
            "type": "diagnosis_report",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "sent"
        })
    except Exception as e:
        logger.error(f"Failed to send report notification: {e}")
        state.notifications_sent.append({
            "type": "diagnosis_report",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "failed",
            "error": str(e)
        })

    logger.info("Report generation complete")

    # Update state
    state.diagnosis_report = report
    state.updated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return state


def _generate_key_findings(state: DiagnosisState) -> List[str]:
    """Generate key findings from analysis results"""
    findings = []

    # Critical reason first
    if state.critical_reason:
        findings.append(state.critical_reason)

    # Symptom findings
    if state.symptom_analysis:
        severity = state.symptom_analysis.get("severity_score", 0.0)
        level = state.symptom_analysis.get("severity_level", "")
        if severity > 0:
            findings.append(f"Symptom severity: {severity}/10 ({level})")

        suspected = state.symptom_analysis.get("suspected_conditions", [])
        if suspected:
            top_condition = suspected[0]
            findings.append(
                f"Top suspected condition: {top_condition.get('condition')} "
                f"({top_condition.get('match_percentage')}% match)"
            )

    # Lab findings
    if state.lab_analysis:
        abnormal_count = state.lab_analysis.get("abnormal_count", 0)
        critical_count = len(state.lab_analysis.get("critical_findings", []))
        if critical_count > 0:
            findings.append(f"Critical lab findings: {critical_count}")
        elif abnormal_count > 0:
            findings.append(f"Abnormal lab results: {abnormal_count}")

    # Drug interaction findings
    if state.drug_interaction_analysis:
        critical_interactions = state.drug_interaction_analysis.get("critical_count", 0)
        allergy_conflicts = len(state.drug_interaction_analysis.get("allergy_conflicts", []))
        if allergy_conflicts > 0:
            findings.append(f"Drug allergy conflicts: {allergy_conflicts}")
        elif critical_interactions > 0:
            findings.append(f"Critical drug interactions: {critical_interactions}")

    # Medical history findings
    if state.medical_history_analysis:
        high_risk_count = len(state.medical_history_analysis.get("high_risk_conditions", []))
        if high_risk_count > 0:
            findings.append(f"High-risk chronic conditions: {high_risk_count}")

    if not findings:
        findings.append("No critical findings identified")

    return findings


def _generate_action_items(state: DiagnosisState) -> List[str]:
    """Generate action items based on decision"""
    action_items = []

    decision = state.decision
    metrics = state.decision_metrics

    if decision == "immediate_intervention":
        action_items.append("URGENT: Immediate medical intervention required")
        action_items.append("Transfer to emergency department if not already present")
        action_items.append("Initiate appropriate emergency protocols")

    elif decision == "urgent_specialist_referral":
        action_items.append("Expedited specialist referral required within 24 hours")
        specialists = state.coordination_summary.get("high_priority_specialists", [])
        for spec in specialists[:2]:
            action_items.append(f"Refer to: {spec.get('specialist', 'Specialist')}")

    elif decision == "specialist_consultation":
        action_items.append("Schedule specialist consultation within 1 week")
        specialists = state.coordination_summary.get("high_priority_specialists", [])
        if specialists:
            action_items.append(f"Recommended: {specialists[0].get('specialist', 'Specialist')}")

    elif decision == "pharmacist_review":
        action_items.append("Pharmacist review required for drug interactions")
        action_items.append("Assess medication regimen for potential modifications")

    elif decision == "follow_up_care":
        action_items.append("Schedule follow-up appointment within 2-4 weeks")
        action_items.append("Monitor symptoms and report any worsening")

    else:  # routine_care
        action_items.append("Continue routine care with primary care physician")
        action_items.append("Monitor symptoms and schedule follow-up as needed")

    # Add specific recommendations from analyses
    recommendations = state.coordination_summary.get("all_recommendations", [])
    # Add top 3 unique recommendations
    for rec in recommendations[:3]:
        if rec not in action_items and not any(rec in item for item in action_items):
            action_items.append(rec)

    return action_items
