"""
Lab Analysis Node - Simplified Wrapper

Calls LabAgent to perform lab results analysis.
"""

from state import DiagnosisState
from agents.lab_agent import LabAgent

# Create agent instance
agent = LabAgent()


def lab_node(state: DiagnosisState) -> DiagnosisState:
    """
    Perform lab results analysis

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with lab analysis results
    """
    state.lab_analysis = agent.analyze(state.lab_results)
    return state
