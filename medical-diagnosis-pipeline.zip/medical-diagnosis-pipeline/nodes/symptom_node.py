"""
Symptom Analysis Node - Simplified Wrapper

Calls SymptomAgent to perform symptom analysis.
"""

from state import DiagnosisState
from agents.symptom_agent import SymptomAgent

# Create agent instance
agent = SymptomAgent()


def symptom_node(state: DiagnosisState) -> DiagnosisState:
    """
    Perform symptom analysis

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with symptom analysis results
    """
    duration = state.patient_details.get("symptom_duration_days", 1)
    state.symptom_analysis = agent.analyze(state.current_symptoms, duration)
    return state
