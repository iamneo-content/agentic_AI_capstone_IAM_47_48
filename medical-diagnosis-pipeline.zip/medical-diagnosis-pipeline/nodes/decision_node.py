"""
Decision Node - Business Logic

Makes diagnostic decision based on clinical thresholds.
"""

import logging
from state import DiagnosisState
from config import get_config_value

logger = logging.getLogger("decision_node")


def decision_node(state: DiagnosisState) -> DiagnosisState:
    """
    Make diagnostic decision based on clinical thresholds

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with decision
    """
    logger.info("Making diagnostic decision based on clinical thresholds")

    # Get thresholds from config
    SYMPTOM_SEVERITY_THRESHOLD = get_config_value("SYMPTOM_SEVERITY_THRESHOLD", 7.0)
    LAB_ABNORMALITY_THRESHOLD = get_config_value("LAB_ABNORMALITY_THRESHOLD", 2.0)
    SPECIALIST_REFERRAL_THRESHOLD = get_config_value("SPECIALIST_REFERRAL_THRESHOLD", 8.0)

    # Get coordination summary
    summary = state.coordination_summary

    # Extract metrics
    overall_severity = summary.get("overall_severity_score", 0.0)
    severity_level = summary.get("severity_level", "UNKNOWN")
    critical_flags = summary.get("critical_flags", [])
    symptom_severity = summary.get("symptom_severity", 0.0)
    lab_abnormality = summary.get("lab_abnormality", 0.0)
    drug_interaction_score = summary.get("drug_interaction_score", 0.0)

    # Make decision
    decision = "routine_care"
    requires_immediate_attention = False
    critical_reason = ""

    # Check for critical conditions
    if len(critical_flags) > 0:
        decision = "immediate_intervention"
        requires_immediate_attention = True
        critical_reason = "; ".join(critical_flags)
        logger.warning(f"CRITICAL: {critical_reason}")

    # Check for urgent specialist referral
    elif overall_severity >= SPECIALIST_REFERRAL_THRESHOLD:
        decision = "urgent_specialist_referral"
        requires_immediate_attention = True
        critical_reason = f"Overall clinical severity: {overall_severity}/10 ({severity_level})"
        logger.warning(f"Urgent specialist referral needed: {critical_reason}")

    # Check for standard specialist referral
    elif symptom_severity >= SYMPTOM_SEVERITY_THRESHOLD or lab_abnormality >= LAB_ABNORMALITY_THRESHOLD:
        decision = "specialist_consultation"
        requires_immediate_attention = False
        if symptom_severity >= SYMPTOM_SEVERITY_THRESHOLD:
            critical_reason = f"High symptom severity: {symptom_severity}/10"
        else:
            critical_reason = f"Significant lab abnormalities: {lab_abnormality}/10"
        logger.info(f"Specialist consultation recommended: {critical_reason}")

    # Check for drug interactions
    elif drug_interaction_score >= 5.0:
        decision = "pharmacist_review"
        requires_immediate_attention = False
        critical_reason = f"Significant drug interactions detected: {drug_interaction_score}/10"
        logger.info(f"Pharmacist review needed: {critical_reason}")

    # Check for moderate severity
    elif overall_severity >= 4.0:
        decision = "follow_up_care"
        requires_immediate_attention = False
        critical_reason = f"Moderate clinical findings require follow-up: {overall_severity}/10"
        logger.info("Follow-up care recommended")

    else:
        decision = "routine_care"
        requires_immediate_attention = False
        critical_reason = "No critical findings - routine care appropriate"
        logger.info("Routine care decision - no critical findings")

    logger.info(f"Decision: {decision.upper()}")

    # Prepare decision metrics for report
    decision_metrics = {
        "overall_severity_score": overall_severity,
        "severity_level": severity_level,
        "symptom_severity": symptom_severity,
        "lab_abnormality": lab_abnormality,
        "medical_history_risk": summary.get("history_risk", 0.0),
        "drug_interaction_score": drug_interaction_score,
        "ai_assessment_score": summary.get("ai_assessment_score", 0.0),
        "ai_confidence": summary.get("ai_confidence", 0.0),
        "critical_flags_count": len(critical_flags)
    }

    # Update state
    state.decision = decision
    state.requires_immediate_attention = requires_immediate_attention
    state.critical_reason = critical_reason
    state.decision_metrics = decision_metrics

    return state
