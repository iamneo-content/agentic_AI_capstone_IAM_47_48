"""
Patient Intake Node - Simplified Wrapper

Calls PatientIntakeAgent to process patient data.
"""

from state import DiagnosisState
from agents.patient_intake_agent import PatientIntakeAgent

# Create agent instance
agent = PatientIntakeAgent()


def patient_intake_node(state: DiagnosisState) -> DiagnosisState:
    """
    Process patient intake data

    Args:
        state: Current diagnosis state

    Returns:
        Updated state with patient data
    """
    # Construct patient data from state
    patient_data = {
        "name": state.patient_name,
        "age": state.patient_age,
        "gender": state.patient_gender,
        "medical_history": state.medical_history,
        "symptoms": state.current_symptoms,
        "vital_signs": state.vital_signs,
        "lab_results": state.lab_results,
        "current_medications": state.patient_details.get("current_medications", []),
        "allergies": state.patient_details.get("allergies", []),
        "family_history": state.patient_details.get("family_history", []),
        "symptom_duration_days": state.patient_details.get("symptom_duration_days", 1)
    }

    intake_data = agent.analyze(state.patient_id, patient_data)

    # Update state with intake data
    state.patient_details.update(intake_data.get("patient_details", {}))
    state.medical_history = intake_data.get("medical_history", [])
    state.current_symptoms = intake_data.get("symptoms", [])
    state.vital_signs = intake_data.get("vital_signs", {})
    state.lab_results = intake_data.get("lab_results", {})

    return state
