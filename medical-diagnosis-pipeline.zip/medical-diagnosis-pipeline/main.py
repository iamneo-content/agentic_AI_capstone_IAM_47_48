"""
Medical Diagnosis Pipeline - Client Format
Main application entry point
"""

import sys
import argparse
from datetime import datetime
import uuid

from config import validate_config, get_config_value
from state import DiagnosisState
from workflows.diagnosis_workflow import build_diagnosis_workflow
from utils.logging_utils import setup_logging


def main():
    """Main application entry point"""
    # Setup logging
    log_file = get_config_value("LOG_FILE", "logs/medical_diagnosis.log")
    log_level = get_config_value("LOG_LEVEL", "INFO")
    setup_logging(log_level, log_file)

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Medical Diagnosis Pipeline - Client Format Multi-Agent System"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Diagnose command
    diagnose_parser = subparsers.add_parser("diagnose", help="Run medical diagnosis")
    diagnose_parser.add_argument("patient_id", help="Patient ID")
    diagnose_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run demo with sample patient data")
    demo_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    args = parser.parse_args()

    try:
        # Validate configuration
        validate_config()

        # Handle commands
        if args.command == "diagnose":
            diagnose_patient(args.patient_id, args.max_workers)
        elif args.command == "demo":
            run_demo(args.max_workers)
        else:
            # Interactive mode
            interactive_mode()

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


def diagnose_patient(patient_id: str, max_workers: int = 5):
    """
    Run diagnosis for a patient

    Args:
        patient_id: Patient identifier
        max_workers: Maximum parallel workers
    """
    print(f"\n{'='*70}")
    print(f"MEDICAL DIAGNOSIS PIPELINE - CLIENT FORMAT")
    print(f"{'='*70}")
    print(f"Patient ID: {patient_id}")
    print(f"Max Workers: {max_workers}")
    print(f"{'='*70}\n")

    # Using mock patient data for demonstration
    print("NOTE: Using mock patient data for demonstration purposes.")

    initial_state = create_demo_patient_state(patient_id)

    print(f"Diagnosis ID: {initial_state.diagnosis_id}")
    print(f"Starting workflow execution...\n")

    # Build and execute workflow
    workflow = build_diagnosis_workflow(max_workers=max_workers)
    final_state = workflow.run(initial_state)

    # Display results
    display_results(final_state)


def create_demo_patient_state(patient_id: str) -> DiagnosisState:
    """Create a demo patient state with sample data"""
    diagnosis_id = f"DX-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"

    return DiagnosisState(
        diagnosis_id=diagnosis_id,
        patient_id=patient_id,
        patient_name="John Doe (Demo Patient)",
        patient_age=55,
        patient_gender="Male",
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        patient_details={
            "current_medications": ["metformin", "lisinopril", "atorvastatin"],
            "allergies": ["penicillin"],
            "family_history": ["diabetes", "heart disease"],
            "symptom_duration_days": 3
        },
        medical_history=["diabetes", "hypertension"],
        current_symptoms=["chest pain", "difficulty breathing", "fatigue"],
        vital_signs={
            "temperature": 98.6,
            "blood_pressure": "145/90",
            "heart_rate": 88,
            "respiratory_rate": 18,
            "oxygen_saturation": 96
        },
        lab_results={
            "glucose": 145,
            "cholesterol": 220,
            "ldl": 140,
            "hdl": 35,
            "creatinine": 1.4,
            "hemoglobin": 13.2,
            "wbc": 9.5
        }
    )


def display_results(state: DiagnosisState):
    """Display diagnosis results"""
    print(f"\n{'='*70}")
    print("DIAGNOSIS COMPLETE")
    print(f"{'='*70}")
    print(f"Diagnosis ID: {state.diagnosis_id}")
    print(f"Patient: {state.patient_name}")
    print(f"Decision: {state.decision.upper()}")

    if state.requires_immediate_attention:
        print(f"\n[!] ALERT: {state.critical_reason}")
    else:
        print(f"\n[OK] Status: {state.critical_reason}")

    # Display metrics
    if state.decision_metrics:
        print(f"\n{'='*70}")
        print("CLINICAL METRICS")
        print(f"{'='*70}")
        metrics = state.decision_metrics
        print(f"Overall Severity:     {metrics.get('overall_severity_score', 0):.2f}/10.0 ({metrics.get('severity_level', 'UNKNOWN')})")
        print(f"Symptom Severity:     {metrics.get('symptom_severity', 0):.2f}/10.0")
        print(f"Lab Abnormality:      {metrics.get('lab_abnormality', 0):.2f}/10.0")
        print(f"History Risk:         {metrics.get('medical_history_risk', 0):.2f}/10.0")
        print(f"Drug Interactions:    {metrics.get('drug_interaction_score', 0):.2f}/10.0")
        print(f"AI Assessment:        {metrics.get('ai_assessment_score', 0):.2f}/1.0")
        print(f"AI Confidence:        {metrics.get('ai_confidence', 0):.2f}")

    # Display report summary
    if state.diagnosis_report:
        print(f"\n{'='*70}")
        print("DIAGNOSIS REPORT SUMMARY")
        print(f"{'='*70}")
        report = state.diagnosis_report

        print(f"Recommendation: {report.get('recommendation', 'UNKNOWN')}")
        print(f"Priority: {report.get('priority', 'ROUTINE')}")

        key_findings = report.get('key_findings', [])
        if key_findings:
            print(f"\nKey Findings:")
            for finding in key_findings[:5]:  # Top 5
                print(f"  - {finding}")

        suspected = report.get('suspected_conditions', [])
        if suspected:
            print(f"\nSuspected Conditions:")
            for cond in suspected[:3]:  # Top 3
                print(f"  - {cond.get('condition', 'Unknown')} ({cond.get('source', 'Analysis')})")

        action_items = report.get('action_items', [])
        if action_items:
            print(f"\nRecommended Actions:")
            for action in action_items[:5]:  # Top 5
                print(f"  - {action}")

    print(f"\n{'='*70}")
    print("Notification sent to configured healthcare provider")
    print(f"{'='*70}\n")


def run_demo(max_workers: int = 5):
    """Run demo with sample patient data"""
    print("\n" + "="*70)
    print("DEMO MODE - Medical Diagnosis Pipeline")
    print("="*70)
    print("This will analyze a sample patient with demo clinical data.")
    print("\nExample: 55-year-old male with chest pain and breathing difficulty")

    patient_id = "DEMO-PT-001"

    print(f"\nAnalyzing patient: {patient_id}\n")

    diagnose_patient(patient_id, max_workers)


def interactive_mode():
    """Interactive mode for diagnosis"""
    print("\n" + "="*70)
    print("Medical Diagnosis Pipeline - Client Format Multi-Agent System")
    print("="*70)
    print("\n1. Run Diagnosis (with Patient ID)")
    print("2. Run Demo")
    print("0. Exit")

    choice = input("\nSelect option (0-2): ").strip()

    if choice == "0":
        print("Goodbye!")
        return

    elif choice == "1":
        patient_id = input("Enter patient ID: ").strip()
        max_workers_str = input("Enter max workers (default 5): ").strip()

        max_workers = int(max_workers_str) if max_workers_str else 5
        diagnose_patient(patient_id, max_workers)

    elif choice == "2":
        max_workers_str = input("Enter max workers (default 5): ").strip()
        max_workers = int(max_workers_str) if max_workers_str else 5
        run_demo(max_workers)

    else:
        print("ERROR: Invalid choice")


if __name__ == "__main__":
    main()
