==============================================================================
                    MEDICAL DIAGNOSIS PIPELINE SYSTEM
          AI-POWERED MULTI-AGENT MEDICAL DIAGNOSTIC ASSISTANCE PLATFORM
==============================================================================

==============================================================================
PROBLEM STATEMENT
==============================================================================

The Medical Diagnosis Pipeline is an AI-powered multi-agent system designed to
assist healthcare professionals in making informed diagnostic decisions. The
system processes patient medical data through a structured workflow that
analyzes symptoms, laboratory results, medical history, drug interactions,
and provides specialist recommendations.

The primary challenge addressed by this system is the complexity of medical
diagnosis which requires:
- Analyzing multiple data sources simultaneously (symptoms, labs, history)
- Evaluating drug interactions and contraindications
- Assessing clinical severity and urgency
- Recommending appropriate specialists and care pathways
- Generating comprehensive diagnostic reports
- Providing AI-powered diagnostic assistance

This system automates the initial diagnostic assessment process, helping
healthcare providers quickly identify critical cases requiring immediate
intervention versus routine care cases.

IMPORTANT DISCLAIMER: This is a diagnostic assistance tool for healthcare
professionals only. All recommendations must be verified by licensed medical
professionals. The system provides decision support and does not replace
clinical judgment.


==============================================================================
FILE STRUCTURE
==============================================================================

ROOT DIRECTORY:
medical-diagnosis-pipeline/
├── main.py                         (Main application entry point)
├── state.py                        (Shared state data structure)
├── graph.py                        (Parallel execution engine)
├── config.py                       (Configuration management)
├── requirements.txt                (Python dependencies)
├── .env.example                    (Environment variable template)
│
├── agents/                         (Business logic agents)
│   ├── __init__.py
│   ├── base_agent.py              (Abstract base agent class)
│   ├── patient_intake_agent.py    (Patient data validation)
│   ├── symptom_agent.py           (Symptom analysis logic)
│   ├── lab_agent.py               (Lab results analysis)
│   ├── medical_history_agent.py   (Medical history evaluation)
│   ├── drug_interaction_agent.py  (Drug interaction checking)
│   ├── specialist_agent.py        (Specialist recommendations)
│   └── coordinator_agent.py       (Results aggregation)
│
├── analyzers/                      (Pure analysis tools)
│   ├── __init__.py
│   ├── symptom_analyzer.py        (Symptom severity calculator)
│   ├── lab_analyzer.py            (Lab test evaluator)
│   ├── medical_history_analyzer.py (History risk assessment)
│   ├── drug_interaction_analyzer.py (Drug compatibility checker)
│   ├── specialist_recommender.py   (Specialist matching system)
│   └── gemini_client.py           (Google Gemini AI integration)
│
├── nodes/                          (Workflow nodes)
│   ├── __init__.py
│   ├── patient_intake_node.py     (Data intake wrapper)
│   ├── symptom_node.py            (Symptom analysis wrapper)
│   ├── lab_node.py                (Lab analysis wrapper)
│   ├── medical_history_node.py    (History analysis wrapper)
│   ├── drug_interaction_node.py   (Drug interaction wrapper)
│   ├── specialist_node.py         (Specialist recommendation wrapper)
│   ├── coordinator_node.py        (Coordination wrapper)
│   ├── decision_node.py           (Clinical decision logic)
│   └── report_node.py             (Report generation)
│
├── workflows/                      (Workflow definitions)
│   ├── __init__.py
│   └── diagnosis_workflow.py      (Main diagnosis workflow builder)
│
├── services/                       (External services)
│   ├── __init__.py
│   └── notification_service.py    (Email notification service)
│
├── utils/                          (Utilities)
│   ├── __init__.py
│   └── logging_utils.py           (Logging configuration)
│
└── logs/                           (Application logs)
    └── medical_diagnosis.log      (Runtime logs)


==============================================================================
KEY FILES AND THEIR PURPOSES
==============================================================================

------------------------------------------------------------------------------
MAIN APPLICATION FILE
------------------------------------------------------------------------------

FILE: main.py
PURPOSE: Application entry point that handles command-line interface,
         initializes the diagnosis workflow, and displays results

IMPORTANT METHODS:

1. main()
   Parameters: None
   Purpose: Main entry point that parses command-line arguments and routes
            to appropriate functions
   Returns: None

2. diagnose_patient(patient_id: str, max_workers: int = 5)
   Parameters:
     - patient_id: String identifier for the patient
     - max_workers: Maximum number of parallel worker threads (default: 5)
   Purpose: Execute diagnosis workflow for a specific patient and display
            results
   Returns: None

3. create_demo_patient_state(patient_id: str) -> DiagnosisState
   Parameters:
     - patient_id: Patient identifier string
   Purpose: Create a demo patient state with sample clinical data for testing
   Returns: DiagnosisState object with populated demo data

4. display_results(state: DiagnosisState)
   Parameters:
     - state: Final DiagnosisState after workflow completion
   Purpose: Format and display diagnosis results including metrics,
            recommendations, and actions
   Returns: None

5. run_demo(max_workers: int = 5)
   Parameters:
     - max_workers: Maximum parallel workers
   Purpose: Run demonstration with pre-configured sample patient
   Returns: None

6. interactive_mode()
   Parameters: None
   Purpose: Provide interactive menu for user to select diagnosis options
   Returns: None


------------------------------------------------------------------------------
STATE MANAGEMENT
------------------------------------------------------------------------------

FILE: state.py
PURPOSE: Defines the shared state data structure used throughout the
         diagnosis pipeline. Pure data container with no business logic.

IMPORTANT CLASS: DiagnosisState (dataclass)

KEY ATTRIBUTES:
- diagnosis_id: Unique identifier for this diagnosis session
- patient_id: Patient identifier
- patient_name: Patient full name
- patient_age: Patient age in years
- patient_gender: Patient gender
- timestamp: Diagnosis start timestamp
- patient_details: Dictionary of additional patient information
- medical_history: List of past medical conditions
- current_symptoms: List of current symptoms
- vital_signs: Dictionary of vital sign measurements
- lab_results: Dictionary of laboratory test results
- symptom_analysis: Analysis results from symptom analyzer
- lab_analysis: Analysis results from lab analyzer
- medical_history_analysis: Analysis results from history analyzer
- drug_interaction_analysis: Analysis results from drug checker
- specialist_recommendations: List of specialist recommendations
- coordination_summary: Aggregated results from all analyses
- decision: Final clinical decision (e.g., "immediate_intervention")
- requires_immediate_attention: Boolean flag for critical cases
- critical_reason: Explanation for critical decision
- decision_metrics: Dictionary of clinical severity metrics
- diagnosis_report: Final comprehensive report
- notifications_sent: List of notification records
- workflow_complete: Boolean completion flag

IMPORTANT METHODS:

1. clone() -> DiagnosisState
   Parameters: None
   Purpose: Create deep copy of state for safe parallel execution
   Returns: New DiagnosisState object with copied data

2. to_dict() -> Dict[str, Any]
   Parameters: None
   Purpose: Convert state to dictionary format
   Returns: Dictionary representation of entire state

3. merge_from(other: Any, overwrite_scalars: bool = True)
   Parameters:
     - other: Another DiagnosisState or dict to merge
     - overwrite_scalars: Whether to overwrite scalar values (default: True)
   Purpose: Merge another state into this state (lists extended, dicts
            updated, scalars overwritten)
   Returns: None (modifies state in-place)


------------------------------------------------------------------------------
WORKFLOW ORCHESTRATION
------------------------------------------------------------------------------

FILE: graph.py
PURPOSE: Custom graph execution engine that handles multi-stage workflows
         with parallel node execution and state merging

IMPORTANT CLASS: DiagnosisGraph

IMPORTANT METHODS:

1. __init__(stages: List[List[NodeFunc]], max_workers: int = 5,
            raise_on_error: bool = False)
   Parameters:
     - stages: List of stages, each containing list of node functions
     - max_workers: Maximum parallel workers (default: 5)
     - raise_on_error: Whether to raise exceptions or continue (default: False)
   Purpose: Initialize the diagnosis graph with workflow stages
   Returns: None

2. run(initial_state: DiagnosisState) -> DiagnosisState
   Parameters:
     - initial_state: Starting state with patient data
   Purpose: Execute all workflow stages sequentially, running nodes within
            each stage in parallel, merging results after each stage
   Returns: Final DiagnosisState after all stages complete

3. _safe_run(node: NodeFunc, state_snapshot: DiagnosisState) -> DiagnosisState
   Parameters:
     - node: Node function to execute
     - state_snapshot: Cloned state for this node execution
   Purpose: Safely execute a node with error handling
   Returns: Updated state or original state with error metadata on failure


FILE: workflows/diagnosis_workflow.py
PURPOSE: Defines the 5-stage medical diagnosis workflow structure

IMPORTANT METHOD:

1. build_diagnosis_workflow(max_workers: int = 5) -> DiagnosisGraph
   Parameters:
     - max_workers: Maximum parallel workers (default: 5)
   Purpose: Build and configure the diagnosis workflow with 5 stages
   Returns: Configured DiagnosisGraph ready for execution

WORKFLOW STAGES:
Stage 1: Patient Intake (Sequential)
         - patient_intake_node

Stage 2: Parallel Analyses (5 nodes run simultaneously)
         - symptom_node
         - lab_node
         - medical_history_node
         - drug_interaction_node
         - specialist_node

Stage 3: Coordinator (Sequential)
         - coordinator_node

Stage 4: Decision (Sequential)
         - decision_node

Stage 5: Report (Sequential)
         - report_node


------------------------------------------------------------------------------
CONFIGURATION MANAGEMENT
------------------------------------------------------------------------------

FILE: config.py
PURPOSE: Centralized configuration management with environment variable
         support and validation

IMPORTANT CLASS: ConfigManager (Singleton)

DEFAULT CONFIGURATION VALUES:
- EMAIL_FROM: pranavram106@gmail.com
- EMAIL_PASSWORD: (app password for Gmail)
- EMAIL_TO: pranavram106@gmail.com
- SMTP_SERVER: smtp.gmail.com
- SMTP_PORT: 587
- GEMINI_API_KEY: Google Gemini API key
- GEMINI_MODEL: gemini-2.5-flash-lite
- SYMPTOM_SEVERITY_THRESHOLD: 7.0
- LAB_ABNORMALITY_THRESHOLD: 2.0
- DRUG_INTERACTION_SEVERITY: MODERATE
- CRITICAL_VITALS_CHECK: True
- SPECIALIST_REFERRAL_THRESHOLD: 8.0
- LOG_LEVEL: INFO
- LOG_FILE: logs/medical_diagnosis.log

IMPORTANT METHODS:

1. get(key: str, default: Any = None) -> Any
   Parameters:
     - key: Configuration key name
     - default: Default value if key not found
   Purpose: Retrieve configuration value
   Returns: Configuration value or default

2. validate()
   Parameters: None
   Purpose: Validate that all required configuration values are present
   Returns: None (raises ValueError if validation fails)

3. get_all() -> Dict[str, Any]
   Parameters: None
   Purpose: Get all configuration values
   Returns: Dictionary of all config values


CONVENIENCE FUNCTIONS:

1. get_config() -> ConfigManager
   Purpose: Get singleton config manager instance

2. get_config_value(key: str, default: Any = None) -> Any
   Purpose: Quick access to specific config value

3. validate_config()
   Purpose: Validate required configuration


------------------------------------------------------------------------------
AGENT ARCHITECTURE
------------------------------------------------------------------------------

FILE: agents/base_agent.py
PURPOSE: Abstract base class providing common functionality for all agents

IMPORTANT CLASS: BaseAgent

IMPORTANT METHODS:

1. __init__(name: str)
   Parameters:
     - name: Agent name for logging
   Purpose: Initialize base agent with logger
   Returns: None

2. log(message: str, level: str = "info")
   Parameters:
     - message: Message to log
     - level: Log level (info, warning, error, debug)
   Purpose: Log message with agent name prefix
   Returns: None

3. analyze(*args, **kwargs) -> Any
   Parameters: Variable (defined by subclass)
   Purpose: Main analysis method (must be implemented by subclass)
   Returns: Analysis results (type varies by subclass)


FILE: agents/symptom_agent.py
PURPOSE: Agent that analyzes patient symptoms using SymptomAnalyzer

IMPORTANT METHOD:
1. analyze(state: DiagnosisState) -> Dict[str, Any]
   Parameters:
     - state: Current diagnosis state
   Purpose: Analyze symptoms from state and return severity assessment
   Returns: Dictionary with symptom analysis results


FILE: agents/lab_agent.py
PURPOSE: Agent that analyzes laboratory test results using LabAnalyzer

IMPORTANT METHOD:
1. analyze(state: DiagnosisState) -> Dict[str, Any]
   Parameters:
     - state: Current diagnosis state
   Purpose: Analyze lab results and identify abnormalities
   Returns: Dictionary with lab analysis results


FILE: agents/medical_history_agent.py
PURPOSE: Agent that evaluates patient medical history risks

IMPORTANT METHOD:
1. analyze(state: DiagnosisState) -> Dict[str, Any]
   Parameters:
     - state: Current diagnosis state
   Purpose: Assess risk factors from medical history
   Returns: Dictionary with medical history analysis


FILE: agents/drug_interaction_agent.py
PURPOSE: Agent that checks for drug-drug interactions

IMPORTANT METHOD:
1. analyze(state: DiagnosisState) -> Dict[str, Any]
   Parameters:
     - state: Current diagnosis state
   Purpose: Check current medications for interactions
   Returns: Dictionary with drug interaction analysis


FILE: agents/specialist_agent.py
PURPOSE: Agent that recommends specialists and performs AI analysis

IMPORTANT METHOD:
1. analyze(state: DiagnosisState) -> Dict[str, Any]
   Parameters:
     - state: Current diagnosis state
   Purpose: Recommend specialists and get AI diagnostic insights
   Returns: Dictionary with specialist recommendations and AI analysis


FILE: agents/coordinator_agent.py
PURPOSE: Agent that aggregates all analysis results

IMPORTANT METHOD:
1. analyze(state: DiagnosisState) -> Dict[str, Any]
   Parameters:
     - state: Current diagnosis state
   Purpose: Aggregate all analysis results into coordination summary
   Returns: Dictionary with overall severity scores and metrics


------------------------------------------------------------------------------
ANALYZER TOOLS
------------------------------------------------------------------------------

FILE: analyzers/symptom_analyzer.py
PURPOSE: Pure tool for symptom severity analysis with pattern matching

IMPORTANT CLASS: SymptomAnalyzer

SEVERITY MAPPING (0-10 scale):
- Critical (9-10): chest pain, difficulty breathing, severe bleeding,
                   stroke symptoms
- High (7-8): high fever, severe headache, persistent vomiting
- Moderate (4-6): fever, cough, headache, nausea, fatigue
- Low (1-3): mild headache, runny nose, sneezing

CONDITION PATTERNS:
- COVID-19: fever, cough, fatigue, loss of taste, difficulty breathing
- Influenza: fever, cough, muscle pain, fatigue, headache
- Heart Attack: chest pain, difficulty breathing, nausea
- Stroke: stroke symptoms, blurred vision, severe headache
- Appendicitis: severe abdominal pain, nausea, fever

IMPORTANT METHODS:

1. analyze_symptoms(symptoms: List[str], duration_days: int = 1)
   -> Dict[str, Any]
   Parameters:
     - symptoms: List of symptom strings
     - duration_days: Number of days symptoms have persisted (default: 1)
   Purpose: Calculate symptom severity, match conditions, generate
            recommendations
   Returns: Dictionary with severity_score, severity_level,
            suspected_conditions, recommendations,
            requires_immediate_attention

2. _get_symptom_severity(symptom: str) -> int
   Parameters:
     - symptom: Symptom string
   Purpose: Map symptom to severity score (0-10)
   Returns: Integer severity score

3. _match_conditions(symptoms: List[str]) -> List[Dict[str, Any]]
   Parameters:
     - symptoms: List of symptoms
   Purpose: Match symptoms to known condition patterns
   Returns: List of suspected conditions with match percentages


FILE: analyzers/lab_analyzer.py
PURPOSE: Pure tool for laboratory test result evaluation

IMPORTANT CLASS: LabAnalyzer

REFERENCE RANGES:
- glucose: 70-100 mg/dL (normal), >126 (diabetes)
- cholesterol: <200 mg/dL (normal), >240 (high risk)
- ldl: <100 mg/dL (optimal), >160 (high)
- hdl: >40 mg/dL men, >50 women (normal)
- creatinine: 0.7-1.3 mg/dL (normal)
- hemoglobin: 13.5-17.5 g/dL men, 12-15.5 women
- wbc: 4.5-11.0 K/uL (normal)

IMPORTANT METHODS:

1. analyze_lab_results(lab_results: Dict[str, float], patient_age: int,
                      patient_gender: str) -> Dict[str, Any]
   Parameters:
     - lab_results: Dictionary of lab test names and values
     - patient_age: Patient age in years
     - patient_gender: Patient gender
   Purpose: Evaluate all lab results against reference ranges
   Returns: Dictionary with abnormality_score, severity_level,
            abnormal_results, critical_findings, recommendations


FILE: analyzers/medical_history_analyzer.py
PURPOSE: Pure tool for medical history risk assessment

IMPORTANT CLASS: MedicalHistoryAnalyzer

RISK SCORING:
- High-risk conditions (8-10): heart failure, stroke, cancer, kidney disease
- Moderate-risk (5-7): diabetes, hypertension, asthma, chronic conditions
- Low-risk (2-4): allergies, minor conditions

IMPORTANT METHODS:

1. analyze_history(medical_history: List, patient_age: int,
                  current_medications: List, allergies: List,
                  family_history: List) -> Dict[str, Any]
   Parameters:
     - medical_history: List of past medical conditions
     - patient_age: Patient age
     - current_medications: List of current medications
     - allergies: List of known allergies
     - family_history: List of family history items
   Purpose: Calculate overall risk score from medical history
   Returns: Dictionary with risk_score, risk_level, high_risk_conditions,
            concerns, recommendations


FILE: analyzers/drug_interaction_analyzer.py
PURPOSE: Pure tool for checking drug-drug interactions

IMPORTANT CLASS: DrugInteractionAnalyzer

INTERACTION DATABASE:
- Severe interactions: warfarin + aspirin, MAOIs + SSRIs
- Moderate interactions: ACE inhibitors + potassium, beta blockers + insulin
- Mild interactions: statins + grapefruit

IMPORTANT METHODS:

1. analyze_interactions(current_medications: List[str],
                       proposed_medications: List[str] = None)
   -> Dict[str, Any]
   Parameters:
     - current_medications: List of current medication names
     - proposed_medications: Optional list of proposed new medications
   Purpose: Check for known drug interactions
   Returns: Dictionary with interaction_score, severity_level,
            interactions_found, warnings, recommendations


FILE: analyzers/specialist_recommender.py
PURPOSE: Pure tool for recommending appropriate medical specialists

IMPORTANT CLASS: SpecialistRecommender

SPECIALIST MATCHING:
- Cardiologist: heart, chest pain, hypertension, high cholesterol
- Pulmonologist: breathing, cough, asthma, lung
- Endocrinologist: diabetes, thyroid, hormone, glucose
- Neurologist: headache, stroke, seizure, dizziness
- Gastroenterologist: abdominal pain, nausea, digestive

IMPORTANT METHODS:

1. recommend_specialists(symptoms: List[str], medical_history: List,
                        lab_results: Dict, suspected_conditions: List)
   -> List[Dict[str, Any]]
   Parameters:
     - symptoms: Patient symptoms
     - medical_history: Medical history
     - lab_results: Lab test results
     - suspected_conditions: Suspected diagnoses
   Purpose: Match patient data to appropriate specialists
   Returns: List of specialist recommendations with urgency levels


FILE: analyzers/gemini_client.py
PURPOSE: Integration with Google Gemini AI for diagnostic assistance

IMPORTANT CLASS: GeminiClient

IMPORTANT METHODS:

1. __init__()
   Parameters: None
   Purpose: Initialize Gemini AI client with API key from config
   Returns: None

2. analyze_diagnosis(symptoms: List[str], medical_history: List[str],
                    lab_results: Dict[str, float], vital_signs: Dict[str, Any],
                    patient_age: int, patient_gender: str,
                    context: Optional[Dict[str, Any]] = None)
   -> Dict[str, Any]
   Parameters:
     - symptoms: List of patient symptoms
     - medical_history: List of past conditions
     - lab_results: Laboratory test results
     - vital_signs: Vital sign measurements
     - patient_age: Patient age
     - patient_gender: Patient gender
     - context: Optional previous analysis results
   Purpose: Send patient data to Gemini AI for diagnostic assessment
   Returns: Dictionary with overall_assessment_score, confidence,
            likely_diagnoses, clinical_observations, recommended_actions,
            risk_factors, urgency_assessment

3. _build_diagnosis_prompt(...) -> str
   Parameters: Same as analyze_diagnosis
   Purpose: Construct detailed prompt for AI with patient data
   Returns: Formatted prompt string

4. _parse_diagnosis_response(response: str) -> Dict[str, Any]
   Parameters:
     - response: Raw AI response text
   Purpose: Parse AI response into structured data
   Returns: Structured dictionary with extracted information


------------------------------------------------------------------------------
NODE WRAPPERS
------------------------------------------------------------------------------

FILE: nodes/patient_intake_node.py
PURPOSE: Wrapper node that calls PatientIntakeAgent

IMPORTANT FUNCTION:
1. patient_intake_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Process and validate patient intake data
   Returns: Updated state with validated patient data


FILE: nodes/symptom_node.py
PURPOSE: Wrapper node that calls SymptomAgent

IMPORTANT FUNCTION:
1. symptom_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Analyze symptoms and update state
   Returns: State with symptom_analysis populated


FILE: nodes/lab_node.py
PURPOSE: Wrapper node that calls LabAgent

IMPORTANT FUNCTION:
1. lab_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Analyze lab results and update state
   Returns: State with lab_analysis populated


FILE: nodes/medical_history_node.py
PURPOSE: Wrapper node that calls MedicalHistoryAgent

IMPORTANT FUNCTION:
1. medical_history_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Analyze medical history and update state
   Returns: State with medical_history_analysis populated


FILE: nodes/drug_interaction_node.py
PURPOSE: Wrapper node that calls DrugInteractionAgent

IMPORTANT FUNCTION:
1. drug_interaction_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Check drug interactions and update state
   Returns: State with drug_interaction_analysis populated


FILE: nodes/specialist_node.py
PURPOSE: Wrapper node that calls SpecialistAgent

IMPORTANT FUNCTION:
1. specialist_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Generate specialist recommendations and AI analysis
   Returns: State with specialist_recommendations populated


FILE: nodes/coordinator_node.py
PURPOSE: Wrapper node that calls CoordinatorAgent

IMPORTANT FUNCTION:
1. coordinator_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state
   Purpose: Aggregate all analysis results into coordination summary
   Returns: State with coordination_summary populated


FILE: nodes/decision_node.py
PURPOSE: Business logic node for making clinical decisions

CLINICAL THRESHOLDS:
- SYMPTOM_SEVERITY_THRESHOLD: 7.0/10
- LAB_ABNORMALITY_THRESHOLD: 2.0 standard deviations
- SPECIALIST_REFERRAL_THRESHOLD: 8.0/10

DECISION CATEGORIES:
- immediate_intervention: Critical findings requiring ER
- urgent_specialist_referral: Urgent specialist needed
- specialist_consultation: Standard specialist referral
- pharmacist_review: Drug interaction issues
- follow_up_care: Moderate findings requiring follow-up
- routine_care: No critical findings

IMPORTANT FUNCTION:
1. decision_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state with coordination summary
   Purpose: Make diagnostic decision based on clinical thresholds
   Returns: State with decision, requires_immediate_attention,
            critical_reason, decision_metrics populated


FILE: nodes/report_node.py
PURPOSE: Generate final diagnosis report and send notifications

IMPORTANT FUNCTION:
1. report_node(state: DiagnosisState) -> DiagnosisState
   Parameters:
     - state: Current diagnosis state with decision
   Purpose: Generate comprehensive report and send email notification
   Returns: State with diagnosis_report and notifications_sent populated


------------------------------------------------------------------------------
NOTIFICATION SERVICE
------------------------------------------------------------------------------

FILE: services/notification_service.py
PURPOSE: Email notification service for diagnosis reports

IMPORTANT CLASS: NotificationService

CONFIGURATION:
- Uses SMTP for email delivery
- Supports Gmail SMTP by default (smtp.gmail.com:587)
- Requires app-specific password for Gmail

IMPORTANT METHODS:

1. __init__()
   Parameters: None
   Purpose: Initialize notification service with email config
   Returns: None

2. send_email(subject: str, content: str) -> bool
   Parameters:
     - subject: Email subject line
     - content: Email body content
   Purpose: Send email via SMTP
   Returns: True if successful, False otherwise

3. send_diagnosis_started(patient_details: Dict[str, Any]) -> bool
   Parameters:
     - patient_details: Patient information dictionary
   Purpose: Send notification when diagnosis starts
   Returns: True if successful

4. send_diagnosis_report(patient_details: Dict[str, Any],
                        report: Dict[str, Any],
                        is_critical: bool) -> bool
   Parameters:
     - patient_details: Patient information
     - report: Final diagnosis report
     - is_critical: Whether case requires immediate attention
   Purpose: Send final diagnosis report notification
   Returns: True if successful

5. _format_report(report: Dict[str, Any]) -> str
   Parameters:
     - report: Diagnosis report dictionary
   Purpose: Format report for email body
   Returns: Formatted report string


------------------------------------------------------------------------------
LOGGING UTILITIES
------------------------------------------------------------------------------

FILE: utils/logging_utils.py
PURPOSE: Centralized logging configuration

IMPORTANT FUNCTION:
1. setup_logging(level: str = "INFO", log_file: str = None)
   Parameters:
     - level: Log level (DEBUG, INFO, WARNING, ERROR)
     - log_file: Path to log file (optional)
   Purpose: Configure Python logging with file and console handlers
   Returns: None


==============================================================================
RUNNING THE APPLICATION
==============================================================================

PREREQUISITES:
1. Python 3.8 or higher installed
2. All dependencies installed from requirements.txt
3. Configuration set up (see Configuration section)

------------------------------------------------------------------------------
INSTALLATION COMMANDS
------------------------------------------------------------------------------

STEP 1: Install Python Dependencies

Command:
pip install -r requirements.txt

This installs:
- langgraph>=0.2.0 (Workflow orchestration)
- langchain-core>=0.3.0 (LangChain core components)
- google-generativeai>=0.3.0 (Google Gemini AI SDK)
- requests>=2.25.0 (HTTP requests)
- python-dotenv>=0.15.0 (Environment variable management)
- pytest>=6.0.0 (Testing framework)
- pytest-cov>=2.12.0 (Test coverage)


STEP 2: Configure Environment Variables

Create .env file in project root:

EMAIL_FROM=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
EMAIL_TO=recipient@email.com
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587

GEMINI_API_KEY=your-gemini-api-key
GEMINI_MODEL=gemini-2.5-flash-lite

SYMPTOM_SEVERITY_THRESHOLD=7.0
LAB_ABNORMALITY_THRESHOLD=2.0
DRUG_INTERACTION_SEVERITY=MODERATE
CRITICAL_VITALS_CHECK=True
SPECIALIST_REFERRAL_THRESHOLD=8.0

LOG_LEVEL=INFO
LOG_FILE=logs/medical_diagnosis.log

Note: For Gmail, use an app-specific password (not your regular password)
To generate: Google Account -> Security -> 2-Step Verification -> App passwords


STEP 3: Create Logs Directory

Command:
mkdir logs


------------------------------------------------------------------------------
RUNNING COMMANDS
------------------------------------------------------------------------------

COMMAND 1: Interactive Mode (Recommended for first-time use)

Command:
python3 main.py

Description: Launches interactive menu with options:
1. Run Diagnosis (with Patient ID)
2. Run Demo
0. Exit

User selects option and provides required inputs.


COMMAND 2: Demo Mode (Quick test with sample patient)

Command:
python3 main.py demo

Optional parameters:
python3 main.py demo --max-workers 10

Description: Runs diagnosis on pre-configured demo patient (55-year-old male
with chest pain, breathing difficulty, diabetes, and hypertension)


COMMAND 3: Diagnose Specific Patient

Command:
python3 main.py diagnose PATIENT-ID-HERE

Example:
python3 main.py diagnose PT-2024-001

Optional parameters:
python3 main.py diagnose PT-2024-001 --max-workers 8

Description: Runs diagnosis for specified patient ID. Currently uses demo
data (system designed for integration with real patient database).


COMMAND 4: Run Tests

Command:
python3 -m pytest tests.py -v
Description: Run unit tests for the system components


==============================================================================
EXPECTED OUTPUT
==============================================================================

------------------------------------------------------------------------------
CONSOLE OUTPUT (Demo Mode)
------------------------------------------------------------------------------

When running: python3 main.py demo

Expected output:

======================================================================
DEMO MODE - Medical Diagnosis Pipeline
======================================================================
This will analyze a sample patient with demo clinical data.

Example: 55-year-old male with chest pain and breathing difficulty

Analyzing patient: DEMO-PT-001

======================================================================
MEDICAL DIAGNOSIS PIPELINE - CLIENT FORMAT
======================================================================
Patient ID: DEMO-PT-001
Max Workers: 5
======================================================================

NOTE: Using mock patient data for demonstration purposes.
Diagnosis ID: DX-20251202-A1B2C3D4
Starting workflow execution...

[Workflow executes through 5 stages with parallel processing]

======================================================================
DIAGNOSIS COMPLETE
======================================================================
Diagnosis ID: DX-20251202-A1B2C3D4
Patient: John Doe (Demo Patient)
Decision: IMMEDIATE_INTERVENTION

[!] ALERT: Critical lab findings detected; Multiple high-risk conditions

======================================================================
CLINICAL METRICS
======================================================================
Overall Severity:     8.50/10.0 (HIGH)
Symptom Severity:     8.67/10.0
Lab Abnormality:      10.00/10.0
History Risk:         5.85/10.0
Drug Interactions:    0.00/10.0
AI Assessment:        0.50/1.0
AI Confidence:        0.00

======================================================================
DIAGNOSIS REPORT SUMMARY
======================================================================
Recommendation: IMMEDIATE_INTERVENTION
Priority: CRITICAL

Key Findings:
  - Critical symptom severity: 8.67/10 (HIGH)
  - Critical lab abnormalities: 10.0/10 (CRITICAL)
  - Medical history shows high-risk conditions
  - Cardiac symptoms with respiratory distress
  - Elevated glucose levels (diabetes concern)

Suspected Conditions:
  - Heart Attack (Symptom Analysis)
  - COVID-19 (Symptom Analysis)
  - Cardiologist (Specialist Recommendation)

Recommended Actions:
  - URGENT: Seek emergency medical attention immediately
  - Call emergency services (911) or go to nearest ER
  - Chew aspirin if available and no allergies
  - Immediate specialist consultation required
  - Cardiac evaluation within 1 hour

======================================================================
Notification sent to configured healthcare provider
======================================================================


------------------------------------------------------------------------------
EMAIL NOTIFICATION OUTPUT
------------------------------------------------------------------------------

Subject: URGENT - CRITICAL FINDINGS: Patient DEMO-PT-001

Body:

URGENT - CRITICAL FINDINGS
========================

Patient: John Doe (Demo Patient)
Patient ID: DEMO-PT-001
Diagnosis ID: DX-20251202-A1B2C3D4
Timestamp: 2025-12-02 12:29:36

CLINICAL DECISION: IMMEDIATE_INTERVENTION
PRIORITY: CRITICAL

OVERALL ASSESSMENT:
  Severity Score: 8.50/10.0
  Severity Level: HIGH

CLINICAL METRICS:
  Symptom Severity: 8.67/10.0
  Lab Abnormality: 10.00/10.0
  Medical History Risk: 5.85/10.0
  Drug Interaction Score: 0.00/10.0
  AI Assessment: 0.50/1.0
  AI Confidence: 0.00

KEY CLINICAL FINDINGS:
  - Critical symptom severity: 8.67/10 (HIGH)
  - Critical lab abnormalities: 10.0/10 (CRITICAL)
  - Medical history shows high-risk conditions
  - Cardiac symptoms with respiratory distress
  - Elevated glucose levels (diabetes concern)

SUSPECTED CONDITIONS:
  - Heart Attack (Symptom Analysis, 60% confidence)
  - COVID-19 (Symptom Analysis, 40% confidence)
  - Cardiologist (Specialist Recommendation, 0% confidence)

SPECIALIST RECOMMENDATIONS:
  - Cardiologist (HIGH priority)
  - Pulmonologist (HIGH priority)
  - Endocrinologist (MODERATE priority)

AI DIAGNOSTIC INSIGHTS:
  - [AI insights if API key is valid]

RECOMMENDED ACTIONS:
  - URGENT: Seek emergency medical attention immediately
  - Call emergency services (911) or go to nearest ER
  - Chew aspirin if available and no allergies
  - Immediate specialist consultation required
  - Cardiac evaluation within 1 hour