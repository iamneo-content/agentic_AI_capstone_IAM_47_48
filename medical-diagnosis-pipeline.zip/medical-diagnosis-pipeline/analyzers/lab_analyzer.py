"""
Lab Analyzer - Pure Tool
Analyzes laboratory test results
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("lab_analyzer")


class LabAnalyzer:
    """Pure lab analysis tool - reusable across workflows"""

    def __init__(self):
        # Normal ranges for common lab tests
        self.normal_ranges = {
            # Complete Blood Count (CBC)
            "wbc": (4.0, 11.0, "10^3/μL"),  # White Blood Cells
            "rbc": (4.5, 5.5, "10^6/μL"),  # Red Blood Cells
            "hemoglobin": (13.5, 17.5, "g/dL"),
            "hematocrit": (38.0, 50.0, "%"),
            "platelets": (150, 400, "10^3/μL"),

            # Metabolic Panel
            "glucose": (70, 100, "mg/dL"),
            "sodium": (135, 145, "mEq/L"),
            "potassium": (3.5, 5.0, "mEq/L"),
            "calcium": (8.5, 10.5, "mg/dL"),
            "creatinine": (0.7, 1.3, "mg/dL"),
            "bun": (7, 20, "mg/dL"),  # Blood Urea Nitrogen

            # Liver Function
            "alt": (7, 56, "U/L"),  # Alanine Aminotransferase
            "ast": (10, 40, "U/L"),  # Aspartate Aminotransferase
            "bilirubin": (0.1, 1.2, "mg/dL"),

            # Lipid Panel
            "cholesterol": (125, 200, "mg/dL"),
            "ldl": (0, 100, "mg/dL"),
            "hdl": (40, 60, "mg/dL"),
            "triglycerides": (0, 150, "mg/dL"),

            # Thyroid
            "tsh": (0.4, 4.0, "mIU/L"),

            # Other
            "hba1c": (4.0, 5.6, "%"),  # Diabetes marker
        }

    def analyze_labs(self, lab_results: Dict[str, float]) -> Dict[str, Any]:
        """
        Analyze laboratory test results

        Args:
            lab_results: Dictionary of lab test names to values

        Returns:
            Dictionary with lab analysis data
        """
        if not lab_results:
            return {
                "abnormality_score": 0.0,
                "abnormality_level": "NONE",
                "abnormal_results": [],
                "normal_results": [],
                "critical_findings": [],
                "recommendations": ["No lab results to analyze"]
            }

        abnormal_results = []
        normal_results = []
        critical_findings = []
        total_deviation = 0.0

        for test_name, value in lab_results.items():
            test_lower = test_name.lower().strip()

            if test_lower in self.normal_ranges:
                min_val, max_val, unit = self.normal_ranges[test_lower]
                status, deviation = self._evaluate_result(value, min_val, max_val)

                result_detail = {
                    "test": test_name,
                    "value": value,
                    "unit": unit,
                    "normal_range": f"{min_val}-{max_val}",
                    "status": status,
                    "deviation": round(deviation, 2)
                }

                if status != "NORMAL":
                    abnormal_results.append(result_detail)
                    total_deviation += abs(deviation)

                    # Check for critical values
                    if abs(deviation) >= 2.0:  # 2 standard deviations
                        critical_findings.append({
                            **result_detail,
                            "severity": "CRITICAL" if abs(deviation) >= 3.0 else "HIGH"
                        })
                else:
                    normal_results.append(result_detail)
            else:
                # Unknown test - mark as unknown
                logger.warning(f"Unknown lab test: {test_name}")

        # Calculate abnormality score (0-10 scale)
        abnormality_score = min(total_deviation, 10.0)
        abnormality_level = self._get_abnormality_level(abnormality_score)

        # Generate recommendations
        recommendations = self._generate_recommendations(
            abnormal_results, critical_findings, abnormality_score
        )

        return {
            "abnormality_score": round(abnormality_score, 2),
            "abnormality_level": abnormality_level,
            "total_tests": len(lab_results),
            "abnormal_count": len(abnormal_results),
            "normal_count": len(normal_results),
            "abnormal_results": abnormal_results,
            "normal_results": normal_results,
            "critical_findings": critical_findings,
            "recommendations": recommendations,
            "requires_immediate_attention": len(critical_findings) > 0
        }

    def _evaluate_result(self, value: float, min_val: float, max_val: float) -> tuple:
        """
        Evaluate a lab result against normal range

        Returns:
            (status, deviation) where deviation is in standard deviations
        """
        if min_val <= value <= max_val:
            return "NORMAL", 0.0

        # Calculate deviation (simplified - using range as ~4 SD)
        range_width = max_val - min_val
        sd = range_width / 4.0

        if value < min_val:
            deviation = (min_val - value) / sd
            return "LOW", -deviation
        else:
            deviation = (value - max_val) / sd
            return "HIGH", deviation

    def _get_abnormality_level(self, score: float) -> str:
        """Convert abnormality score to level"""
        if score >= 8.0:
            return "CRITICAL"
        elif score >= 5.0:
            return "HIGH"
        elif score >= 2.0:
            return "MODERATE"
        elif score > 0:
            return "MILD"
        else:
            return "NORMAL"

    def _generate_recommendations(
        self, abnormal_results: List[Dict], critical_findings: List[Dict],
        abnormality_score: float
    ) -> List[str]:
        """Generate recommendations based on lab analysis"""
        recommendations = []

        if not abnormal_results:
            recommendations.append("All lab results within normal ranges")
            return recommendations

        # Critical findings
        if critical_findings:
            recommendations.append("URGENT: Critical lab values detected - immediate medical attention required")
            for finding in critical_findings:
                recommendations.append(
                    f"Critical {finding['status'].lower()} {finding['test']}: {finding['value']} {finding['unit']}"
                )

        # Specific recommendations based on abnormal results
        for result in abnormal_results:
            test = result["test"].lower()
            status = result["status"]

            if test == "glucose":
                if status == "HIGH":
                    recommendations.append("Elevated glucose - evaluate for diabetes/pre-diabetes")
                else:
                    recommendations.append("Low glucose - check for hypoglycemia")

            elif test == "creatinine" or test == "bun":
                if status == "HIGH":
                    recommendations.append("Elevated kidney markers - evaluate renal function")

            elif test == "alt" or test == "ast":
                if status == "HIGH":
                    recommendations.append("Elevated liver enzymes - evaluate liver function")

            elif test == "wbc":
                if status == "HIGH":
                    recommendations.append("Elevated WBC - possible infection or inflammation")
                else:
                    recommendations.append("Low WBC - evaluate immune function")

            elif test == "hemoglobin":
                if status == "LOW":
                    recommendations.append("Low hemoglobin - evaluate for anemia")

            elif test == "cholesterol" or test == "ldl":
                if status == "HIGH":
                    recommendations.append("Elevated cholesterol - consider cardiovascular risk")

            elif test == "hba1c":
                if status == "HIGH":
                    recommendations.append("Elevated HbA1c - diabetes management needed")

        # General recommendations
        if abnormality_score >= 5.0:
            recommendations.append("Repeat abnormal tests to confirm results")
            recommendations.append("Consult with healthcare provider within 24-48 hours")
        elif abnormality_score >= 2.0:
            recommendations.append("Follow-up testing recommended")
            recommendations.append("Discuss results with healthcare provider")

        return recommendations
