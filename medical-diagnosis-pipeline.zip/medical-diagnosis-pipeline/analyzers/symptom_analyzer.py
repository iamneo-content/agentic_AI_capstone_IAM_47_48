"""
Symptom Analyzer - Pure Tool
Analyzes patient symptoms and determines severity
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("symptom_analyzer")


class SymptomAnalyzer:
    """Pure symptom analysis tool - reusable across workflows"""

    def __init__(self):
        # Symptom severity mapping (0-10 scale)
        self.severity_map = {
            # Critical symptoms (9-10)
            "chest pain": 10,
            "difficulty breathing": 10,
            "severe bleeding": 10,
            "loss of consciousness": 10,
            "stroke symptoms": 10,
            "seizure": 9,
            "severe abdominal pain": 9,

            # High severity (7-8)
            "high fever": 8,
            "severe headache": 8,
            "persistent vomiting": 7,
            "severe dizziness": 7,
            "blurred vision": 7,

            # Moderate severity (4-6)
            "fever": 6,
            "cough": 5,
            "headache": 5,
            "nausea": 5,
            "fatigue": 4,
            "muscle pain": 4,

            # Low severity (1-3)
            "mild headache": 3,
            "runny nose": 2,
            "sneezing": 2,
            "mild cough": 2,
        }

        # Symptom patterns for common conditions
        self.condition_patterns = {
            "COVID-19": ["fever", "cough", "fatigue", "loss of taste", "difficulty breathing"],
            "Influenza": ["fever", "cough", "muscle pain", "fatigue", "headache"],
            "Migraine": ["severe headache", "nausea", "sensitivity to light", "blurred vision"],
            "Heart Attack": ["chest pain", "difficulty breathing", "nausea", "severe dizziness"],
            "Appendicitis": ["severe abdominal pain", "nausea", "fever", "loss of appetite"],
            "Stroke": ["stroke symptoms", "blurred vision", "severe headache", "confusion"],
            "Common Cold": ["runny nose", "sneezing", "mild cough", "mild headache"],
        }

    def analyze_symptoms(self, symptoms: List[str], duration_days: int = 1) -> Dict[str, Any]:
        """
        Analyze patient symptoms and determine severity

        Args:
            symptoms: List of symptoms
            duration_days: Number of days symptoms have persisted

        Returns:
            Dictionary with symptom analysis data
        """
        if not symptoms:
            return {
                "severity_score": 0.0,
                "severity_level": "NONE",
                "symptom_details": [],
                "suspected_conditions": [],
                "recommendations": ["No symptoms reported"],
                "requires_immediate_attention": False
            }

        symptom_details = []
        total_severity = 0.0
        max_severity = 0

        # Analyze each symptom
        for symptom in symptoms:
            symptom_lower = symptom.lower().strip()
            severity = self._get_symptom_severity(symptom_lower)

            symptom_details.append({
                "symptom": symptom,
                "severity": severity,
                "severity_label": self._get_severity_label(severity)
            })

            total_severity += severity
            max_severity = max(max_severity, severity)

        # Calculate average severity
        avg_severity = total_severity / len(symptoms) if symptoms else 0

        # Adjust for duration
        duration_multiplier = min(1.0 + (duration_days / 10), 1.5)
        adjusted_severity = min(avg_severity * duration_multiplier, 10.0)

        # Determine severity level
        severity_level = self._get_severity_label(adjusted_severity)

        # Check for suspected conditions
        suspected_conditions = self._match_conditions(symptoms)

        # Generate recommendations
        recommendations = self._generate_recommendations(
            adjusted_severity, max_severity, suspected_conditions, duration_days
        )

        # Check if immediate attention is required
        requires_immediate_attention = max_severity >= 9 or adjusted_severity >= 8.0

        return {
            "severity_score": round(adjusted_severity, 2),
            "severity_level": severity_level,
            "max_individual_severity": max_severity,
            "symptom_count": len(symptoms),
            "duration_days": duration_days,
            "symptom_details": symptom_details,
            "suspected_conditions": suspected_conditions,
            "recommendations": recommendations,
            "requires_immediate_attention": requires_immediate_attention
        }

    def _get_symptom_severity(self, symptom: str) -> int:
        """Get severity score for a symptom"""
        # Check for exact matches
        if symptom in self.severity_map:
            return self.severity_map[symptom]

        # Check for partial matches
        for known_symptom, severity in self.severity_map.items():
            if known_symptom in symptom or symptom in known_symptom:
                return severity

        # Default severity for unknown symptoms
        return 5

    def _get_severity_label(self, severity: float) -> str:
        """Convert severity score to label"""
        if severity >= 9:
            return "CRITICAL"
        elif severity >= 7:
            return "HIGH"
        elif severity >= 5:
            return "MODERATE"
        elif severity >= 3:
            return "LOW"
        else:
            return "MINIMAL"

    def _match_conditions(self, symptoms: List[str]) -> List[Dict[str, Any]]:
        """Match symptoms to potential conditions"""
        suspected = []
        symptoms_lower = [s.lower().strip() for s in symptoms]

        for condition, pattern_symptoms in self.condition_patterns.items():
            matches = sum(1 for ps in pattern_symptoms if any(ps in s for s in symptoms_lower))
            match_percentage = (matches / len(pattern_symptoms)) * 100

            if match_percentage >= 30:  # At least 30% match
                suspected.append({
                    "condition": condition,
                    "match_percentage": round(match_percentage, 1),
                    "matched_symptoms": matches,
                    "total_pattern_symptoms": len(pattern_symptoms)
                })

        # Sort by match percentage
        suspected.sort(key=lambda x: x["match_percentage"], reverse=True)
        return suspected

    def _generate_recommendations(
        self, avg_severity: float, max_severity: int,
        suspected_conditions: List[Dict], duration_days: int
    ) -> List[str]:
        """Generate recommendations based on symptom analysis"""
        recommendations = []

        # Critical recommendations
        if max_severity >= 9:
            recommendations.append("URGENT: Seek emergency medical attention immediately")
            recommendations.append("Call emergency services (911) or go to nearest ER")

        elif avg_severity >= 8.0:
            recommendations.append("Immediate medical evaluation required")
            recommendations.append("Visit urgent care or emergency room within 1 hour")

        elif avg_severity >= 6.0:
            recommendations.append("Schedule appointment with healthcare provider within 24 hours")
            recommendations.append("Monitor symptoms closely for any worsening")

        elif avg_severity >= 4.0:
            recommendations.append("Schedule appointment with primary care physician within 2-3 days")
            recommendations.append("Continue monitoring symptoms")

        else:
            recommendations.append("Rest and monitor symptoms")
            recommendations.append("Self-care measures may be appropriate")

        # Duration-based recommendations
        if duration_days > 7:
            recommendations.append(f"Symptoms persisting for {duration_days} days - medical evaluation recommended")

        # Condition-specific recommendations
        if suspected_conditions:
            top_condition = suspected_conditions[0]["condition"]
            if top_condition == "Heart Attack":
                recommendations.append("Chew aspirin if available and no allergies")
            elif top_condition == "Stroke":
                recommendations.append("Note time of symptom onset - critical for treatment")
            elif top_condition in ["COVID-19", "Influenza"]:
                recommendations.append("Consider COVID-19 or flu testing")
                recommendations.append("Isolate from others to prevent spread")

        return recommendations
