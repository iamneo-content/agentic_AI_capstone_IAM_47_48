"""
Specialist Recommender - Pure Tool
Recommends appropriate medical specialists
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("specialist_recommender")


class SpecialistRecommender:
    """Pure specialist recommendation tool - reusable across workflows"""

    def __init__(self):
        # Specialist mappings based on conditions/symptoms
        self.specialist_map = {
            # Cardiology
            "cardiology": {
                "specialization": "Cardiology",
                "conditions": ["heart disease", "chest pain", "heart attack", "hypertension",
                             "high blood pressure", "irregular heartbeat", "arrhythmia"],
                "symptoms": ["chest pain", "difficulty breathing", "palpitations"],
                "lab_indicators": ["cholesterol", "ldl", "triglycerides"],
                "urgency": "HIGH"
            },

            # Endocrinology
            "endocrinology": {
                "specialization": "Endocrinology",
                "conditions": ["diabetes", "thyroid disease", "metabolic disorder"],
                "symptoms": ["excessive thirst", "frequent urination", "unexplained weight changes"],
                "lab_indicators": ["glucose", "hba1c", "tsh"],
                "urgency": "MODERATE"
            },

            # Neurology
            "neurology": {
                "specialization": "Neurology",
                "conditions": ["stroke", "seizure", "migraine", "multiple sclerosis"],
                "symptoms": ["severe headache", "seizure", "numbness", "stroke symptoms"],
                "lab_indicators": [],
                "urgency": "HIGH"
            },

            # Nephrology
            "nephrology": {
                "specialization": "Nephrology (Kidney)",
                "conditions": ["kidney disease", "renal failure"],
                "symptoms": ["decreased urination", "swelling"],
                "lab_indicators": ["creatinine", "bun"],
                "urgency": "HIGH"
            },

            # Gastroenterology
            "gastroenterology": {
                "specialization": "Gastroenterology",
                "conditions": ["liver disease", "cirrhosis", "ibd", "crohn's"],
                "symptoms": ["severe abdominal pain", "persistent vomiting", "blood in stool"],
                "lab_indicators": ["alt", "ast", "bilirubin"],
                "urgency": "MODERATE"
            },

            # Pulmonology
            "pulmonology": {
                "specialization": "Pulmonology (Respiratory)",
                "conditions": ["asthma", "copd", "chronic bronchitis", "pneumonia"],
                "symptoms": ["difficulty breathing", "chronic cough", "wheezing"],
                "lab_indicators": [],
                "urgency": "MODERATE"
            },

            # Hematology
            "hematology": {
                "specialization": "Hematology (Blood)",
                "conditions": ["anemia", "blood disorder", "clotting disorder"],
                "symptoms": ["fatigue", "easy bruising", "excessive bleeding"],
                "lab_indicators": ["wbc", "rbc", "hemoglobin", "platelets"],
                "urgency": "MODERATE"
            },

            # Oncology
            "oncology": {
                "specialization": "Oncology (Cancer)",
                "conditions": ["cancer", "tumor"],
                "symptoms": ["unexplained weight loss", "persistent pain", "lumps"],
                "lab_indicators": [],
                "urgency": "HIGH"
            },

            # Rheumatology
            "rheumatology": {
                "specialization": "Rheumatology",
                "conditions": ["arthritis", "lupus", "autoimmune disease"],
                "symptoms": ["joint pain", "muscle pain", "chronic inflammation"],
                "lab_indicators": [],
                "urgency": "MODERATE"
            },

            # Infectious Disease
            "infectious_disease": {
                "specialization": "Infectious Disease",
                "conditions": ["hiv", "hepatitis", "tuberculosis", "sepsis"],
                "symptoms": ["persistent fever", "night sweats"],
                "lab_indicators": ["wbc"],
                "urgency": "HIGH"
            },
        }

    def recommend_specialists(
        self, symptoms: List[str], medical_history: List[str],
        lab_results: Dict[str, float], symptom_severity: float,
        lab_abnormality_score: float
    ) -> Dict[str, Any]:
        """
        Recommend appropriate specialists

        Args:
            symptoms: List of patient symptoms
            medical_history: List of medical conditions
            lab_results: Dictionary of lab results
            symptom_severity: Severity score from symptom analysis
            lab_abnormality_score: Abnormality score from lab analysis

        Returns:
            Dictionary with specialist recommendations
        """
        recommendations = []
        high_priority = []
        moderate_priority = []
        low_priority = []

        symptoms_lower = [s.lower().strip() for s in symptoms]
        history_lower = [h.lower().strip() for h in medical_history]
        abnormal_labs = [lab.lower() for lab in lab_results.keys()]

        # Check each specialist category
        for category, spec_info in self.specialist_map.items():
            match_score = 0
            matched_reasons = []

            # Check symptom matches
            symptom_matches = [s for s in spec_info["symptoms"]
                             if any(s in sym for sym in symptoms_lower)]
            if symptom_matches:
                match_score += len(symptom_matches) * 3
                matched_reasons.extend([f"Symptom: {s}" for s in symptom_matches])

            # Check condition matches
            condition_matches = [c for c in spec_info["conditions"]
                               if any(c in hist for hist in history_lower)]
            if condition_matches:
                match_score += len(condition_matches) * 5
                matched_reasons.extend([f"Condition: {c}" for c in condition_matches])

            # Check lab indicators
            lab_matches = [lab for lab in spec_info["lab_indicators"]
                         if lab in abnormal_labs]
            if lab_matches:
                match_score += len(lab_matches) * 2
                matched_reasons.extend([f"Abnormal lab: {lab}" for lab in lab_matches])

            # If we have matches, add recommendation
            if match_score > 0:
                recommendation = {
                    "specialist": spec_info["specialization"],
                    "match_score": match_score,
                    "urgency": spec_info["urgency"],
                    "reasons": matched_reasons
                }

                recommendations.append(recommendation)

                # Categorize by urgency
                if spec_info["urgency"] == "HIGH" or symptom_severity >= 8.0:
                    high_priority.append(recommendation)
                elif spec_info["urgency"] == "MODERATE":
                    moderate_priority.append(recommendation)
                else:
                    low_priority.append(recommendation)

        # Sort by match score
        recommendations.sort(key=lambda x: x["match_score"], reverse=True)
        high_priority.sort(key=lambda x: x["match_score"], reverse=True)
        moderate_priority.sort(key=lambda x: x["match_score"], reverse=True)

        # Generate recommendations text
        recommendation_text = self._generate_recommendations(
            recommendations, high_priority, symptom_severity, lab_abnormality_score
        )

        return {
            "recommendation_count": len(recommendations),
            "high_priority_count": len(high_priority),
            "moderate_priority_count": len(moderate_priority),
            "recommendations": recommendations[:5],  # Top 5
            "high_priority": high_priority,
            "moderate_priority": moderate_priority[:3],  # Top 3
            "recommendation_text": recommendation_text,
            "requires_urgent_referral": len(high_priority) > 0 and symptom_severity >= 8.0
        }

    def _generate_recommendations(
        self, all_recommendations: List[Dict], high_priority: List[Dict],
        symptom_severity: float, lab_abnormality_score: float
    ) -> List[str]:
        """Generate recommendation text"""
        recommendations = []

        if not all_recommendations:
            recommendations.append("No specific specialist referral indicated at this time")
            recommendations.append("Continue with primary care physician for routine monitoring")
            return recommendations

        # Urgent referrals
        if high_priority and symptom_severity >= 8.0:
            recommendations.append("URGENT specialist referrals recommended:")
            for spec in high_priority[:2]:  # Top 2 urgent
                recommendations.append(f"  - {spec['specialist']} (High Priority)")
                recommendations.append(f"    Reasons: {', '.join(spec['reasons'][:3])}")

        # General referrals
        elif high_priority:
            recommendations.append("Specialist consultation recommended:")
            for spec in high_priority[:2]:
                recommendations.append(f"  - {spec['specialist']}")

        # Moderate priority
        if len(all_recommendations) > len(high_priority):
            moderate = [r for r in all_recommendations if r not in high_priority][:2]
            if moderate:
                recommendations.append("Consider consultation with:")
                for spec in moderate:
                    recommendations.append(f"  - {spec['specialist']}")

        # Additional guidance
        if symptom_severity >= 8.0 or lab_abnormality_score >= 7.0:
            recommendations.append("Expedited referrals recommended due to severity of findings")

        return recommendations
