"""
Gemini AI Client - Pure Tool
Interfaces with Google Gemini AI for medical diagnosis assistance
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, Optional, List
import google.generativeai as genai
from config import get_config_value

logger = logging.getLogger("gemini_client")


class GeminiClient:
    """Pure Gemini AI client - reusable across workflows"""

    def __init__(self):
        api_key = get_config_value("GEMINI_API_KEY", "")
        model_name = get_config_value("GEMINI_MODEL", "gemini-2.0-flash")

        if not api_key:
            logger.warning("Gemini API key not configured")
            self.model = None
        else:
            try:
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel(model_name)
                logger.info(f"Gemini client initialized with model: {model_name}")
            except Exception as e:
                logger.error(f"Failed to initialize Gemini: {e}")
                self.model = None

    def analyze_diagnosis(
        self, symptoms: List[str], medical_history: List[str],
        lab_results: Dict[str, float], vital_signs: Dict[str, Any],
        patient_age: int, patient_gender: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate AI-powered diagnostic assistance

        Args:
            symptoms: List of patient symptoms
            medical_history: List of past medical conditions
            lab_results: Dictionary of lab test results
            vital_signs: Dictionary of vital signs
            patient_age: Patient age
            patient_gender: Patient gender
            context: Optional context from other analyses

        Returns:
            Dictionary with AI diagnosis assistance data
        """
        if not self.model:
            return self._default_result("Gemini API not available")

        try:
            # Build prompt with medical data
            prompt = self._build_diagnosis_prompt(
                symptoms, medical_history, lab_results, vital_signs,
                patient_age, patient_gender, context
            )

            # Generate analysis
            response = self.model.generate_content(prompt)

            # Parse response
            analysis_text = response.text if hasattr(response, 'text') else str(response)

            # Extract structured data from response
            analysis = self._parse_diagnosis_response(analysis_text)

            return {
                'overall_assessment_score': analysis.get('score', 0.75),
                'confidence': analysis.get('confidence', 0.8),
                'likely_diagnoses': analysis.get('diagnoses', []),
                'clinical_observations': analysis.get('observations', []),
                'recommended_actions': analysis.get('actions', []),
                'risk_factors': analysis.get('risk_factors', []),
                'urgency_assessment': analysis.get('urgency', 'MODERATE'),
                'raw_response': analysis_text[:1000]  # Limit size
            }

        except Exception as e:
            logger.error(f"Gemini diagnosis analysis error: {e}")
            return self._default_result(str(e))

    def _build_diagnosis_prompt(
        self, symptoms: List[str], medical_history: List[str],
        lab_results: Dict[str, float], vital_signs: Dict[str, Any],
        patient_age: int, patient_gender: str,
        context: Optional[Dict[str, Any]]
    ) -> str:
        """Build AI diagnosis prompt with medical data"""
        prompt = f"""You are an expert medical AI assistant helping healthcare providers with diagnostic assessment. Analyze the following patient data and provide structured clinical insights.

IMPORTANT DISCLAIMER: This is a diagnostic assistance tool for healthcare professionals only. All recommendations must be verified by licensed medical professionals.

Patient Demographics:
- Age: {patient_age} years
- Gender: {patient_gender}

Current Symptoms:
{self._format_list(symptoms) if symptoms else "- No symptoms reported"}

Medical History:
{self._format_list(medical_history) if medical_history else "- No significant medical history"}

Vital Signs:
{self._format_dict(vital_signs) if vital_signs else "- Not provided"}

Laboratory Results:
{self._format_dict(lab_results) if lab_results else "- Not provided"}
"""

        # Add context if available
        if context:
            prompt += "\n\nPrevious Analysis Results:\n"

            if 'symptom_severity' in context:
                prompt += f"- Symptom Severity Score: {context['symptom_severity']}/10\n"

            if 'lab_abnormality' in context:
                prompt += f"- Lab Abnormality Score: {context['lab_abnormality']}/10\n"

            if 'risk_score' in context:
                prompt += f"- Medical History Risk Score: {context['risk_score']}/10\n"

            if 'suspected_conditions' in context:
                prompt += f"- Suspected Conditions: {', '.join(context['suspected_conditions'])}\n"

        prompt += """
Please provide a structured clinical assessment with:

1. Assessment Score (0.0 to 1.0): Overall confidence in diagnostic clarity
2. Likely Diagnoses: List 2-5 possible diagnoses ranked by likelihood
3. Clinical Observations: Key findings from the patient data
4. Recommended Actions: Specific next steps for healthcare provider
5. Risk Factors: Any concerning patterns or risk factors
6. Urgency Assessment: CRITICAL, HIGH, MODERATE, or LOW

Format your response clearly with sections for each point.

Remember: This is clinical decision support only. All findings must be reviewed and validated by qualified healthcare professionals.
"""

        return prompt

    def _format_list(self, items: List[str]) -> str:
        """Format list for prompt"""
        return '\n'.join([f"- {item}" for item in items])

    def _format_dict(self, data: Dict[str, Any]) -> str:
        """Format dictionary for prompt"""
        return '\n'.join([f"- {key}: {value}" for key, value in data.items()])

    def _parse_diagnosis_response(self, response: str) -> Dict[str, Any]:
        """Parse AI response into structured data"""
        analysis = {
            'score': 0.75,
            'confidence': 0.8,
            'diagnoses': [],
            'observations': [],
            'actions': [],
            'risk_factors': [],
            'urgency': 'MODERATE'
        }

        # Extract score if mentioned
        if 'score' in response.lower() or 'assessment' in response.lower():
            try:
                import re
                score_match = re.search(r'(\d+\.?\d*)\s*/\s*(?:1\.0|10)', response)
                if score_match:
                    score = float(score_match.group(1))
                    if score > 1:
                        score = score / 10  # Convert to 0-1 scale
                    analysis['score'] = score
            except Exception:
                pass

        # Extract urgency
        if 'CRITICAL' in response.upper():
            analysis['urgency'] = 'CRITICAL'
        elif 'HIGH' in response and 'urgency' in response.lower():
            analysis['urgency'] = 'HIGH'
        elif 'LOW' in response and 'urgency' in response.lower():
            analysis['urgency'] = 'LOW'

        # Extract sections
        lines = response.split('\n')
        current_section = None

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Detect section headers
            line_lower = line.lower()
            if 'diagnos' in line_lower or 'differential' in line_lower:
                current_section = 'diagnoses'
            elif 'observation' in line_lower or 'finding' in line_lower:
                current_section = 'observations'
            elif 'action' in line_lower or 'recommend' in line_lower or 'next step' in line_lower:
                current_section = 'actions'
            elif 'risk' in line_lower or 'concern' in line_lower:
                current_section = 'risk_factors'
            elif line.startswith('-') or line.startswith('*') or line[0:2].replace('.', '').isdigit():
                if current_section and current_section in analysis:
                    cleaned_line = line.lstrip('-*0123456789. ').strip()
                    if cleaned_line and len(cleaned_line) > 3:
                        analysis[current_section].append(cleaned_line)

        return analysis

    def _default_result(self, reason: str) -> Dict[str, Any]:
        """Return default result when AI analysis fails"""
        return {
            'overall_assessment_score': 0.5,
            'confidence': 0.0,
            'likely_diagnoses': [],
            'clinical_observations': [f"AI analysis unavailable: {reason}"],
            'recommended_actions': ["Proceed with standard clinical evaluation"],
            'risk_factors': [],
            'urgency_assessment': 'MODERATE',
            'raw_response': f"Error: {reason}"
        }
