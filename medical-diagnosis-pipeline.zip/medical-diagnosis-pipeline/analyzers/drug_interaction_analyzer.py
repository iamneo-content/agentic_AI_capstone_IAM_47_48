"""
Drug Interaction Analyzer - Pure Tool
Analyzes potential drug interactions
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("drug_interaction_analyzer")


class DrugInteractionAnalyzer:
    """Pure drug interaction analysis tool - reusable across workflows"""

    def __init__(self):
        # Known drug interactions (simplified database)
        # Format: (drug1, drug2, severity, description)
        self.interactions = [
            # Critical interactions
            ("warfarin", "aspirin", "CRITICAL", "Increased bleeding risk"),
            ("warfarin", "nsaid", "CRITICAL", "Increased bleeding risk"),
            ("ssri", "maoi", "CRITICAL", "Serotonin syndrome risk"),
            ("statin", "gemfibrozil", "CRITICAL", "Severe muscle damage risk"),
            ("methotrexate", "nsaid", "CRITICAL", "Increased methotrexate toxicity"),

            # Major interactions
            ("ace inhibitor", "potassium", "MAJOR", "Hyperkalemia risk"),
            ("digoxin", "diuretic", "MAJOR", "Digoxin toxicity risk"),
            ("beta blocker", "calcium channel blocker", "MAJOR", "Bradycardia and hypotension risk"),
            ("lithium", "diuretic", "MAJOR", "Lithium toxicity risk"),
            ("insulin", "beta blocker", "MAJOR", "Masked hypoglycemia symptoms"),

            # Moderate interactions
            ("statin", "fibrate", "MODERATE", "Increased muscle pain risk"),
            ("ssri", "nsaid", "MODERATE", "Increased bleeding risk"),
            ("antibiotic", "oral contraceptive", "MODERATE", "Reduced contraceptive effectiveness"),
            ("thyroid hormone", "iron", "MODERATE", "Reduced thyroid hormone absorption"),
            ("metformin", "contrast dye", "MODERATE", "Lactic acidosis risk"),
        ]

        # Drug categories for matching
        self.drug_categories = {
            "nsaid": ["ibuprofen", "naproxen", "diclofenac", "celecoxib", "indomethacin"],
            "ssri": ["fluoxetine", "sertraline", "paroxetine", "citalopram", "escitalopram"],
            "maoi": ["phenelzine", "tranylcypromine", "selegiline"],
            "statin": ["atorvastatin", "simvastatin", "rosuvastatin", "pravastatin"],
            "ace inhibitor": ["lisinopril", "enalapril", "ramipril", "captopril"],
            "beta blocker": ["metoprolol", "atenolol", "propranolol", "carvedilol"],
            "diuretic": ["furosemide", "hydrochlorothiazide", "spironolactone"],
            "calcium channel blocker": ["amlodipine", "diltiazem", "verapamil"],
            "antibiotic": ["amoxicillin", "azithromycin", "ciprofloxacin", "doxycycline"],
        }

    def analyze_interactions(
        self, current_medications: List[str],
        proposed_medications: List[str] = None,
        allergies: List[str] = None
    ) -> Dict[str, Any]:
        """
        Analyze drug interactions

        Args:
            current_medications: List of current medications
            proposed_medications: List of proposed new medications
            allergies: List of drug allergies

        Returns:
            Dictionary with interaction analysis data
        """
        if proposed_medications is None:
            proposed_medications = []
        if allergies is None:
            allergies = []

        # All medications to check
        all_medications = current_medications + proposed_medications

        # Find interactions
        interactions_found = []
        critical_interactions = []
        major_interactions = []
        moderate_interactions = []

        for i, drug1 in enumerate(all_medications):
            for drug2 in all_medications[i+1:]:
                interaction = self._check_interaction(drug1, drug2)
                if interaction:
                    interactions_found.append(interaction)

                    if interaction["severity"] == "CRITICAL":
                        critical_interactions.append(interaction)
                    elif interaction["severity"] == "MAJOR":
                        major_interactions.append(interaction)
                    elif interaction["severity"] == "MODERATE":
                        moderate_interactions.append(interaction)

        # Check for allergy conflicts
        allergy_conflicts = self._check_allergies(all_medications, allergies)

        # Calculate interaction score
        interaction_score = self._calculate_interaction_score(
            critical_interactions, major_interactions, moderate_interactions
        )

        # Generate recommendations
        recommendations = self._generate_recommendations(
            critical_interactions, major_interactions, moderate_interactions,
            allergy_conflicts, interaction_score
        )

        return {
            "interaction_score": round(interaction_score, 2),
            "interaction_level": self._get_interaction_level(interaction_score),
            "total_medications": len(all_medications),
            "total_interactions": len(interactions_found),
            "critical_count": len(critical_interactions),
            "major_count": len(major_interactions),
            "moderate_count": len(moderate_interactions),
            "critical_interactions": critical_interactions,
            "major_interactions": major_interactions,
            "moderate_interactions": moderate_interactions,
            "allergy_conflicts": allergy_conflicts,
            "recommendations": recommendations,
            "requires_pharmacist_review": len(critical_interactions) > 0 or len(major_interactions) > 1
        }

    def _check_interaction(self, drug1: str, drug2: str) -> Dict[str, Any]:
        """Check if two drugs interact"""
        drug1_lower = drug1.lower().strip()
        drug2_lower = drug2.lower().strip()

        # Get drug categories
        drug1_categories = self._get_drug_categories(drug1_lower)
        drug2_categories = self._get_drug_categories(drug2_lower)

        # Check for interactions
        for int_drug1, int_drug2, severity, description in self.interactions:
            # Check direct match or category match
            if self._drugs_match(drug1_lower, drug1_categories, int_drug1) and \
               self._drugs_match(drug2_lower, drug2_categories, int_drug2):
                return {
                    "drug1": drug1,
                    "drug2": drug2,
                    "severity": severity,
                    "description": description,
                    "interaction_type": int_drug1 + " + " + int_drug2
                }
            # Check reverse order
            elif self._drugs_match(drug1_lower, drug1_categories, int_drug2) and \
                 self._drugs_match(drug2_lower, drug2_categories, int_drug1):
                return {
                    "drug1": drug1,
                    "drug2": drug2,
                    "severity": severity,
                    "description": description,
                    "interaction_type": int_drug2 + " + " + int_drug1
                }

        return None

    def _get_drug_categories(self, drug: str) -> List[str]:
        """Get categories for a drug"""
        categories = [drug]  # Include drug itself
        for category, drugs in self.drug_categories.items():
            if drug in drugs or any(d in drug for d in drugs):
                categories.append(category)
        return categories

    def _drugs_match(self, drug: str, drug_categories: List[str], target: str) -> bool:
        """Check if drug matches target (by name or category)"""
        return target in drug or target in drug_categories or drug == target

    def _check_allergies(self, medications: List[str], allergies: List[str]) -> List[Dict[str, Any]]:
        """Check for allergy conflicts"""
        conflicts = []

        for med in medications:
            med_lower = med.lower().strip()
            for allergy in allergies:
                allergy_lower = allergy.lower().strip()
                if allergy_lower in med_lower or med_lower in allergy_lower:
                    conflicts.append({
                        "medication": med,
                        "allergy": allergy,
                        "severity": "CRITICAL"
                    })

        return conflicts

    def _calculate_interaction_score(
        self, critical: List, major: List, moderate: List
    ) -> float:
        """Calculate overall interaction score (0-10)"""
        score = 0.0
        score += len(critical) * 4.0  # Critical = 4 points each
        score += len(major) * 2.0     # Major = 2 points each
        score += len(moderate) * 0.5  # Moderate = 0.5 points each
        return min(score, 10.0)

    def _get_interaction_level(self, score: float) -> str:
        """Convert interaction score to level"""
        if score >= 8.0:
            return "CRITICAL"
        elif score >= 5.0:
            return "HIGH"
        elif score >= 2.0:
            return "MODERATE"
        elif score > 0:
            return "LOW"
        else:
            return "NONE"

    def _generate_recommendations(
        self, critical: List, major: List, moderate: List,
        allergy_conflicts: List, score: float
    ) -> List[str]:
        """Generate recommendations"""
        recommendations = []

        # Allergy conflicts
        if allergy_conflicts:
            recommendations.append("CRITICAL: Allergy conflicts detected - DO NOT administer")
            for conflict in allergy_conflicts:
                recommendations.append(f"  - {conflict['medication']} conflicts with {conflict['allergy']} allergy")

        # Critical interactions
        if critical:
            recommendations.append("CRITICAL drug interactions detected - immediate pharmacist review required")
            for interaction in critical:
                recommendations.append(
                    f"  - {interaction['drug1']} + {interaction['drug2']}: {interaction['description']}"
                )

        # Major interactions
        if major:
            recommendations.append("Major drug interactions detected - healthcare provider review recommended")
            for interaction in major[:3]:  # Show first 3
                recommendations.append(
                    f"  - {interaction['drug1']} + {interaction['drug2']}: {interaction['description']}"
                )

        # Moderate interactions
        if moderate and not critical and not major:
            recommendations.append("Moderate drug interactions detected - monitor patient closely")

        # Overall assessment
        if score >= 5.0:
            recommendations.append("Consider alternative medications to reduce interaction risk")
        elif score == 0.0:
            recommendations.append("No known drug interactions detected")

        return recommendations
