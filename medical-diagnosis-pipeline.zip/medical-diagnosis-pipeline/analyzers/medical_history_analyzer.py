"""
Medical History Analyzer - Pure Tool
Analyzes patient medical history for risk factors
NO state management, NO orchestration logic
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("medical_history_analyzer")


class MedicalHistoryAnalyzer:
    """Pure medical history analysis tool - reusable across workflows"""

    def __init__(self):
        # Risk factors and their severity
        self.risk_factors = {
            # Cardiovascular
            "heart disease": 8,
            "hypertension": 7,
            "high blood pressure": 7,
            "stroke": 9,
            "heart attack": 9,

            # Metabolic
            "diabetes": 8,
            "obesity": 6,
            "high cholesterol": 6,

            # Respiratory
            "asthma": 6,
            "copd": 8,
            "chronic bronchitis": 7,

            # Cancer
            "cancer": 9,

            # Kidney/Liver
            "kidney disease": 8,
            "liver disease": 8,
            "cirrhosis": 9,

            # Other chronic conditions
            "autoimmune disease": 7,
            "immunodeficiency": 8,
            "chronic pain": 5,
        }

        # Drug allergies severity
        self.allergy_severity = {
            "penicillin": 8,
            "aspirin": 7,
            "nsaids": 7,
            "sulfa": 7,
            "latex": 6,
        }

    def analyze_history(
        self, medical_history: List[str], current_medications: List[str],
        allergies: List[str], family_history: List[str], age: int
    ) -> Dict[str, Any]:
        """
        Analyze patient medical history

        Args:
            medical_history: List of past diagnoses/conditions
            current_medications: List of current medications
            allergies: List of known allergies
            family_history: List of family medical history
            age: Patient age

        Returns:
            Dictionary with history analysis data
        """
        # Analyze past conditions
        conditions_analysis = self._analyze_conditions(medical_history)

        # Analyze allergies
        allergy_analysis = self._analyze_allergies(allergies)

        # Analyze medications
        medication_analysis = self._analyze_medications(current_medications)

        # Analyze family history
        family_risk = self._analyze_family_history(family_history)

        # Calculate overall risk score
        risk_score = self._calculate_risk_score(
            conditions_analysis, allergy_analysis, age, family_risk
        )

        # Generate recommendations
        recommendations = self._generate_recommendations(
            conditions_analysis, allergy_analysis, medication_analysis,
            family_risk, age, risk_score
        )

        return {
            "risk_score": round(risk_score, 2),
            "risk_level": self._get_risk_level(risk_score),
            "chronic_conditions": conditions_analysis["chronic_conditions"],
            "high_risk_conditions": conditions_analysis["high_risk_conditions"],
            "current_medication_count": len(current_medications),
            "current_medications": current_medications,
            "allergy_count": len(allergies),
            "allergies": allergies,
            "critical_allergies": allergy_analysis["critical_allergies"],
            "family_risk_factors": family_risk,
            "age_category": self._get_age_category(age),
            "recommendations": recommendations,
            "requires_specialist_review": risk_score >= 7.0
        }

    def _analyze_conditions(self, medical_history: List[str]) -> Dict[str, Any]:
        """Analyze past medical conditions"""
        chronic_conditions = []
        high_risk_conditions = []
        total_severity = 0.0

        for condition in medical_history:
            condition_lower = condition.lower().strip()
            severity = 5  # Default severity

            # Check for known risk factors
            for risk_factor, risk_severity in self.risk_factors.items():
                if risk_factor in condition_lower:
                    severity = risk_severity
                    break

            chronic_conditions.append({
                "condition": condition,
                "severity": severity
            })

            total_severity += severity

            if severity >= 8:
                high_risk_conditions.append({
                    "condition": condition,
                    "severity": severity
                })

        return {
            "chronic_conditions": chronic_conditions,
            "high_risk_conditions": high_risk_conditions,
            "total_severity": total_severity,
            "condition_count": len(medical_history)
        }

    def _analyze_allergies(self, allergies: List[str]) -> Dict[str, Any]:
        """Analyze patient allergies"""
        critical_allergies = []

        for allergy in allergies:
            allergy_lower = allergy.lower().strip()
            severity = 5  # Default severity

            # Check for known high-risk allergies
            for known_allergy, allergy_sev in self.allergy_severity.items():
                if known_allergy in allergy_lower:
                    severity = allergy_sev
                    break

            if severity >= 7:
                critical_allergies.append({
                    "allergy": allergy,
                    "severity": severity
                })

        return {
            "critical_allergies": critical_allergies,
            "total_allergies": len(allergies)
        }

    def _analyze_medications(self, medications: List[str]) -> Dict[str, Any]:
        """Analyze current medications"""
        polypharmacy = len(medications) >= 5

        return {
            "medication_count": len(medications),
            "polypharmacy": polypharmacy,
            "medications": medications
        }

    def _analyze_family_history(self, family_history: List[str]) -> List[Dict[str, Any]]:
        """Analyze family medical history"""
        risk_factors = []

        for item in family_history:
            item_lower = item.lower().strip()

            # Check for hereditary conditions
            if any(condition in item_lower for condition in [
                "heart disease", "cancer", "diabetes", "stroke", "hypertension"
            ]):
                risk_factors.append({
                    "condition": item,
                    "hereditary_risk": "HIGH"
                })

        return risk_factors

    def _calculate_risk_score(
        self, conditions_analysis: Dict, allergy_analysis: Dict,
        age: int, family_risk: List[Dict]
    ) -> float:
        """Calculate overall medical risk score (0-10)"""
        risk_score = 0.0

        # Condition severity contribution (max 5 points)
        if conditions_analysis["condition_count"] > 0:
            avg_severity = conditions_analysis["total_severity"] / conditions_analysis["condition_count"]
            risk_score += min(avg_severity / 2, 5.0)

        # Critical allergies (max 2 points)
        risk_score += min(len(allergy_analysis["critical_allergies"]) * 0.5, 2.0)

        # Age factor (max 2 points)
        if age >= 65:
            risk_score += 2.0
        elif age >= 50:
            risk_score += 1.0
        elif age <= 5:
            risk_score += 1.5

        # Family history (max 1 point)
        risk_score += min(len(family_risk) * 0.3, 1.0)

        return min(risk_score, 10.0)

    def _get_risk_level(self, score: float) -> str:
        """Convert risk score to level"""
        if score >= 8.0:
            return "CRITICAL"
        elif score >= 6.0:
            return "HIGH"
        elif score >= 4.0:
            return "MODERATE"
        elif score >= 2.0:
            return "LOW"
        else:
            return "MINIMAL"

    def _get_age_category(self, age: int) -> str:
        """Get age category"""
        if age < 2:
            return "INFANT"
        elif age < 12:
            return "CHILD"
        elif age < 18:
            return "ADOLESCENT"
        elif age < 65:
            return "ADULT"
        else:
            return "SENIOR"

    def _generate_recommendations(
        self, conditions_analysis: Dict, allergy_analysis: Dict,
        medication_analysis: Dict, family_risk: List, age: int, risk_score: float
    ) -> List[str]:
        """Generate recommendations based on history"""
        recommendations = []

        # High-risk conditions
        if conditions_analysis["high_risk_conditions"]:
            recommendations.append("High-risk chronic conditions identified - specialist monitoring recommended")

        # Critical allergies
        if allergy_analysis["critical_allergies"]:
            recommendations.append("ALERT: Critical drug allergies on record - verify before prescribing")
            for allergy in allergy_analysis["critical_allergies"]:
                recommendations.append(f"  - Avoid: {allergy['allergy']}")

        # Polypharmacy
        if medication_analysis["polypharmacy"]:
            recommendations.append("Multiple medications in use - review for drug interactions")

        # Age-specific
        if age >= 65:
            recommendations.append("Senior patient - consider age-related dosing adjustments")
        elif age <= 5:
            recommendations.append("Pediatric patient - ensure pediatric-appropriate treatments")

        # Family history
        if family_risk:
            recommendations.append("Hereditary risk factors identified - consider preventive screening")

        # Overall risk
        if risk_score >= 6.0:
            recommendations.append("High-risk patient profile - multidisciplinary care recommended")

        if not recommendations:
            recommendations.append("No significant risk factors identified in medical history")

        return recommendations
