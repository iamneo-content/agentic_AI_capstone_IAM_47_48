"""
Symptom Analysis Agent

Agent responsible for coordinating symptom analysis.
Uses SymptomAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.symptom_analyzer import SymptomAnalyzer


class SymptomAgent(BaseAgent):
    """Agent for symptom analysis"""

    def __init__(self):
        """Initialize symptom agent with analyzer"""
        super().__init__("symptom")
        self.analyzer = SymptomAnalyzer()
        self.log("Symptom agent initialized")

    def analyze(self, symptoms: List[str], duration_days: int = 1) -> Dict[str, Any]:
        """
        Perform symptom analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            symptoms: List of patient symptoms
            duration_days: Number of days symptoms have persisted

        Returns:
            Dictionary with symptom analysis results
        """
        self.log(f"Analyzing {len(symptoms)} symptoms (duration: {duration_days} days)")

        if not symptoms:
            self.log("No symptoms to analyze", "warning")
            return {
                "severity_score": 0.0,
                "severity_level": "NONE",
                "symptom_details": [],
                "suspected_conditions": [],
                "recommendations": ["No symptoms reported"],
                "requires_immediate_attention": False
            }

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_symptoms(symptoms, duration_days)

        severity = analysis.get("severity_score", 0.0)
        level = analysis.get("severity_level", "UNKNOWN")
        conditions_count = len(analysis.get("suspected_conditions", []))

        self.log(f"Symptom analysis complete: Severity {severity}/10 ({level})")
        self.log(f"Suspected conditions: {conditions_count}")

        if analysis.get("requires_immediate_attention"):
            self.log("ALERT: Immediate attention required!", "warning")

        return analysis
