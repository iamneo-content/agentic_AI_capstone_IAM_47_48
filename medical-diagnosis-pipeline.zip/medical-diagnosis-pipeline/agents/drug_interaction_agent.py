"""
Drug Interaction Analysis Agent

Agent responsible for coordinating drug interaction analysis.
Uses DrugInteractionAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.drug_interaction_analyzer import DrugInteractionAnalyzer


class DrugInteractionAgent(BaseAgent):
    """Agent for drug interaction analysis"""

    def __init__(self):
        """Initialize drug interaction agent with analyzer"""
        super().__init__("drug_interaction")
        self.analyzer = DrugInteractionAnalyzer()
        self.log("Drug interaction agent initialized")

    def analyze(
        self, current_medications: List[str],
        proposed_medications: List[str] = None,
        allergies: List[str] = None
    ) -> Dict[str, Any]:
        """
        Perform drug interaction analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            current_medications: List of current medications
            proposed_medications: List of proposed new medications
            allergies: List of drug allergies

        Returns:
            Dictionary with drug interaction analysis results
        """
        if proposed_medications is None:
            proposed_medications = []
        if allergies is None:
            allergies = []

        total_meds = len(current_medications) + len(proposed_medications)
        self.log(f"Analyzing drug interactions for {total_meds} medications")
        self.log(f"Current: {len(current_medications)}, Proposed: {len(proposed_medications)}")

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_interactions(
            current_medications, proposed_medications, allergies
        )

        score = analysis.get("interaction_score", 0.0)
        level = analysis.get("interaction_level", "UNKNOWN")
        critical_count = analysis.get("critical_count", 0)
        allergy_conflicts = len(analysis.get("allergy_conflicts", []))

        self.log(f"Drug interaction analysis complete: Score {score}/10 ({level})")
        self.log(f"Interactions found: {analysis.get('total_interactions', 0)}")

        if critical_count > 0:
            self.log(f"CRITICAL: {critical_count} critical drug interactions detected!", "error")

        if allergy_conflicts > 0:
            self.log(f"CRITICAL: {allergy_conflicts} allergy conflicts detected!", "error")

        return analysis
