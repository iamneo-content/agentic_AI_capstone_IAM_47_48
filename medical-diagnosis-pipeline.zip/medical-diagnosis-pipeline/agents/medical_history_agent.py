"""
Medical History Analysis Agent

Agent responsible for coordinating medical history analysis.
Uses MedicalHistoryAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.medical_history_analyzer import MedicalHistoryAnalyzer


class MedicalHistoryAgent(BaseAgent):
    """Agent for medical history analysis"""

    def __init__(self):
        """Initialize medical history agent with analyzer"""
        super().__init__("medical_history")
        self.analyzer = MedicalHistoryAnalyzer()
        self.log("Medical history agent initialized")

    def analyze(
        self, medical_history: List[str], current_medications: List[str],
        allergies: List[str], family_history: List[str], age: int
    ) -> Dict[str, Any]:
        """
        Perform medical history analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            medical_history: List of past diagnoses/conditions
            current_medications: List of current medications
            allergies: List of known allergies
            family_history: List of family medical history
            age: Patient age

        Returns:
            Dictionary with medical history analysis results
        """
        self.log(f"Analyzing medical history for {age}-year-old patient")
        self.log(f"Conditions: {len(medical_history)}, Medications: {len(current_medications)}")
        self.log(f"Allergies: {len(allergies)}, Family history items: {len(family_history)}")

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_history(
            medical_history, current_medications, allergies, family_history, age
        )

        risk_score = analysis.get("risk_score", 0.0)
        risk_level = analysis.get("risk_level", "UNKNOWN")
        high_risk_count = len(analysis.get("high_risk_conditions", []))

        self.log(f"Medical history analysis complete: Risk score {risk_score}/10 ({risk_level})")

        if high_risk_count > 0:
            self.log(f"ALERT: {high_risk_count} high-risk conditions identified", "warning")

        if len(analysis.get("critical_allergies", [])) > 0:
            self.log("ALERT: Critical allergies on record", "warning")

        return analysis
