"""
Specialist Recommendation Agent

Agent responsible for coordinating specialist recommendations.
Uses SpecialistRecommender as a tool for actual analysis.
Also uses GeminiClient for AI-powered diagnostic insights.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.specialist_recommender import SpecialistRecommender
from analyzers.gemini_client import GeminiClient


class SpecialistAgent(BaseAgent):
    """Agent for specialist recommendations and AI diagnostic insights"""

    def __init__(self):
        """Initialize specialist agent with recommender and AI client"""
        super().__init__("specialist")
        self.recommender = SpecialistRecommender()
        self.ai_client = GeminiClient()
        self.log("Specialist agent initialized")

    def analyze(
        self, symptoms: List[str], medical_history: List[str],
        lab_results: Dict[str, float], symptom_severity: float,
        lab_abnormality_score: float, patient_age: int,
        patient_gender: str, vital_signs: Dict[str, Any],
        context: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Perform specialist recommendation and AI diagnostic analysis

        Coordinates both specialist matching and AI-powered insights

        Args:
            symptoms: List of patient symptoms
            medical_history: List of medical conditions
            lab_results: Dictionary of lab results
            symptom_severity: Severity score from symptom analysis
            lab_abnormality_score: Abnormality score from lab analysis
            patient_age: Patient age
            patient_gender: Patient gender
            vital_signs: Dictionary of vital signs
            context: Optional context from other analyses

        Returns:
            Dictionary with specialist recommendations and AI insights
        """
        self.log("Performing specialist recommendations and AI diagnostic analysis")

        # Get specialist recommendations
        specialist_analysis = self.recommender.recommend_specialists(
            symptoms, medical_history, lab_results,
            symptom_severity, lab_abnormality_score
        )

        self.log(f"Specialist recommendations: {specialist_analysis.get('recommendation_count', 0)} matches")
        self.log(f"High priority referrals: {specialist_analysis.get('high_priority_count', 0)}")

        # Get AI diagnostic insights
        ai_analysis = self.ai_client.analyze_diagnosis(
            symptoms, medical_history, lab_results, vital_signs,
            patient_age, patient_gender, context
        )

        ai_score = ai_analysis.get("overall_assessment_score", 0.0)
        ai_confidence = ai_analysis.get("confidence", 0.0)
        urgency = ai_analysis.get("urgency_assessment", "MODERATE")

        self.log(f"AI diagnostic analysis complete: Score {ai_score:.2f}, Confidence {ai_confidence:.2f}")
        self.log(f"AI urgency assessment: {urgency}")

        # Combine both analyses
        combined_analysis = {
            "specialist_recommendations": specialist_analysis.get("recommendations", []),
            "high_priority_specialists": specialist_analysis.get("high_priority", []),
            "moderate_priority_specialists": specialist_analysis.get("moderate_priority", []),
            "recommendation_text": specialist_analysis.get("recommendation_text", []),
            "requires_urgent_referral": specialist_analysis.get("requires_urgent_referral", False),

            "ai_assessment_score": ai_score,
            "ai_confidence": ai_confidence,
            "ai_likely_diagnoses": ai_analysis.get("likely_diagnoses", []),
            "ai_clinical_observations": ai_analysis.get("clinical_observations", []),
            "ai_recommended_actions": ai_analysis.get("recommended_actions", []),
            "ai_risk_factors": ai_analysis.get("risk_factors", []),
            "ai_urgency_assessment": urgency,
            "ai_raw_response": ai_analysis.get("raw_response", "")
        }

        self.log("Specialist and AI analysis complete")
        return combined_analysis
