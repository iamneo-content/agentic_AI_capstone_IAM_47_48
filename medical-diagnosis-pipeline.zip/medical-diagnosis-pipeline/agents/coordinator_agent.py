"""
Coordinator Agent

Agent responsible for aggregating and coordinating results from all analysis agents.
Calculates summary metrics and prepares data for decision making.
"""

from typing import Dict, Any
from .base_agent import BaseAgent


class CoordinatorAgent(BaseAgent):
    """Agent for coordinating and aggregating analysis results"""

    def __init__(self):
        """Initialize coordinator agent"""
        super().__init__("coordinator")
        self.log("Coordinator agent initialized")

    def analyze(
        self, symptom_analysis: Dict[str, Any],
        lab_analysis: Dict[str, Any],
        medical_history_analysis: Dict[str, Any],
        drug_interaction_analysis: Dict[str, Any],
        specialist_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Aggregate and coordinate results from all analysis agents

        Args:
            symptom_analysis: Results from symptom agent
            lab_analysis: Results from lab agent
            medical_history_analysis: Results from medical history agent
            drug_interaction_analysis: Results from drug interaction agent
            specialist_analysis: Results from specialist agent

        Returns:
            Dictionary with coordination summary and aggregated metrics
        """
        self.log("Coordinating results from all analysis agents")

        # Extract key metrics from each analysis
        symptom_severity = symptom_analysis.get("severity_score", 0.0)
        lab_abnormality = lab_analysis.get("abnormality_score", 0.0)
        history_risk = medical_history_analysis.get("risk_score", 0.0)
        drug_interaction_score = drug_interaction_analysis.get("interaction_score", 0.0)
        ai_assessment = specialist_analysis.get("ai_assessment_score", 0.0)

        self.log(f"Results collected:")
        self.log(f"  Symptom Severity: {symptom_severity}/10")
        self.log(f"  Lab Abnormality: {lab_abnormality}/10")
        self.log(f"  History Risk: {history_risk}/10")
        self.log(f"  Drug Interactions: {drug_interaction_score}/10")
        self.log(f"  AI Assessment: {ai_assessment:.2f}/1.0")

        # Calculate overall clinical severity score (0-10 scale)
        # Weighted average: symptoms (30%), labs (25%), history (20%), drugs (15%), AI (10%)
        overall_severity = (
            symptom_severity * 0.30 +
            lab_abnormality * 0.25 +
            history_risk * 0.20 +
            drug_interaction_score * 0.15 +
            (ai_assessment * 10) * 0.10  # Convert AI score to 0-10 scale
        )

        # Determine severity level
        if overall_severity >= 8.0:
            severity_level = "CRITICAL"
        elif overall_severity >= 6.0:
            severity_level = "HIGH"
        elif overall_severity >= 4.0:
            severity_level = "MODERATE"
        elif overall_severity >= 2.0:
            severity_level = "LOW"
        else:
            severity_level = "MINIMAL"

        # Collect critical flags
        critical_flags = []
        if symptom_analysis.get("requires_immediate_attention"):
            critical_flags.append("Critical symptoms detected")
        if lab_analysis.get("requires_immediate_attention"):
            critical_flags.append("Critical lab values detected")
        if drug_interaction_analysis.get("requires_pharmacist_review"):
            critical_flags.append("Critical drug interactions")
        if len(drug_interaction_analysis.get("allergy_conflicts", [])) > 0:
            critical_flags.append("Drug allergy conflicts")
        if specialist_analysis.get("requires_urgent_referral"):
            critical_flags.append("Urgent specialist referral needed")

        # Collect suspected conditions from various sources
        suspected_conditions = []
        for condition in symptom_analysis.get("suspected_conditions", []):
            suspected_conditions.append({
                "condition": condition.get("condition", ""),
                "source": "Symptom Analysis",
                "confidence": condition.get("match_percentage", 0) / 100
            })

        for diagnosis in specialist_analysis.get("ai_likely_diagnoses", [])[:3]:
            suspected_conditions.append({
                "condition": diagnosis,
                "source": "AI Analysis",
                "confidence": specialist_analysis.get("ai_confidence", 0.0)
            })

        # Aggregate recommendations
        all_recommendations = []
        all_recommendations.extend(symptom_analysis.get("recommendations", []))
        all_recommendations.extend(lab_analysis.get("recommendations", []))
        all_recommendations.extend(medical_history_analysis.get("recommendations", []))
        all_recommendations.extend(drug_interaction_analysis.get("recommendations", []))
        all_recommendations.extend(specialist_analysis.get("recommendation_text", []))
        all_recommendations.extend(specialist_analysis.get("ai_recommended_actions", []))

        # Create coordination summary
        summary = {
            "overall_severity_score": round(overall_severity, 2),
            "severity_level": severity_level,
            "symptom_severity": symptom_severity,
            "lab_abnormality": lab_abnormality,
            "history_risk": history_risk,
            "drug_interaction_score": drug_interaction_score,
            "ai_assessment_score": ai_assessment,
            "ai_confidence": specialist_analysis.get("ai_confidence", 0.0),
            "critical_flags": critical_flags,
            "suspected_conditions": suspected_conditions,
            "high_priority_specialists": specialist_analysis.get("high_priority_specialists", []),
            "all_recommendations": all_recommendations,
            "requires_immediate_attention": len(critical_flags) > 0,
            "analyses_completed": [
                "symptom", "lab", "medical_history", "drug_interaction", "specialist_ai"
            ]
        }

        self.log(f"Coordination complete - Overall severity: {overall_severity:.2f}/10 ({severity_level})")
        self.log(f"Critical flags: {len(critical_flags)}")
        self.log(f"Suspected conditions: {len(suspected_conditions)}")

        return {
            "coordination_summary": summary
        }
