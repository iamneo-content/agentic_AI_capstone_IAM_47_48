"""
Lab Analysis Agent

Agent responsible for coordinating laboratory test analysis.
Uses LabAnalyzer as a tool for actual analysis.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.lab_analyzer import LabAnalyzer


class LabAgent(BaseAgent):
    """Agent for laboratory test analysis"""

    def __init__(self):
        """Initialize lab agent with analyzer"""
        super().__init__("lab")
        self.analyzer = LabAnalyzer()
        self.log("Lab agent initialized")

    def analyze(self, lab_results: Dict[str, float]) -> Dict[str, Any]:
        """
        Perform lab results analysis

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            lab_results: Dictionary of lab test names to values

        Returns:
            Dictionary with lab analysis results
        """
        self.log(f"Analyzing {len(lab_results)} lab test results")

        if not lab_results:
            self.log("No lab results to analyze", "warning")
            return {
                "abnormality_score": 0.0,
                "abnormality_level": "NONE",
                "abnormal_results": [],
                "normal_results": [],
                "critical_findings": [],
                "recommendations": ["No lab results available"]
            }

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_labs(lab_results)

        score = analysis.get("abnormality_score", 0.0)
        level = analysis.get("abnormality_level", "UNKNOWN")
        abnormal_count = analysis.get("abnormal_count", 0)
        critical_count = len(analysis.get("critical_findings", []))

        self.log(f"Lab analysis complete: Abnormality score {score}/10 ({level})")
        self.log(f"Abnormal results: {abnormal_count}/{len(lab_results)}")

        if critical_count > 0:
            self.log(f"ALERT: {critical_count} critical findings detected!", "warning")

        return analysis
