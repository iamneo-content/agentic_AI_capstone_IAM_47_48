"""
Patient Intake Agent

Agent responsible for coordinating patient data intake and validation.
Fetches patient details, medical history, and current symptoms.
"""

from typing import Dict, Any
from .base_agent import BaseAgent


class PatientIntakeAgent(BaseAgent):
    """Agent for patient intake and data collection"""

    def __init__(self):
        """Initialize patient intake agent"""
        super().__init__("patient_intake")
        self.log("Patient intake agent initialized")

    def analyze(self, patient_id: str, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process patient intake data

        Pure reasoning logic only - validates and structures patient data

        Args:
            patient_id: Unique patient identifier
            patient_data: Dictionary containing patient information

        Returns:
            Dictionary with structured patient data
        """
        self.log(f"Processing intake for patient: {patient_id}")

        # Extract patient details
        patient_details = {
            "patient_id": patient_id,
            "patient_name": patient_data.get("name", "Unknown"),
            "patient_age": patient_data.get("age", 0),
            "patient_gender": patient_data.get("gender", "Unknown")
        }

        # Extract medical history
        medical_history = patient_data.get("medical_history", [])
        self.log(f"Medical history: {len(medical_history)} conditions")

        # Extract current symptoms
        current_symptoms = patient_data.get("symptoms", [])
        self.log(f"Current symptoms: {len(current_symptoms)} reported")

        # Extract vital signs
        vital_signs = patient_data.get("vital_signs", {})
        self.log(f"Vital signs: {len(vital_signs)} measurements")

        # Extract lab results
        lab_results = patient_data.get("lab_results", {})
        self.log(f"Lab results: {len(lab_results)} tests")

        # Extract current medications
        current_medications = patient_data.get("current_medications", [])
        self.log(f"Current medications: {len(current_medications)}")

        # Extract allergies
        allergies = patient_data.get("allergies", [])
        self.log(f"Known allergies: {len(allergies)}")

        # Extract family history
        family_history = patient_data.get("family_history", [])

        self.log("Patient intake processing complete")

        return {
            "patient_details": patient_details,
            "medical_history": medical_history,
            "current_symptoms": current_symptoms,
            "vital_signs": vital_signs,
            "lab_results": lab_results,
            "current_medications": current_medications,
            "allergies": allergies,
            "family_history": family_history,
            "symptom_duration_days": patient_data.get("symptom_duration_days", 1)
        }
