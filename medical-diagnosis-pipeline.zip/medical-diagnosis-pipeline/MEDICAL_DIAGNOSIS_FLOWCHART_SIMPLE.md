```mermaid
graph TD
    %% Entry Point
    START([🏥 Patient Data Received]) --> INTAKE[🔍 Patient Intake Node]

    %% Stage 1: Patient Intake
    INTAKE --> |"Validate & Process<br/>Patient Data"| PARALLEL{"🎯 Launch Parallel<br/>Analysis"}

    %% Stage 2: Parallel Agent Execution
    PARALLEL --> |"Run Simultaneously"| SYMPTOM[🤒 Symptom Agent]
    PARALLEL --> |"Run Simultaneously"| LAB[🧪 Lab Agent]
    PARALLEL --> |"Run Simultaneously"| HISTORY[📋 History Agent]
    PARALLEL --> |"Run Simultaneously"| DRUG[💊 Drug Agent]
    PARALLEL --> |"Run Simultaneously"| SPECIALIST[👨‍⚕️ Specialist & AI Agent]

    %% Agent Results
    SYMPTOM --> |"Severity: 8.67/10<br/>Level: HIGH"| WAIT[⏳ Wait for All Agents]
    LAB --> |"Abnormality: 10.0/10<br/>Level: CRITICAL"| WAIT
    HISTORY --> |"Risk: 5.85/10<br/>Level: MODERATE"| WAIT
    DRUG --> |"Interaction: 0.0/10<br/>Level: NONE"| WAIT
    SPECIALIST --> |"5 Specialists<br/>AI Analysis"| WAIT

    %% Stage 3: Coordination
    WAIT --> COORDINATOR[🎯 Coordinator Agent]
    COORDINATOR --> |"Overall Severity: 8.50/10<br/>Level: HIGH<br/>Critical Flags: 2"| DECISION

    %% Stage 4: Decision Logic
    DECISION{"⚖️ Clinical<br/>Decision Logic"}

    DECISION --> |"Critical Flags Present"| IMMEDIATE[🔴 IMMEDIATE<br/>INTERVENTION]
    DECISION --> |"Overall Severity ≥ 8.0"| URGENT[🟠 URGENT SPECIALIST<br/>REFERRAL]
    DECISION --> |"Symptom ≥ 7.0 OR Lab ≥ 2.0"| SPECIALIST_CONSULT[🟡 SPECIALIST<br/>CONSULTATION]
    DECISION --> |"Drug Interaction ≥ 5.0"| PHARMACIST[🟢 PHARMACIST<br/>REVIEW]
    DECISION --> |"Overall Severity ≥ 4.0"| FOLLOWUP[🟢 FOLLOW-UP<br/>CARE]
    DECISION --> |"Overall Severity < 4.0"| ROUTINE[🟢 ROUTINE<br/>CARE]

    %% Stage 5: Report & Notification
    IMMEDIATE --> REPORT[📋 Generate Report]
    URGENT --> REPORT
    SPECIALIST_CONSULT --> REPORT
    PHARMACIST --> REPORT
    FOLLOWUP --> REPORT
    ROUTINE --> REPORT

    REPORT --> NOTIFY[📧 Send Email Notification]
    NOTIFY --> |"Success"| END_SUCCESS([✅ Diagnosis Complete<br/>Provider Notified])
    NOTIFY --> |"Failed"| END_FAIL([⚠️ Diagnosis Complete<br/>Email Failed])

    %% Styling
    classDef agentNode fill:#e3f2fd,stroke:#1565c0,stroke-width:2px,color:#000000
    classDef criticalNode fill:#ffebee,stroke:#c62828,stroke-width:3px,color:#000000
    classDef urgentNode fill:#ffe0b2,stroke:#e65100,stroke-width:3px,color:#000000
    classDef moderateNode fill:#fff9c4,stroke:#f57f17,stroke-width:3px,color:#000000
    classDef routineNode fill:#e8f5e9,stroke:#2e7d32,stroke-width:3px,color:#000000
    classDef coordinatorNode fill:#e0f2f1,stroke:#00695c,stroke-width:3px,color:#000000
    classDef decisionNode fill:#fff3e0,stroke:#e65100,stroke-width:2px,color:#000000
    classDef waitNode fill:#f5f5f5,stroke:#616161,stroke-width:2px,color:#000000
    classDef endNode fill:#c8e6c9,stroke:#1b5e20,stroke-width:3px,color:#000000

    class SYMPTOM,LAB,HISTORY,DRUG,SPECIALIST agentNode
    class IMMEDIATE criticalNode
    class URGENT urgentNode
    class SPECIALIST_CONSULT,PHARMACIST moderateNode
    class FOLLOWUP,ROUTINE routineNode
    class COORDINATOR coordinatorNode
    class DECISION decisionNode
    class WAIT,PARALLEL waitNode
    class START,END_SUCCESS,END_FAIL endNode
```

---

## Flow Summary

**Stage 1: Patient Intake**
- Validates and processes all patient data

**Stage 2: Parallel Analysis (5 Agents)**
- All agents run simultaneously using ThreadPoolExecutor
- Each agent analyzes specific aspect of patient data

**Stage 3: Coordination**
- Aggregates all analysis results
- Calculates overall severity score

**Stage 4: Clinical Decision**
- Applies clinical thresholds
- Determines appropriate care level

**Stage 5: Report & Notification**
- Generates comprehensive diagnosis report
- Sends email notification to healthcare provider

## Decision Thresholds

| Decision | Criteria |
|----------|----------|
| Immediate Intervention | Critical flags present |
| Urgent Specialist | Overall severity ≥ 8.0 |
| Specialist Consultation | Symptom ≥ 7.0 OR Lab ≥ 2.0 |
| Pharmacist Review | Drug interaction ≥ 5.0 |
| Follow-Up Care | Overall severity ≥ 4.0 |
| Routine Care | Overall severity < 4.0 |

## Parallel Execution

- **Max Workers:** 5
- **Execution Time:** 1-2 seconds (vs 5-10 seconds sequential)
- **State Management:** Each agent receives deep copy of state
- **Result Merging:** Lists extended, dicts updated, scalars overwritten
```
