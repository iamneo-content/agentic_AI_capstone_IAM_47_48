"""
Diagnosis Workflow Builder

Defines the staged medical diagnosis pipeline with parallel and sequential nodes.
"""

from graph import DiagnosisGraph
from nodes import (
    patient_intake_node,
    symptom_node,
    lab_node,
    medical_history_node,
    drug_interaction_node,
    specialist_node,
    coordinator_node,
    decision_node,
    report_node
)


def build_diagnosis_workflow(max_workers: int = 5) -> DiagnosisGraph:
    """
    Build the medical diagnosis workflow with parallel execution

    Stages:
    1. Patient intake (collect and validate patient data)
    2. Parallel analyses (symptom, lab, history, drug interactions, specialist/AI)
    3. Coordinator (aggregate results)
    4. Decision (make diagnostic decision)
    5. Report (generate final report and send notification)

    Args:
        max_workers: Maximum number of parallel workers (default: 5)

    Returns:
        Compiled DiagnosisGraph ready for execution
    """
    stages = [
        # Stage 1: Patient intake
        [patient_intake_node],

        # Stage 2: Parallel analyses (all 5 run simultaneously)
        [symptom_node, lab_node, medical_history_node, drug_interaction_node, specialist_node],

        # Stage 3: Coordinator
        [coordinator_node],

        # Stage 4: Decision
        [decision_node],

        # Stage 5: Report
        [report_node]
    ]

    return DiagnosisGraph(stages=stages, max_workers=max_workers, raise_on_error=False)
