"""
Workflows - Workflow Definitions
All workflow definitions for medical diagnosis
"""

from .diagnosis_workflow import build_diagnosis_workflow

__all__ = ["build_diagnosis_workflow"]
