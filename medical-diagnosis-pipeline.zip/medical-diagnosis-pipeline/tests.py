#!/usr/bin/env python3
"""
Comprehensive Test Suite for Medical Diagnosis Pipeline

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import DiagnosisState
    from graph import DiagnosisGraph
    from workflows.diagnosis_workflow import build_diagnosis_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.patient_intake_agent import PatientIntakeAgent
    from agents.symptom_agent import SymptomAgent
    from agents.medical_history_agent import MedicalHistoryAgent
    from agents.lab_agent import LabAgent
    from agents.drug_interaction_agent import DrugInteractionAgent
    from agents.specialist_agent import SpecialistAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.symptom_analyzer import SymptomAnalyzer
    from analyzers.medical_history_analyzer import MedicalHistoryAnalyzer
    from analyzers.lab_analyzer import LabAnalyzer
    from analyzers.drug_interaction_analyzer import DrugInteractionAnalyzer
    from analyzers.specialist_recommender import SpecialistRecommender

    # Import nodes
    from nodes.patient_intake_node import patient_intake_node
    from nodes.symptom_node import symptom_node
    from nodes.medical_history_node import medical_history_node
    from nodes.lab_node import lab_node
    from nodes.drug_interaction_node import drug_interaction_node
    from nodes.specialist_node import specialist_node
    from nodes.decision_node import decision_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestMedicalDiagnosisPipelineArchitecture(unittest.TestCase):
    """Test suite for Medical Diagnosis Pipeline Architecture"""

    SAMPLE_PATIENT = {
        "patient_id": "TEST-123",
        "name": "Jane Doe",
        "age": 45,
        "gender": "female",
        "symptoms": ["fever", "cough", "fatigue"],
        "medical_history": ["hypertension", "diabetes"],
        "current_medications": ["metformin", "lisinopril"],
        "lab_results": {
            "blood_pressure": "140/90",
            "blood_sugar": "180 mg/dL",
            "white_blood_cell_count": "12000"
        }
    }

    def setUp(self):
        """Setup test environment"""
        self.sample_patient = self.SAMPLE_PATIENT.copy()

    def tearDown(self):
        """Clean up test environment"""
        pass

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test DiagnosisState dataclass creation"""
        logger.info("Testing DiagnosisState creation...")

        state = DiagnosisState(
            patient_id="TEST-123",
            patient_name="Jane Doe",
            patient_age=45,
            patient_gender="female",
            current_symptoms=self.sample_patient["symptoms"],
            medical_history=self.sample_patient["medical_history"]
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.patient_id, "TEST-123", "Patient ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test DiagnosisState clone method"""
        logger.info("Testing DiagnosisState clone...")

        state = DiagnosisState(patient_id="TEST-123", patient_name="Jane Doe")
        state.symptom_analysis = {"test": "data"}

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.patient_id, state.patient_id, "Patient ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_symptom_analyzer(self):
        """Test SymptomAnalyzer (pure tool)"""
        logger.info("Testing SymptomAnalyzer...")

        analyzer = SymptomAnalyzer()
        results = analyzer.analyze_symptoms(self.sample_patient)

        self.assertIsNotNone(results, "Symptom analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ SymptomAnalyzer tests passed")

    def test_medical_history_analyzer(self):
        """Test MedicalHistoryAnalyzer (pure tool)"""
        logger.info("Testing MedicalHistoryAnalyzer...")

        analyzer = MedicalHistoryAnalyzer()
        results = analyzer.analyze_history(
            medical_history=self.sample_patient["medical_history"],
            current_medications=self.sample_patient["current_medications"],
            allergies=["penicillin"],
            family_history=["diabetes", "heart disease"],
            age=self.sample_patient["age"]
        )

        self.assertIsNotNone(results, "Medical history analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ MedicalHistoryAnalyzer tests passed")

    def test_lab_analyzer(self):
        """Test LabAnalyzer (pure tool)"""
        logger.info("Testing LabAnalyzer...")

        analyzer = LabAnalyzer()
        # Extract numeric lab results from the sample data
        lab_results = {
            "glucose": 145,
            "cholesterol": 220,
            "hemoglobin": 13.2
        }
        results = analyzer.analyze_labs(lab_results)

        self.assertIsNotNone(results, "Lab analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ LabAnalyzer tests passed")

    def test_drug_interaction_analyzer(self):
        """Test DrugInteractionAnalyzer (pure tool)"""
        logger.info("Testing DrugInteractionAnalyzer...")

        analyzer = DrugInteractionAnalyzer()
        results = analyzer.analyze_interactions(
            current_medications=self.sample_patient["current_medications"],
            proposed_medications=[]
        )

        self.assertIsNotNone(results, "Drug interaction analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ DrugInteractionAnalyzer tests passed")

    def test_specialist_recommender(self):
        """Test SpecialistRecommender (pure tool)"""
        logger.info("Testing SpecialistRecommender...")

        analyzer = SpecialistRecommender()
        results = analyzer.recommend_specialists(
            symptoms=self.sample_patient["symptoms"],
            medical_history=self.sample_patient["medical_history"],
            lab_results={"glucose": 145, "cholesterol": 220},
            symptom_severity=6.5,
            lab_abnormality_score=4.0
        )

        self.assertIsNotNone(results, "Specialist recommendation results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ SpecialistRecommender tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_patient_intake_agent(self):
        """Test PatientIntakeAgent (coordinator)"""
        logger.info("Testing PatientIntakeAgent...")

        agent = PatientIntakeAgent()
        results = agent.analyze("TEST-123", self.sample_patient)

        self.assertIsNotNone(results, "Patient intake agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ PatientIntakeAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_patient_intake_node(self):
        """Test patient_intake_node (thin wrapper)"""
        logger.info("Testing patient_intake_node...")

        state = DiagnosisState(
            patient_id="TEST-PATIENT",
            patient_name=self.sample_patient["name"],
            patient_age=self.sample_patient["age"],
            patient_gender=self.sample_patient["gender"],
            current_symptoms=self.sample_patient["symptoms"],
            medical_history=self.sample_patient["medical_history"],
            patient_details={
                "current_medications": self.sample_patient["current_medications"]
            }
        )

        result = patient_intake_node(state)

        self.assertIsNotNone(result, "Patient intake node result should not be None")
        self.assertIsInstance(result, DiagnosisState, "Result should be DiagnosisState")

        logger.info("✓ patient_intake_node tests passed")

    def test_symptom_node(self):
        """Test symptom_node (thin wrapper)"""
        logger.info("Testing symptom_node...")

        state = DiagnosisState(
            patient_id="TEST-PATIENT",
            current_symptoms=self.sample_patient["symptoms"],
            patient_details={"symptom_duration_days": 3}
        )

        result = symptom_node(state)

        self.assertIsNotNone(result, "Symptom node result should not be None")
        self.assertIsInstance(result, DiagnosisState, "Result should be DiagnosisState")

        logger.info("✓ symptom_node tests passed")

    def test_decision_node(self):
        """Test decision_node logic"""
        logger.info("Testing decision_node...")

        state = DiagnosisState(
            patient_id="TEST-PATIENT",
            symptom_analysis={"severity_score": 5.0},
            medical_history_analysis={"risk_score": 4.0},
            lab_analysis={"abnormality_score": 3.0, "critical_findings": []},
            drug_interaction_analysis={"interaction_score": 0.0},
            specialist_recommendations=[{"specialist": "cardiologist"}],
            coordination_summary={
                "overall_severity_score": 4.0,
                "severity_level": "MODERATE"
            }
        )

        result = decision_node(state)

        self.assertIsNotNone(result, "Decision result should not be None")
        self.assertIsInstance(result, DiagnosisState, "Result should be DiagnosisState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ decision_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_diagnosis_graph_creation(self):
        """Test DiagnosisGraph class creation"""
        logger.info("Testing DiagnosisGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = DiagnosisGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ DiagnosisGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_diagnosis_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, DiagnosisGraph, "Workflow should be DiagnosisGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        symptom_agent = SymptomAgent()
        self.assertIsNotNone(symptom_agent.analyzer, "SymptomAgent should have an analyzer")
        self.assertIsInstance(symptom_agent.analyzer, SymptomAnalyzer, "Should use SymptomAnalyzer")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        state = DiagnosisState(
            patient_id="TEST-PATIENT",
            current_symptoms=self.sample_patient["symptoms"],
            patient_details={"symptom_duration_days": 3}
        )

        result = symptom_node(state)
        self.assertIsInstance(result, DiagnosisState, "Node should return DiagnosisState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Medical Diagnosis Pipeline - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
