"""
Comprehensive Test Suite for Customer Support System

Test coverage:
- Agents (6 tests): Core agent functionality
- Nodes (5 tests): Key workflow nodes
- Graph (2 tests): Graph construction and execution
- Workflow (2 tests): Critical routing logic

Total: 15 test cases
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import sys
import os
from datetime import datetime

# Add parent directory to path if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Set up test environment variable for Gemini API
os.environ['GOOGLE_API_KEY'] = 'test_key_for_testing'

from agents.planner import PlannerAgent
from agents.sentiment import SentimentAgent
from agents.classifier import ClassifierAgent
from agents.resolver import ResolverAgent
from agents.quality_assurance import QualityAssuranceAgent
from agents.escalation import EscalationAgent
from state import create_initial_state, CustomerSupportState
from nodes.planning_node import planning_node
from nodes.sentiment_node import sentiment_node
from nodes.resolution_node import resolution_node
from nodes.qa_node import qa_node
from nodes.human_node import human_node
from graph import create_customer_support_graph
from workflow.routing import (
    route_from_planning,
    should_escalate
)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def mock_llm_service():
    """Mock LLM service for testing - patches all agent modules."""
    llm = MagicMock()
    llm.invoke_structured = MagicMock()
    llm.invoke = MagicMock()

    # Patch get_llm_service in all agent modules
    with patch('agents.planner.get_llm_service', return_value=llm), \
         patch('agents.sentiment.get_llm_service', return_value=llm), \
         patch('agents.classifier.get_llm_service', return_value=llm), \
         patch('agents.resolver.get_llm_service', return_value=llm), \
         patch('agents.quality_assurance.get_llm_service', return_value=llm), \
         patch('agents.followup.get_llm_service', return_value=llm), \
         patch('agents.escalation.get_llm_service', return_value=llm):
        yield llm


@pytest.fixture
def sample_state():
    """Create a sample state for testing."""
    return create_initial_state("I can't log in to my account", "test_thread")


# =============================================================================
# AGENT TESTS (6 test cases)
# =============================================================================

# Test Case 1: PlannerAgent - Analyze simple query
def test_planner_agent_simple_query(mock_llm_service):
    """Test PlannerAgent with a simple query."""
    mock_llm_service.invoke_structured.return_value = {
        "analysis": "Simple login issue",
        "complexity": "simple",
        "recommended_flow": ["classifier", "resolver"],
        "special_notes": "Standard technical issue"
    }

    agent = PlannerAgent()
    result = agent.analyze_and_plan("I can't log in", [])

    assert result["complexity"] == "simple"
    assert "classifier" in result["recommended_flow"]
    assert "resolver" in result["recommended_flow"]


# Test Case 2: SentimentAgent - Analyze frustrated customer
def test_sentiment_agent_frustrated_customer(mock_llm_service):
    """Test SentimentAgent detects frustrated sentiment."""
    mock_llm_service.invoke_structured.return_value = {
        "primary_sentiment": "frustrated",
        "sentiment_score": -0.6,
        "urgency_level": "high",
        "emotion_triggers": ["delay", "not working"],
        "customer_state": "Frustrated with delays",
        "response_recommendations": ["Be empathetic", "Act quickly"],
        "empathy_level_needed": "high"
    }

    agent = SentimentAgent()
    result = agent.analyze_sentiment("This is taking too long!", [])

    assert result["primary_sentiment"] == "frustrated"
    assert result["urgency_level"] == "high"
    assert result["sentiment_score"] < 0


# Test Case 3: ClassifierAgent - Technical query classification
def test_classifier_agent_technical_query(mock_llm_service):
    """Test ClassifierAgent classifies technical queries."""
    mock_llm_service.invoke_structured.return_value = {
        "category": "technical",
        "confidence": 0.95,
        "reasoning": "Query about account access",
        "key_topics": ["login", "password", "access"]
    }

    agent = ClassifierAgent()
    current_plan = {"analysis": "Login issue", "complexity": "simple"}
    result = agent.classify_query("Can't access my account", [], current_plan)

    assert result["category"] == "technical"
    assert result["confidence"] > 0.9


# Test Case 4: ResolverAgent - Generate resolution with knowledge base
def test_resolver_agent_with_knowledge_base(mock_llm_service):
    """Test ResolverAgent generates resolution."""
    with patch('agents.resolver.get_tools_service') as mock_tools:
        mock_tools.return_value.search_knowledge_base.return_value = [
            {
                "category": "technical",
                "topic": "password_reset",
                "question": "How do I reset my password?",
                "solution": "Follow these steps to reset your password..."
            }
        ]

        mock_llm_service.invoke_structured.return_value = {
            "resolution": "Please follow our password reset guide",
            "confidence": 0.9,
            "needs_escalation": False,
            "escalation_reason": None,
            "follow_up_questions": []
        }

        agent = ResolverAgent()
        result = agent.resolve_query(
            "I forgot my password",
            "technical",
            0.95,
            []
        )

        assert result["confidence"] == 0.9
        assert "resolution" in result
        assert result["needs_escalation"] == False


# Test Case 5: QualityAssuranceAgent - Approve quality response
def test_qa_agent_approve_quality_response(mock_llm_service):
    """Test QualityAssuranceAgent approves good responses."""
    mock_llm_service.invoke_structured.return_value = {
        "quality_score": 0.95,
        "is_approved": True,
        "accuracy_check": {"score": 0.95, "issues": []},
        "relevance_check": {"score": 0.92, "issues": []},
        "tone_check": {"score": 0.98, "appropriate_empathy": True},
        "completeness_check": {"score": 0.90, "missing_elements": []},
        "improvement_suggestions": []
    }

    agent = QualityAssuranceAgent()
    result = agent.review_response(
        "How do I reset my password?",
        "technical",
        "Click on 'Forgot Password' and follow the steps.",
        {"primary_sentiment": "neutral"}
    )

    assert result["is_approved"] == True
    assert result["quality_score"] > 0.9


# Test Case 6: EscalationAgent - Prepare escalation
def test_escalation_agent_prepare_escalation(mock_llm_service):
    """Test EscalationAgent prepares proper escalation."""
    with patch('agents.escalation.get_tools_service') as mock_tools:
        mock_tools.return_value.create_support_ticket.return_value = {
            "ticket_id": "TICKET-12345",
            "status": "open"
        }
        mock_tools.return_value.notify_human_agent.return_value = True

        mock_llm_service.invoke_structured.return_value = {
            "summary_for_human": "Customer needs immediate refund",
            "specific_question": "Should we process refund immediately?",
            "customer_impact": "high",
            "suggested_actions": ["Process refund", "Apologize", "Follow up"],
            "context_for_human": {
                "customer_sentiment": "frustrated",
                "urgency": "high",
                "business_impact": "Potential churn risk"
            }
        }

        agent = EscalationAgent()
        result = agent.prepare_escalation(
            "I want a refund NOW!",
            "billing",
            "Previous resolution failed",
            "Multiple failed attempts",
            []
        )

        assert "ticket_id" in result
        assert result["ticket_id"] == "TICKET-12345"


# =============================================================================
# NODE TESTS (5 test cases)
# =============================================================================

# Test Case 7: Planning Node - Successful execution
def test_planning_node_success(mock_llm_service, sample_state):
    """Test planning_node executes successfully."""
    mock_llm_service.invoke_structured.return_value = {
        "analysis": "Customer has login issue",
        "complexity": "simple",
        "recommended_flow": ["classifier", "resolver"],
        "special_notes": "Standard issue"
    }

    result = planning_node(sample_state)

    assert "current_plan" in result
    assert result["current_plan"]["complexity"] == "simple"
    assert result["current_node"] == "planning"


# Test Case 8: Sentiment Node - Successful execution
def test_sentiment_node_success(mock_llm_service, sample_state):
    """Test sentiment_node analyzes sentiment."""
    sample_state["current_plan"] = {"analysis": "Login issue", "complexity": "simple"}

    mock_llm_service.invoke_structured.return_value = {
        "primary_sentiment": "neutral",
        "sentiment_score": 0.0,
        "urgency_level": "medium",
        "emotion_triggers": [],
        "customer_state": "Calm inquiry",
        "response_recommendations": ["Professional tone"],
        "empathy_level_needed": "medium"
    }

    result = sentiment_node(sample_state)

    assert "sentiment_analysis" in result
    assert result["sentiment_analysis"]["primary_sentiment"] == "neutral"
    assert result["current_node"] == "sentiment_analysis"


# Test Case 9: Resolution Node - Successful resolution
def test_resolution_node_success(mock_llm_service, sample_state):
    """Test resolution_node generates resolution."""
    sample_state["classification"] = "technical"
    sample_state["classification_confidence"] = 0.9
    sample_state["sentiment_analysis"] = {"urgency_level": "medium"}

    with patch('agents.resolver.get_tools_service') as mock_tools:
        mock_tools.return_value.search_knowledge_base.return_value = []

        mock_llm_service.invoke_structured.return_value = {
            "resolution": "Try resetting your password",
            "confidence": 0.85,
            "needs_escalation": False,
            "escalation_reason": None,
            "follow_up_questions": []
        }

        result = resolution_node(sample_state)

        assert "resolution" in result
        assert isinstance(result["resolution"], str)
        assert result["current_node"] == "resolution"


# Test Case 10: QA Node - Approve response
def test_qa_node_approve(mock_llm_service, sample_state):
    """Test qa_node approves quality response."""
    sample_state["classification"] = "technical"
    sample_state["resolution"] = {"resolution": "Reset your password"}
    sample_state["sentiment_analysis"] = {"primary_sentiment": "neutral"}

    mock_llm_service.invoke_structured.return_value = {
        "quality_score": 0.92,
        "is_approved": True,
        "accuracy_check": {"score": 0.9, "issues": []},
        "relevance_check": {"score": 0.95, "issues": []},
        "tone_check": {"score": 0.9, "appropriate_empathy": True},
        "completeness_check": {"score": 0.93, "missing_elements": []},
        "improvement_suggestions": []
    }

    result = qa_node(sample_state)

    assert "qa_result" in result
    assert result["qa_result"]["is_approved"] == True
    assert result["quality_score"] == 0.92


# Test Case 11: Human Node - Prepare escalation
def test_human_node_prepare_escalation(mock_llm_service, sample_state):
    """Test human_node prepares escalation."""
    sample_state["classification"] = "billing"
    sample_state["escalation_reason"] = "Complex billing dispute"
    sample_state["escalation_needed"] = True

    with patch('agents.escalation.get_tools_service') as mock_tools:
        mock_tools.return_value.create_support_ticket.return_value = {
            "ticket_id": "TICKET-789",
            "status": "open"
        }
        mock_tools.return_value.notify_human_agent.return_value = True

        mock_llm_service.invoke_structured.return_value = {
            "summary_for_human": "Billing dispute requires review",
            "specific_question": "Should we process refund?",
            "customer_impact": "high",
            "suggested_actions": ["Review account", "Contact customer"],
            "context_for_human": {"urgency": "high"}
        }

        result = human_node(sample_state)

        assert "metadata" in result
        assert "escalation_info" in result["metadata"]
        assert result["current_node"] == "human_intervention"


# =============================================================================
# GRAPH TESTS (2 test cases)
# =============================================================================

# Test Case 12: Create graph without checkpointer
def test_create_graph_without_checkpointer():
    """Test graph creation without checkpointer."""
    graph = create_customer_support_graph(use_checkpointer=False)

    assert graph is not None
    # Graph should be compiled and ready
    assert hasattr(graph, 'invoke')


# Test Case 13: Graph execution - Simple workflow
def test_graph_execution_simple_workflow(mock_llm_service):
    """Test graph executes simple workflow end-to-end."""
    # Mock all agent responses
    mock_llm_service.invoke_structured.return_value = {
        "analysis": "Simple query",
        "complexity": "simple",
        "recommended_flow": ["classifier"],
        "special_notes": "Easy"
    }

    with patch('agents.resolver.get_tools_service') as mock_tools, \
         patch('agents.escalation.get_tools_service') as mock_esc_tools:
        mock_tools.return_value.search_knowledge_base.return_value = []

        graph = create_customer_support_graph(use_checkpointer=False)
        initial_state = create_initial_state("Simple question", "test_123")

        # Stream through graph
        events = []
        for event in graph.stream(initial_state):
            events.append(event)

        # Should have executed multiple nodes
        assert len(events) > 0


# =============================================================================
# WORKFLOW ROUTING TESTS (2 test cases)
# =============================================================================

# Test Case 14: Route from planning to analysis
def test_route_from_planning_to_analysis():
    """Test routing from planning to analysis."""
    state = {
        "planning": {
            "complexity": "simple",
            "recommended_flow": ["classifier"]
        },
        "escalation_reason": None
    }

    route = route_from_planning(state)
    assert route == "analysis"


# Test Case 15: Should escalate after resolution
def test_should_escalate_after_resolution():
    """Test escalation decision after resolution."""
    # Should escalate - no final response
    state1 = {
        "resolution": "Try this solution",
        "escalation_needed": False
    }
    assert should_escalate(state1) == "escalate"

    # Should end - has final response
    state2 = {
        "resolution": "Try this solution",
        "final_response": "Here's your solution",
        "escalation_needed": False
    }
    assert should_escalate(state2) == "end"
