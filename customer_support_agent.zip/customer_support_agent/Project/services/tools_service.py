"""
Tools Service for external integrations.

This service provides access to external tools like knowledge bases,
ticketing systems, and other APIs.
"""

import logging
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)


class ToolsService:
    """
    Service for managing external tools and integrations.

    This class provides methods for accessing knowledge bases, creating tickets,
    and other external system interactions.
    """

    def __init__(self):
        """Initialize the tools service."""
        self.knowledge_base = self._initialize_knowledge_base()
        logger.info("Tools Service initialized")

    def _initialize_knowledge_base(self) -> Dict[str, List[Dict[str, str]]]:
        """
        Initialize a simple knowledge base.

        In production, this would connect to a real database or vector store.

        Returns:
            Knowledge base dictionary
        """
        return {
            "technical": [
                {
                    "topic": "login_issues",
                    "question": "Cannot log in to my account",
                    "solution": "Please try resetting your password using the 'Forgot Password' link. If the issue persists, clear your browser cache and cookies, or try a different browser."
                },
                {
                    "topic": "api_errors",
                    "question": "Getting API error 500",
                    "solution": "Error 500 indicates a server issue. Please check our status page at status.example.com. If all systems are operational, try again in a few minutes or contact support with your request details."
                },
                {
                    "topic": "slow_performance",
                    "question": "Application is running slowly",
                    "solution": "Slow performance can be caused by: 1) Heavy traffic periods, 2) Browser cache issues, 3) Large dataset queries. Try clearing cache, using a smaller dataset, or scheduling intensive operations during off-peak hours."
                }
            ],
            "billing": [
                {
                    "topic": "refund_request",
                    "question": "How to request a refund",
                    "solution": "Refunds can be requested within 30 days of purchase. Go to Account > Billing > Request Refund, or contact our billing team at billing@example.com with your order number."
                },
                {
                    "topic": "subscription_cancel",
                    "question": "How to cancel subscription",
                    "solution": "To cancel your subscription: 1) Log in to your account, 2) Go to Settings > Subscription, 3) Click 'Cancel Subscription'. You'll retain access until the end of your billing period."
                },
                {
                    "topic": "payment_failed",
                    "question": "Payment failed",
                    "solution": "Payment failures can occur due to: 1) Insufficient funds, 2) Expired card, 3) Billing address mismatch. Please update your payment method in Account > Billing > Payment Methods."
                }
            ],
            "general": [
                {
                    "topic": "account_creation",
                    "question": "How to create an account",
                    "solution": "To create an account: 1) Visit our signup page, 2) Enter your email and create a password, 3) Verify your email address, 4) Complete your profile. You'll receive a welcome email with next steps."
                },
                {
                    "topic": "feature_request",
                    "question": "How to request a new feature",
                    "solution": "We love feature requests! Submit them through: 1) Our feedback portal at feedback.example.com, 2) In-app feedback button, or 3) Email features@example.com. We review all requests quarterly."
                }
            ]
        }

    def search_knowledge_base(
        self,
        query: str,
        category: Optional[str] = None,
        max_results: int = 3
    ) -> List[Dict[str, str]]:
        """
        Search the knowledge base for relevant articles.

        Args:
            query: Search query
            category: Optional category filter (technical, billing, general)
            max_results: Maximum number of results to return

        Returns:
            List of relevant knowledge base entries
        """
        query_lower = query.lower()
        results = []

        # Determine which categories to search
        categories = [category] if category and category in self.knowledge_base else self.knowledge_base.keys()

        for cat in categories:
            for entry in self.knowledge_base.get(cat, []):
                # Simple keyword matching (in production, use vector similarity)
                if any(word in entry["question"].lower() for word in query_lower.split()):
                    results.append({
                        "category": cat,
                        "topic": entry["topic"],
                        "question": entry["question"],
                        "solution": entry["solution"]
                    })

                if len(results) >= max_results:
                    break

            if len(results) >= max_results:
                break

        logger.info(f"Knowledge base search for '{query}' returned {len(results)} results")
        return results

    def create_support_ticket(
        self,
        customer_query: str,
        classification: str,
        priority: str = "medium"
    ) -> Dict[str, Any]:
        """
        Create a support ticket in the ticketing system.

        Args:
            customer_query: The customer's issue
            classification: Issue category
            priority: Ticket priority (low, medium, high)

        Returns:
            Ticket information
        """
        # In production, this would call a real ticketing API
        ticket_id = f"TICKET-{hash(customer_query) % 100000:05d}"

        ticket_info = {
            "ticket_id": ticket_id,
            "status": "open",
            "priority": priority,
            "classification": classification,
            "query": customer_query,
            "created_at": "2025-12-18T00:00:00Z"
        }

        logger.info(f"Created support ticket: {ticket_id}")
        return ticket_info

    def notify_human_agent(
        self,
        ticket_id: str,
        summary: str,
        urgency: str = "medium"
    ) -> bool:
        """
        Notify a human agent about an escalated case.

        Args:
            ticket_id: Ticket identifier
            summary: Summary of the issue
            urgency: Urgency level (low, medium, high)

        Returns:
            True if notification was sent successfully
        """
        # In production, this would send an email, Slack message, etc.
        logger.info(f"Human agent notified for ticket {ticket_id} (urgency: {urgency})")
        logger.debug(f"Notification summary: {summary}")
        return True

    def get_customer_history(self, customer_id: str) -> Dict[str, Any]:
        """
        Retrieve customer interaction history.

        Args:
            customer_id: Customer identifier

        Returns:
            Customer history information
        """
        # In production, this would query a CRM or database
        logger.info(f"Retrieving history for customer: {customer_id}")
        return {
            "customer_id": customer_id,
            "total_tickets": 0,
            "open_tickets": 0,
            "satisfaction_score": None,
            "last_interaction": None
        }


# Singleton instance
_tools_service_instance: Optional[ToolsService] = None


def get_tools_service() -> ToolsService:
    """
    Get or create the tools service singleton instance.

    Returns:
        ToolsService instance
    """
    global _tools_service_instance

    if _tools_service_instance is None:
        _tools_service_instance = ToolsService()

    return _tools_service_instance
