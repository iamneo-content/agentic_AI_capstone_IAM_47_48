"""
LLM Service for interacting with language models.

This service provides a centralized interface for all LLM interactions,
including error handling, retries, and response parsing.

Now using Google Gemini API instead of OpenAI.
"""

import os
import logging
from typing import Optional, Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage, SystemMessage

logger = logging.getLogger(__name__)


class LLMService:
    """
    Service for managing LLM interactions.

    This class provides methods for invoking language models with proper
    error handling and configuration management.
    """

    def __init__(
        self,
        model_name: str = "gemini-pro",
        temperature: float = 0.7,
        max_retries: int = 3,
        timeout: int = 60
    ):
        """
        Initialize the LLM service with Google Gemini.

        Args:
            model_name: Name of the Gemini model to use (gemini-pro, gemini-1.5-pro)
            temperature: Sampling temperature (0.0 to 1.0)
            max_retries: Maximum number of retry attempts
            timeout: Request timeout in seconds
        """
        self.model_name = model_name
        self.temperature = temperature
        self.max_retries = max_retries
        self.timeout = timeout

        # Initialize the Gemini LLM
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_API_KEY environment variable not set")

        self.llm = ChatGoogleGenerativeAI(
            model=model_name,
            temperature=temperature,
            max_retries=max_retries,
            timeout=timeout,
            google_api_key=api_key
        )

        logger.info(f"LLM Service initialized with Gemini model: {model_name}")

    def invoke(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> str:
        """
        Invoke the LLM with a prompt.

        Args:
            prompt: User prompt
            system_message: Optional system message
            temperature: Override default temperature

        Returns:
            LLM response as string

        Raises:
            Exception: If LLM invocation fails after all retries
        """
        try:
            messages = []

            if system_message:
                messages.append(SystemMessage(content=system_message))

            messages.append(HumanMessage(content=prompt))

            # Override temperature if provided
            llm = self.llm
            if temperature is not None:
                api_key = os.getenv("GOOGLE_API_KEY")
                llm = ChatGoogleGenerativeAI(
                    model=self.model_name,
                    temperature=temperature,
                    max_retries=self.max_retries,
                    timeout=self.timeout,
                    google_api_key=api_key
                )

            response = llm.invoke(messages)

            logger.debug(f"LLM response received (length: {len(response.content)})")
            return response.content

        except Exception as e:
            logger.error(f"LLM invocation failed: {str(e)}")
            raise

    def invoke_json(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Invoke the LLM expecting a JSON response.

        Args:
            prompt: User prompt
            system_message: Optional system message
            temperature: Override default temperature

        Returns:
            Parsed JSON response as dictionary

        Raises:
            Exception: If LLM invocation fails or response is not valid JSON
        """
        from utils.helpers import extract_json_from_text

        response = self.invoke(prompt, system_message, temperature)

        # Extract JSON from response
        json_data = extract_json_from_text(response)

        if json_data is None:
            logger.error(f"Failed to extract JSON from LLM response: {response}")
            raise ValueError("LLM response did not contain valid JSON")

        logger.debug(f"Successfully parsed JSON response with keys: {list(json_data.keys())}")
        return json_data

    def invoke_structured(
        self,
        prompt: str,
        temperature: float = 0.3
    ) -> Dict[str, Any]:
        """
        Invoke the LLM with low temperature for structured output.

        This method is optimized for getting consistent, structured responses
        like JSON objects.

        Args:
            prompt: User prompt (should request JSON format)
            temperature: Sampling temperature (default 0.3 for consistency)

        Returns:
            Parsed JSON response
        """
        return self.invoke_json(prompt, temperature=temperature)


# Singleton instance
_llm_service_instance: Optional[LLMService] = None


def get_llm_service(
    model_name: Optional[str] = None,
    temperature: Optional[float] = None
) -> LLMService:
    """
    Get or create the LLM service singleton instance.

    Args:
        model_name: Model name (only used on first call)
        temperature: Temperature (only used on first call)

    Returns:
        LLMService instance
    """
    global _llm_service_instance

    if _llm_service_instance is None:
        _llm_service_instance = LLMService(
            model_name=model_name or os.getenv("LLM_MODEL", "gemini-pro"),
            temperature=temperature or float(os.getenv("LLM_TEMPERATURE", "0.7"))
        )

    return _llm_service_instance
