"""
Memory Service for conversation persistence.

This service manages conversation checkpointing and retrieval using
LangGraph's memory system.
"""

import os
import logging
from typing import Optional
from langgraph.checkpoint.memory import MemorySaver

logger = logging.getLogger(__name__)


class MemoryService:
    """
    Service for managing conversation memory and checkpointing.

    This class provides methods for storing and retrieving conversation state
    across multiple turns.
    """

    def __init__(self, use_persistent: bool = False):
        """
        Initialize the memory service.

        Args:
            use_persistent: If True, use persistent storage (PostgreSQL)
                          If False, use in-memory storage
        """
        self.use_persistent = use_persistent

        if use_persistent:
            # For production, you would use PostgresSaver or similar
            # from langgraph.checkpoint.postgres import PostgresSaver
            # self.checkpointer = PostgresSaver(connection_string)
            logger.warning("Persistent storage requested but not configured. Using in-memory storage.")
            self.checkpointer = MemorySaver()
        else:
            # In-memory storage for development
            self.checkpointer = MemorySaver()

        logger.info(f"Memory Service initialized (persistent: {use_persistent})")

    def get_checkpointer(self):
        """
        Get the checkpointer instance.

        Returns:
            Checkpointer instance for use with LangGraph
        """
        return self.checkpointer

    def clear_thread(self, thread_id: str) -> None:
        """
        Clear conversation history for a specific thread.

        Args:
            thread_id: Thread identifier to clear
        """
        # Note: MemorySaver doesn't have a direct clear method
        # For production with PostgresSaver, you would implement this
        logger.info(f"Clear requested for thread: {thread_id}")
        logger.warning("Thread clearing not implemented for MemorySaver")

    def get_thread_history(self, thread_id: str) -> Optional[dict]:
        """
        Get conversation history for a thread.

        Args:
            thread_id: Thread identifier

        Returns:
            Thread history or None if not found
        """
        try:
            # This would be implemented with the specific checkpointer
            logger.debug(f"Retrieving history for thread: {thread_id}")
            return None
        except Exception as e:
            logger.error(f"Error retrieving thread history: {str(e)}")
            return None


# Singleton instance
_memory_service_instance: Optional[MemoryService] = None


def get_memory_service(use_persistent: bool = False) -> MemoryService:
    """
    Get or create the memory service singleton instance.

    Args:
        use_persistent: Whether to use persistent storage (only used on first call)

    Returns:
        MemoryService instance
    """
    global _memory_service_instance

    if _memory_service_instance is None:
        persistent = use_persistent or os.getenv("USE_PERSISTENT_MEMORY", "false").lower() == "true"
        _memory_service_instance = MemoryService(use_persistent=persistent)

    return _memory_service_instance
