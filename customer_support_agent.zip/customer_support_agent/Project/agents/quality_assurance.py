"""
Quality Assurance Agent for reviewing responses before sending.

This agent ensures responses are accurate, appropriate, and high-quality
before being delivered to customers.
"""

import logging
from typing import Dict, Any, List
from services.llm_service import get_llm_service

logger = logging.getLogger(__name__)


# QA Agent Prompt
QA_PROMPT = """You are a Quality Assurance Agent for customer support responses. Your role is to review and validate responses before they're sent to customers.

**Customer Query:**
{customer_query}

**Classification:** {classification}

**Proposed Response:**
{proposed_response}

**Sentiment Analysis:**
{sentiment_info}

**Instructions:**
- Review the response for accuracy, clarity, and appropriateness
- Check if it addresses the customer's actual question
- Verify the tone matches the customer's sentiment
- Identify any potential issues or red flags
- Suggest improvements if needed
- Determine if the response is ready to send

**Quality Criteria:**
1. Accuracy: Is the information correct?
2. Relevance: Does it address the customer's query?
3. Tone: Is it appropriate for the sentiment?
4. Clarity: Is it easy to understand?
5. Completeness: Does it fully answer the question?
6. Professionalism: Is it professional and respectful?

**Output Format (JSON):**
{{
    "quality_score": 0.0-1.0,
    "is_approved": true|false,
    "accuracy_check": "pass|fail|warning",
    "relevance_check": "pass|fail|warning",
    "tone_check": "pass|fail|warning",
    "clarity_check": "pass|fail|warning",
    "issues_found": ["issue1", "issue2"] or [],
    "suggestions": ["suggestion1", "suggestion2"] or [],
    "needs_revision": true|false,
    "revision_reason": "Reason if needs revision, or null",
    "improved_response": "Improved version if needed, or null"
}}

Provide your response as valid JSON only.
"""


class QualityAssuranceAgent:
    """
    Agent responsible for quality assurance of responses.

    The QA agent reviews responses before delivery to ensure they meet
    quality standards and are appropriate for the customer.
    """

    def __init__(self):
        """Initialize the quality assurance agent."""
        self.llm_service = get_llm_service()
        logger.info("QualityAssuranceAgent initialized")

    def review_response(
        self,
        customer_query: str,
        classification: str,
        proposed_response: str,
        sentiment_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Review a proposed response for quality.

        Args:
            customer_query: The customer's original query
            classification: The category of the query
            proposed_response: The response to review
            sentiment_analysis: Sentiment analysis of the query

        Returns:
            Dictionary containing QA results with keys:
                - quality_score: Overall quality (0.0 to 1.0)
                - is_approved: Whether to send the response
                - accuracy_check, relevance_check, tone_check, clarity_check
                - issues_found: List of problems identified
                - suggestions: List of improvements
                - needs_revision: Whether response needs to be rewritten
                - improved_response: Better version if available
        """
        try:
            # Format sentiment info
            sentiment_info = self._format_sentiment_info(sentiment_analysis)

            # Generate the prompt
            prompt = QA_PROMPT.format(
                customer_query=customer_query,
                classification=classification,
                proposed_response=proposed_response,
                sentiment_info=sentiment_info
            )

            # Get QA review from LLM
            logger.info("Performing quality assurance review")
            qa_result = self.llm_service.invoke_structured(prompt)

            quality_score = qa_result.get("quality_score", 0.5)
            is_approved = qa_result.get("is_approved", False)

            logger.info(f"QA Score: {quality_score:.2f}, Approved: {is_approved}")

            if qa_result.get("issues_found"):
                logger.warning(f"Issues found: {qa_result['issues_found']}")

            # Validate quality score
            if not isinstance(quality_score, (int, float)) or not 0.0 <= quality_score <= 1.0:
                logger.warning(f"Invalid quality score {quality_score}, using 0.5")
                qa_result["quality_score"] = 0.5

            return qa_result

        except Exception as e:
            logger.error(f"Error in QA agent: {str(e)}")
            # Return a default approval on error to not block workflow
            return self._get_default_approval(proposed_response)

    def _format_sentiment_info(self, sentiment_analysis: Dict[str, Any]) -> str:
        """Format sentiment analysis for the prompt."""
        if not sentiment_analysis:
            return "No sentiment analysis available"

        return (
            f"Primary Sentiment: {sentiment_analysis.get('primary_sentiment', 'N/A')}\n"
            f"Sentiment Score: {sentiment_analysis.get('sentiment_score', 0.0)}\n"
            f"Urgency: {sentiment_analysis.get('urgency_level', 'N/A')}\n"
            f"Empathy Needed: {sentiment_analysis.get('empathy_level_needed', 'N/A')}"
        )

    def _get_default_approval(self, proposed_response: str) -> Dict[str, Any]:
        """
        Get a default approval when QA fails.

        Args:
            proposed_response: The response that was being reviewed

        Returns:
            Default QA approval
        """
        return {
            "quality_score": 0.7,
            "is_approved": True,
            "accuracy_check": "warning",
            "relevance_check": "warning",
            "tone_check": "warning",
            "clarity_check": "warning",
            "issues_found": ["QA system unavailable, manual review recommended"],
            "suggestions": [],
            "needs_revision": False,
            "revision_reason": None,
            "improved_response": None
        }

    def get_final_response(
        self,
        qa_result: Dict[str, Any],
        original_response: str
    ) -> str:
        """
        Get the final response to send based on QA results.

        Args:
            qa_result: QA review results
            original_response: Original proposed response

        Returns:
            Final response to send to customer
        """
        # If QA suggested an improved response, use it
        if qa_result.get("improved_response"):
            logger.info("Using improved response from QA")
            return qa_result["improved_response"]

        # Otherwise use original
        return original_response

    def calculate_confidence(
        self,
        qa_result: Dict[str, Any]
    ) -> float:
        """
        Calculate overall confidence in the response.

        Args:
            qa_result: QA review results

        Returns:
            Confidence score (0.0 to 1.0)
        """
        quality_score = qa_result.get("quality_score", 0.5)
        is_approved = qa_result.get("is_approved", False)
        needs_revision = qa_result.get("needs_revision", False)

        if not is_approved or needs_revision:
            return quality_score * 0.5

        return quality_score
