"""
Escalation Agent for handling complex cases requiring human intervention.

This agent prepares cases for human review and manages the escalation process.
"""

import logging
from typing import Dict, Any, Optional
from services.llm_service import get_llm_service
from services.tools_service import get_tools_service
from utils.prompts import get_escalation_prompt
from utils.helpers import format_conversation_history

logger = logging.getLogger(__name__)


class EscalationAgent:
    """
    Agent responsible for managing escalations to human agents.

    The escalation agent prepares comprehensive summaries, identifies
    what human input is needed, and manages the handoff process.
    """

    def __init__(self):
        """Initialize the escalation agent."""
        self.llm_service = get_llm_service()
        self.tools_service = get_tools_service()
        logger.info("EscalationAgent initialized")

    def prepare_escalation(
        self,
        customer_query: str,
        classification: str,
        previous_resolution: Optional[str],
        escalation_reason: str,
        conversation_history: list
    ) -> Dict[str, Any]:
        """
        Prepare a case for escalation to a human agent.

        Args:
            customer_query: The customer's question or issue
            classification: The category assigned to the query
            previous_resolution: Previous resolution attempt if any
            escalation_reason: Reason why escalation is needed
            conversation_history: Previous conversation messages

        Returns:
            Dictionary containing escalation information with keys:
                - summary_for_human: Clear summary for the human agent
                - specific_question: What decision/input is needed
                - customer_impact: Impact level (high, medium, low)
                - suggested_actions: Recommended actions
                - context_for_human: Additional context dict
        """
        try:
            # Format inputs
            history_str = format_conversation_history(conversation_history)
            resolution_str = previous_resolution or "No resolution attempted"

            # Generate the prompt
            prompt = get_escalation_prompt(
                customer_query=customer_query,
                classification=classification,
                previous_resolution=resolution_str,
                escalation_reason=escalation_reason,
                conversation_history=history_str
            )

            # Get escalation plan from LLM
            logger.info("Preparing escalation information")
            escalation_info = self.llm_service.invoke_structured(prompt)

            logger.info(f"Escalation prepared - Impact: {escalation_info.get('customer_impact', 'unknown')}")

            # Create a support ticket
            ticket = self.tools_service.create_support_ticket(
                customer_query=customer_query,
                classification=classification,
                priority=self._map_impact_to_priority(escalation_info.get('customer_impact', 'medium'))
            )

            escalation_info['ticket_id'] = ticket['ticket_id']

            # Notify human agent
            urgency = escalation_info.get('context_for_human', {}).get('urgency', 'medium')
            self.tools_service.notify_human_agent(
                ticket_id=ticket['ticket_id'],
                summary=escalation_info.get('summary_for_human', ''),
                urgency=urgency
            )

            return escalation_info

        except Exception as e:
            logger.error(f"Error in escalation agent: {str(e)}")
            # Return a basic escalation on error
            return self._get_default_escalation(escalation_reason)

    def _map_impact_to_priority(self, impact: str) -> str:
        """
        Map customer impact level to ticket priority.

        Args:
            impact: Customer impact (high, medium, low)

        Returns:
            Priority level for the ticket
        """
        impact_map = {
            "high": "high",
            "medium": "medium",
            "low": "low"
        }
        return impact_map.get(impact.lower(), "medium")

    def _get_default_escalation(self, reason: str) -> Dict[str, Any]:
        """
        Create a default escalation when preparation fails.

        Args:
            reason: Escalation reason

        Returns:
            Default escalation information
        """
        return {
            "summary_for_human": "Customer query requires human attention. Automatic escalation preparation failed.",
            "specific_question": "Please review the customer query and provide appropriate assistance.",
            "customer_impact": "medium",
            "suggested_actions": [
                "Review conversation history",
                "Contact customer directly if needed",
                "Provide resolution or guidance"
            ],
            "context_for_human": {
                "customer_sentiment": "neutral",
                "urgency": "medium",
                "business_impact": f"Escalated due to: {reason}"
            }
        }

    def format_for_human_display(self, escalation_info: Dict[str, Any]) -> str:
        """
        Format escalation information for human-readable display.

        Args:
            escalation_info: Escalation information dictionary

        Returns:
            Formatted string for display
        """
        from utils.prompts import HUMAN_INTERVENTION_PROMPT

        context = escalation_info.get('context_for_human', {})
        suggested_actions = escalation_info.get('suggested_actions', [])

        actions_formatted = "\n".join([f"  • {action}" for action in suggested_actions])

        return HUMAN_INTERVENTION_PROMPT.format(
            summary=escalation_info.get('summary_for_human', 'No summary available'),
            question=escalation_info.get('specific_question', 'Please review and provide guidance'),
            impact=escalation_info.get('customer_impact', 'medium').upper(),
            urgency=context.get('urgency', 'medium').upper(),
            suggested_actions=actions_formatted
        )

    def process_human_feedback(
        self,
        human_feedback: str,
        escalation_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Process feedback from a human agent.

        Args:
            human_feedback: The feedback provided by the human agent
            escalation_info: Original escalation information

        Returns:
            Dictionary with processed feedback and final response
        """
        logger.info("Processing human feedback")

        # In a production system, you might want to:
        # 1. Validate the feedback
        # 2. Update the ticket
        # 3. Log the interaction
        # 4. Format the response for the customer

        return {
            "final_response": human_feedback,
            "ticket_id": escalation_info.get('ticket_id'),
            "resolved_by": "human_agent",
            "resolution_method": "escalation"
        }
