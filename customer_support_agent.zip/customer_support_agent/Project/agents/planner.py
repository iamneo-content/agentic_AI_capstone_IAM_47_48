"""
Planner Agent for analyzing customer queries and creating execution plans.

This agent is responsible for understanding the customer's request and
determining the best workflow to handle it.
"""

import logging
from typing import Dict, Any
from services.llm_service import get_llm_service
from utils.prompts import get_planner_prompt
from utils.helpers import format_conversation_history

logger = logging.getLogger(__name__)


class PlannerAgent:
    """
    Agent responsible for analyzing customer queries and planning workflows.

    The planner agent examines the customer query, considers conversation history,
    and creates a structured plan for handling the request.
    """

    def __init__(self):
        """Initialize the planner agent."""
        self.llm_service = get_llm_service()
        logger.info("PlannerAgent initialized")

    def analyze_and_plan(
        self,
        customer_query: str,
        conversation_history: list
    ) -> Dict[str, Any]:
        """
        Analyze the customer query and create an execution plan.

        Args:
            customer_query: The customer's question or issue
            conversation_history: Previous conversation messages

        Returns:
            Dictionary containing the plan with keys:
                - analysis: Analysis of the query
                - complexity: simple|moderate|complex
                - recommended_flow: List of agents to invoke
                - special_notes: Any special considerations
        """
        try:
            # Format conversation history
            history_str = format_conversation_history(conversation_history)

            # Generate the prompt
            prompt = get_planner_prompt(customer_query, history_str)

            # Get the plan from LLM
            logger.info("Generating execution plan")
            plan = self.llm_service.invoke_structured(prompt)

            logger.info(f"Plan created - Complexity: {plan.get('complexity', 'unknown')}")
            logger.debug(f"Recommended flow: {plan.get('recommended_flow', [])}")

            # Validate the plan structure
            required_keys = ["analysis", "complexity", "recommended_flow"]
            if not all(key in plan for key in required_keys):
                logger.warning("Plan missing required keys, using defaults")
                plan = self._get_default_plan()

            return plan

        except Exception as e:
            logger.error(f"Error in planner agent: {str(e)}")
            # Return a default plan on error
            return self._get_default_plan()

    def _get_default_plan(self) -> Dict[str, Any]:
        """
        Get a default plan to use when planning fails.

        Returns:
            Default execution plan
        """
        return {
            "analysis": "Unable to analyze query, using default workflow",
            "complexity": "moderate",
            "recommended_flow": ["classifier", "resolver"],
            "special_notes": "Using fallback plan due to analysis error"
        }

    def should_escalate_immediately(self, customer_query: str) -> bool:
        """
        Determine if a query should be escalated immediately without processing.

        Args:
            customer_query: The customer's question or issue

        Returns:
            True if immediate escalation is needed
        """
        # Keywords that indicate immediate escalation
        escalation_keywords = [
            "urgent", "emergency", "critical", "legal",
            "lawsuit", "complaint", "refund now", "cancel immediately"
        ]

        query_lower = customer_query.lower()
        return any(keyword in query_lower for keyword in escalation_keywords)
