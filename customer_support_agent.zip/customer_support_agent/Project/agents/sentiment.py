"""
Sentiment Analysis Agent for understanding customer emotions.

This agent analyzes the emotional tone of customer queries to help
tailor responses appropriately.
"""

import logging
from typing import Dict, Any
from services.llm_service import get_llm_service
from utils.helpers import format_conversation_history

logger = logging.getLogger(__name__)


# Sentiment Analysis Prompt
SENTIMENT_PROMPT = """You are a Sentiment Analysis Agent for customer support. Your role is to analyze the emotional tone and sentiment of customer messages.

**Customer Query:**
{customer_query}

**Conversation History:**
{conversation_history}

**Instructions:**
- Analyze the customer's emotional state
- Identify the primary sentiment (positive, neutral, negative, frustrated, angry, confused, satisfied)
- Assess the urgency level based on emotional indicators
- Identify key emotion triggers or pain points
- Provide actionable insights for response tailoring

**Output Format (JSON):**
{{
    "primary_sentiment": "positive|neutral|negative|frustrated|angry|confused|satisfied",
    "sentiment_score": -1.0 to 1.0 (negative to positive),
    "urgency_level": "low|medium|high|critical",
    "emotion_triggers": ["trigger1", "trigger2"],
    "customer_state": "Brief description of customer's emotional state",
    "response_recommendations": ["recommendation1", "recommendation2"],
    "empathy_level_needed": "low|medium|high"
}}

Provide your response as valid JSON only.
"""


class SentimentAgent:
    """
    Agent responsible for analyzing customer sentiment and emotions.

    The sentiment agent examines the customer's messages to understand
    their emotional state and provides insights for response tailoring.
    """

    def __init__(self):
        """Initialize the sentiment agent."""
        self.llm_service = get_llm_service()
        logger.info("SentimentAgent initialized")

    def analyze_sentiment(
        self,
        customer_query: str,
        conversation_history: list
    ) -> Dict[str, Any]:
        """
        Analyze the sentiment of the customer query.

        Args:
            customer_query: The customer's question or issue
            conversation_history: Previous conversation messages

        Returns:
            Dictionary containing sentiment analysis with keys:
                - primary_sentiment: Main emotional tone
                - sentiment_score: Numerical sentiment (-1.0 to 1.0)
                - urgency_level: How urgent the issue is
                - emotion_triggers: What's causing strong emotions
                - customer_state: Description of emotional state
                - response_recommendations: How to tailor response
                - empathy_level_needed: How much empathy to show
        """
        try:
            # Format conversation history
            history_str = format_conversation_history(conversation_history)

            # Generate the prompt
            prompt = SENTIMENT_PROMPT.format(
                customer_query=customer_query,
                conversation_history=history_str
            )

            # Get sentiment analysis from LLM
            logger.info("Analyzing customer sentiment")
            sentiment_analysis = self.llm_service.invoke_structured(prompt)

            primary_sentiment = sentiment_analysis.get("primary_sentiment", "neutral")
            urgency = sentiment_analysis.get("urgency_level", "medium")

            logger.info(f"Sentiment: {primary_sentiment}, Urgency: {urgency}")
            logger.debug(f"Sentiment score: {sentiment_analysis.get('sentiment_score', 0.0)}")

            # Validate sentiment score
            score = sentiment_analysis.get("sentiment_score", 0.0)
            if not isinstance(score, (int, float)) or not -1.0 <= score <= 1.0:
                logger.warning(f"Invalid sentiment score {score}, using 0.0")
                sentiment_analysis["sentiment_score"] = 0.0

            return sentiment_analysis

        except Exception as e:
            logger.error(f"Error in sentiment agent: {str(e)}")
            # Return a default sentiment analysis on error
            return self._get_default_sentiment()

    def _get_default_sentiment(self) -> Dict[str, Any]:
        """
        Get a default sentiment analysis to use when analysis fails.

        Returns:
            Default sentiment analysis
        """
        return {
            "primary_sentiment": "neutral",
            "sentiment_score": 0.0,
            "urgency_level": "medium",
            "emotion_triggers": [],
            "customer_state": "Unable to analyze sentiment, treating as neutral",
            "response_recommendations": ["Use professional and helpful tone"],
            "empathy_level_needed": "medium"
        }

    def should_escalate_based_on_sentiment(
        self,
        sentiment_analysis: Dict[str, Any]
    ) -> bool:
        """
        Determine if escalation is needed based on sentiment.

        Args:
            sentiment_analysis: Sentiment analysis results

        Returns:
            True if sentiment indicates escalation is needed
        """
        # Escalate for high urgency or very negative sentiment
        urgency = sentiment_analysis.get("urgency_level", "medium")
        sentiment_score = sentiment_analysis.get("sentiment_score", 0.0)
        primary_sentiment = sentiment_analysis.get("primary_sentiment", "neutral")

        if urgency == "critical":
            return True

        if sentiment_score < -0.7:  # Very negative
            return True

        if primary_sentiment in ["angry", "frustrated"] and urgency == "high":
            return True

        return False

    def get_tone_recommendation(
        self,
        sentiment_analysis: Dict[str, Any]
    ) -> str:
        """
        Get tone recommendation based on sentiment.

        Args:
            sentiment_analysis: Sentiment analysis results

        Returns:
            Recommended tone for the response
        """
        primary_sentiment = sentiment_analysis.get("primary_sentiment", "neutral")
        empathy_level = sentiment_analysis.get("empathy_level_needed", "medium")

        tone_map = {
            ("angry", "high"): "apologetic_empathetic",
            ("frustrated", "high"): "understanding_supportive",
            ("confused", "medium"): "patient_explanatory",
            ("negative", "high"): "empathetic_solution_focused",
            ("neutral", "medium"): "professional_helpful",
            ("positive", "low"): "friendly_efficient",
            ("satisfied", "low"): "appreciative_confirming"
        }

        return tone_map.get((primary_sentiment, empathy_level), "professional_helpful")
