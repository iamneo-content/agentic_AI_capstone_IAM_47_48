"""
Resolver Agent for providing solutions to customer issues.

This agent attempts to resolve customer queries using the knowledge base
and LLM reasoning.
"""

import logging
from typing import Dict, Any, Optional
from services.llm_service import get_llm_service
from services.tools_service import get_tools_service
from utils.prompts import get_resolver_prompt
from utils.helpers import format_conversation_history

logger = logging.getLogger(__name__)


class ResolverAgent:
    """
    Agent responsible for resolving customer issues.

    The resolver agent searches the knowledge base, analyzes the query,
    and provides appropriate solutions or recommendations.
    """

    def __init__(self):
        """Initialize the resolver agent."""
        self.llm_service = get_llm_service()
        self.tools_service = get_tools_service()
        logger.info("ResolverAgent initialized")

    def resolve_query(
        self,
        customer_query: str,
        classification: str,
        confidence: float,
        conversation_history: list,
        resolution_attempts: int = 0
    ) -> Dict[str, Any]:
        """
        Attempt to resolve the customer query.

        Args:
            customer_query: The customer's question or issue
            classification: The category assigned by the classifier
            confidence: Classification confidence score
            conversation_history: Previous conversation messages
            resolution_attempts: Number of previous resolution attempts

        Returns:
            Dictionary containing resolution with keys:
                - resolution: The response to the customer
                - confidence: Confidence in the resolution
                - needs_escalation: Whether escalation is needed
                - escalation_reason: Reason for escalation if needed
                - follow_up_questions: Any follow-up questions
        """
        try:
            # Search knowledge base for relevant articles
            kb_results = self.tools_service.search_knowledge_base(
                customer_query,
                category=classification
            )

            # Format knowledge base context
            kb_context = self._format_kb_context(kb_results)

            # Format conversation history
            history_str = format_conversation_history(conversation_history)

            # Generate the prompt
            prompt = get_resolver_prompt(
                customer_query=customer_query,
                classification=classification,
                confidence=confidence,
                conversation_history=history_str,
                resolution_attempts=resolution_attempts,
                knowledge_base_context=kb_context
            )

            # Get resolution from LLM
            logger.info(f"Generating resolution (attempt {resolution_attempts + 1})")
            resolution = self.llm_service.invoke_structured(prompt)

            logger.info(f"Resolution generated - Escalation needed: {resolution.get('needs_escalation', False)}")

            # Validate resolution structure
            if "resolution" not in resolution:
                logger.warning("Resolution missing 'resolution' key")
                resolution["resolution"] = "I apologize, but I'm having trouble formulating a response. Let me escalate this to a human agent."
                resolution["needs_escalation"] = True
                resolution["escalation_reason"] = "Failed to generate resolution"

            # Auto-escalate if multiple attempts have failed
            if resolution_attempts >= 2 and not resolution.get("needs_escalation"):
                logger.warning("Multiple resolution attempts failed, forcing escalation")
                resolution["needs_escalation"] = True
                resolution["escalation_reason"] = "Multiple resolution attempts unsuccessful"

            return resolution

        except Exception as e:
            logger.error(f"Error in resolver agent: {str(e)}")
            # Return an escalation response on error
            return self._get_escalation_response(str(e))

    def _format_kb_context(self, kb_results: list) -> str:
        """
        Format knowledge base results for inclusion in the prompt.

        Args:
            kb_results: List of knowledge base entries

        Returns:
            Formatted string of KB articles
        """
        if not kb_results:
            return "No specific knowledge base articles found for this query."

        formatted = ["Relevant Knowledge Base Articles:", ""]
        for i, result in enumerate(kb_results, 1):
            formatted.append(f"Article {i}:")
            formatted.append(f"Category: {result['category']}")
            formatted.append(f"Topic: {result['topic']}")
            formatted.append(f"Question: {result['question']}")
            formatted.append(f"Solution: {result['solution']}")
            formatted.append("")

        return "\n".join(formatted)

    def _get_escalation_response(self, error_msg: str) -> Dict[str, Any]:
        """
        Create an escalation response when resolution fails.

        Args:
            error_msg: Error message that caused the failure

        Returns:
            Escalation response dictionary
        """
        return {
            "resolution": "I apologize for the inconvenience. I'm unable to fully address your issue at the moment. Let me connect you with a human agent who can better assist you.",
            "confidence": 0.0,
            "needs_escalation": True,
            "escalation_reason": f"Resolution failed due to: {error_msg}",
            "follow_up_questions": []
        }

    def enhance_resolution_with_empathy(
        self,
        resolution: str,
        category: str
    ) -> str:
        """
        Add empathetic language to the resolution based on category.

        Args:
            resolution: Original resolution text
            category: Query category

        Returns:
            Enhanced resolution with empathy
        """
        empathy_prefixes = {
            "complaint": "I sincerely apologize for your experience. ",
            "technical": "I understand technical issues can be frustrating. ",
            "billing": "I appreciate your patience with this billing matter. ",
            "general": "Thank you for reaching out. "
        }

        prefix = empathy_prefixes.get(category, "")
        return prefix + resolution if prefix and not resolution.startswith(prefix) else resolution
