"""
Follow-up Agent for suggesting next steps and follow-up actions.

This agent determines what follow-up actions should be taken after
resolving a customer query.
"""

import logging
from typing import Dict, Any, List
from services.llm_service import get_llm_service

logger = logging.getLogger(__name__)


# Follow-up Agent Prompt
FOLLOWUP_PROMPT = """You are a Follow-up Agent for customer support. Your role is to determine what follow-up actions should be taken after addressing a customer query.

**Customer Query:**
{customer_query}

**Classification:** {classification}

**Resolution Provided:**
{resolution}

**Sentiment:**
{sentiment}

**Quality Assessment:**
Quality Score: {quality_score}

**Instructions:**
- Determine if follow-up is needed
- Suggest specific follow-up actions
- Identify if customer satisfaction should be tracked
- Recommend timeline for follow-up
- Suggest any proactive measures to prevent similar issues

**Follow-up Considerations:**
1. Was the issue fully resolved?
2. Does the customer need additional support?
3. Should we check if the solution worked?
4. Are there preventive measures to suggest?
5. Should we gather feedback?

**Output Format (JSON):**
{{
    "follow_up_needed": true|false,
    "follow_up_priority": "low|medium|high",
    "suggested_actions": ["action1", "action2"],
    "follow_up_timeline": "immediate|24h|3days|1week|none",
    "satisfaction_tracking": true|false,
    "proactive_measures": ["measure1", "measure2"] or [],
    "additional_resources": ["resource1", "resource2"] or [],
    "closure_status": "resolved|pending|requires_monitoring",
    "follow_up_message": "Optional follow-up message template or null"
}}

Provide your response as valid JSON only.
"""


class FollowUpAgent:
    """
    Agent responsible for determining follow-up actions.

    The follow-up agent analyzes the resolution and determines what
    additional actions should be taken to ensure customer satisfaction.
    """

    def __init__(self):
        """Initialize the follow-up agent."""
        self.llm_service = get_llm_service()
        logger.info("FollowUpAgent initialized")

    def determine_followup(
        self,
        customer_query: str,
        classification: str,
        resolution: str,
        sentiment_analysis: Dict[str, Any],
        quality_score: float
    ) -> Dict[str, Any]:
        """
        Determine appropriate follow-up actions.

        Args:
            customer_query: The customer's original query
            classification: The category of the query
            resolution: The resolution that was provided
            sentiment_analysis: Sentiment analysis results
            quality_score: Quality score of the resolution

        Returns:
            Dictionary containing follow-up recommendations with keys:
                - follow_up_needed: Whether follow-up is needed
                - follow_up_priority: Priority level
                - suggested_actions: List of recommended actions
                - follow_up_timeline: When to follow up
                - satisfaction_tracking: Whether to track satisfaction
                - proactive_measures: Preventive actions
                - additional_resources: Helpful resources to provide
                - closure_status: Status of the ticket
                - follow_up_message: Template message for follow-up
        """
        try:
            # Format sentiment info
            sentiment = sentiment_analysis.get("primary_sentiment", "neutral")

            # Generate the prompt
            prompt = FOLLOWUP_PROMPT.format(
                customer_query=customer_query,
                classification=classification,
                resolution=resolution,
                sentiment=sentiment,
                quality_score=quality_score
            )

            # Get follow-up recommendations from LLM
            logger.info("Determining follow-up actions")
            followup_result = self.llm_service.invoke_structured(prompt)

            follow_up_needed = followup_result.get("follow_up_needed", False)
            priority = followup_result.get("follow_up_priority", "low")

            logger.info(f"Follow-up needed: {follow_up_needed}, Priority: {priority}")

            if followup_result.get("suggested_actions"):
                logger.debug(f"Suggested actions: {followup_result['suggested_actions']}")

            return followup_result

        except Exception as e:
            logger.error(f"Error in follow-up agent: {str(e)}")
            # Return a default follow-up plan on error
            return self._get_default_followup()

    def _get_default_followup(self) -> Dict[str, Any]:
        """
        Get a default follow-up plan when analysis fails.

        Returns:
            Default follow-up recommendations
        """
        return {
            "follow_up_needed": True,
            "follow_up_priority": "medium",
            "suggested_actions": [
                "Monitor customer satisfaction",
                "Check if issue was resolved"
            ],
            "follow_up_timeline": "24h",
            "satisfaction_tracking": True,
            "proactive_measures": [],
            "additional_resources": [],
            "closure_status": "requires_monitoring",
            "follow_up_message": "Thank you for contacting support. Please let us know if you need any additional assistance."
        }

    def should_send_followup_message(
        self,
        followup_result: Dict[str, Any]
    ) -> bool:
        """
        Determine if a follow-up message should be sent immediately.

        Args:
            followup_result: Follow-up analysis results

        Returns:
            True if follow-up message should be sent now
        """
        timeline = followup_result.get("follow_up_timeline", "none")
        return timeline == "immediate" and followup_result.get("follow_up_message")

    def get_followup_summary(
        self,
        followup_result: Dict[str, Any]
    ) -> str:
        """
        Create a summary of follow-up actions for internal use.

        Args:
            followup_result: Follow-up analysis results

        Returns:
            Formatted summary string
        """
        lines = []
        lines.append("=== Follow-up Summary ===")
        lines.append(f"Follow-up Needed: {followup_result.get('follow_up_needed', 'Unknown')}")
        lines.append(f"Priority: {followup_result.get('follow_up_priority', 'Unknown')}")
        lines.append(f"Timeline: {followup_result.get('follow_up_timeline', 'Unknown')}")
        lines.append(f"Closure Status: {followup_result.get('closure_status', 'Unknown')}")

        actions = followup_result.get("suggested_actions", [])
        if actions:
            lines.append("\nSuggested Actions:")
            for action in actions:
                lines.append(f"  - {action}")

        measures = followup_result.get("proactive_measures", [])
        if measures:
            lines.append("\nProactive Measures:")
            for measure in measures:
                lines.append(f"  - {measure}")

        return "\n".join(lines)

    def append_followup_to_response(
        self,
        response: str,
        followup_result: Dict[str, Any]
    ) -> str:
        """
        Append follow-up information to the customer response if appropriate.

        Args:
            response: Original response
            followup_result: Follow-up analysis results

        Returns:
            Response with follow-up information appended if needed
        """
        # Add follow-up message if it should be sent immediately
        if self.should_send_followup_message(followup_result):
            followup_msg = followup_result.get("follow_up_message", "")
            if followup_msg:
                return f"{response}\n\n{followup_msg}"

        # Add resources if any
        resources = followup_result.get("additional_resources", [])
        if resources:
            resource_text = "\n\nAdditional Resources:\n" + "\n".join([f"- {r}" for r in resources])
            return response + resource_text

        return response
