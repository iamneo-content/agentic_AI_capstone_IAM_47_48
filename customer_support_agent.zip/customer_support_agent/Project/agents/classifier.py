"""
Classifier Agent for categorizing customer queries.

This agent analyzes the customer query and assigns it to the appropriate
category for handling.
"""

import logging
from typing import Dict, Any
from services.llm_service import get_llm_service
from utils.prompts import get_classifier_prompt
from utils.helpers import format_conversation_history

logger = logging.getLogger(__name__)


class ClassifierAgent:
    """
    Agent responsible for classifying customer queries into categories.

    The classifier agent examines the query and assigns it to one of the
    predefined categories: technical, billing, general, or complaint.
    """

    def __init__(self):
        """Initialize the classifier agent."""
        self.llm_service = get_llm_service()
        logger.info("ClassifierAgent initialized")

    def classify_query(
        self,
        customer_query: str,
        conversation_history: list,
        current_plan: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Classify the customer query into a category.

        Args:
            customer_query: The customer's question or issue
            conversation_history: Previous conversation messages
            current_plan: The execution plan from the planner

        Returns:
            Dictionary containing classification results with keys:
                - category: The assigned category
                - confidence: Confidence score (0.0 to 1.0)
                - reasoning: Explanation for the classification
                - key_topics: List of identified topics
        """
        try:
            # Format conversation history and plan
            history_str = format_conversation_history(conversation_history)
            plan_str = str(current_plan)

            # Generate the prompt
            prompt = get_classifier_prompt(customer_query, history_str, plan_str)

            # Get classification from LLM
            logger.info("Classifying customer query")
            classification = self.llm_service.invoke_structured(prompt)

            category = classification.get("category", "general")
            confidence = classification.get("confidence", 0.5)

            logger.info(f"Query classified as: {category} (confidence: {confidence:.2f})")
            logger.debug(f"Key topics: {classification.get('key_topics', [])}")

            # Validate the classification
            valid_categories = ["technical", "billing", "general", "complaint"]
            if category not in valid_categories:
                logger.warning(f"Invalid category '{category}', defaulting to 'general'")
                classification["category"] = "general"
                classification["confidence"] = 0.5

            # Ensure confidence is in valid range
            if not 0.0 <= confidence <= 1.0:
                logger.warning(f"Invalid confidence {confidence}, clamping to range")
                classification["confidence"] = max(0.0, min(1.0, confidence))

            return classification

        except Exception as e:
            logger.error(f"Error in classifier agent: {str(e)}")
            # Return a default classification on error
            return self._get_default_classification()

    def _get_default_classification(self) -> Dict[str, Any]:
        """
        Get a default classification to use when classification fails.

        Returns:
            Default classification
        """
        return {
            "category": "general",
            "confidence": 0.5,
            "reasoning": "Unable to classify query, using default category",
            "key_topics": []
        }

    def get_category_priority(self, category: str) -> str:
        """
        Determine the priority level for a category.

        Args:
            category: The category name

        Returns:
            Priority level (low, medium, high)
        """
        priority_map = {
            "complaint": "high",
            "billing": "high",
            "technical": "medium",
            "general": "low"
        }
        return priority_map.get(category, "medium")
