"""
Graph construction for the customer support multi-agent system.

This module creates and compiles the LangGraph StateGraph with all nodes,
edges, and routing logic.
"""

import logging
from typing import Optional
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from state import CustomerSupportState
from nodes import (
    planning_node, sentiment_node, analysis_node,
    resolution_node, qa_node, followup_node, human_node
)
from workflow.routing import (
    route_from_planning,
    should_continue_to_resolution,
    should_escalate
)
from services.memory_service import get_memory_service

logger = logging.getLogger(__name__)


def create_customer_support_graph(use_checkpointer: bool = True):
    """
    Create and compile the customer support workflow graph.

    This function constructs the complete LangGraph with:
    - All agent nodes (planning, sentiment, analysis, resolution, QA, followup, human)
    - Conditional routing logic
    - Human-in-the-loop checkpoints
    - Memory persistence

    Workflow:
        planning -> sentiment -> analysis -> resolution -> qa -> followup -> END
        (with conditional routing to escalate at various points)

    Args:
        use_checkpointer: Whether to use memory checkpointing (default: True)

    Returns:
        Compiled LangGraph instance
    """
    logger.info("Creating customer support workflow graph")

    # Create the StateGraph
    workflow = StateGraph(CustomerSupportState)

    # Add nodes to the graph
    # Note: Node names must not conflict with state keys
    logger.debug("Adding nodes to graph")
    workflow.add_node("plan", planning_node)
    workflow.add_node("sentiment", sentiment_node)
    workflow.add_node("classify", analysis_node)
    workflow.add_node("resolve", resolution_node)
    workflow.add_node("quality", qa_node)
    workflow.add_node("followup", followup_node)
    workflow.add_node("escalate", human_node)

    # Set the entry point
    workflow.set_entry_point("plan")

    # Add edges
    logger.debug("Adding edges to graph")

    # From plan: conditional routing to sentiment or escalation
    workflow.add_conditional_edges(
        "plan",
        route_from_planning,
        {
            "analysis": "sentiment",  # Go to sentiment first
            "escalate": "escalate"
        }
    )

    # From sentiment: always go to classify
    workflow.add_edge("sentiment", "classify")

    # From classify: always go to resolve
    workflow.add_edge("classify", "resolve")

    # From resolve: conditional routing to quality or escalation
    workflow.add_conditional_edges(
        "resolve",
        should_escalate,
        {
            "escalate": "escalate",
            "end": "quality"  # Go to quality instead of ending
        }
    )

    # From quality: always go to followup
    workflow.add_edge("quality", "followup")

    # From followup: always end
    workflow.add_edge("followup", END)

    # From escalate (human intervention): always end
    # The graph will be interrupted BEFORE this node to get human input
    workflow.add_edge("escalate", END)

    # Compile the graph
    logger.debug("Compiling graph")

    if use_checkpointer:
        # Get the memory service and checkpointer
        memory_service = get_memory_service()
        checkpointer = memory_service.get_checkpointer()

        # Compile with checkpointer and interrupts
        graph = workflow.compile(
            checkpointer=checkpointer,
            interrupt_before=["escalate"]  # Interrupt before human intervention
        )
    else:
        # Compile without checkpointer (for testing)
        graph = workflow.compile()

    logger.info("Graph compiled successfully")

    return graph


def visualize_graph(graph, output_path: str = "workflow_graph.png"):
    """
    Visualize the graph structure and save to a file.

    Args:
        graph: Compiled LangGraph instance
        output_path: Path to save the visualization

    Note:
        Requires graphviz to be installed
    """
    try:
        from IPython.display import Image
        import io

        # Get the graph visualization
        img_data = graph.get_graph().draw_mermaid_png()

        # Save to file
        with open(output_path, "wb") as f:
            f.write(img_data)

        logger.info(f"Graph visualization saved to {output_path}")
        return True

    except ImportError:
        logger.warning("IPython or graphviz not available, skipping visualization")
        return False
    except Exception as e:
        logger.error(f"Error creating visualization: {str(e)}")
        return False


# Create a singleton graph instance
_graph_instance = None


def get_graph(use_checkpointer: bool = True, force_recreate: bool = False):
    """
    Get or create the customer support graph singleton.

    Args:
        use_checkpointer: Whether to use memory checkpointing
        force_recreate: Force recreation of the graph

    Returns:
        Compiled LangGraph instance
    """
    global _graph_instance

    if _graph_instance is None or force_recreate:
        _graph_instance = create_customer_support_graph(use_checkpointer)

    return _graph_instance


if __name__ == "__main__":
    # Example: Create and visualize the graph
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    graph = create_customer_support_graph(use_checkpointer=False)
    print("Graph created successfully!")

    # Try to visualize
    visualize_graph(graph, "customer_support_workflow.png")
