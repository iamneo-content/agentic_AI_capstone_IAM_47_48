CUSTOMER SUPPORT MULTI-AGENT SYSTEM - PROBLEM DESCRIPTION
==========================================================

PROBLEM STATEMENT
=================

Modern customer support systems face several challenges:

1. High Volume of Queries - Support teams receive thousands of customer queries daily across multiple categories (technical, billing, general inquiries)

2. Inconsistent Response Quality - Different support agents provide varying levels of service quality and empathy

3. Slow Response Times - Manual processing of queries leads to delays and customer frustration

4. Lack of Sentiment Awareness - Traditional systems fail to detect customer emotions and adjust responses accordingly

5. Poor Escalation Management - Critical issues are not identified and escalated promptly to human agents

6. No Quality Control - Responses are sent without systematic quality assurance checks

SOLUTION OVERVIEW
=================

This project implements an intelligent multi-agent customer support system using LangGraph that:

- Automatically analyzes and categorizes customer queries
- Detects customer sentiment and urgency levels
- Generates contextual responses using AI agents
- Performs quality assurance on responses before delivery
- Intelligently escalates complex issues to human agents
- Maintains conversation history and state throughout the workflow
- Provides human-in-the-loop intervention capability


SYSTEM ARCHITECTURE
===================

The system uses a state-based workflow with 7 specialized AI agents:

1. PlannerAgent - Analyzes queries and creates execution plans
2. SentimentAgent - Detects customer emotions and urgency
3. ClassifierAgent - Categorizes queries into domains
4. ResolverAgent - Generates solutions using knowledge base
5. QualityAssuranceAgent - Reviews response quality
6. FollowUpAgent - Plans post-resolution actions
7. EscalationAgent - Handles human escalations

Workflow Flow:
Planning → Sentiment Analysis → Classification → Resolution → Quality Check → Follow-up → End
                                                    ↓
                                            Human Escalation (if needed)


FILE STRUCTURE
==============

customer_support_agent/
│
├── agents/
│   ├── planner.py
│   ├── sentiment.py
│   ├── classifier.py
│   ├── resolver.py
│   ├── quality_assurance.py
│   ├── followup.py
│   └── escalation.py
│
├── nodes/
│   ├── planning_node.py
│   ├── sentiment_node.py
│   ├── analysis_node.py
│   ├── resolution_node.py
│   ├── qa_node.py
│   ├── followup_node.py
│   └── human_node.py
│
├── services/
│   ├── llm_service.py
│   ├── memory_service.py
│   └── tools_service.py
│
├── utils/
│   ├── prompts.py
│   ├── validators.py
│   └── helpers.py
│
├── workflow/
│   └── routing.py
│
├── state.py
├── graph.py
├── main.py
├── tests.py
├── .env
├── requirements.txt
├── README.md
├── TEST_GUIDE.md
└── TEST_SUMMARY.md


DETAILED FILE DESCRIPTIONS
===========================

CORE FILES
----------

1. state.py
   Purpose: Defines the application state structure

   Key Components:
   - CustomerSupportState (TypedDict)
     Fields: customer_query, thread_id, current_node, classification, sentiment_analysis,
             resolution, qa_result, quality_score, followup_plan, escalation_needed,
             escalation_reason, conversation_history, metadata, error

   - create_initial_state(customer_query: str, thread_id: str) -> CustomerSupportState
     Parameters:
       - customer_query: The customer's question or issue
       - thread_id: Unique identifier for the conversation
     Returns: Initialized state dictionary

   - update_conversation_history(state: CustomerSupportState, role: str, content: str) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
       - role: Message sender (customer/agent/system/human_agent)
       - content: Message content
     Returns: Updated state with new message


2. graph.py
   Purpose: Constructs the LangGraph workflow

   Key Methods:
   - create_customer_support_graph(use_checkpointer: bool = True) -> CompiledGraph
     Parameters:
       - use_checkpointer: Enable conversation persistence
     Returns: Compiled LangGraph workflow

   - get_graph() -> CompiledGraph
     Parameters: None
     Returns: Singleton graph instance


3. main.py
   Purpose: CLI interface for the application

   Key Functions:
   - run_customer_support_system()
     Parameters: None
     Returns: None
     Description: Main entry point, handles user interaction

   - display_welcome_screen()
     Parameters: None
     Returns: None
     Description: Shows welcome message and instructions


AGENT FILES
-----------

1. agents/planner.py
   Purpose: Analyzes customer queries and creates execution plans

   Class: PlannerAgent

   Methods:
   - analyze_and_plan(customer_query: str, conversation_history: list) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - conversation_history: Previous messages
     Returns: Dictionary with analysis, complexity, recommended_flow, special_notes

   - should_escalate_immediately(customer_query: str) -> bool
     Parameters:
       - customer_query: The customer's question
     Returns: True if urgent keywords detected


2. agents/sentiment.py
   Purpose: Analyzes customer emotions and urgency

   Class: SentimentAgent

   Methods:
   - analyze_sentiment(customer_query: str, conversation_history: list) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - conversation_history: Previous messages
     Returns: Dictionary with primary_sentiment, sentiment_score, urgency_level,
              emotion_triggers, customer_state, response_recommendations, empathy_level_needed

   - should_escalate_based_on_sentiment(sentiment_analysis: Dict[str, Any]) -> bool
     Parameters:
       - sentiment_analysis: Result from analyze_sentiment
     Returns: True if escalation needed based on sentiment


3. agents/classifier.py
   Purpose: Categorizes customer queries

   Class: ClassifierAgent

   Methods:
   - classify_query(customer_query: str, conversation_history: list, current_plan: Dict[str, Any]) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - conversation_history: Previous messages
       - current_plan: Execution plan from planner
     Returns: Dictionary with category, confidence, reasoning, key_topics


4. agents/resolver.py
   Purpose: Generates solutions using knowledge base

   Class: ResolverAgent

   Methods:
   - resolve_query(customer_query: str, classification: str, confidence: float,
                   conversation_history: list, resolution_attempts: int = 0) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - classification: Category from classifier
       - confidence: Classification confidence score
       - conversation_history: Previous messages
       - resolution_attempts: Number of previous attempts
     Returns: Dictionary with resolution, confidence, needs_escalation, escalation_reason, follow_up_questions

   - enhance_resolution_with_empathy(resolution: str, category: str) -> str
     Parameters:
       - resolution: Original response text
       - category: Query category
     Returns: Enhanced response with empathetic language


5. agents/quality_assurance.py
   Purpose: Reviews response quality before delivery

   Class: QualityAssuranceAgent

   Methods:
   - review_response(customer_query: str, classification: str, proposed_response: str,
                     sentiment_analysis: Dict[str, Any]) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - classification: Query category
       - proposed_response: Generated response
       - sentiment_analysis: Customer sentiment data
     Returns: Dictionary with quality_score, is_approved, accuracy_check, relevance_check,
              tone_check, completeness_check, improvement_suggestions


6. agents/followup.py
   Purpose: Plans post-resolution actions

   Class: FollowUpAgent

   Methods:
   - determine_followup(customer_query: str, classification: str, resolution: str,
                        sentiment_analysis: Dict[str, Any], quality_score: float) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - classification: Query category
       - resolution: Final response
       - sentiment_analysis: Customer sentiment data
       - quality_score: QA score
     Returns: Dictionary with follow_up_needed, priority, timeline, suggested_actions,
              satisfaction_survey, documentation_needed


7. agents/escalation.py
   Purpose: Handles human agent escalations

   Class: EscalationAgent

   Methods:
   - prepare_escalation(customer_query: str, classification: str, previous_resolution: str,
                        escalation_reason: str, conversation_history: list) -> Dict[str, Any]
     Parameters:
       - customer_query: The customer's question
       - classification: Query category
       - previous_resolution: Previous resolution attempt
       - escalation_reason: Why escalation is needed
       - conversation_history: Previous messages
     Returns: Dictionary with ticket_id, summary_for_human, specific_question, customer_impact,
              suggested_actions, context_for_human

   - process_human_feedback(human_feedback: str, escalation_info: Dict[str, Any]) -> Dict[str, Any]
     Parameters:
       - human_feedback: Response from human agent
       - escalation_info: Escalation context
     Returns: Dictionary with final_response, resolution_summary


NODE FILES
----------

1. nodes/planning_node.py
   Purpose: Executes planning phase

   Function:
   - planning_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with planning information


2. nodes/sentiment_node.py
   Purpose: Executes sentiment analysis phase

   Function:
   - sentiment_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with sentiment analysis


3. nodes/analysis_node.py
   Purpose: Executes classification phase

   Function:
   - analysis_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with classification


4. nodes/resolution_node.py
   Purpose: Executes resolution generation phase

   Function:
   - resolution_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with resolution


5. nodes/qa_node.py
   Purpose: Executes quality assurance phase

   Function:
   - qa_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with QA results


6. nodes/followup_node.py
   Purpose: Executes follow-up planning phase

   Function:
   - followup_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with follow-up plan


7. nodes/human_node.py
   Purpose: Handles human escalation

   Function:
   - human_node(state: CustomerSupportState) -> CustomerSupportState
     Parameters:
       - state: Current workflow state
     Returns: Updated state with escalation info or human feedback processing


SERVICE FILES
-------------

1. services/llm_service.py
   Purpose: Manages LLM interactions with Google Gemini API

   Class: LLMService

   Methods:
   - __init__(model_name: str = "gemini-2.5-flash-lite", temperature: float = 0.7,
              max_retries: int = 3, timeout: int = 60)
     Parameters:
       - model_name: Gemini model identifier
       - temperature: Response randomness (0.0-1.0)
       - max_retries: Retry attempts on failure
       - timeout: Request timeout in seconds

   - invoke_structured(prompt: str, max_tokens: int = 2000) -> Dict[str, Any]
     Parameters:
       - prompt: Input prompt for LLM
       - max_tokens: Maximum response length
     Returns: Structured response dictionary

   - get_llm_service() -> LLMService
     Parameters: None
     Returns: Singleton LLM service instance


2. services/memory_service.py
   Purpose: Manages conversation persistence

   Functions:
   - get_memory_service() -> MemorySaver
     Parameters: None
     Returns: LangGraph memory checkpointer


3. services/tools_service.py
   Purpose: Provides external tools (knowledge base, ticketing)

   Class: ToolsService

   Methods:
   - search_knowledge_base(query: str, category: str = None, limit: int = 5) -> List[Dict[str, Any]]
     Parameters:
       - query: Search query
       - category: Filter by category
       - limit: Maximum results
     Returns: List of knowledge base articles

   - create_support_ticket(customer_query: str, classification: str, priority: str) -> Dict[str, Any]
     Parameters:
       - customer_query: Customer's question
       - classification: Query category
       - priority: Urgency level
     Returns: Ticket details with ticket_id

   - notify_human_agent(ticket_id: str, summary: str, urgency: str) -> bool
     Parameters:
       - ticket_id: Support ticket ID
       - summary: Issue summary
       - urgency: Priority level
     Returns: Success status


WORKFLOW FILES
--------------

1. workflow/routing.py
   Purpose: Defines conditional routing logic

   Functions:
   - route_from_planning(state: CustomerSupportState) -> Literal["analysis", "escalate"]
     Parameters:
       - state: Current workflow state
     Returns: Next node destination

   - should_continue_to_resolution(state: CustomerSupportState) -> Literal["resolution", "end"]
     Parameters:
       - state: Current workflow state
     Returns: Next node destination

   - should_escalate(state: CustomerSupportState) -> Literal["escalate", "end"]
     Parameters:
       - state: Current workflow state
     Returns: Next node destination

   - needs_human_feedback(state: CustomerSupportState) -> bool
     Parameters:
       - state: Current workflow state
     Returns: True if human intervention needed

   - route_after_human(state: CustomerSupportState) -> Literal["end"]
     Parameters:
       - state: Current workflow state
     Returns: Always "end"


UTILITY FILES
-------------

1. utils/prompts.py
   Purpose: Stores all LLM prompts

   Functions:
   - get_planner_prompt(customer_query: str, conversation_history: str) -> str
   - get_sentiment_prompt(customer_query: str, conversation_history: str) -> str
   - get_classifier_prompt(customer_query: str, conversation_history: str, plan: str) -> str
   - get_resolver_prompt(customer_query: str, classification: str, confidence: float,
                         conversation_history: str, resolution_attempts: int, knowledge_base_context: str) -> str
   - get_qa_prompt(customer_query: str, classification: str, proposed_response: str,
                   sentiment_analysis: str) -> str
   - get_followup_prompt(customer_query: str, classification: str, resolution: str,
                         sentiment_analysis: str, quality_score: float) -> str
   - get_escalation_prompt(customer_query: str, classification: str, previous_resolution: str,
                           escalation_reason: str, conversation_history: str) -> str


2. utils/validators.py
   Purpose: Input validation functions

   Functions:
   - validate_customer_query(query: str) -> Tuple[bool, str]
     Parameters:
       - query: Customer input
     Returns: (is_valid, error_message)

   - validate_thread_id(thread_id: str) -> bool
     Parameters:
       - thread_id: Conversation identifier
     Returns: True if valid format


3. utils/helpers.py
   Purpose: Common helper functions

   Functions:
   - format_conversation_history(history: list) -> str
     Parameters:
       - history: List of conversation messages
     Returns: Formatted string for LLM prompts

   - extract_metadata(state: CustomerSupportState, key: str) -> Any
     Parameters:
       - state: Current workflow state
       - key: Metadata key to extract
     Returns: Metadata value or None


CONFIGURATION FILES
-------------------

1. .env
   Purpose: Environment variables configuration

   Variables:
   - GOOGLE_API_KEY: Google Gemini API key
   - LLM_MODEL: Model name (gemini-2.5-flash-lite)
   - LLM_TEMPERATURE: Response randomness (0.7)
   - LLM_MAX_TOKENS: Maximum response tokens (2000)
   - LOG_LEVEL: Logging verbosity (INFO)


2. requirements.txt
   Purpose: Python package dependencies

   Core Dependencies:
   - langgraph>=0.2.0
   - langchain>=0.3.0
   - langchain-core>=0.3.0
   - langchain-google-genai>=2.0.0
   - google-generativeai>=0.8.0
   - python-dotenv>=1.0.0
   - colorama>=0.4.6
   - typing-extensions>=4.8.0
   - pytest>=7.4.0
   - pytest-mock>=3.12.0


TEST FILES
----------

1. tests.py
   Purpose: Comprehensive test suite with 15 test cases

   Test Categories:
   - Agent Tests (6): test_planner_agent_simple_query, test_sentiment_agent_frustrated_customer,
                      test_classifier_agent_technical_query, test_resolver_agent_with_knowledge_base,
                      test_qa_agent_approve_quality_response, test_escalation_agent_prepare_escalation

   - Node Tests (5): test_planning_node_success, test_sentiment_node_success,
                     test_resolution_node_success, test_qa_node_approve, test_human_node_prepare_escalation

   - Graph Tests (2): test_create_graph_without_checkpointer, test_graph_execution_simple_workflow

   - Workflow Tests (2): test_route_from_planning_to_analysis, test_should_escalate_after_resolution

   Fixtures:
   - mock_llm_service(): Mocks LLM service across all agents
   - sample_state(): Creates test state instance


INSTALLATION AND SETUP
=======================

Step 1: Install Dependencies
-----------------------------
    pip install -r requirements.txt


Step 2: Configure Environment
------------------------------
Create .env file with:
    GOOGLE_API_KEY=your_actual_api_key_here
    LLM_MODEL=gemini-2.5-flash-lite
    LLM_TEMPERATURE=0.7

RUNNING THE APPLICATION
========================

Command 1: Start Customer Support System
-----------------------------------------
    python3 main.py

Expected Behavior:
- Displays welcome screen with system information
- Shows available commands
- Prompts for customer query input


Command 2: Run All Tests
-------------------------
    python3 -m pytest tests.py -v

SAMPLE APPLICATION OUTPUT
==========================

Example 1: Simple Technical Query
----------------------------------

User Input:
    I can't log in to my account

System Processing Flow:
    Step 1 - Planning Node
    Analysis: Simple login issue
    Complexity: simple
    Recommended flow: classifier, resolver

    Step 2 - Sentiment Analysis Node
    Primary sentiment: neutral
    Urgency level: medium
    Sentiment score: 0.0

    Step 3 - Classification Node
    Category: technical
    Subcategory: account_access
    Confidence: 0.95

    Step 4 - Resolution Node
    Searching knowledge base for solutions...
    Found 2 relevant articles
    Generating resolution...

    Step 5 - Quality Assurance Node
    Quality score: 0.92
    Status: APPROVED
    Accuracy: High
    Tone: Appropriate

    Step 6 - Follow-up Node
    Follow-up needed: Yes
    Timeline: 24 hours
    Suggested actions: Check if issue resolved

Final Response:
    I understand technical issues can be frustrating. To resolve your login issue,
    please try the following steps:

    1. Click on "Forgot Password" on the login page
    2. Enter your registered email address
    3. Check your email for a password reset link
    4. Create a new password following the security requirements
    5. Try logging in with your new password

    If you continue to experience issues, please clear your browser cache and try again.

    We'll follow up with you in 24 hours to ensure this resolved your issue.


Example 2: Urgent Escalation Query
-----------------------------------

User Input:
    This is URGENT! I've been charged twice for my subscription and need an immediate refund!

System Processing Flow:
    Step 1 - Planning Node
    URGENT keyword detected
    Immediate escalation triggered
    Escalation reason: Urgent keywords detected in query

    Step 2 - Sentiment Analysis Node
    Primary sentiment: frustrated
    Urgency level: critical
    Sentiment score: -0.8
    Escalation recommended: Yes

    Step 3 - Human Escalation Node
    Creating support ticket...
    Ticket ID: TICKET-78945
    Notifying human agent...
    Priority: HIGH

Escalation Summary for Human Agent:
    Customer Impact: HIGH
    Issue: Billing error - duplicate charge
    Sentiment: Frustrated and urgent

    Suggested Actions:
    1. Verify duplicate charge in billing system
    2. Process immediate refund if confirmed
    3. Apply courtesy credit for inconvenience
    4. Contact customer within 1 hour

    Context:
    - Customer explicitly requested urgency
    - Billing issues have high churn risk
    - No previous resolution attempts


Example 3: Follow-up Planning Query
------------------------------------

User Input:
    How do I update my payment method?

System Processing Flow:
    Step 1 - Planning Node
    Analysis: Payment method update request
    Complexity: simple

    Step 2 - Sentiment Analysis Node
    Primary sentiment: neutral
    Urgency level: low

    Step 3 - Classification Node
    Category: billing
    Subcategory: payment_methods
    Confidence: 0.89

    Step 4 - Resolution Node
    Resolution: Step-by-step payment update guide
    Confidence: 0.95

    Step 5 - Quality Assurance Node
    Quality score: 0.94
    Status: APPROVED

    Step 6 - Follow-up Node
    Follow-up needed: Yes
    Priority: medium
    Timeline: 48 hours
    Suggested actions: Verify payment method updated successfully
    Satisfaction survey: Yes

Final Response:
    Thank you for reaching out. To update your payment method, please follow these steps:

    1. Log in to your account
    2. Navigate to Settings > Billing
    3. Click "Update Payment Method"
    4. Enter your new card details
    5. Click "Save Changes"

    Your new payment method will be used for all future charges.

    We'll send you a satisfaction survey in 48 hours to ensure everything is working smoothly.