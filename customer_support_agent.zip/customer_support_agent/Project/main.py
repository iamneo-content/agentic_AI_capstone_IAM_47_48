"""
Main CLI interface for the customer support multi-agent system.

This module provides an interactive command-line interface for testing
and demonstrating the customer support workflow.
"""

import os
import sys
import logging
import uuid
from typing import Optional
from datetime import datetime
from dotenv import load_dotenv

# Add the parent directory to the path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from state import create_initial_state, CustomerSupportState
from graph import get_graph
from utils.validators import validate_customer_query, sanitize_input

# Try to import colorama for colored output (optional)
try:
    from colorama import init, Fore, Style, Back
    init(autoreset=True)
    COLORS_AVAILABLE = True
except ImportError:
    COLORS_AVAILABLE = False
    # Fallback: create dummy color objects
    class DummyColor:
        def __getattr__(self, name):
            return ""
    Fore = Style = Back = DummyColor()


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('customer_support.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class CustomerSupportCLI:
    """
    Command-line interface for the customer support system.

    This class provides methods for interactive conversation with
    the multi-agent support system.
    """

    def __init__(self):
        """Initialize the CLI."""
        # Load environment variables
        load_dotenv()

        # Check for required environment variables
        if not os.getenv("GOOGLE_API_KEY"):
            print(f"{Fore.RED}Error: GOOGLE_API_KEY not found in environment variables{Style.RESET_ALL}")
            print("Please create a .env file with your Google API key")
            sys.exit(1)

        # Initialize the graph
        self.graph = get_graph(use_checkpointer=True)

        # Session management
        self.current_thread_id: Optional[str] = None
        self.session_active = False

        logger.info("Customer Support CLI initialized")

    def print_header(self):
        """Print the CLI header."""
        print("\n" + "=" * 70)
        print(f"{Fore.CYAN}{Style.BRIGHT}Customer Support Multi-Agent System{Style.RESET_ALL}")
        print("=" * 70)
        print(f"\n{Fore.GREEN}Welcome! I'm here to help with your questions and issues.{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}Commands:{Style.RESET_ALL}")
        print("  - Type your question or issue to get help")
        print("  - Type 'exit' or 'quit' to end the session")
        print("  - Type 'new' to start a new conversation")
        print("  - Type 'help' for more information")
        print("=" * 70 + "\n")

    def print_agent_info(self, node: str, message: str):
        """Print agent activity information."""
        icons = {
            "planning": "📋",
            "sentiment": "😊",
            "analysis": "🔍",
            "resolution": "💡",
            "qa": "✅",
            "followup": "📌",
            "human_intervention": "👤"
        }
        icon = icons.get(node, "🤖")

        print(f"\n{Fore.BLUE}{icon} {node.upper().replace('_', ' ')}: {Fore.WHITE}{message}{Style.RESET_ALL}")

    def print_response(self, response: str, is_final: bool = False):
        """Print the agent's response."""
        if is_final:
            print(f"\n{Fore.GREEN}{Style.BRIGHT}{'─' * 70}{Style.RESET_ALL}")
            print(f"{Fore.GREEN}{Style.BRIGHT}Response:{Style.RESET_ALL}")
            print(f"{Fore.WHITE}{response}{Style.RESET_ALL}")
            print(f"{Fore.GREEN}{Style.BRIGHT}{'─' * 70}{Style.RESET_ALL}\n")
        else:
            print(f"{Fore.WHITE}{response}{Style.RESET_ALL}")

    def print_error(self, error: str):
        """Print an error message."""
        print(f"\n{Fore.RED}❌ Error: {error}{Style.RESET_ALL}\n")

    def get_user_input(self, prompt: str = "You") -> str:
        """Get input from the user."""
        try:
            user_input = input(f"{Fore.CYAN}{prompt}:{Style.RESET_ALL} ").strip()
            return sanitize_input(user_input)
        except KeyboardInterrupt:
            print(f"\n{Fore.YELLOW}Session interrupted by user{Style.RESET_ALL}")
            sys.exit(0)
        except EOFError:
            return "exit"

    def handle_command(self, command: str) -> bool:
        """
        Handle special commands.

        Args:
            command: User command

        Returns:
            True if command was handled, False otherwise
        """
        command = command.lower()

        if command in ["exit", "quit"]:
            print(f"\n{Fore.YELLOW}Thank you for using Customer Support! Goodbye.{Style.RESET_ALL}\n")
            return True

        if command == "new":
            self.current_thread_id = None
            self.session_active = False
            print(f"\n{Fore.GREEN}✓ Started new conversation{Style.RESET_ALL}\n")
            return True

        if command == "help":
            self.print_help()
            return True

        return False

    def print_help(self):
        """Print help information."""
        print(f"\n{Fore.CYAN}{Style.BRIGHT}Help - Customer Support System{Style.RESET_ALL}")
        print("=" * 70)
        print(f"\n{Fore.YELLOW}How it works:{Style.RESET_ALL}")
        print("  1. Enter your question or describe your issue")
        print("  2. The system will analyze and classify your query")
        print("  3. Multiple AI agents will work together to help you")
        print("  4. If needed, a human agent will be brought in")
        print(f"\n{Fore.YELLOW}Available commands:{Style.RESET_ALL}")
        print("  exit/quit - End the session")
        print("  new       - Start a new conversation")
        print("  help      - Show this help message")
        print(f"\n{Fore.YELLOW}Example queries:{Style.RESET_ALL}")
        print("  - I can't log in to my account")
        print("  - How do I request a refund?")
        print("  - The application is running very slowly")
        print("  - I want to cancel my subscription")
        print("=" * 70 + "\n")

    def process_query(self, query: str):
        """
        Process a customer query through the workflow.

        Args:
            query: Customer query string
        """
        # Validate query
        is_valid, error_msg = validate_customer_query(query)
        if not is_valid:
            self.print_error(error_msg)
            return

        # Generate thread ID if needed
        if not self.current_thread_id:
            self.current_thread_id = f"thread_{uuid.uuid4().hex[:8]}"
            logger.info(f"New thread created: {self.current_thread_id}")

        # Create initial state
        initial_state = create_initial_state(query, self.current_thread_id)

        # Configuration for graph execution
        config = {
            "configurable": {
                "thread_id": self.current_thread_id
            }
        }

        try:
            print(f"\n{Fore.YELLOW}Processing your request...{Style.RESET_ALL}")

            # Stream the graph execution
            for event in self.graph.stream(initial_state, config, stream_mode="values"):
                self._handle_event(event)

            # Check if we need to resume after human intervention
            state = self.graph.get_state(config)

            if state.next and "escalate" in state.next:
                # We're interrupted before human intervention
                self._handle_human_intervention(config)

        except Exception as e:
            logger.error(f"Error processing query: {str(e)}", exc_info=True)
            self.print_error(f"An error occurred: {str(e)}")

    def _handle_event(self, event: CustomerSupportState):
        """
        Handle a state update event from the graph.

        Args:
            event: Current state
        """
        current_node = event.get("current_node")

        if current_node == "planning":
            plan = event.get("current_plan", {})
            self.print_agent_info("planning", f"Analyzing query (complexity: {plan.get('complexity', 'unknown')})")

        elif current_node == "sentiment_analysis":
            sentiment = event.get("sentiment_analysis", {})
            primary_sentiment = sentiment.get("primary_sentiment", "unknown")
            urgency = sentiment.get("urgency_level", "unknown")
            self.print_agent_info("sentiment", f"Sentiment: {primary_sentiment} (urgency: {urgency})")

        elif current_node == "analysis":
            classification = event.get("classification", "unknown")
            confidence = event.get("classification_confidence", 0.0)
            self.print_agent_info("analysis", f"Classified as: {classification} (confidence: {confidence:.2f})")

        elif current_node == "resolution":
            if event.get("escalation_needed"):
                self.print_agent_info("resolution", "Escalation needed, preparing for human agent")
            else:
                attempts = event.get("resolution_attempts", 0)
                self.print_agent_info("resolution", f"Generating solution (attempt {attempts})")

        elif current_node == "quality_assurance":
            qa_result = event.get("qa_result", {})
            quality_score = qa_result.get("quality_score", 0.0)
            is_approved = qa_result.get("is_approved", False)
            self.print_agent_info("qa", f"Quality score: {quality_score:.2f}, Approved: {is_approved}")

        elif current_node == "followup":
            followup = event.get("followup_plan", {})
            follow_up_needed = followup.get("follow_up_needed", False)
            priority = followup.get("follow_up_priority", "unknown")
            self.print_agent_info("followup", f"Follow-up: {follow_up_needed} (priority: {priority})")

        # Check for final response (only print at the end of workflow)
        if current_node == "followup" and event.get("final_response") and not event.get("escalation_needed"):
            self.print_response(event["final_response"], is_final=True)

    def _handle_human_intervention(self, config: dict):
        """
        Handle human intervention workflow.

        Args:
            config: Graph execution configuration
        """
        # Get current state
        state = self.graph.get_state(config)
        current_state = state.values

        # Get the human prompt from metadata
        human_prompt = current_state.get("metadata", {}).get("human_prompt", "")

        if human_prompt:
            print(f"\n{Fore.YELLOW}{human_prompt}{Style.RESET_ALL}")
        else:
            print(f"\n{Fore.YELLOW}Human intervention needed. Please provide your response:{Style.RESET_ALL}")

        # Get human feedback
        feedback = self.get_user_input("Human Agent")

        if not feedback or feedback.lower() in ["exit", "quit"]:
            print(f"{Fore.YELLOW}Escalation cancelled{Style.RESET_ALL}")
            return

        # Update state with human feedback
        current_state["human_feedback"] = feedback

        # Resume the graph
        print(f"\n{Fore.YELLOW}Processing human feedback...{Style.RESET_ALL}")

        for event in self.graph.stream(None, config, stream_mode="values"):
            if event.get("final_response"):
                self.print_response(event["final_response"], is_final=True)

    def run(self):
        """Run the interactive CLI."""
        self.print_header()

        while True:
            # Get user input
            user_input = self.get_user_input()

            if not user_input:
                continue

            # Check for commands
            if self.handle_command(user_input):
                if user_input.lower() in ["exit", "quit"]:
                    break
                continue

            # Process the query
            self.process_query(user_input)


def main():
    """Main entry point for the CLI."""
    try:
        cli = CustomerSupportCLI()
        cli.run()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Session interrupted. Goodbye!{Style.RESET_ALL}\n")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        print(f"\n{Fore.RED}An unexpected error occurred. Please check the logs.{Style.RESET_ALL}\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
