"""
State schema for the customer support multi-agent system.

This module defines the state structure that flows through the LangGraph workflow.
The state is updated by each node and persists across the entire conversation.
"""

from typing import TypedDict, List, Optional, Dict, Any
from datetime import datetime


class CustomerSupportState(TypedDict, total=False):
    """
    State schema for the customer support workflow.

    Attributes:
        customer_query: The original customer question/issue
        conversation_history: List of all messages exchanged
        current_plan: The execution plan created by the planner agent
        classification: Category of the customer query (technical, billing, general, complaint)
        classification_confidence: Confidence score for the classification
        resolution: The proposed solution or response
        resolution_attempts: Number of times resolution was attempted
        escalation_needed: Flag indicating if human intervention is required
        escalation_reason: Reason for escalation
        human_feedback: Feedback provided by human agent
        sentiment_analysis: Results from sentiment analysis agent
        qa_result: Results from quality assurance review
        quality_score: Quality score of the response
        followup_plan: Follow-up actions and recommendations
        final_response: The final response to be delivered to customer
        metadata: Additional context and tracking information
        error: Any error that occurred during processing
        current_node: Current node being executed (for debugging)
        thread_id: Unique identifier for this conversation thread
        timestamp: Timestamp of the current state update
    """

    # Core query and response
    customer_query: str
    conversation_history: List[Dict[str, str]]
    final_response: Optional[str]

    # Planning and execution
    current_plan: Optional[Dict[str, Any]]
    current_node: Optional[str]

    # Classification
    classification: Optional[str]
    classification_confidence: Optional[float]

    # Resolution
    resolution: Optional[str]
    resolution_attempts: int

    # Escalation
    escalation_needed: bool
    escalation_reason: Optional[str]
    human_feedback: Optional[str]

    # Sentiment Analysis
    sentiment_analysis: Optional[Dict[str, Any]]

    # Quality Assurance
    qa_result: Optional[Dict[str, Any]]
    quality_score: Optional[float]

    # Follow-up
    followup_plan: Optional[Dict[str, Any]]

    # Metadata and tracking
    metadata: Dict[str, Any]
    error: Optional[str]
    thread_id: Optional[str]
    timestamp: Optional[str]


def create_initial_state(customer_query: str, thread_id: Optional[str] = None) -> CustomerSupportState:
    """
    Create an initial state for a new customer support interaction.

    Args:
        customer_query: The customer's question or issue
        thread_id: Optional thread identifier for conversation continuity

    Returns:
        CustomerSupportState: Initialized state object
    """
    return CustomerSupportState(
        customer_query=customer_query,
        conversation_history=[
            {
                "role": "customer",
                "content": customer_query,
                "timestamp": datetime.now().isoformat()
            }
        ],
        final_response=None,
        current_plan=None,
        current_node="start",
        classification=None,
        classification_confidence=None,
        resolution=None,
        resolution_attempts=0,
        escalation_needed=False,
        escalation_reason=None,
        human_feedback=None,
        sentiment_analysis=None,
        qa_result=None,
        quality_score=None,
        followup_plan=None,
        metadata={
            "started_at": datetime.now().isoformat(),
            "source": "cli"
        },
        error=None,
        thread_id=thread_id,
        timestamp=datetime.now().isoformat()
    )


def update_conversation_history(
    state: CustomerSupportState,
    role: str,
    content: str
) -> CustomerSupportState:
    """
    Add a message to the conversation history.

    Args:
        state: Current state
        role: Role of the speaker (customer, agent, system)
        content: Message content

    Returns:
        Updated state with new message in history
    """
    state["conversation_history"].append({
        "role": role,
        "content": content,
        "timestamp": datetime.now().isoformat()
    })
    state["timestamp"] = datetime.now().isoformat()
    return state
