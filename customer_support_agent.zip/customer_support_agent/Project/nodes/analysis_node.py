"""
Analysis Node for the customer support workflow.

This node uses the ClassifierAgent to categorize customer queries.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.classifier import ClassifierAgent

logger = logging.getLogger(__name__)


def analysis_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the analysis/classification phase of the workflow.

    This node classifies the customer query into a category to help
    route it appropriately and provide context-aware responses.

    Args:
        state: Current workflow state

    Returns:
        Updated state with classification information
    """
    logger.info("=== ANALYSIS NODE ===")

    # Update current node
    state["current_node"] = "analysis"

    try:
        # Initialize the classifier agent
        classifier = ClassifierAgent()

        # Get required information from state
        customer_query = state["customer_query"]
        conversation_history = state.get("conversation_history", [])
        current_plan = state.get("current_plan", {})

        logger.info("Classifying customer query")

        # Classify the query
        classification = classifier.classify_query(
            customer_query=customer_query,
            conversation_history=conversation_history,
            current_plan=current_plan
        )

        # Update state with classification results
        state["classification"] = classification.get("category", "general")
        state["classification_confidence"] = classification.get("confidence", 0.5)

        # Store full classification in metadata
        if "metadata" not in state:
            state["metadata"] = {}
        state["metadata"]["classification_details"] = classification

        logger.info(
            f"Query classified as: {state['classification']} "
            f"(confidence: {state['classification_confidence']:.2f})"
        )
        logger.debug(f"Key topics: {classification.get('key_topics', [])}")

        # Add classification to conversation history
        state = update_conversation_history(
            state,
            role="system",
            content=f"Query classified as: {state['classification']} "
                   f"(confidence: {state['classification_confidence']:.2f})"
        )

        # Determine priority based on category
        priority = classifier.get_category_priority(state['classification'])
        state["metadata"]["priority"] = priority
        logger.debug(f"Priority level: {priority}")

    except Exception as e:
        logger.error(f"Error in analysis node: {str(e)}")
        state["error"] = f"Classification error: {str(e)}"
        # Set default classification to allow workflow to continue
        state["classification"] = "general"
        state["classification_confidence"] = 0.5

    return state
