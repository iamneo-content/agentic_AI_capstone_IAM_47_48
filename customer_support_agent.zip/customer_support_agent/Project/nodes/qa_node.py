"""
Quality Assurance Node for the customer support workflow.

This node uses the QualityAssuranceAgent to review responses before delivery.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.quality_assurance import QualityAssuranceAgent

logger = logging.getLogger(__name__)


def qa_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the quality assurance phase of the workflow.

    This node reviews the proposed response to ensure it meets quality
    standards before being sent to the customer.

    Args:
        state: Current workflow state

    Returns:
        Updated state with QA results and possibly improved response
    """
    logger.info("=== QUALITY ASSURANCE NODE ===")

    # Update current node
    state["current_node"] = "quality_assurance"

    try:
        # Initialize the QA agent
        qa_agent = QualityAssuranceAgent()

        # Get required information from state
        customer_query = state["customer_query"]
        classification = state.get("classification", "general")
        proposed_response = state.get("resolution", "")
        sentiment_analysis = state.get("sentiment_analysis", {})

        if not proposed_response:
            logger.warning("No resolution available for QA review")
            return state

        logger.info("Performing quality assurance review")

        # Review the response
        qa_result = qa_agent.review_response(
            customer_query=customer_query,
            classification=classification,
            proposed_response=proposed_response,
            sentiment_analysis=sentiment_analysis
        )

        # Update state with QA results
        state["qa_result"] = qa_result
        state["quality_score"] = qa_result.get("quality_score", 0.7)

        quality_score = qa_result.get("quality_score", 0.0)
        is_approved = qa_result.get("is_approved", False)
        needs_revision = qa_result.get("needs_revision", False)

        logger.info(f"QA Score: {quality_score:.2f}, Approved: {is_approved}")

        # If QA suggests improvements, use them
        final_response = qa_agent.get_final_response(qa_result, proposed_response)
        state["resolution"] = final_response

        # If not approved or needs revision, flag for potential escalation
        if not is_approved or needs_revision:
            logger.warning("Response did not pass QA review")
            issues = qa_result.get("issues_found", [])
            if issues:
                logger.warning(f"Issues found: {issues}")

            # Low quality might require escalation
            if quality_score < 0.5:
                state["metadata"]["qa_escalation_flag"] = True

        # Store QA details in metadata
        if "metadata" not in state:
            state["metadata"] = {}

        state["metadata"]["qa_details"] = {
            "quality_score": quality_score,
            "is_approved": is_approved,
            "issues_count": len(qa_result.get("issues_found", [])),
            "checks": {
                "accuracy": qa_result.get("accuracy_check", "unknown"),
                "relevance": qa_result.get("relevance_check", "unknown"),
                "tone": qa_result.get("tone_check", "unknown"),
                "clarity": qa_result.get("clarity_check", "unknown")
            }
        }

        # Add QA result to conversation history
        state = update_conversation_history(
            state,
            role="system",
            content=f"QA review: quality={quality_score:.2f}, approved={is_approved}"
        )

    except Exception as e:
        logger.error(f"Error in QA node: {str(e)}")
        state["error"] = f"QA error: {str(e)}"
        # Set default QA result to allow workflow to continue
        state["qa_result"] = {
            "quality_score": 0.7,
            "is_approved": True,
            "needs_revision": False
        }
        state["quality_score"] = 0.7

    return state
