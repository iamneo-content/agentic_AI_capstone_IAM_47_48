"""
Sentiment Analysis Node for the customer support workflow.

This node uses the SentimentAgent to analyze customer emotions and sentiment.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.sentiment import SentimentAgent

logger = logging.getLogger(__name__)


def sentiment_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the sentiment analysis phase of the workflow.

    This node analyzes the customer's emotional state and provides
    insights for response tailoring.

    Args:
        state: Current workflow state

    Returns:
        Updated state with sentiment analysis information
    """
    logger.info("=== SENTIMENT ANALYSIS NODE ===")

    # Update current node
    state["current_node"] = "sentiment_analysis"

    try:
        # Initialize the sentiment agent
        sentiment_agent = SentimentAgent()

        # Get required information from state
        customer_query = state["customer_query"]
        conversation_history = state.get("conversation_history", [])

        logger.info("Analyzing customer sentiment")

        # Analyze sentiment
        sentiment_analysis = sentiment_agent.analyze_sentiment(
            customer_query=customer_query,
            conversation_history=conversation_history
        )

        # Update state with sentiment analysis
        state["sentiment_analysis"] = sentiment_analysis

        primary_sentiment = sentiment_analysis.get("primary_sentiment", "neutral")
        urgency = sentiment_analysis.get("urgency_level", "medium")
        sentiment_score = sentiment_analysis.get("sentiment_score", 0.0)

        logger.info(
            f"Sentiment: {primary_sentiment} (score: {sentiment_score:.2f}), "
            f"Urgency: {urgency}"
        )

        # Check if sentiment indicates escalation is needed
        if sentiment_agent.should_escalate_based_on_sentiment(sentiment_analysis):
            logger.warning("Sentiment indicates escalation may be needed")
            state["metadata"]["sentiment_escalation_flag"] = True

        # Store sentiment details in metadata
        if "metadata" not in state:
            state["metadata"] = {}

        state["metadata"]["sentiment_details"] = {
            "primary_sentiment": primary_sentiment,
            "urgency": urgency,
            "empathy_needed": sentiment_analysis.get("empathy_level_needed", "medium"),
            "tone_recommendation": sentiment_agent.get_tone_recommendation(sentiment_analysis)
        }

        # Add sentiment to conversation history
        state = update_conversation_history(
            state,
            role="system",
            content=f"Sentiment analysis: {primary_sentiment} (urgency: {urgency})"
        )

    except Exception as e:
        logger.error(f"Error in sentiment analysis node: {str(e)}")
        state["error"] = f"Sentiment analysis error: {str(e)}"
        # Set default sentiment to allow workflow to continue
        state["sentiment_analysis"] = {
            "primary_sentiment": "neutral",
            "sentiment_score": 0.0,
            "urgency_level": "medium",
            "empathy_level_needed": "medium"
        }

    return state
