"""
Follow-up Node for the customer support workflow.

This node uses the FollowUpAgent to determine post-resolution actions.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.followup import FollowUpAgent

logger = logging.getLogger(__name__)


def followup_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the follow-up planning phase of the workflow.

    This node determines what follow-up actions should be taken after
    resolving the customer query.

    Args:
        state: Current workflow state

    Returns:
        Updated state with follow-up plan and enhanced final response
    """
    logger.info("=== FOLLOW-UP NODE ===")

    # Update current node
    state["current_node"] = "followup"

    try:
        # Initialize the follow-up agent
        followup_agent = FollowUpAgent()

        # Get required information from state
        customer_query = state["customer_query"]
        classification = state.get("classification", "general")
        resolution = state.get("resolution", "")
        sentiment_analysis = state.get("sentiment_analysis", {})
        quality_score = state.get("quality_score", 0.7)

        if not resolution:
            logger.warning("No resolution available for follow-up planning")
            return state

        logger.info("Determining follow-up actions")

        # Determine follow-up plan
        followup_plan = followup_agent.determine_followup(
            customer_query=customer_query,
            classification=classification,
            resolution=resolution,
            sentiment_analysis=sentiment_analysis,
            quality_score=quality_score
        )

        # Update state with follow-up plan
        state["followup_plan"] = followup_plan

        follow_up_needed = followup_plan.get("follow_up_needed", False)
        priority = followup_plan.get("follow_up_priority", "low")
        timeline = followup_plan.get("follow_up_timeline", "none")

        logger.info(
            f"Follow-up: needed={follow_up_needed}, "
            f"priority={priority}, timeline={timeline}"
        )

        # Append follow-up information to the final response if appropriate
        final_response = state.get("resolution", "")
        enhanced_response = followup_agent.append_followup_to_response(
            final_response,
            followup_plan
        )

        state["final_response"] = enhanced_response

        # Store follow-up details in metadata
        if "metadata" not in state:
            state["metadata"] = {}

        state["metadata"]["followup_details"] = {
            "follow_up_needed": follow_up_needed,
            "priority": priority,
            "timeline": timeline,
            "actions_count": len(followup_plan.get("suggested_actions", [])),
            "closure_status": followup_plan.get("closure_status", "resolved")
        }

        # Log follow-up summary
        summary = followup_agent.get_followup_summary(followup_plan)
        logger.debug(f"Follow-up summary:\n{summary}")

        # Add follow-up plan to conversation history
        state = update_conversation_history(
            state,
            role="system",
            content=f"Follow-up plan: needed={follow_up_needed}, priority={priority}"
        )

    except Exception as e:
        logger.error(f"Error in follow-up node: {str(e)}")
        state["error"] = f"Follow-up error: {str(e)}"
        # Set default follow-up to allow workflow to continue
        state["followup_plan"] = {
            "follow_up_needed": True,
            "follow_up_priority": "medium",
            "follow_up_timeline": "24h"
        }

        # Ensure final_response is set
        if not state.get("final_response"):
            state["final_response"] = state.get("resolution", "")

    return state
