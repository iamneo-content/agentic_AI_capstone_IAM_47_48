"""
Resolution Node for the customer support workflow.

This node uses the ResolverAgent to provide solutions to customer issues.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.resolver import ResolverAgent

logger = logging.getLogger(__name__)


def resolution_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the resolution phase of the workflow.

    This node attempts to resolve the customer query using the knowledge
    base and LLM reasoning.

    Args:
        state: Current workflow state

    Returns:
        Updated state with resolution information
    """
    logger.info("=== RESOLUTION NODE ===")

    # Update current node
    state["current_node"] = "resolution"

    try:
        # Initialize the resolver agent
        resolver = ResolverAgent()

        # Get required information from state
        customer_query = state["customer_query"]
        classification = state.get("classification", "general")
        confidence = state.get("classification_confidence", 0.5)
        conversation_history = state.get("conversation_history", [])
        resolution_attempts = state.get("resolution_attempts", 0)

        logger.info(f"Attempting resolution (attempt {resolution_attempts + 1})")

        # Attempt to resolve the query
        resolution = resolver.resolve_query(
            customer_query=customer_query,
            classification=classification,
            confidence=confidence,
            conversation_history=conversation_history,
            resolution_attempts=resolution_attempts
        )

        # Update state with resolution
        state["resolution"] = resolution.get("resolution", "")
        state["resolution_attempts"] = resolution_attempts + 1

        # Check if escalation is needed
        needs_escalation = resolution.get("needs_escalation", False)
        state["escalation_needed"] = needs_escalation

        if needs_escalation:
            state["escalation_reason"] = resolution.get(
                "escalation_reason",
                "Resolution agent determined escalation is necessary"
            )
            logger.info(f"Escalation needed: {state['escalation_reason']}")
        else:
            # Enhance resolution with empathy
            enhanced_resolution = resolver.enhance_resolution_with_empathy(
                state["resolution"],
                classification
            )
            state["resolution"] = enhanced_resolution
            state["final_response"] = enhanced_resolution
            logger.info("Resolution completed successfully")

        # Store resolution details in metadata
        if "metadata" not in state:
            state["metadata"] = {}
        state["metadata"]["resolution_confidence"] = resolution.get("confidence", 0.0)
        state["metadata"]["follow_up_questions"] = resolution.get("follow_up_questions", [])

        # Add resolution to conversation history
        if not needs_escalation:
            state = update_conversation_history(
                state,
                role="agent",
                content=state["resolution"]
            )
        else:
            state = update_conversation_history(
                state,
                role="system",
                content=f"Resolution requires escalation: {state['escalation_reason']}"
            )

    except Exception as e:
        logger.error(f"Error in resolution node: {str(e)}")
        state["error"] = f"Resolution error: {str(e)}"
        # Escalate on error
        state["escalation_needed"] = True
        state["escalation_reason"] = f"Resolution failed due to error: {str(e)}"

    return state
