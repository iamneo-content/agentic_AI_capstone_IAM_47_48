"""
Planning Node for the customer support workflow.

This node uses the PlannerAgent to analyze queries and create execution plans.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.planner import PlannerAgent

logger = logging.getLogger(__name__)


def planning_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the planning phase of the workflow.

    This node analyzes the customer query and creates an execution plan
    that will guide the rest of the workflow.

    Args:
        state: Current workflow state

    Returns:
        Updated state with planning information
    """
    logger.info("=== PLANNING NODE ===")

    # Update current node
    state["current_node"] = "planning"

    try:
        # Initialize the planner agent
        planner = PlannerAgent()

        # Get customer query and conversation history
        customer_query = state["customer_query"]
        conversation_history = state.get("conversation_history", [])

        logger.info(f"Planning for query: {customer_query[:100]}...")

        # Check if immediate escalation is needed
        if planner.should_escalate_immediately(customer_query):
            logger.warning("Immediate escalation triggered")
            state["current_plan"] = {
                "analysis": "Query contains urgent/critical keywords",
                "complexity": "complex",
                "recommended_flow": ["escalation"],
                "special_notes": "Immediate escalation required"
            }
            state["escalation_needed"] = True
            state["escalation_reason"] = "Urgent keywords detected in query"
        else:
            # Analyze and create plan
            plan = planner.analyze_and_plan(customer_query, conversation_history)
            state["current_plan"] = plan

            logger.info(f"Plan created - Complexity: {plan.get('complexity')}")
            logger.debug(f"Recommended flow: {plan.get('recommended_flow')}")

        # Add plan to conversation history as a system message
        state = update_conversation_history(
            state,
            role="system",
            content=f"Execution plan created: {state['current_plan'].get('analysis', 'N/A')}"
        )

    except Exception as e:
        logger.error(f"Error in planning node: {str(e)}")
        state["error"] = f"Planning error: {str(e)}"
        # Set a default plan to allow workflow to continue
        state["current_plan"] = {
            "analysis": "Error occurred during planning",
            "complexity": "moderate",
            "recommended_flow": ["classifier", "resolver"],
            "special_notes": f"Fallback plan due to error: {str(e)}"
        }

    return state
