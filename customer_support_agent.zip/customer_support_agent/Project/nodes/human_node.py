"""
Human Intervention Node for the customer support workflow.

This node uses the EscalationAgent to prepare cases for human review
and processes human feedback.
"""

import logging
from typing import Dict, Any
from state import CustomerSupportState, update_conversation_history
from agents.escalation import EscalationAgent

logger = logging.getLogger(__name__)


def human_node(state: CustomerSupportState) -> CustomerSupportState:
    """
    Execute the human intervention phase of the workflow.

    This node prepares the escalation, displays information to the human agent,
    and processes their feedback. The graph will be interrupted before this node
    to allow human input.

    Args:
        state: Current workflow state

    Returns:
        Updated state with human feedback and final response
    """
    logger.info("=== HUMAN INTERVENTION NODE ===")

    # Update current node
    state["current_node"] = "human_intervention"

    try:
        # Initialize the escalation agent
        escalation_agent = EscalationAgent()

        # Get required information from state
        customer_query = state["customer_query"]
        classification = state.get("classification", "general")
        previous_resolution = state.get("resolution")
        escalation_reason = state.get("escalation_reason", "Unknown reason")
        conversation_history = state.get("conversation_history", [])

        # Check if we already have human feedback (resuming after interrupt)
        if state.get("human_feedback"):
            logger.info("Processing existing human feedback")

            # Get escalation info from metadata if available
            escalation_info = state.get("metadata", {}).get("escalation_info", {})

            # Process the human feedback
            result = escalation_agent.process_human_feedback(
                human_feedback=state["human_feedback"],
                escalation_info=escalation_info
            )

            # Update state with final response
            state["final_response"] = result.get("final_response", state["human_feedback"])

            # Add to conversation history
            state = update_conversation_history(
                state,
                role="human_agent",
                content=state["human_feedback"]
            )

            state = update_conversation_history(
                state,
                role="agent",
                content=state["final_response"]
            )

            logger.info("Human feedback processed successfully")

        else:
            # Prepare escalation information for human review
            logger.info("Preparing case for human escalation")

            escalation_info = escalation_agent.prepare_escalation(
                customer_query=customer_query,
                classification=classification,
                previous_resolution=previous_resolution,
                escalation_reason=escalation_reason,
                conversation_history=conversation_history
            )

            # Store escalation info in metadata
            if "metadata" not in state:
                state["metadata"] = {}
            state["metadata"]["escalation_info"] = escalation_info

            # Format the escalation for display
            display_text = escalation_agent.format_for_human_display(escalation_info)

            logger.info("Escalation prepared - waiting for human input")
            logger.debug(f"Ticket ID: {escalation_info.get('ticket_id', 'N/A')}")

            # Store the display text for the CLI to show
            state["metadata"]["human_prompt"] = display_text

            # Add escalation to conversation history
            state = update_conversation_history(
                state,
                role="system",
                content=f"Case escalated to human agent. Ticket ID: {escalation_info.get('ticket_id', 'N/A')}"
            )

    except Exception as e:
        logger.error(f"Error in human intervention node: {str(e)}")
        state["error"] = f"Escalation error: {str(e)}"

        # Provide a fallback response
        state["final_response"] = (
            "I apologize for the inconvenience. We're experiencing technical difficulties. "
            "Please contact our support team directly at support@example.com or call 1-800-SUPPORT."
        )

    return state
