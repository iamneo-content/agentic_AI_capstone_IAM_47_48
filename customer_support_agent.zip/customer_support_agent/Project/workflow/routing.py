"""
Routing logic for conditional edges in the workflow.

This module contains functions that determine which path the workflow
should take based on the current state.
"""

import logging
from typing import Literal
from state import CustomerSupportState

logger = logging.getLogger(__name__)


def route_from_planning(
    state: CustomerSupportState
) -> Literal["analysis", "escalate"]:
    """
    Determine the next step after planning.

    Args:
        state: Current workflow state

    Returns:
        Next node to execute: "analysis" or "escalate"
    """
    # Check if immediate escalation was flagged during planning
    if state.get("escalation_needed", False):
        logger.info("Routing: planning -> escalate (immediate escalation needed)")
        return "escalate"

    # Check the recommended flow from the plan
    plan = state.get("current_plan", {})
    recommended_flow = plan.get("recommended_flow", [])

    if "escalation" in recommended_flow and "classifier" not in recommended_flow:
        logger.info("Routing: planning -> escalate (plan recommends direct escalation)")
        return "escalate"

    # Default to analysis
    logger.info("Routing: planning -> analysis")
    return "analysis"


def should_continue_to_analysis(
    state: CustomerSupportState
) -> Literal["analysis", "end"]:
    """
    Determine if workflow should continue to analysis.

    This is used when planning might route directly to escalation.

    Args:
        state: Current workflow state

    Returns:
        Next node: "analysis" or "end"
    """
    if state.get("error"):
        logger.warning("Error detected, ending workflow")
        return "end"

    logger.info("Continuing to analysis")
    return "analysis"


def should_continue_to_resolution(
    state: CustomerSupportState
) -> Literal["resolution", "end"]:
    """
    Determine if workflow should continue to resolution.

    Args:
        state: Current workflow state

    Returns:
        Next node: "resolution" or "end"
    """
    if state.get("error"):
        logger.warning("Error detected, ending workflow")
        return "end"

    # Check if classification confidence is too low
    confidence = state.get("classification_confidence", 1.0)
    if confidence < 0.3:
        logger.warning(f"Low classification confidence ({confidence:.2f})")
        # Continue anyway but log the concern
        # In production, you might want to escalate here

    logger.info("Continuing to resolution")
    return "resolution"


def should_escalate(
    state: CustomerSupportState
) -> Literal["escalate", "end"]:
    """
    Determine if the case should be escalated after resolution attempt.

    Args:
        state: Current workflow state

    Returns:
        Next node: "escalate" or "end"
    """
    # Check for errors
    if state.get("error"):
        logger.warning("Error detected, escalating")
        return "escalate"

    # Check escalation flag
    if state.get("escalation_needed", False):
        logger.info("Routing: resolution -> escalate (escalation flag set)")
        return "escalate"

    # Check resolution attempts
    attempts = state.get("resolution_attempts", 0)
    if attempts >= 3:
        logger.warning(f"Maximum resolution attempts ({attempts}) reached, escalating")
        state["escalation_needed"] = True
        state["escalation_reason"] = f"Maximum resolution attempts ({attempts}) exceeded"
        return "escalate"

    # Check if we have a final response
    if state.get("final_response"):
        logger.info("Final response available, ending workflow")
        return "end"

    # If resolution exists but no final response, something went wrong
    if state.get("resolution"):
        logger.warning("Resolution exists but no final response, escalating")
        state["escalation_needed"] = True
        state["escalation_reason"] = "Resolution incomplete"
        return "escalate"

    # Default to ending
    logger.info("Routing: resolution -> end")
    return "end"


def needs_human_feedback(state: CustomerSupportState) -> bool:
    """
    Check if human feedback is needed.

    This is used to determine if the workflow should be interrupted
    for human input.

    Args:
        state: Current workflow state

    Returns:
        True if human feedback is needed, False otherwise
    """
    # If we already have human feedback, no need to wait
    if state.get("human_feedback"):
        return False

    # If escalation is needed and we don't have feedback, we need it
    if state.get("escalation_needed", False):
        return True

    return False


def route_after_human(
    state: CustomerSupportState
) -> Literal["end"]:
    """
    Determine routing after human intervention.

    Typically, after human intervention, the workflow ends.

    Args:
        state: Current workflow state

    Returns:
        Always returns "end" as human intervention is the final step
    """
    logger.info("Routing: human intervention -> end")
    return "end"
