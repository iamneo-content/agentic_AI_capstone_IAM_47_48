"""
Input validation and sanitization utilities.

This module provides functions to validate and sanitize user inputs
to ensure security and data integrity.
"""

import re
from typing import Tuple


def validate_customer_query(query: str) -> Tuple[bool, str]:
    """
    Validate a customer query for basic sanity checks.

    Args:
        query: The customer query string

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not query:
        return False, "Query cannot be empty"

    if not isinstance(query, str):
        return False, "Query must be a string"

    # Check minimum length
    if len(query.strip()) < 3:
        return False, "Query is too short (minimum 3 characters)"

    # Check maximum length
    if len(query) > 5000:
        return False, "Query is too long (maximum 5000 characters)"

    # Check for suspicious patterns (basic injection prevention)
    suspicious_patterns = [
        r"<script\s*>",
        r"javascript:",
        r"on\w+\s*=",  # event handlers
    ]

    for pattern in suspicious_patterns:
        if re.search(pattern, query, re.IGNORECASE):
            return False, "Query contains suspicious content"

    return True, ""


def sanitize_input(text: str) -> str:
    """
    Sanitize user input by removing or escaping potentially harmful content.

    Args:
        text: Input text to sanitize

    Returns:
        Sanitized text
    """
    if not isinstance(text, str):
        return str(text)

    # Remove null bytes
    text = text.replace("\x00", "")

    # Strip leading/trailing whitespace
    text = text.strip()

    # Normalize whitespace
    text = " ".join(text.split())

    # Remove common control characters but keep newlines and tabs
    text = "".join(char for char in text if char.isprintable() or char in "\n\t")

    return text


def validate_thread_id(thread_id: str) -> bool:
    """
    Validate a thread ID format.

    Args:
        thread_id: Thread identifier

    Returns:
        True if valid, False otherwise
    """
    if not thread_id:
        return False

    # Thread ID should be alphanumeric with hyphens, underscores
    pattern = r"^[a-zA-Z0-9_-]{1,100}$"
    return bool(re.match(pattern, thread_id))


def validate_json_string(json_str: str) -> bool:
    """
    Basic validation for JSON string format.

    Args:
        json_str: String to validate as JSON

    Returns:
        True if it looks like valid JSON, False otherwise
    """
    import json
    try:
        json.loads(json_str)
        return True
    except (json.JSONDecodeError, TypeError):
        return False
