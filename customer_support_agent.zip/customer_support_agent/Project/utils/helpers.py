"""
Helper utilities for the customer support system.

This module provides utility functions used across the application.
"""

import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime


def format_conversation_history(history: List[Dict[str, str]], max_messages: int = 10) -> str:
    """
    Format conversation history for display in prompts.

    Args:
        history: List of conversation messages
        max_messages: Maximum number of recent messages to include

    Returns:
        Formatted conversation history string
    """
    if not history:
        return "No previous conversation"

    # Take only the most recent messages
    recent_history = history[-max_messages:]

    formatted = []
    for msg in recent_history:
        role = msg.get("role", "unknown").capitalize()
        content = msg.get("content", "")
        timestamp = msg.get("timestamp", "")

        if timestamp:
            try:
                dt = datetime.fromisoformat(timestamp)
                time_str = dt.strftime("%H:%M:%S")
                formatted.append(f"[{time_str}] {role}: {content}")
            except ValueError:
                formatted.append(f"{role}: {content}")
        else:
            formatted.append(f"{role}: {content}")

    return "\n".join(formatted)


def extract_json_from_text(text: str) -> Optional[Dict[str, Any]]:
    """
    Extract JSON object from text that may contain markdown or other formatting.

    This function handles cases where LLMs return JSON wrapped in markdown code blocks
    or mixed with other text.

    Args:
        text: Text potentially containing JSON

    Returns:
        Parsed JSON dict or None if no valid JSON found
    """
    # Try direct JSON parsing first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to extract JSON from markdown code blocks
    json_code_block_pattern = r"```(?:json)?\s*(\{.*?\})\s*```"
    matches = re.findall(json_code_block_pattern, text, re.DOTALL)

    if matches:
        try:
            return json.loads(matches[0])
        except json.JSONDecodeError:
            pass

    # Try to find JSON object in the text
    json_pattern = r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}"
    matches = re.findall(json_pattern, text, re.DOTALL)

    for match in matches:
        try:
            return json.loads(match)
        except json.JSONDecodeError:
            continue

    return None


def truncate_text(text: str, max_length: int = 200, suffix: str = "...") -> str:
    """
    Truncate text to a maximum length while preserving word boundaries.

    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add when truncating

    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text

    # Find the last space within max_length
    truncated = text[:max_length - len(suffix)]
    last_space = truncated.rfind(" ")

    if last_space > 0:
        truncated = truncated[:last_space]

    return truncated + suffix


def get_timestamp() -> str:
    """
    Get current timestamp in ISO format.

    Returns:
        ISO formatted timestamp string
    """
    return datetime.now().isoformat()


def calculate_confidence_level(confidence: float) -> str:
    """
    Convert numerical confidence to human-readable level.

    Args:
        confidence: Confidence score (0.0 to 1.0)

    Returns:
        Confidence level string
    """
    if confidence >= 0.9:
        return "Very High"
    elif confidence >= 0.75:
        return "High"
    elif confidence >= 0.5:
        return "Medium"
    elif confidence >= 0.25:
        return "Low"
    else:
        return "Very Low"


def merge_dicts_deep(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries, with dict2 values taking precedence.

    Args:
        dict1: First dictionary
        dict2: Second dictionary (values take precedence)

    Returns:
        Merged dictionary
    """
    result = dict1.copy()

    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts_deep(result[key], value)
        else:
            result[key] = value

    return result


def safe_get(dictionary: Dict[str, Any], key: str, default: Any = None) -> Any:
    """
    Safely get a value from a dictionary with a default.

    Args:
        dictionary: Dictionary to get value from
        key: Key to look up
        default: Default value if key not found

    Returns:
        Value or default
    """
    try:
        return dictionary.get(key, default)
    except (AttributeError, TypeError):
        return default
