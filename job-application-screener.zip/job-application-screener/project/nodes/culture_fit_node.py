"""
Culture Fit Node - Simplified Wrapper

Calls CultureFitAgent to analyze culture fit.
"""

from state import JobApplicationState
from agents.culture_fit_agent import CultureFitAgent

# Create agent instance
agent = CultureFitAgent()


def culture_fit_node(state: JobApplicationState) -> JobApplicationState:
    """
    Analyze culture fit

    Args:
        state: Current job application state

    Returns:
        Updated state with culture fit results
    """
    state.culture_fit_results = agent.analyze(
        state.candidate_info,
        state.cover_letter,
        state.job_requirements
    )
    return state
