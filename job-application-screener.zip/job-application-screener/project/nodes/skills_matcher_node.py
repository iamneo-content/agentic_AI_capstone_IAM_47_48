"""
Skills Matcher Node - Simplified Wrapper

Calls SkillsMatcherAgent to match skills.
"""

from state import JobApplicationState
from agents.skills_matcher_agent import SkillsMatcherAgent

# Create agent instance
agent = SkillsMatcherAgent()


def skills_matcher_node(state: JobApplicationState) -> JobApplicationState:
    """
    Match candidate skills with job requirements

    Args:
        state: Current job application state

    Returns:
        Updated state with skills matching results
    """
    candidate_skills = state.candidate_info.get("skills", [])
    state.skills_matching_results = agent.analyze(candidate_skills, state.job_requirements)
    return state
