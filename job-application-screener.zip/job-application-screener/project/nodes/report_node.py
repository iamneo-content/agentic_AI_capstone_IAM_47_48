"""
Report Node

Generates final screening report and sends email notification.
"""

from state import JobApplicationState
from services.email_service import EmailService
from datetime import datetime
import logging

logger = logging.getLogger("node.report")


def report_node(state: JobApplicationState) -> JobApplicationState:
    """
    Generate final screening report and send email notification

    Args:
        state: Current job application state

    Returns:
        Updated state with report
    """
    logger.info("Generating final screening report")

    # Determine priority
    if state.decision == "INTERVIEW":
        priority = "HIGH"
    elif state.decision == "WAITLIST":
        priority = "MEDIUM"
    else:
        priority = "LOW"

    # Key findings
    key_findings = [
        f"Overall Score: {state.overall_score:.2f}/10",
        f"Decision: {state.decision}",
        f"Recommendation: {state.recommendation_level}"
    ]

    if state.has_critical_issues:
        key_findings.append(f"Critical Issues: {state.critical_reason}")

    # Action items
    action_items = []
    if state.decision == "INTERVIEW":
        action_items.extend([
            "Schedule initial interview",
            "Prepare technical assessment",
            "Review interview questions provided"
        ])
    elif state.decision == "WAITLIST":
        action_items.extend([
            "Add to talent pool",
            "Review when position requirements change",
            "Consider for alternative roles"
        ])
    else:
        action_items.extend([
            "Send rejection email",
            "Archive application",
            "Note reasons for future reference"
        ])

    # Next steps
    next_steps = []
    if state.decision == "INTERVIEW":
        next_steps.extend(state.interview_questions)
    else:
        next_steps.append(f"Process as {state.decision}")

    # Create report
    report = {
        "screening_id": state.screening_id,
        "candidate_name": state.candidate_name,
        "candidate_email": state.candidate_email,
        "position_title": state.position_title,
        "timestamp": state.timestamp,
        "overall_score": state.overall_score,
        "decision": state.decision,
        "recommendation": state.recommendation_level,
        "priority": priority,
        "key_findings": key_findings,
        "action_items": action_items,
        "next_steps": next_steps,
        "metrics": state.decision_metrics,
        "feedback_points": state.feedback_points,
        "interview_questions": state.interview_questions
    }

    state.report = report

    # Send email notification
    try:
        email_service = EmailService()

        # Send screening start notification
        email_service.send_screening_start_email(
            state.screening_id,
            state.candidate_name,
            state.position_title
        )

        # Send final report
        email_service.send_final_report_email(state)

        state.notifications_sent.append({
            "type": "email",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "sent"
        })

        logger.info("Email notifications sent successfully")
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        state.notifications_sent.append({
            "type": "email",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "failed",
            "error": str(e)
        })

    logger.info("Report generation complete")
    return state
