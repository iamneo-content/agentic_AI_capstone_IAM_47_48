"""
Experience Analyzer Node - Simplified Wrapper

Calls ExperienceAnalyzerAgent to analyze experience.
"""

from state import JobApplicationState
from agents.experience_analyzer_agent import ExperienceAnalyzerAgent

# Create agent instance
agent = ExperienceAnalyzerAgent()


def experience_analyzer_node(state: JobApplicationState) -> JobApplicationState:
    """
    Analyze work experience

    Args:
        state: Current job application state

    Returns:
        Updated state with experience analysis results
    """
    work_experience = state.candidate_info.get("work_experience", [])
    state.experience_results = agent.analyze(work_experience, state.job_requirements)
    return state
