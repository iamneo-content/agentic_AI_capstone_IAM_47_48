"""
Decision Node

Makes automated hiring decision based on coordinated screening results.
"""

from state import JobApplicationState
from config import get_config_value
import logging

logger = logging.getLogger("node.decision")


def decision_node(state: JobApplicationState) -> JobApplicationState:
    """
    Make automated hiring decision

    Args:
        state: Current job application state

    Returns:
        Updated state with decision and metrics
    """
    logger.info("Making automated hiring decision")

    summary = state.coordination_summary
    overall_score = summary.get("overall_score", 0)

    # Get thresholds from config
    skills_threshold = get_config_value("SKILLS_MATCH_THRESHOLD", 70.0)
    experience_threshold = get_config_value("EXPERIENCE_THRESHOLD", 7.0)
    culture_threshold = get_config_value("CULTURE_FIT_THRESHOLD", 7.0)
    overall_threshold = get_config_value("OVERALL_SCORE_THRESHOLD", 7.5)

    # Extract individual scores
    skills_match = summary.get("skills_match_percentage", 0)
    experience_score = summary.get("experience_score", 0)
    culture_fit_score = summary.get("culture_fit_score", 0)
    salary_score = summary.get("salary_alignment_score", 0)

    # Check for critical issues
    has_critical_issues = summary.get("has_critical_issues", False)
    critical_issues = summary.get("critical_issues", [])
    critical_reason = "; ".join(critical_issues) if critical_issues else ""

    # Determine recommendation level
    if overall_score >= 8.5 and not has_critical_issues:
        recommendation_level = "STRONG RECOMMEND"
    elif overall_score >= 7.5 and not has_critical_issues:
        recommendation_level = "RECOMMEND"
    elif overall_score >= 6.0:
        recommendation_level = "CONSIDER"
    else:
        recommendation_level = "NOT RECOMMENDED"

    # Make decision: INTERVIEW, WAITLIST, or REJECT
    decision = ""

    if has_critical_issues:
        if skills_match < 40 or experience_score < 4.0:
            decision = "REJECT"
        else:
            decision = "WAITLIST"
    elif overall_score >= overall_threshold and skills_match >= skills_threshold:
        decision = "INTERVIEW"
    elif overall_score >= 6.0:
        decision = "WAITLIST"
    else:
        decision = "REJECT"

    # Generate interview questions if proceeding to interview
    interview_questions = []
    if decision == "INTERVIEW":
        interview_questions = [
            f"Can you elaborate on your experience with {state.candidate_info.get('skills', ['relevant skills'])[0]}?",
            "Describe a challenging project you've worked on and how you approached it.",
            "How do you handle tight deadlines and multiple priorities?",
            f"What interests you most about this {state.position_title} role?"
        ]

    # Generate feedback points
    feedback_points = []
    if skills_match < skills_threshold:
        feedback_points.append(f"Skills match below threshold ({skills_match:.1f}% < {skills_threshold}%)")
    if experience_score < experience_threshold:
        feedback_points.append(f"Experience below threshold ({experience_score:.1f} < {experience_threshold})")
    if culture_fit_score < culture_threshold:
        feedback_points.append(f"Culture fit concerns (score: {culture_fit_score:.1f})")
    if decision == "INTERVIEW":
        feedback_points.append("Strong candidate - recommended for interview")

    # Store decision metrics
    decision_metrics = {
        "overall_score": overall_score,
        "skills_match_percentage": skills_match,
        "experience_score": experience_score,
        "culture_fit_score": culture_fit_score,
        "salary_alignment_score": salary_score
    }

    state.decision = decision
    state.overall_score = overall_score
    state.recommendation_level = recommendation_level
    state.has_critical_issues = has_critical_issues
    state.critical_reason = critical_reason
    state.decision_metrics = decision_metrics
    state.interview_questions = interview_questions
    state.feedback_points = feedback_points

    logger.info(f"Decision: {decision}, Overall Score: {overall_score:.2f}/10")
    return state
