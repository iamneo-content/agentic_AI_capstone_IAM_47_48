"""
Coordinator Node - Simplified Wrapper

Calls CoordinatorAgent to coordinate and aggregate results.
"""

from state import JobApplicationState
from agents.coordinator_agent import CoordinatorAgent

# Create agent instance
agent = CoordinatorAgent()


def coordinator_node(state: JobApplicationState) -> JobApplicationState:
    """
    Coordinate and aggregate screening results

    Args:
        state: Current job application state

    Returns:
        Updated state with coordination summary
    """
    state.coordination_summary = agent.analyze(
        state.resume_parsing_results,
        state.skills_matching_results,
        state.experience_results,
        state.culture_fit_results,
        state.salary_results
    )
    return state
