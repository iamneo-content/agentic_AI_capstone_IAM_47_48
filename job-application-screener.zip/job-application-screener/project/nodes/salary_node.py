"""
Salary Node - Simplified Wrapper

Calls SalaryAgent to analyze salary expectations.
"""

from state import JobApplicationState
from agents.salary_agent import SalaryAgent

# Create agent instance
agent = SalaryAgent()


def salary_node(state: JobApplicationState) -> JobApplicationState:
    """
    Analyze salary expectations

    Args:
        state: Current job application state

    Returns:
        Updated state with salary analysis results
    """
    state.salary_results = agent.analyze(state.candidate_info, state.job_requirements)
    return state
