"""
Resume Parser Node - Simplified Wrapper

Calls ResumeParserAgent to parse resume.
"""

from state import JobApplicationState
from agents.resume_parser_agent import ResumeParserAgent

# Create agent instance
agent = ResumeParserAgent()


def resume_parser_node(state: JobApplicationState) -> JobApplicationState:
    """
    Parse resume and extract information

    Args:
        state: Current job application state

    Returns:
        Updated state with parsed resume data
    """
    result = agent.analyze(state.resume_text, state.candidate_name)

    state.resume_parsing_results = result
    state.candidate_info = result

    # Update candidate name and email if found
    if result.get("candidate_name"):
        state.candidate_name = result["candidate_name"]
    if result.get("email"):
        state.candidate_email = result["email"]

    return state
