"""
Job Application Screener - Client Format
Main application entry point
"""

import sys
import argparse
from datetime import datetime
import uuid

from config import validate_config, get_config_value
from state import JobApplicationState
from workflows.screening_workflow import build_screening_workflow
from utils.logging_utils import setup_logging


def main():
    """Main application entry point"""
    # Setup logging
    log_file = get_config_value("LOG_FILE", "logs/job_screening.log")
    log_level = get_config_value("LOG_LEVEL", "INFO")
    setup_logging(log_level, log_file)

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Job Application Screener - Multi-Agent Screening System"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Screen application command
    screen_parser = subparsers.add_parser("screen", help="Screen a job application")
    screen_parser.add_argument("candidate_name", help="Candidate name")
    screen_parser.add_argument("position", help="Position title")
    screen_parser.add_argument("--resume-file", help="Path to resume file")
    screen_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run demo with sample application")
    demo_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    args = parser.parse_args()

    try:
        # Validate configuration
        validate_config()

        # Handle commands
        if args.command == "screen":
            resume_text = ""
            if args.resume_file:
                with open(args.resume_file, 'r') as f:
                    resume_text = f.read()
            else:
                resume_text = get_sample_resume()

            screen_application(args.candidate_name, args.position, resume_text, args.max_workers)
        elif args.command == "demo":
            run_demo(args.max_workers)
        else:
            # Interactive mode
            interactive_mode()

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


def screen_application(candidate_name: str, position: str, resume_text: str, max_workers: int = 5):
    """
    Screen a job application

    Args:
        candidate_name: Candidate's name
        position: Position title
        resume_text: Resume content
        max_workers: Maximum parallel workers
    """
    print(f"\n{'='*70}")
    print(f"JOB APPLICATION SCREENER - CLIENT FORMAT")
    print(f"{'='*70}")
    print(f"Candidate: {candidate_name}")
    print(f"Position: {position}")
    print(f"Max Workers: {max_workers}")
    print(f"{'='*70}\n")

    # Create initial state
    screening_id = f"SCR-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"

    # Sample job requirements (in real scenario, would come from job posting)
    job_requirements = get_sample_job_requirements(position)

    initial_state = JobApplicationState(
        screening_id=screening_id,
        candidate_name=candidate_name,
        position_title=position,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        resume_text=resume_text,
        cover_letter=get_sample_cover_letter(),
        job_requirements=job_requirements
    )

    print(f"Screening ID: {screening_id}")
    print(f"Starting workflow execution...\n")

    # Build and execute workflow
    workflow = build_screening_workflow(max_workers=max_workers)
    final_state = workflow.run(initial_state)

    # Display results
    display_results(final_state)


def display_results(state: JobApplicationState):
    """Display workflow results"""
    print(f"\n{'='*70}")
    print("SCREENING COMPLETE")
    print(f"{'='*70}")
    print(f"Screening ID: {state.screening_id}")
    print(f"Candidate: {state.candidate_name}")
    print(f"Position: {state.position_title}")
    print(f"Overall Score: {state.overall_score:.2f}/10.0")
    print(f"Decision: {state.decision}")
    print(f"Recommendation: {state.recommendation_level}")

    if state.has_critical_issues:
        print(f"\n[!] CRITICAL ISSUES: {state.critical_reason}")
    else:
        print(f"\n[OK] No critical issues found")

    # Display metrics
    if state.decision_metrics:
        print(f"\n{'='*70}")
        print("SCREENING METRICS")
        print(f"{'='*70}")
        metrics = state.decision_metrics
        print(f"Skills Match:           {metrics.get('skills_match_percentage', 0):.1f}%")
        print(f"Experience Score:       {metrics.get('experience_score', 0):.2f}/10.0")
        print(f"Culture Fit Score:      {metrics.get('culture_fit_score', 0):.2f}/10.0")
        print(f"Salary Alignment:       {metrics.get('salary_alignment_score', 0):.2f}/10.0")

    # Display report summary
    if state.report:
        print(f"\n{'='*70}")
        print("SCREENING REPORT")
        print(f"{'='*70}")
        report = state.report

        print(f"Priority: {report.get('priority', 'MEDIUM')}")

        key_findings = report.get('key_findings', [])
        if key_findings:
            print(f"\nKey Findings:")
            for finding in key_findings:
                print(f"  - {finding}")

        action_items = report.get('action_items', [])
        if action_items:
            print(f"\nAction Items:")
            for action in action_items:
                print(f"  - {action}")

        if state.decision == "INTERVIEW" and state.interview_questions:
            print(f"\nSuggested Interview Questions:")
            for i, question in enumerate(state.interview_questions, 1):
                print(f"  {i}. {question}")

    print(f"\n{'='*70}")
    print("Email notification sent to hiring manager")
    print(f"{'='*70}\n")


def run_demo(max_workers: int = 5):
    """Run demo with sample application"""
    print("\n" + "="*70)
    print("DEMO MODE - Job Application Screener")
    print("="*70)
    print("This will screen a sample job application with mock data.")
    print("\nExample: John Smith applying for Software Engineer position")

    # Demo application
    candidate_name = "John Smith"
    position = "Senior Software Engineer"
    resume_text = get_sample_resume()

    print(f"\nScreening: {candidate_name} for {position}\n")

    screen_application(candidate_name, position, resume_text, max_workers)


def interactive_mode():
    """Interactive mode for job screening"""
    print("\n" + "="*70)
    print("Job Application Screener - Multi-Agent Screening System")
    print("="*70)
    print("\n1. Screen Application")
    print("2. Run Demo")
    print("0. Exit")

    choice = input("\nSelect option (0-2): ").strip()

    if choice == "0":
        print("Goodbye!")
        return

    elif choice == "1":
        candidate_name = input("Enter candidate name: ").strip()
        position = input("Enter position title: ").strip()
        resume_file = input("Enter resume file path (or press Enter for sample): ").strip()
        max_workers_str = input("Enter max workers (default 5): ").strip()

        try:
            max_workers = int(max_workers_str) if max_workers_str else 5
            resume_text = ""
            if resume_file:
                with open(resume_file, 'r') as f:
                    resume_text = f.read()
            else:
                resume_text = get_sample_resume()

            screen_application(candidate_name, position, resume_text, max_workers)
        except Exception as e:
            print(f"ERROR: {e}")

    elif choice == "2":
        max_workers_str = input("Enter max workers (default 5): ").strip()
        max_workers = int(max_workers_str) if max_workers_str else 5
        run_demo(max_workers)

    else:
        print("ERROR: Invalid choice")


def get_sample_resume() -> str:
    """Get sample resume text"""
    return """
John Smith
john.smith@email.com
(555) 123-4567

PROFESSIONAL SUMMARY
Experienced software engineer with 5+ years of experience in full-stack development.
Proficient in Python, JavaScript, and cloud technologies. Strong problem-solving skills
and proven track record of delivering high-quality software solutions.

EDUCATION
Master of Science in Computer Science
University of Technology, 2018
Bachelor of Science in Software Engineering
State University, 2016

WORK EXPERIENCE
Senior Software Engineer
Tech Solutions Inc., 2020 - Present (3 years)
- Led development of microservices architecture using Python and Docker
- Implemented CI/CD pipelines reducing deployment time by 50%
- Mentored junior developers and conducted code reviews

Software Engineer
Digital Innovations Corp., 2018 - 2020 (2 years)
- Developed React-based web applications
- Worked with AWS cloud services
- Collaborated in Agile team environment

SKILLS
- Programming: Python, JavaScript, Java, SQL
- Frameworks: React, Node.js, Django
- Cloud: AWS, Docker, Kubernetes
- Tools: Git, Jenkins, Agile
- Soft Skills: Leadership, Communication, Team Collaboration

CERTIFICATIONS
- AWS Certified Solutions Architect
- Certified Scrum Master
"""


def get_sample_cover_letter() -> str:
    """Get sample cover letter"""
    return """
Dear Hiring Manager,

I am excited to apply for the Senior Software Engineer position. With over 5 years of
experience in software development, I am confident in my ability to contribute to your team.

My passion for technology and problem-solving has driven me to continuously improve my skills.
I thrive in collaborative environments and enjoy mentoring junior developers. I am particularly
interested in your company's innovative approach to software development.

I look forward to the opportunity to discuss how my experience aligns with your needs.

Best regards,
John Smith
"""


def get_sample_job_requirements(position: str) -> dict:
    """Get sample job requirements"""
    return {
        "position_title": position,
        "required_skills": ["Python", "JavaScript", "AWS", "Docker", "Git"],
        "preferred_skills": ["Kubernetes", "React", "Leadership", "Agile"],
        "min_years_experience": 3,
        "industries": ["Technology", "Software"],
        "roles": ["Software Engineer", "Developer"],
        "company_values": ["Innovation", "Collaboration", "Excellence"],
        "soft_skills": ["Communication", "Teamwork", "Leadership"],
        "salary_min": 100000,
        "salary_max": 140000
    }


if __name__ == "__main__":
    main()
