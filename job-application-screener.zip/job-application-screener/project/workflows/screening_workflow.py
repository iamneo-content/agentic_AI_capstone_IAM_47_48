"""
Job Screening Workflow Builder

Defines the staged job application screening pipeline with parallel and sequential nodes.
"""

from graph import JobScreeningGraph
from nodes import (
    resume_parser_node,
    skills_matcher_node,
    experience_analyzer_node,
    culture_fit_node,
    salary_node,
    coordinator_node,
    decision_node,
    report_node
)


def build_screening_workflow(max_workers: int = 5) -> JobScreeningGraph:
    """
    Build the job application screening workflow with parallel execution

    Stages:
    1. Resume parsing (extract candidate information)
    2. Parallel analyses (skills, experience, culture fit, salary)
    3. Coordinator (aggregate results)
    4. Decision (make hiring decision)
    5. Report (generate final report and send notification)

    Args:
        max_workers: Maximum number of parallel workers (default: 5)

    Returns:
        Compiled JobScreeningGraph ready for execution
    """
    stages = [
        # Stage 1: Resume parsing
        [resume_parser_node],

        # Stage 2: Parallel analyses (all 4 run simultaneously)
        [skills_matcher_node, experience_analyzer_node, culture_fit_node, salary_node],

        # Stage 3: Coordinator
        [coordinator_node],

        # Stage 4: Decision
        [decision_node],

        # Stage 5: Report
        [report_node]
    ]

    return JobScreeningGraph(stages=stages, max_workers=max_workers, raise_on_error=False)
