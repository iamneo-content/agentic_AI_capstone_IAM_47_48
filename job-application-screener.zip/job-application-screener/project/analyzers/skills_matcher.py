"""
Skills Matcher

Pure tool for matching candidate skills with job requirements.
No state management - just matching logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.skills_matcher")


class SkillsMatcher:
    """Analyzer for skills matching"""

    def match_skills(self, candidate_skills: List[str], job_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Match candidate skills with job requirements

        Args:
            candidate_skills: List of candidate skills
            job_requirements: Job requirements with required and preferred skills

        Returns:
            Dictionary containing skills matching analysis
        """
        logger.info(f"Matching {len(candidate_skills)} candidate skills with job requirements")

        required_skills = job_requirements.get("required_skills", [])
        preferred_skills = job_requirements.get("preferred_skills", [])

        # Normalize skills for comparison
        candidate_skills_lower = [s.lower().strip() for s in candidate_skills]
        required_skills_lower = [s.lower().strip() for s in required_skills]
        preferred_skills_lower = [s.lower().strip() for s in preferred_skills]

        # Find matches
        matched_required = [s for s in required_skills if s.lower() in candidate_skills_lower]
        matched_preferred = [s for s in preferred_skills if s.lower() in candidate_skills_lower]

        # Find missing and additional skills
        missing_required = [s for s in required_skills if s.lower() not in candidate_skills_lower]
        missing_preferred = [s for s in preferred_skills if s.lower() not in candidate_skills_lower]
        additional_skills = [s for s in candidate_skills if s.lower() not in required_skills_lower + preferred_skills_lower]

        # Calculate match percentages
        required_match_pct = (len(matched_required) / len(required_skills) * 100) if required_skills else 100
        preferred_match_pct = (len(matched_preferred) / len(preferred_skills) * 100) if preferred_skills else 100

        # Overall match (weighted: required 70%, preferred 30%)
        overall_match = required_match_pct * 0.7 + preferred_match_pct * 0.3

        # Categorize skills
        skill_categories = self._categorize_skills(candidate_skills)

        # Generate recommendations
        recommendations = []
        if required_match_pct < 80:
            recommendations.append(f"Missing {len(missing_required)} required skills")
        if missing_required:
            recommendations.append(f"Consider training in: {', '.join(missing_required[:3])}")
        if overall_match >= 90:
            recommendations.append("Excellent skills match - strong candidate")

        result = {
            "overall_match_percentage": round(overall_match, 2),
            "required_skills_match": round(required_match_pct, 2),
            "preferred_skills_match": round(preferred_match_pct, 2),
            "matched_skills": matched_required + matched_preferred,
            "missing_skills": missing_required + missing_preferred,
            "additional_skills": additional_skills,
            "skill_categories": skill_categories,
            "recommendations": recommendations
        }

        logger.info(f"Skills matching complete: {overall_match:.1f}% overall match")
        return result

    def _categorize_skills(self, skills: List[str]) -> Dict[str, List[str]]:
        """Categorize skills into technical, soft, and other"""
        technical_keywords = ["python", "java", "javascript", "sql", "aws", "docker", "react", "node", "git"]
        soft_keywords = ["leadership", "communication", "teamwork", "management", "agile"]

        categories = {
            "technical": [],
            "soft_skills": [],
            "other": []
        }

        for skill in skills:
            skill_lower = skill.lower()
            if any(kw in skill_lower for kw in technical_keywords):
                categories["technical"].append(skill)
            elif any(kw in skill_lower for kw in soft_keywords):
                categories["soft_skills"].append(skill)
            else:
                categories["other"].append(skill)

        return categories
