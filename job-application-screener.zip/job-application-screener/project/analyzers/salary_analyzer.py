"""
Salary Analyzer

Pure tool for analyzing salary expectations alignment.
No state management - just analysis logic.
"""

from typing import Dict, Any
import logging

logger = logging.getLogger("analyzer.salary")


class SalaryAnalyzer:
    """Analyzer for salary expectations assessment"""

    def analyze_salary(self, candidate_info: Dict[str, Any], job_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze salary expectations alignment

        Args:
            candidate_info: Parsed candidate information
            job_requirements: Job requirements including salary range

        Returns:
            Dictionary containing salary analysis
        """
        logger.info("Analyzing salary expectations")

        # Get salary information
        candidate_expectation = candidate_info.get("salary_expectation", 0)
        budget_min = job_requirements.get("salary_min", 0)
        budget_max = job_requirements.get("salary_max", 0)

        # If candidate expectation not provided, estimate based on experience
        if candidate_expectation == 0:
            years_exp = candidate_info.get("total_years_experience", 0)
            # Mock estimation: $60k base + $10k per year experience
            candidate_expectation = 60000 + (years_exp * 10000)

        # Calculate variance
        budget_midpoint = (budget_min + budget_max) / 2 if budget_max > 0 else budget_min
        if budget_midpoint > 0:
            variance_percentage = ((candidate_expectation - budget_midpoint) / budget_midpoint) * 100
        else:
            variance_percentage = 0

        # Check if within budget
        within_budget = budget_min <= candidate_expectation <= budget_max if budget_max > 0 else True

        # Assess negotiation potential
        if variance_percentage <= 5:
            negotiation_potential = "Minimal negotiation needed"
        elif variance_percentage <= 15:
            negotiation_potential = "Moderate negotiation possible"
        elif variance_percentage <= 25:
            negotiation_potential = "Significant negotiation required"
        else:
            negotiation_potential = "Major gap - difficult to bridge"

        # Market comparison (mock)
        if candidate_expectation > budget_max:
            market_comparison = "Above budget range"
        elif candidate_expectation < budget_min:
            market_comparison = "Below budget range"
        else:
            market_comparison = "Within budget range"

        # Calculate salary alignment score
        salary_score = 10.0

        if not within_budget:
            if variance_percentage > 0:  # Candidate wants more
                salary_score -= min(abs(variance_percentage) / 5, 6.0)
            else:  # Candidate wants less (red flag or junior)
                salary_score -= 1.0

        salary_score = max(0, min(salary_score, 10.0))

        # Recommendations
        recommendations = []
        if within_budget:
            recommendations.append("Salary expectations align with budget")
        if variance_percentage > 20:
            recommendations.append("Consider if candidate brings exceptional value to justify higher salary")
        if variance_percentage < -10:
            recommendations.append("Candidate may be underqualified or have unrealistic expectations")
        if 0 <= variance_percentage <= 10:
            recommendations.append("Strong alignment - proceed with confidence")

        result = {
            "salary_alignment_score": round(salary_score, 2),
            "candidate_expectation": candidate_expectation,
            "budget_range": {
                "min": budget_min,
                "max": budget_max,
                "midpoint": budget_midpoint
            },
            "variance_percentage": round(variance_percentage, 2),
            "within_budget": within_budget,
            "negotiation_potential": negotiation_potential,
            "market_comparison": market_comparison,
            "recommendations": recommendations
        }

        logger.info(f"Salary analysis complete: Score {salary_score:.1f}/10, Within budget: {within_budget}")
        return result
