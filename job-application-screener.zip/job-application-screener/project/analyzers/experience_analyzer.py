"""
Experience Analyzer

Pure tool for analyzing work experience relevance and quality.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.experience_analyzer")


class ExperienceAnalyzer:
    """Analyzer for work experience assessment"""

    def analyze_experience(self, work_experience: List[Dict[str, Any]], job_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze work experience relevance and quality

        Args:
            work_experience: List of work experience entries
            job_requirements: Job requirements including experience needs

        Returns:
            Dictionary containing experience analysis
        """
        logger.info(f"Analyzing {len(work_experience)} work experience entries")

        min_years_required = job_requirements.get("min_years_experience", 0)
        required_industries = job_requirements.get("industries", [])
        required_roles = job_requirements.get("roles", [])

        # Calculate total years
        total_years = 0
        for exp in work_experience:
            duration_str = exp.get("duration", "1 year")
            years = self._extract_years(duration_str)
            total_years += years

        # Analyze relevance
        relevant_years = 0
        industry_match = False
        role_progression = []

        for exp in work_experience:
            title = exp.get("title", "").lower()
            company = exp.get("company", "").lower()
            description = exp.get("description", "").lower()

            duration_str = exp.get("duration", "1 year")
            years = self._extract_years(duration_str)

            # Check industry relevance
            if any(industry.lower() in company or industry.lower() in description for industry in required_industries):
                industry_match = True
                relevant_years += years

            # Check role relevance
            if any(role.lower() in title for role in required_roles):
                relevant_years += years

            # Track progression
            if "senior" in title or "lead" in title or "manager" in title:
                role_progression.append(f"{title} (senior role)")

        # Calculate relevance percentage
        relevance_percentage = (relevant_years / total_years * 100) if total_years > 0 else 0

        # Calculate experience score
        experience_score = 0.0
        if total_years >= min_years_required:
            experience_score += 5.0
        else:
            experience_score += (total_years / min_years_required) * 5.0

        # Add points for relevance
        experience_score += (relevance_percentage / 100) * 3.0

        # Add points for progression
        if role_progression:
            experience_score += min(len(role_progression) * 0.5, 2.0)

        experience_score = min(experience_score, 10.0)

        # Identify gaps
        experience_gaps = []
        if total_years < min_years_required:
            experience_gaps.append(f"Below minimum {min_years_required} years required")
        if not industry_match and required_industries:
            experience_gaps.append("No direct industry experience")
        if relevance_percentage < 50:
            experience_gaps.append("Low relevance to job requirements")

        # Key achievements (mock)
        key_achievements = ["Professional experience in relevant field"]

        # Recommendations
        recommendations = []
        if total_years < min_years_required:
            recommendations.append("Consider candidates with growth potential")
        if relevance_percentage < 70:
            recommendations.append("Assess transferable skills during interview")
        if experience_score >= 8.0:
            recommendations.append("Strong experience match - prioritize for interview")

        result = {
            "experience_score": round(experience_score, 2),
            "total_years": total_years,
            "relevant_years": relevant_years,
            "relevance_percentage": round(relevance_percentage, 2),
            "industry_match": industry_match,
            "role_progression": role_progression,
            "key_achievements": key_achievements,
            "experience_gaps": experience_gaps,
            "recommendations": recommendations
        }

        logger.info(f"Experience analysis complete: Score {experience_score:.1f}/10")
        return result

    def _extract_years(self, duration_str: str) -> float:
        """Extract years from duration string"""
        duration_lower = duration_str.lower()

        if "year" in duration_lower:
            # Extract number before "year"
            import re
            match = re.search(r'(\d+(?:\.\d+)?)\s*year', duration_lower)
            if match:
                return float(match.group(1))

        if "month" in duration_lower:
            # Extract number before "month" and convert to years
            import re
            match = re.search(r'(\d+)\s*month', duration_lower)
            if match:
                return float(match.group(1)) / 12

        # Default to 1 year
        return 1.0
