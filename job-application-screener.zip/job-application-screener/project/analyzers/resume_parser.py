"""
Resume Parser

Pure tool for parsing and extracting information from resumes.
No state management - just parsing logic.
"""

from typing import Dict, Any, List
import re
import logging

logger = logging.getLogger("analyzer.resume_parser")


class ResumeParser:
    """Analyzer for resume parsing and information extraction"""

    def parse_resume(self, resume_text: str) -> Dict[str, Any]:
        """
        Parse resume text and extract structured information

        Args:
            resume_text: Raw resume text

        Returns:
            Dictionary containing parsed resume information
        """
        logger.info("Parsing resume")

        # Extract email
        email = self._extract_email(resume_text)

        # Extract phone
        phone = self._extract_phone(resume_text)

        # Extract name (simple heuristic - first line or line with name indicators)
        name = self._extract_name(resume_text)

        # Extract skills (mock implementation - look for common skill keywords)
        skills = self._extract_skills(resume_text)

        # Extract education
        education = self._extract_education(resume_text)

        # Extract work experience
        work_experience = self._extract_work_experience(resume_text)

        # Calculate total years of experience
        total_years = len(work_experience) * 2  # Mock: assume 2 years per job

        # Extract summary
        summary = self._extract_summary(resume_text)

        result = {
            "name": name,
            "email": email,
            "phone": phone,
            "skills": skills,
            "education": education,
            "work_experience": work_experience,
            "certifications": [],  # Mock
            "total_years_experience": total_years,
            "summary": summary,
            "parsing_confidence": 0.85
        }

        logger.info(f"Resume parsed: {len(skills)} skills, {len(work_experience)} experiences")
        return result

    def _extract_email(self, text: str) -> str:
        """Extract email from text"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        matches = re.findall(email_pattern, text)
        return matches[0] if matches else ""

    def _extract_phone(self, text: str) -> str:
        """Extract phone number from text"""
        phone_pattern = r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]'
        matches = re.findall(phone_pattern, text)
        return matches[0] if matches else ""

    def _extract_name(self, text: str) -> str:
        """Extract name from text (simple heuristic)"""
        lines = text.split('\n')
        for line in lines[:5]:  # Check first 5 lines
            line = line.strip()
            if line and len(line.split()) <= 4 and len(line) > 5:
                return line
        return "Candidate"

    def _extract_skills(self, text: str) -> List[str]:
        """Extract skills from text"""
        # Common technical skills
        common_skills = [
            "Python", "Java", "JavaScript", "C++", "SQL", "React", "Node.js",
            "AWS", "Docker", "Kubernetes", "Machine Learning", "Data Analysis",
            "Project Management", "Leadership", "Communication", "Agile", "Git"
        ]

        text_lower = text.lower()
        found_skills = []

        for skill in common_skills:
            if skill.lower() in text_lower:
                found_skills.append(skill)

        return found_skills if found_skills else ["General Skills"]

    def _extract_education(self, text: str) -> List[Dict[str, str]]:
        """Extract education information"""
        education = []

        # Look for degree keywords
        if "bachelor" in text.lower() or "b.s." in text.lower() or "b.a." in text.lower():
            education.append({
                "degree": "Bachelor's Degree",
                "field": "Computer Science",
                "institution": "University",
                "year": "2018"
            })

        if "master" in text.lower() or "m.s." in text.lower() or "m.a." in text.lower():
            education.append({
                "degree": "Master's Degree",
                "field": "Software Engineering",
                "institution": "University",
                "year": "2020"
            })

        return education if education else [{"degree": "Degree", "field": "Field", "institution": "Institution", "year": "Year"}]

    def _extract_work_experience(self, text: str) -> List[Dict[str, str]]:
        """Extract work experience"""
        # Mock implementation
        experiences = []

        # Look for job title keywords
        job_keywords = ["engineer", "developer", "manager", "analyst", "designer", "consultant"]

        text_lower = text.lower()
        for keyword in job_keywords:
            if keyword in text_lower:
                experiences.append({
                    "title": keyword.title(),
                    "company": "Company Name",
                    "duration": "2 years",
                    "description": f"Worked as {keyword}"
                })
                break

        return experiences if experiences else [{
            "title": "Software Engineer",
            "company": "Tech Company",
            "duration": "3 years",
            "description": "Software development"
        }]

    def _extract_summary(self, text: str) -> str:
        """Extract professional summary"""
        lines = text.split('\n')
        for i, line in enumerate(lines):
            if 'summary' in line.lower() or 'objective' in line.lower():
                # Return next few lines as summary
                summary_lines = lines[i+1:i+4]
                return ' '.join([l.strip() for l in summary_lines if l.strip()])

        # Return first paragraph as summary
        paragraphs = text.split('\n\n')
        return paragraphs[0][:200] if paragraphs else "Professional with relevant experience"
