"""
Culture Fit Analyzer

Pure tool for analyzing cultural fit and soft skills.
No state management - just analysis logic.
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger("analyzer.culture_fit")


class CultureFitAnalyzer:
    """Analyzer for culture fit and soft skills assessment"""

    def analyze_culture_fit(self, candidate_info: Dict[str, Any], cover_letter: str, job_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze cultural fit and soft skills alignment

        Args:
            candidate_info: Parsed candidate information
            cover_letter: Candidate's cover letter
            job_requirements: Job requirements including culture fit criteria

        Returns:
            Dictionary containing culture fit analysis
        """
        logger.info("Analyzing culture fit")

        company_values = job_requirements.get("company_values", [])
        required_soft_skills = job_requirements.get("soft_skills", [])

        # Analyze cover letter if available
        text_to_analyze = cover_letter.lower() if cover_letter else ""

        # Also include resume summary
        if candidate_info.get("summary"):
            text_to_analyze += " " + candidate_info["summary"].lower()

        # Identify soft skills
        soft_skills_map = {
            "communication": ["communicate", "presentation", "writing", "speaking"],
            "teamwork": ["team", "collaborate", "cooperation", "group"],
            "leadership": ["lead", "manage", "mentor", "guide"],
            "problem-solving": ["solve", "problem", "analytical", "critical thinking"],
            "adaptability": ["adapt", "flexible", "change", "dynamic"],
            "creativity": ["creative", "innovative", "design", "ideate"]
        }

        soft_skills_identified = []
        for skill, keywords in soft_skills_map.items():
            if any(keyword in text_to_analyze for keyword in keywords):
                soft_skills_identified.append(skill)

        # Assess communication style
        communication_style = self._assess_communication_style(text_to_analyze)

        # Identify motivation indicators
        motivation_keywords = ["passionate", "excited", "motivated", "eager", "interested", "dedicated"]
        motivation_indicators = [kw for kw in motivation_keywords if kw in text_to_analyze]

        # Values alignment
        values_alignment = []
        for value in company_values:
            if value.lower() in text_to_analyze:
                values_alignment.append(f"Alignment with {value}")

        # Team fit assessment
        team_fit_assessment = "Good potential fit" if soft_skills_identified else "Need to assess in interview"

        # Identify red flags
        red_flags = []
        negative_keywords = ["quit", "fired", "conflict", "disagree", "problem with"]
        for keyword in negative_keywords:
            if keyword in text_to_analyze:
                red_flags.append(f"Mentions '{keyword}' - requires clarification")

        # Calculate culture fit score
        culture_fit_score = 5.0  # Base score

        # Add points for soft skills
        culture_fit_score += min(len(soft_skills_identified) * 0.5, 3.0)

        # Add points for motivation
        culture_fit_score += min(len(motivation_indicators) * 0.3, 1.5)

        # Add points for values alignment
        culture_fit_score += min(len(values_alignment) * 0.3, 1.0)

        # Deduct points for red flags
        culture_fit_score -= len(red_flags) * 0.5

        culture_fit_score = max(0, min(culture_fit_score, 10.0))

        # Recommendations
        recommendations = []
        if culture_fit_score >= 8.0:
            recommendations.append("Strong culture fit - values alignment evident")
        if len(soft_skills_identified) < 3:
            recommendations.append("Probe for soft skills during interview")
        if red_flags:
            recommendations.append("Address red flags during screening call")

        result = {
            "culture_fit_score": round(culture_fit_score, 2),
            "soft_skills_identified": soft_skills_identified,
            "communication_style": communication_style,
            "motivation_indicators": motivation_indicators,
            "values_alignment": values_alignment,
            "team_fit_assessment": team_fit_assessment,
            "red_flags": red_flags,
            "recommendations": recommendations
        }

        logger.info(f"Culture fit analysis complete: Score {culture_fit_score:.1f}/10")
        return result

    def _assess_communication_style(self, text: str) -> str:
        """Assess communication style from text"""
        if not text:
            return "Unable to assess"

        word_count = len(text.split())

        if word_count > 300:
            return "Detailed and thorough"
        elif word_count > 150:
            return "Balanced and clear"
        elif word_count > 50:
            return "Concise and direct"
        else:
            return "Very brief"
