"""
Resume Parser Agent

Agent responsible for parsing and extracting information from resumes.
Uses ResumeParser as a tool for actual parsing.
"""

from typing import Dict, Any
from .base_agent import BaseAgent
from analyzers.resume_parser import ResumeParser


class ResumeParserAgent(BaseAgent):
    """Agent for resume parsing and information extraction"""

    def __init__(self):
        """Initialize resume parser agent with parser"""
        super().__init__("resume_parser")
        self.parser = ResumeParser()
        self.log("Resume parser agent initialized")

    def analyze(self, resume_text: str, candidate_name: str = "") -> Dict[str, Any]:
        """
        Parse resume and extract structured information

        Pure reasoning logic only - coordinates parsing using parser tool

        Args:
            resume_text: Raw resume text
            candidate_name: Candidate name (optional)

        Returns:
            Dictionary containing parsed resume information
        """
        self.log(f"Parsing resume for {candidate_name if candidate_name else 'candidate'}")

        # Use parser tool for actual parsing
        parsed_data = self.parser.parse_resume(resume_text)

        result = {
            "candidate_name": parsed_data.get("name", candidate_name),
            "email": parsed_data.get("email", ""),
            "phone": parsed_data.get("phone", ""),
            "education": parsed_data.get("education", []),
            "work_experience": parsed_data.get("work_experience", []),
            "skills": parsed_data.get("skills", []),
            "certifications": parsed_data.get("certifications", []),
            "total_years_experience": parsed_data.get("total_years_experience", 0),
            "summary": parsed_data.get("summary", ""),
            "parsing_confidence": parsed_data.get("parsing_confidence", 0.8)
        }

        skills_count = len(result.get("skills", []))
        exp_count = len(result.get("work_experience", []))
        self.log(f"Parsing complete: {skills_count} skills, {exp_count} work experiences found")

        return result
