"""
Coordinator Agent

Agent responsible for coordinating and aggregating results from all screening agents.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent


class CoordinatorAgent(BaseAgent):
    """Agent for coordinating and aggregating screening results"""

    def __init__(self):
        """Initialize coordinator agent"""
        super().__init__("coordinator")
        self.log("Coordinator agent initialized")

    def analyze(self, resume_parsing_results: Dict[str, Any],
                skills_matching_results: List[Dict[str, Any]],
                experience_results: List[Dict[str, Any]],
                culture_fit_results: List[Dict[str, Any]],
                salary_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Coordinate and aggregate results from all screening agents

        Args:
            resume_parsing_results: Results from resume parser agent
            skills_matching_results: Results from skills matcher agent
            experience_results: Results from experience analyzer agent
            culture_fit_results: Results from culture fit agent
            salary_results: Results from salary agent

        Returns:
            Coordinated summary of all results
        """
        self.log("Coordinating results from all screening agents")

        # Extract scores
        skills_match = skills_matching_results[0].get("overall_match_percentage", 0) if skills_matching_results else 0
        experience_score = experience_results[0].get("experience_score", 0) if experience_results else 0
        culture_fit_score = culture_fit_results[0].get("culture_fit_score", 0) if culture_fit_results else 0
        salary_score = salary_results[0].get("salary_alignment_score", 0) if salary_results else 0

        # Calculate overall score (weighted average)
        # Skills: 35%, Experience: 30%, Culture Fit: 20%, Salary: 15%
        overall_score = (
            (skills_match / 10) * 0.35 +  # Convert percentage to 0-10 scale
            experience_score * 0.30 +
            culture_fit_score * 0.20 +
            salary_score * 0.15
        )

        # Check for critical issues
        has_critical_issues = False
        critical_issues = []

        if skills_match < 50:
            critical_issues.append("Skills match below 50%")
        if experience_score < 5.0:
            critical_issues.append("Experience score below minimum threshold")
        if culture_fit_results and len(culture_fit_results[0].get("red_flags", [])) > 2:
            critical_issues.append("Multiple culture fit red flags")
        if salary_results and not salary_results[0].get("within_budget", True):
            critical_issues.append("Salary expectations outside budget range")

        coordination_summary = {
            "overall_score": round(overall_score, 2),
            "skills_match_percentage": round(skills_match, 2),
            "experience_score": round(experience_score, 2),
            "culture_fit_score": round(culture_fit_score, 2),
            "salary_alignment_score": round(salary_score, 2),
            "total_agents": 5,
            "has_critical_issues": len(critical_issues) > 0,
            "critical_issues": critical_issues,
            "analysis_complete": True
        }

        self.log(f"Coordination complete: Overall score {overall_score:.2f}/10")
        return coordination_summary
