"""
Culture Fit Agent

Agent responsible for assessing cultural alignment and soft skills.
Uses CultureFitAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.culture_fit_analyzer import CultureFitAnalyzer


class CultureFitAgent(BaseAgent):
    """Agent for culture fit and soft skills analysis"""

    def __init__(self):
        """Initialize culture fit agent with analyzer"""
        super().__init__("culture_fit")
        self.analyzer = CultureFitAnalyzer()
        self.log("Culture fit agent initialized")

    def analyze(self, candidate_info: Dict[str, Any], cover_letter: str, job_requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze cultural fit and soft skills alignment

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            candidate_info: Parsed candidate information
            cover_letter: Candidate's cover letter
            job_requirements: Job requirements including culture fit criteria

        Returns:
            List of culture fit analysis results
        """
        self.log(f"Analyzing culture fit for candidate")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_culture_fit(candidate_info, cover_letter, job_requirements)

        results.append({
            "culture_fit_score": analysis.get("culture_fit_score", 0),
            "soft_skills_identified": analysis.get("soft_skills_identified", []),
            "communication_style": analysis.get("communication_style", ""),
            "motivation_indicators": analysis.get("motivation_indicators", []),
            "values_alignment": analysis.get("values_alignment", []),
            "team_fit_assessment": analysis.get("team_fit_assessment", ""),
            "red_flags": analysis.get("red_flags", []),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("culture_fit_score", 0)
        red_flags = len(analysis.get("red_flags", []))
        self.log(f"Culture fit analysis complete: Score {score}/10, {red_flags} red flags")
        return results
