"""
Skills Matcher Agent

Agent responsible for matching candidate skills with job requirements.
Uses SkillsMatcher as a tool for actual matching.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.skills_matcher import SkillsMatcher


class SkillsMatcherAgent(BaseAgent):
    """Agent for skills matching analysis"""

    def __init__(self):
        """Initialize skills matcher agent with matcher"""
        super().__init__("skills_matcher")
        self.matcher = SkillsMatcher()
        self.log("Skills matcher agent initialized")

    def analyze(self, candidate_skills: List[str], job_requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Match candidate skills with job requirements

        Pure reasoning logic only - coordinates matching using matcher tool

        Args:
            candidate_skills: List of candidate skills
            job_requirements: Job requirements including required and preferred skills

        Returns:
            List of skills matching analysis results
        """
        self.log(f"Matching {len(candidate_skills)} candidate skills with job requirements")
        results: List[Dict[str, Any]] = []

        # Use matcher tool for actual matching
        matching_analysis = self.matcher.match_skills(candidate_skills, job_requirements)

        results.append({
            "overall_match_percentage": matching_analysis.get("overall_match_percentage", 0),
            "required_skills_match": matching_analysis.get("required_skills_match", 0),
            "preferred_skills_match": matching_analysis.get("preferred_skills_match", 0),
            "matched_skills": matching_analysis.get("matched_skills", []),
            "missing_skills": matching_analysis.get("missing_skills", []),
            "additional_skills": matching_analysis.get("additional_skills", []),
            "skill_categories": matching_analysis.get("skill_categories", {}),
            "recommendations": matching_analysis.get("recommendations", [])
        })

        match_pct = matching_analysis.get("overall_match_percentage", 0)
        self.log(f"Skills matching complete: {match_pct}% overall match")
        return results
