"""
Experience Analyzer Agent

Agent responsible for analyzing work experience relevance and quality.
Uses ExperienceAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.experience_analyzer import ExperienceAnalyzer


class ExperienceAnalyzerAgent(BaseAgent):
    """Agent for work experience analysis"""

    def __init__(self):
        """Initialize experience analyzer agent with analyzer"""
        super().__init__("experience_analyzer")
        self.analyzer = ExperienceAnalyzer()
        self.log("Experience analyzer agent initialized")

    def analyze(self, work_experience: List[Dict[str, Any]], job_requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze work experience relevance and quality

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            work_experience: List of work experience entries
            job_requirements: Job requirements including experience needs

        Returns:
            List of experience analysis results
        """
        self.log(f"Analyzing {len(work_experience)} work experience entries")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_experience(work_experience, job_requirements)

        results.append({
            "experience_score": analysis.get("experience_score", 0),
            "total_years": analysis.get("total_years", 0),
            "relevant_years": analysis.get("relevant_years", 0),
            "relevance_percentage": analysis.get("relevance_percentage", 0),
            "industry_match": analysis.get("industry_match", False),
            "role_progression": analysis.get("role_progression", []),
            "key_achievements": analysis.get("key_achievements", []),
            "experience_gaps": analysis.get("experience_gaps", []),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("experience_score", 0)
        relevant_years = analysis.get("relevant_years", 0)
        self.log(f"Experience analysis complete: Score {score}/10, {relevant_years} relevant years")
        return results
