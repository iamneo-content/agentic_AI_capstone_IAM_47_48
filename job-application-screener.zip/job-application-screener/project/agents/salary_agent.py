"""
Salary Expectations Agent

Agent responsible for analyzing salary expectations alignment.
Uses SalaryAnalyzer as a tool for actual analysis.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.salary_analyzer import SalaryAnalyzer


class SalaryAgent(BaseAgent):
    """Agent for salary expectations analysis"""

    def __init__(self):
        """Initialize salary agent with analyzer"""
        super().__init__("salary")
        self.analyzer = SalaryAnalyzer()
        self.log("Salary agent initialized")

    def analyze(self, candidate_info: Dict[str, Any], job_requirements: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze salary expectations alignment

        Pure reasoning logic only - coordinates analysis using analyzer tool

        Args:
            candidate_info: Parsed candidate information including salary expectations
            job_requirements: Job requirements including salary range

        Returns:
            List of salary analysis results
        """
        self.log(f"Analyzing salary expectations")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual analysis
        analysis = self.analyzer.analyze_salary(candidate_info, job_requirements)

        results.append({
            "salary_alignment_score": analysis.get("salary_alignment_score", 0),
            "candidate_expectation": analysis.get("candidate_expectation", 0),
            "budget_range": analysis.get("budget_range", {}),
            "variance_percentage": analysis.get("variance_percentage", 0),
            "within_budget": analysis.get("within_budget", False),
            "negotiation_potential": analysis.get("negotiation_potential", ""),
            "market_comparison": analysis.get("market_comparison", ""),
            "recommendations": analysis.get("recommendations", [])
        })

        score = analysis.get("salary_alignment_score", 0)
        within_budget = analysis.get("within_budget", False)
        self.log(f"Salary analysis complete: Score {score}/10, Within budget: {within_budget}")
        return results
