"""
Email Notification Service

Sends email notifications for job screening events.
"""

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
from config import get_config_value

logger = logging.getLogger("service.email")


class EmailService:
    """Service for sending email notifications"""

    def __init__(self):
        """Initialize email service"""
        self.smtp_server = get_config_value("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = get_config_value("SMTP_PORT", 587)
        self.email_from = get_config_value("EMAIL_FROM", "")
        self.email_password = get_config_value("EMAIL_PASSWORD", "")
        self.email_to = get_config_value("EMAIL_TO", "")

    def send_email(self, subject: str, body: str, html: bool = False) -> bool:
        """
        Send an email

        Args:
            subject: Email subject
            body: Email body
            html: Whether body is HTML (default: False)

        Returns:
            True if sent successfully, False otherwise
        """
        if not all([self.email_from, self.email_password, self.email_to]):
            logger.warning("Email configuration incomplete, skipping email")
            return False

        try:
            # Create message
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = self.email_from
            msg["To"] = self.email_to

            # Add body
            if html:
                msg.attach(MIMEText(body, "html"))
            else:
                msg.attach(MIMEText(body, "plain"))

            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.email_from, self.email_password)
                server.send_message(msg)

            logger.info(f"Email sent successfully: {subject}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False

    def send_screening_start_email(self, screening_id: str, candidate_name: str, position: str) -> bool:
        """
        Send notification that screening has started

        Args:
            screening_id: Screening ID
            candidate_name: Candidate name
            position: Position title

        Returns:
            True if sent successfully
        """
        subject = f"Application Screening Started - {candidate_name} for {position}"

        body = f"""
Job Application Screening Started

Screening ID: {screening_id}
Candidate: {candidate_name}
Position: {position}

Automated screening is now in progress. You will receive a final report once complete.

This is an automated message from the Job Application Screener system.
        """

        return self.send_email(subject, body.strip())

    def send_final_report_email(self, state) -> bool:
        """
        Send final screening report

        Args:
            state: JobApplicationState with complete screening results

        Returns:
            True if sent successfully
        """
        subject = f"Screening Complete - {state.candidate_name} - {state.decision}"

        # Build email body
        body = f"""
JOB APPLICATION SCREENING COMPLETE
{'='*60}

Screening ID: {state.screening_id}
Candidate: {state.candidate_name}
Email: {state.candidate_email}
Position: {state.position_title}
Timestamp: {state.timestamp}

DECISION: {state.decision}
OVERALL SCORE: {state.overall_score:.2f}/10.0
RECOMMENDATION: {state.recommendation_level}

{'='*60}
SCREENING METRICS
{'='*60}

Skills Match:         {state.decision_metrics.get('skills_match_percentage', 0):.1f}%
Experience Score:     {state.decision_metrics.get('experience_score', 0):.2f}/10.0
Culture Fit Score:    {state.decision_metrics.get('culture_fit_score', 0):.2f}/10.0
Salary Alignment:     {state.decision_metrics.get('salary_alignment_score', 0):.2f}/10.0

{'='*60}
KEY FINDINGS
{'='*60}

"""
        if state.report and state.report.get('key_findings'):
            for finding in state.report['key_findings']:
                body += f"  - {finding}\n"

        if state.has_critical_issues:
            body += f"\n[!] CRITICAL ISSUES: {state.critical_reason}\n"

        body += f"\n{'='*60}\n"
        body += "ACTION ITEMS\n"
        body += f"{'='*60}\n\n"

        if state.feedback_points:
            for point in state.feedback_points:
                body += f"  - {point}\n"

        if state.decision == "INTERVIEW" and state.interview_questions:
            body += f"\n{'='*60}\n"
            body += "SUGGESTED INTERVIEW QUESTIONS\n"
            body += f"{'='*60}\n\n"
            for i, question in enumerate(state.interview_questions, 1):
                body += f"  {i}. {question}\n"

        body += "\n" + "="*60 + "\n"
        body += "This is an automated message from the Job Application Screener system.\n"

        return self.send_email(subject, body.strip())
