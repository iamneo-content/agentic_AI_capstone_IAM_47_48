"""
Job Application State - Shared State for Job Screening Pipeline

Dataclass-based state management with clone and merge capabilities.
This is ONLY a data structure - NO business logic, NO orchestration logic.
"""

from dataclasses import dataclass, field, asdict, is_dataclass
from typing import List, Dict, Any, Optional
import copy


@dataclass
class JobApplicationState:
    """
    Shared state for multi-agent job application screening pipeline

    This is a pure data structure with helper methods for state management.
    All business logic lives in agents/ and nodes/
    All orchestration logic lives in graph.py and workflows/
    """

    # Basic application information
    screening_id: str = ""
    candidate_name: str = ""
    candidate_email: str = ""
    position_title: str = ""
    timestamp: str = ""

    # Application data
    resume_text: str = ""
    cover_letter: str = ""
    job_description: str = ""
    job_requirements: Dict[str, Any] = field(default_factory=dict)
    candidate_info: Dict[str, Any] = field(default_factory=dict)

    # Analysis results (populated by agents)
    resume_parsing_results: Dict[str, Any] = field(default_factory=dict)
    skills_matching_results: List[Dict[str, Any]] = field(default_factory=list)
    experience_results: List[Dict[str, Any]] = field(default_factory=list)
    culture_fit_results: List[Dict[str, Any]] = field(default_factory=list)
    salary_results: List[Dict[str, Any]] = field(default_factory=list)

    # Coordination data
    coordination_summary: Dict[str, Any] = field(default_factory=dict)

    # Decision results
    decision: str = ""  # INTERVIEW, REJECT, WAITLIST
    overall_score: float = 0.0
    recommendation_level: str = ""
    has_critical_issues: bool = False
    critical_reason: str = ""
    decision_metrics: Dict[str, Any] = field(default_factory=dict)

    # Report data
    report: Dict[str, Any] = field(default_factory=dict)
    interview_questions: List[str] = field(default_factory=list)
    feedback_points: List[str] = field(default_factory=list)

    # Workflow metadata
    notifications_sent: List[Dict[str, Any]] = field(default_factory=list)
    error: str = ""
    workflow_complete: bool = False
    updated_at: str = ""

    # Extra metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def clone(self) -> "JobApplicationState":
        """
        Deep copy for safe parallel execution

        Returns:
            Deep copy of the current state
        """
        return copy.deepcopy(self)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert state to dictionary

        Returns:
            Dictionary representation of state
        """
        return asdict(self)

    def merge_from(self, other: Any, overwrite_scalars: bool = True) -> None:
        """
        Merge another JobApplicationState or dict into this state

        Lists are extended, dicts are shallow merged, scalars are overwritten if allowed.

        Args:
            other: Another JobApplicationState instance or dictionary to merge from
            overwrite_scalars: Whether to overwrite scalar values (default: True)
        """
        if other is None:
            return

        # Convert to dict if it's a dataclass
        if is_dataclass(other):
            other_dict = asdict(other)
        elif isinstance(other, dict):
            other_dict = other
        else:
            return

        for key, val in other_dict.items():
            if val is None:
                continue

            if not hasattr(self, key):
                # Store unknown keys in metadata
                self.metadata.setdefault("extra", {})[key] = val
                continue

            current = getattr(self, key)

            # Merge lists by extending
            if isinstance(current, list) and isinstance(val, list):
                current.extend(val)
                setattr(self, key, current)
                continue

            # Merge dicts by updating
            if isinstance(current, dict) and isinstance(val, dict):
                merged = current.copy()
                merged.update(val)
                setattr(self, key, merged)
                continue

            # Merge scalars by overwriting (if allowed and value is not empty)
            if overwrite_scalars and val not in (None, "", [], {}):
                setattr(self, key, val)
