#!/usr/bin/env python3
"""
Comprehensive Test Suite for Job Application Screener

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
import tempfile
from typing import Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import JobApplicationState
    from graph import JobScreeningGraph
    from workflows.screening_workflow import build_screening_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.resume_parser_agent import ResumeParserAgent
    from agents.skills_matcher_agent import SkillsMatcherAgent
    from agents.experience_analyzer_agent import ExperienceAnalyzerAgent
    from agents.culture_fit_agent import CultureFitAgent
    from agents.salary_agent import SalaryAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.resume_parser import ResumeParser
    from analyzers.skills_matcher import SkillsMatcher
    from analyzers.experience_analyzer import ExperienceAnalyzer
    from analyzers.culture_fit_analyzer import CultureFitAnalyzer
    from analyzers.salary_analyzer import SalaryAnalyzer

    # Import nodes
    from nodes.resume_parser_node import resume_parser_node
    from nodes.skills_matcher_node import skills_matcher_node
    from nodes.experience_analyzer_node import experience_analyzer_node
    from nodes.culture_fit_node import culture_fit_node
    from nodes.salary_node import salary_node
    from nodes.decision_node import decision_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestJobApplicationScreenerArchitecture(unittest.TestCase):
    """Test suite for Job Application Screener Architecture"""

    SAMPLE_RESUME = '''
John Doe
Software Engineer

EXPERIENCE:
- Senior Software Engineer at Tech Corp (2020-2023)
  - Led team of 5 developers
  - Developed microservices using Python and Docker
  - Implemented CI/CD pipelines

- Software Engineer at StartUp Inc (2018-2020)
  - Built web applications using React and Node.js
  - Worked with AWS cloud services

SKILLS:
Python, JavaScript, React, Node.js, Docker, Kubernetes, AWS, Git

EDUCATION:
Bachelor of Science in Computer Science, State University (2014-2018)

Expected Salary: $120,000 - $150,000
    '''

    SAMPLE_JOB = {
        "title": "Senior Software Engineer",
        "required_skills": ["Python", "Docker", "Kubernetes"],
        "experience_required": 3,
        "salary_range": {"min": 100000, "max": 140000}
    }

    def setUp(self):
        """Setup test environment"""
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
        self.temp_file.write(self.SAMPLE_RESUME)
        self.temp_file_path = self.temp_file.name
        self.temp_file.close()

    def tearDown(self):
        """Clean up test environment"""
        if os.path.exists(self.temp_file_path):
            os.unlink(self.temp_file_path)

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test JobApplicationState dataclass creation"""
        logger.info("Testing JobApplicationState creation...")

        state = JobApplicationState(
            screening_id="TEST-123",
            job_requirements=self.SAMPLE_JOB
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.screening_id, "TEST-123", "Screening ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test JobApplicationState clone method"""
        logger.info("Testing JobApplicationState clone...")

        state = JobApplicationState(screening_id="TEST-123", job_requirements=self.SAMPLE_JOB)
        state.resume_parsing_results = {"test": "data"}

        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.screening_id, state.screening_id, "Screening ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_resume_parser(self):
        """Test ResumeParser (pure tool)"""
        logger.info("Testing ResumeParser...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        analyzer = ResumeParser()
        results = analyzer.parse_resume(content)

        self.assertIsNotNone(results, "Resume parsing results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ ResumeParser tests passed")

    def test_skills_matcher(self):
        """Test SkillsMatcher (pure tool)"""
        logger.info("Testing SkillsMatcher...")

        resume_data = {"skills": ["Python", "Docker", "Kubernetes"]}

        analyzer = SkillsMatcher()
        results = analyzer.match_skills(resume_data, self.SAMPLE_JOB)

        self.assertIsNotNone(results, "Skills matching results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ SkillsMatcher tests passed")

    def test_experience_analyzer(self):
        """Test ExperienceAnalyzer (pure tool)"""
        logger.info("Testing ExperienceAnalyzer...")

        work_experience = [{"title": "Software Engineer", "company": "Tech Corp", "duration": "5 years", "description": "Developed software"}]

        analyzer = ExperienceAnalyzer()
        results = analyzer.analyze_experience(work_experience, self.SAMPLE_JOB)

        self.assertIsNotNone(results, "Experience analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ ExperienceAnalyzer tests passed")

    def test_culture_fit_analyzer(self):
        """Test CultureFitAnalyzer (pure tool)"""
        logger.info("Testing CultureFitAnalyzer...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        candidate_info = {"summary": "Passionate software engineer with team leadership experience"}
        cover_letter = content

        analyzer = CultureFitAnalyzer()
        results = analyzer.analyze_culture_fit(candidate_info, cover_letter, self.SAMPLE_JOB)

        self.assertIsNotNone(results, "Culture fit analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ CultureFitAnalyzer tests passed")

    def test_salary_analyzer(self):
        """Test SalaryAnalyzer (pure tool)"""
        logger.info("Testing SalaryAnalyzer...")

        resume_data = {"expected_salary": {"min": 120000, "max": 150000}}

        analyzer = SalaryAnalyzer()
        results = analyzer.analyze_salary(resume_data, self.SAMPLE_JOB)

        self.assertIsNotNone(results, "Salary analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ SalaryAnalyzer tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_resume_parser_agent(self):
        """Test ResumeParserAgent (coordinator)"""
        logger.info("Testing ResumeParserAgent...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        agent = ResumeParserAgent()
        results = agent.analyze(content, self.temp_file_path)

        self.assertIsNotNone(results, "Resume parser agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ ResumeParserAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_resume_parser_node(self):
        """Test resume_parser_node (thin wrapper)"""
        logger.info("Testing resume_parser_node...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        state = JobApplicationState(
            screening_id="TEST-APP",
            resume_text=content,
            job_requirements=self.SAMPLE_JOB
        )

        result = resume_parser_node(state)

        self.assertIsNotNone(result, "Resume parser node result should not be None")
        self.assertIsInstance(result, JobApplicationState, "Result should be JobApplicationState")

        logger.info("✓ resume_parser_node tests passed")

    def test_decision_node(self):
        """Test decision_node logic"""
        logger.info("Testing decision_node...")

        state = JobApplicationState(
            screening_id="TEST-APP",
            resume_parsing_results={"parsing_score": 8.5},
            skills_matching_results=[{"skills_score": 8.0}],
            experience_results=[{"experience_score": 7.5}],
            culture_fit_results=[{"culture_score": 8.0}],
            salary_results=[{"salary_match": True}]
        )

        result = decision_node(state)

        self.assertIsNotNone(result, "Decision result should not be None")
        self.assertIsInstance(result, JobApplicationState, "Result should be JobApplicationState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ decision_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_screening_graph_creation(self):
        """Test JobScreeningGraph class creation"""
        logger.info("Testing JobScreeningGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = JobScreeningGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ JobScreeningGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_screening_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, JobScreeningGraph, "Workflow should be JobScreeningGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        resume_agent = ResumeParserAgent()
        self.assertIsNotNone(resume_agent.parser, "ResumeParserAgent should have a parser")
        self.assertIsInstance(resume_agent.parser, ResumeParser, "Should use ResumeParser")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        state = JobApplicationState(
            screening_id="TEST-APP",
            resume_text=content,
            job_requirements=self.SAMPLE_JOB
        )

        result = resume_parser_node(state)
        self.assertIsInstance(result, JobApplicationState, "Node should return JobApplicationState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Job Application Screener - Test Suite")
    logger.info("=" * 70)

    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
