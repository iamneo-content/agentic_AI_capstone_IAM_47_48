import os
from serpapi import GoogleSearch

class WebSearchService:
    def search(self, query: str, num_results: int = 5) -> list[dict]:
        print(f"WEB SEARCH SERVICE: Searching for '{query}' using SerpApi...")
        results = []
        try:
            api_key = os.getenv("SERPAPI_API_KEY")
            if not api_key:
                raise ValueError("SERPAPI_API_KEY not found in .env file or is not set.")

            params = {
                "q": query,
                "api_key": api_key,
                "num": num_results,
            }
            
            search = GoogleSearch(params)
            search_results = search.get_dict()
            
            if "organic_results" in search_results:
                for result in search_results["organic_results"]:
                    results.append({"url": result.get("link"), "content": result.get("snippet")})
            
        except Exception as e:
            print(f"An error occurred during web search with SerpApi: {e}")
        
        return results
