from ..state import ResearchState

def synthesis_node(state: ResearchState) -> ResearchState:
    print("---SYNTHESIS NODE---")
    # In a real implementation, this would call the result synthesizer agent
    print("Results synthesized.")
    return state
