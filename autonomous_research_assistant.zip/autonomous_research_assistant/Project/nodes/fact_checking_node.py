from ..state import ResearchState

def fact_checking_node(state: ResearchState) -> ResearchState:
    print("---FACT CHECKING NODE---")
    # In a real implementation, this would call the fact checker agent
    print("Facts checked.")
    return state
