from state import ResearchState
from services.llm_service import LLMService

def analysis_node(state: ResearchState) -> dict:
    print("---ANALYSIS NODE---")
    
    llm_service = LLMService()
    
    prompt = f"""
    You are a research analyst. Your task is to provide a concise summary of the following search results for the query: "{state["original_query"]}"
    
    Search results:
    """
    
    for result in state["search_results"]:
        prompt += f"- {result['url']}: {result['content']}\n"
        
    prompt += "\nSummary:"

    summary = llm_service.invoke(prompt)
    
    print(f"ANALYSIS: Summary generated.")
    return {"research_summary": summary}
