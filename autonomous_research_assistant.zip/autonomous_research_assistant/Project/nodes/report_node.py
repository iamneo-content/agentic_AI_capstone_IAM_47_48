from state import ResearchState
from services.llm_service import LLMService

def report_node(state: ResearchState) -> dict:
    print("---REPORT NODE---")
    
    llm_service = LLMService()
    
    prompt = f"""
    You are a report generator. Your task is to generate a comprehensive report based on the following research summary for the query: "{state["original_query"]}"
    
    Research Summary:
    {state["research_summary"]}
    
    Provide a detailed report based on this summary.
    """

    report = llm_service.invoke(prompt)

    print("\n" + "="*80)
    print("FINAL RESEARCH REPORT")
    print("="*80 + "\n")
    print(report)
    print("\n" + "="*80)

    return state
