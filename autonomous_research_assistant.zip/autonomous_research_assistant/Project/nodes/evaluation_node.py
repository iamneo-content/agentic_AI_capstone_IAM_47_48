from ..state import ResearchState

def evaluation_node(state: ResearchState) -> ResearchState:
    print("---EVALUATION NODE---")
    # In a real implementation, this would call the source evaluator agent
    print("Sources evaluated.")
    return state
