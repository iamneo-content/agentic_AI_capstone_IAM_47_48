from state import ResearchState
from nodes.planning_node import planning_node
from nodes.data_gathering_node import data_gathering_node
from nodes.analysis_node import analysis_node
from nodes.report_node import report_node
from langgraph.graph import StateGraph, END

def create_graph():
    workflow = StateGraph(ResearchState)

    workflow.add_node("planner", planning_node)
    workflow.add_node("data_gathering", data_gathering_node)
    workflow.add_node("analysis", analysis_node)
    workflow.add_node("report", report_node)

    workflow.set_entry_point("planner")
    workflow.add_edge("planner", "data_gathering")
    workflow.add_edge("data_gathering", "analysis")
    workflow.add_edge("analysis", "report")
    workflow.add_edge("report", END)

    app = workflow.compile()
    return app
