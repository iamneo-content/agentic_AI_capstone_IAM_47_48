class QueryClassifierAgent:
    def classify(self, query: str) -> str:
        print(f"CLASSIFIER: Classifying query: '{query}'")
        return "general_query"
