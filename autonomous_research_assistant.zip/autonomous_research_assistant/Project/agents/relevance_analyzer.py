class RelevanceAnalyzerAgent:
    def analyze(self, query: str, results: list) -> list:
        print("RELEVANCE ANALYZER: Analyzing relevance...")
        return results
