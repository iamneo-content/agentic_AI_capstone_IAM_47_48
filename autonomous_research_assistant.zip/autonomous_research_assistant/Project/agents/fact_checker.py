class FactCheckerAgent:
    def check(self, claims: list) -> bool:
        print("FACT CHECKER: Checking facts...")
        return True
