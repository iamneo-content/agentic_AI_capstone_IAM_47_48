class ResearchPlannerAgent:
    def plan(self, research_goal: str) -> list[str]:
        print(f"RESEARCH PLANNER: Planning research for goal: '{research_goal}'")
        return ["step 1", "step 2", "step 3"]
