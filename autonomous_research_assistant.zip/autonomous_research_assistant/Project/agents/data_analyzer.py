class DataAnalyzerAgent:
    def analyze(self, data: list) -> str:
        print("ANALYZER: Analyzing data...")
        return "Analysis complete."
