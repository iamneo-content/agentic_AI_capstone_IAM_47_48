class ResultValidatorAgent:
    def validate(self, results: list) -> bool:
        print("VALIDATOR: Validating results...")
        return True
