class SourceEvaluatorAgent:
    def evaluate(self, sources: list) -> list:
        print("SOURCE EVALUATOR: Evaluating sources...")
        return sources
