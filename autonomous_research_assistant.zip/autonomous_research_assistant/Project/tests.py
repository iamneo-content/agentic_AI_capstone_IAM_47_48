import pytest
from unittest.mock import Mock, patch, MagicMock
from state import ResearchState
from agents.planner import PlannerAgent
from agents.research_agent import ResearchAgent
from services.llm_service import LLMService
from services.web_search_service import WebSearchService
from nodes.planning_node import planning_node
from nodes.data_gathering_node import data_gathering_node
from nodes.analysis_node import analysis_node
from nodes.report_node import report_node
from graph import create_graph


class TestResearchState:
    """Test cases for ResearchState"""

    def test_state_initialization_empty(self):
        """Test 1: Verify empty state initialization"""
        state = ResearchState()
        assert state.get('original_query') is None
        assert state.get('search_queries') is None
        assert state.get('search_results') is None
        assert state.get('research_summary') is None
        assert state.get('error') is None

    def test_state_with_query(self):
        """Test 2: Verify state initialization with query"""
        state = ResearchState(original_query="test query")
        assert state['original_query'] == "test query"
        assert state.get('search_queries') is None


class TestLLMService:
    """Test cases for LLMService"""

    @patch('services.llm_service.ChatGoogleGenerativeAI')
    @patch.dict('os.environ', {'GOOGLE_API_KEY': 'test_key'})
    def test_llm_service_initialization(self, mock_llm):
        """Test 3: Verify LLMService initializes correctly with API key"""
        service = LLMService()
        assert service.llm is not None
        mock_llm.assert_called_once()

    @patch.dict('os.environ', {}, clear=True)
    def test_llm_service_missing_api_key(self):
        """Test 4: Verify LLMService raises error without API key"""
        with pytest.raises(ValueError, match="GOOGLE_API_KEY not found"):
            LLMService()

    @patch('services.llm_service.ChatGoogleGenerativeAI')
    @patch.dict('os.environ', {'GOOGLE_API_KEY': 'test_key'})
    def test_llm_service_invoke(self, mock_llm):
        """Test 5: Verify LLMService invokes correctly"""
        mock_response = Mock()
        mock_response.content = "Test response"
        mock_llm.return_value.invoke.return_value = mock_response

        service = LLMService()
        result = service.invoke("test prompt")

        assert result == "Test response"
        service.llm.invoke.assert_called_once_with("test prompt")


class TestWebSearchService:
    """Test cases for WebSearchService"""

    @patch('services.web_search_service.GoogleSearch')
    @patch.dict('os.environ', {'SERPAPI_API_KEY': 'test_key'})
    def test_web_search_success(self, mock_search):
        """Test 6: Verify WebSearchService returns results successfully"""
        mock_search.return_value.get_dict.return_value = {
            'organic_results': [
                {'link': 'http://example.com', 'snippet': 'Example snippet'}
            ]
        }

        service = WebSearchService()
        results = service.search("test query")

        assert len(results) == 1
        assert results[0]['url'] == 'http://example.com'
        assert results[0]['content'] == 'Example snippet'

    @patch.dict('os.environ', {}, clear=True)
    def test_web_search_missing_api_key(self):
        """Test 7: Verify WebSearchService handles missing API key"""
        service = WebSearchService()
        results = service.search("test query")
        assert results == []

    @patch('services.web_search_service.GoogleSearch')
    @patch.dict('os.environ', {'SERPAPI_API_KEY': 'test_key'})
    def test_web_search_no_results(self, mock_search):
        """Test 8: Verify WebSearchService handles empty results"""
        mock_search.return_value.get_dict.return_value = {}

        service = WebSearchService()
        results = service.search("test query")

        assert results == []


class TestPlannerAgent:
    """Test cases for PlannerAgent"""

    @patch('agents.planner.LLMService')
    def test_planner_generates_queries(self, mock_llm_service):
        """Test 9: Verify PlannerAgent generates search queries"""
        mock_service = Mock()
        mock_service.invoke.return_value = "query 1\nquery 2\nquery 3"
        mock_llm_service.return_value = mock_service

        planner = PlannerAgent()
        queries = planner.plan("test topic")

        assert len(queries) == 3
        assert "query 1" in queries
        assert "query 2" in queries
        assert "query 3" in queries

    @patch('agents.planner.LLMService')
    def test_planner_handles_empty_lines(self, mock_llm_service):
        """Test 10: Verify PlannerAgent filters empty lines"""
        mock_service = Mock()
        mock_service.invoke.return_value = "query 1\n\nquery 2\n\n"
        mock_llm_service.return_value = mock_service

        planner = PlannerAgent()
        queries = planner.plan("test topic")

        assert len(queries) == 2
        assert "" not in queries


class TestResearchAgent:
    """Test cases for ResearchAgent"""

    @patch('agents.research_agent.WebSearchService')
    def test_research_agent_returns_results(self, mock_search_service):
        """Test 11: Verify ResearchAgent returns search results"""
        mock_service = Mock()
        mock_service.search.return_value = [
            {'url': 'http://test.com', 'content': 'Test content'}
        ]
        mock_search_service.return_value = mock_service

        agent = ResearchAgent()
        results = agent.research("test query")

        assert len(results) == 1
        assert results[0]['url'] == 'http://test.com'


class TestNodes:
    """Test cases for workflow nodes"""

    @patch('nodes.planning_node.PlannerAgent')
    def test_planning_node(self, mock_planner):
        """Test 12: Verify planning_node processes state correctly"""
        mock_agent = Mock()
        mock_agent.plan.return_value = ["query 1", "query 2"]
        mock_planner.return_value = mock_agent

        state = {"original_query": "test query"}
        result = planning_node(state)

        assert "search_queries" in result
        assert len(result["search_queries"]) == 2

    @patch('nodes.data_gathering_node.ResearchAgent')
    def test_data_gathering_node(self, mock_researcher):
        """Test 13: Verify data_gathering_node collects results"""
        mock_agent = Mock()
        mock_agent.research.return_value = [
            {'url': 'http://test.com', 'content': 'Test'}
        ]
        mock_researcher.return_value = mock_agent

        state = {"search_queries": ["query 1", "query 2"]}
        result = data_gathering_node(state)

        assert "search_results" in result
        assert len(result["search_results"]) == 2

    @patch('nodes.analysis_node.LLMService')
    def test_analysis_node(self, mock_llm_service):
        """Test 14: Verify analysis_node generates summary"""
        mock_service = Mock()
        mock_service.invoke.return_value = "Test summary"
        mock_llm_service.return_value = mock_service

        state = {
            "original_query": "test",
            "search_results": [
                {'url': 'http://test.com', 'content': 'Content'}
            ]
        }
        result = analysis_node(state)

        assert "research_summary" in result
        assert result["research_summary"] == "Test summary"


class TestGraphIntegration:
    """Test cases for graph workflow"""

    def test_create_graph(self):
        """Test 15: Verify graph creation and structure"""
        graph = create_graph()

        assert graph is not None
        # Verify the graph is compiled and ready to use
        assert hasattr(graph, 'invoke')


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
