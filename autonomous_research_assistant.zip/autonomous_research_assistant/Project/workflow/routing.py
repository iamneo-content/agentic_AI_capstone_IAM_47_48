from ..state import ResearchState

def route_query(state: ResearchState) -> str:
    """
    A placeholder function to decide which node to go to next.
    """
    print("ROUTING: Deciding next step...")

    if not state.search_queries:
        return "planner"
    elif not state.search_results:
        return "data_gathering"
    elif not state.research_summary:
        return "analysis"
    else:
        return "report"
